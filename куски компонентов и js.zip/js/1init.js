var mySwiper5= {};
function swiper5Start(slidesPerView)
{
    if (slidesPerView){

     mySwiper5 = new Swiper('#swiper-5 .swiper-container', {
        slidesPerView: slidesPerView,
        spaceBetween: 10,
        navigation: {
            nextEl: '#swiper-5 .swiper-button-next',
            prevEl: '#swiper-5 .swiper-button-prev',
        },
    });
 }
 else{


    mySwiper5 = new Swiper('#swiper-5 .swiper-container', {
        slidesPerView: 10,
        spaceBetween: 30,
        navigation: {
            nextEl: '#swiper-5 .swiper-button-next',
            prevEl: '#swiper-5 .swiper-button-prev',
        },
        breakpoints: {
            576: {
                slidesPerView: 3,
                spaceBetween: 5
            },
            768: {
                slidesPerView: 5,
                spaceBetween: 5
            },
            992: {
                slidesPerView: 8,
                spaceBetween: 5
            },
            1200: {
                slidesPerView: 10,
                spaceBetween: 5
            },
        }
    });
}

var to5 = 0;
$('.v2 .block-7-1-1').each(function(i, el) {
    if ($(el).hasClass('active')) to5 = i;
});
mySwiper5.slideTo(to5)
}
$(function() {
    if ($("#swiper-2").length > 0) {
        var mySwiper2 = new Swiper('#swiper-2 .swiper-container', {
            slidesPerView: 5,
            spaceBetween: 30,
            navigation: {
                nextEl: '#swiper-2 .swiper-button-next',
                prevEl: '#swiper-2 .swiper-button-prev',
            },
            breakpoints: {
                576: {
                    slidesPerView: 1,
                    spaceBetween: 5
                },
                768: {
                    slidesPerView: 2,
                    spaceBetween: 5
                },
                992: {
                    slidesPerView: 3,
                    spaceBetween: 5
                },
                1248: {
                    slidesPerView: 4,
                    spaceBetween: 5
                },
            }
        });
    }
    if ($("#swiper-3").length > 0) {
        var mySwiper3 = new Swiper('#swiper-3 .swiper-container', {
            slidesPerView: 5,
            spaceBetween: 30,
            navigation: {
                nextEl: '#swiper-3 .swiper-button-next',
                prevEl: '#swiper-3 .swiper-button-prev',
            },
            breakpoints: {
                576: {
                    slidesPerView: 1,
                    spaceBetween: 5
                },
                768: {
                    slidesPerView: 2,
                    spaceBetween: 5
                },
                992: {
                    slidesPerView: 3,
                    spaceBetween: 5
                },
                1200: {
                    slidesPerView: 5,
                    spaceBetween: 5
                },
            }
        });
    }
    $('#basket').on('shown.bs.modal', function() {
        var mySwiper4 = new Swiper('#swiper-4 .swiper-container', {
            slidesPerView: 5,
            spaceBetween: 30,
            navigation: {
                nextEl: '#swiper-4 .swiper-button-next',
                prevEl: '#swiper-4 .swiper-button-prev',
            },
            breakpoints: {
                576: {
                    slidesPerView: 2,
                    spaceBetween: 5
                },
                768: {
                    slidesPerView: 2,
                    spaceBetween: 5
                },
                992: {
                    slidesPerView: 3,
                    spaceBetween: 5
                },
                1200: {
                    slidesPerView: 5,
                    spaceBetween: 5
                },
            }
        });
        var to4 = 0;
        $('.v1 .block-7-1-1').each(function(i, el) {
            if ($(el).hasClass('active')) to4 = i;
        });
        mySwiper4.slideTo(to4);
    })

    if ($("#swiper-5").length > 0) {
        swiper5Start();
    }
    if ($("#swiper-6").length > 0) {
        var mySwiper6 = new Swiper('#swiper-6 .swiper-container', {
            slidesPerView: 2,
            spaceBetween: 5,
            navigation: {
                nextEl: '#swiper-6 .swiper-button-next',
                prevEl: '#swiper-6 .swiper-button-prev',
            },
            /*
                    breakpoints: {

                        576: {
                            slidesPerView:3,
                            spaceBetween: 5
                        },
             
                        768: { 
                            slidesPerView: 5,
                            spaceBetween: 5
                        }, 
                        992: {
                            slidesPerView: 8 ,
                            spaceBetween: 5
                        },
                        1200: {
                            slidesPerView: 10,
                            spaceBetween: 5
                        },

                    }*/
                });
    }
    $('.tab').on('click', function() {
        $('body,html').animate({
            scrollTop: 0
        }, 200);
    });
    var w = ($(window).width() - $('.container').eq(0).width()) / 2 + 'px';
    $('.block-filter.fixed:not(.open)').css({
        'left': parseInt(w) - 260 + "px"
    });
    $('.block-filter-hide.fixed:not(.open)').css({
        'width': w
    });
    
    $(window).resize(function() {

        var w = ($(window).width() - $('.container').eq(0).width()) / 2 + 'px';
        
        $('.block-filter-hide, .block-filter-fade, .block-filter.fixed').css({'height': $(window).height()})

        $('.block-filter.fixed:not(.open)').css({
            'left': parseInt(w) - 260 + "px"
        });
        $('.block-filter-hide.fixed:not(.open)').css({
            'width': w
        });

        if ($('.navbar-expand-lg .navbar-collapse').hasClass('open')) {
            $('.navbar-expand-lg .navbar-collapse').css({
                'left': w
            });
            $('.mobile-menu-hide').css({
                'width': w
            });
        }
    });
    $('.mobile-menu-fade').on('click', function() {
        $('.navbar-toggler').trigger('click');
    });
    $('.navbar-toggler').on('click', function() {
        if ($('.block-filter').hasClass('open')) {
            $('.block-filter-btn').trigger('click');
        }
        $('.navbar-expand-lg .navbar-collapse').toggleClass('open');
        if ($('.navbar-expand-lg .navbar-collapse').hasClass('open')) {
            var w = ($(window).width() - $('.container').eq(0).width() ) / 2 + 'px';
            $('.mobile-menu-hide').css({
                'visibility': 'visible',
                'display': 'block',
                'width': w
            }).toggleClass('open');
            $('.mobile-menu-fade').css({
                'width': "calc(100% - " + w + ")"
            }).toggleClass('open');
            setTimeout(function() {
                $('.navbar-expand-lg .navbar-collapse').animate({
                    'left': w
                }, 300);
            }, 100);
        } else {
            $('.navbar-expand-lg .navbar-collapse').animate({
                'left': '-100%'
            }, 200, '', function() {
                $('.mobile-menu-fade').toggleClass('open');
                $('.mobile-menu-hide').toggleClass('open');
            });
        }
    });
    

    $('.block-filter-fade').on('click', function() {
        $('.block-filter-btn').trigger('click');
    });


    var blockFilterBtn = 0;
    $('.block-filter-btn').on('click', function() {

        
        if (blockFilterBtn != 0) return;
        blockFilterBtn = 1;

        if ($('.navbar-expand-lg .navbar-collapse').hasClass('open')) {
            $('.navbar-toggler').trigger('click');
        }


        var w = ($(window).width() - $('.container').eq(0).width() ) / 2 + 'px';
        
        $('.block-filter').toggleClass('open');

        if ($('.block-filter').hasClass('open')) {
            $('.block-filter-hide').css({
                'visibility': 'visible',
                'display': 'block',
                'width': w
            }).toggleClass('open');
            $('.block-filter-fade').css({
                'width': "calc(100% - " + w + ")"
            }).toggleClass('open');
            setTimeout(function() {
                $('.block-filter').animate({
                    'left': w
                }, 300);
            }, 100);

        } else {

            $('.block-filter').animate({
                'left': parseInt(w) - 260 + "px"
            }, 200, '', function() {
                $('.block-filter-fade').toggleClass('open');
                $('.block-filter-hide').toggleClass('open');
            });
        }
        blockFilterBtn = 0;
        
    });
    
    $(window).scroll(function() {

        // Если отступ сверху больше 50px то показываем кнопку "Наверх"
        if ($(this).scrollTop() > 50) {
            $('#button-up').fadeIn();
        } else {
            $('#button-up').fadeOut();
        }

        if ($(this).scrollTop() > 135) {

            if (!$('.block-filter').hasClass('open'))
            {
                $('.block-filter,.block-filter-hide').hide();
                $('.block-filter-hide').addClass('fixed');
                $('.block-filter').addClass('fixed');
                $(window).resize();
                $('.block-filter,.block-filter-hide').show();
                mySwiper5.destroy();
                swiper5Start(2);
            }

        } else {
            mySwiper5.destroy();
            swiper5Start();
            if ($('.block-filter').hasClass('open')) {

                $('.block-filter-hide, .block-filter, .block-filter-fade').removeClass('open')
                
            }

            $('.block-filter,.block-filter-hide').css({'left':'0'});
            $('.block-filter-hide, .block-filter, .block-filter-fade').removeClass('fixed')

            
        }
    });
    $('#button-up').click(function() {
        $('body,html').animate({
            scrollTop: 0
        }, 500);
        return false;
    });
})