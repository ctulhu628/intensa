
$(function() {

    $('.sostavlistkopleks .izm').on('click', function() {
      
        $('.loading-vspl').toggleClass('open');
        
        var cat = $(this).attr('cat');
        var catname = $(this).attr('catname');
        var idr = $(this).attr('idr');
        var index = $(this).attr('index');
        var id_kompleks = $(this).attr('id_kompleks');
        var day = $(this).attr('day');
        var max_price = $(this).attr('max_price');
        
        $.post("/ajax/ajax_function.php", {
            cat: cat,
            catname: catname,
            idr: idr,
            index: index,
            id_kompleks: id_kompleks,
            day: day,
            max_price: max_price,
            action: 'kompleks_izm'
        }, function onAjaxSuccess(data) {
            
            $('#kompleks-izm .modal-body').html(data);
            $('#kompleks-izm').modal('toggle')
            $('.loading-vspl').toggleClass('open');

            	$('.modal.show .lazy').lazy({
                    effect: "fadeIn",
                    effectTime: 200,
                    threshold: 0,
                    appendScroll: $('.modal.show')
                });
        });
    });

    $(document).on('click','.kopmsostav .minus', function() {
        var ob = $(this).siblings('.form-group').children('.qn'),
        qn = parseInt(ob.val());
        if (qn > 1)
        {
            ob.val(--qn);
        }
    })
    
    $(document).on('click','.kopmsostav .plus', function() {
        var ob = $(this).siblings('.form-group').children('.qn'),
        qn = parseInt(ob.val());
        
        ob.val(++qn);
        
    })
    
    $('.summaryy').on('click', '[name="ORDER_CONFIRM_BUTTON"]', function(e) {
        e.preventDefault();
        
        $('.loading-vspl').toggleClass('open');
        
        var msg = $("#ORDER_FORM").serialize();
        var paymaster = $("#paymaster_system").val();
        $.ajax({
            type: "POST",
            url: "/ajax/add_order.php",
            data: msg,
            success: function(data) {

                var res = JSON.parse(data);
                
                if (res[0] && res[0] == 1 && res[1]) 
                {
                    if (paymaster != '' && res.payment_id) 
                    {
                        if (res.user_id == -1) console.log(paymaster + "&LMI_PAYMENT_NO=" + res.payment_id + "&LMI_PAYMENT_DESC=" + res.work_company + ". №" + res[1] + "&R_ORDER_ID=" + res[1]);
                        else window.location.href = paymaster + "&LMI_PAYMENT_NO=" + res.payment_id + "&LMI_PAYMENT_DESC=" + res.work_company + ". №" + res[1] + "&R_ORDER_ID=" + res[1];
                    } 
                    else 
                    {
                        window.location.href = "/personal/order/success/?orders=" + res[1];
                    }
                } 
                else if(res['error_data'] )
                {
                    window.location.href = "/";
                }
                else {
                    alert("Возникла ошибка!");
                }
                
                $('.loading-vspl').toggleClass('open');

            },
            error: function(xhr, str) {
                alert("Возникла ошибка!");
            }
        });

        $('.bx_ordercart_order_pay_center').on('click', '.order_button_cart.disabledclass', function() {
            return false;
        })
        return false;
    })

    $(document).on('click', '.summaryy .quantity .plus', function() {


        $('.loading-vspl').toggleClass('open');

        
        var input = $(this).parent('.quantity').find('input'),
        a = input.val(),
        garnir_id = input.attr('garnir_id'),
        sum = Number(a) + 1,
        limit = $('#limit').val(),
        priceOrderDat = $(this).attr('priceOrderDat'),
        stop = 0,
        url = '/ajax/cart_function.php',
        tpl = false;

        if ($('#small-basket-content').length > 0)
            tpl = 'popup';

        if (limit > 0) 
        {

            var timesec = $(this).attr('timesec'),
            datasecsumm = parseFloat($('.summordday' + timesec + ' span').text()) + parseFloat(priceOrderDat),
            sumca = $(this).attr('sumca'),
            sumcaplus = datasecsumm + parseFloat(sumca);
            
            if (sumcaplus > limit) 
            {
             $('.loading-vspl').toggleClass('open');
             stop = 1;
         }
     }

     if (stop == 0) 
     {
        input.val(sum);
        $.post(url, {
            action: 'edit_quantity',
            id: $(this).attr('id_edit'),
            garnir_id: garnir_id,
            qn: sum,
            tpl: tpl

        }, 
        function onAjaxSuccess(data) {
         $('.summaryy').html(data);
         if (tpl)
         {
            $('.dicart_item').removeClass('active');
            $('.dicart_item[order = "'+$('.action-basket.active').data('date')+'"]').addClass('active');
        }
        $('.loading-vspl').toggleClass('open');

    })
    }
});

    $(document).on('click', '.summaryy .quantity .minus', function() {

        var input = $(this).parent('.quantity').find('input'),
        a = input.val(),
        garnir_id = input.attr('garnir_id'),
        url = '/ajax/cart_function.php',
        tpl = false;

        if ($('#small-basket-content').length > 0)
            tpl = 'popup';

        if (Number(a) != 1) 
        {

            $('.loading-vspl').toggleClass('open');
            var sum = Number(a) - 1;
            $(this).siblings('input').val(sum);
            $.post(url, {
                action: 'edit_quantity',
                id: $(this).attr('id_edit'),
                garnir_id: garnir_id,
                qn: sum,
                tpl: tpl
            }, 
            function onAjaxSuccess(data) {

                $('.summaryy').html(data);
                $('.loading-vspl').toggleClass('open');
            })
        }

    });

    $(document).on('click', '.summaryy .del', function() {
        $('.loading-vspl').toggleClass('open');

        var iddel = $(this).attr('id_or'),
        garnir_id = $(this).attr('garnir_id'),
        garnir = $(this).attr('garnir'),
        url = '/ajax/cart_function.php',
        tpl = false;

        if ($('#small-basket-content').length > 0)
            tpl = 'popup';

        $.post("/ajax/cart_function.php", 
        {
            id: iddel,
            action: 'delete',
            garnir_id: garnir_id,
            tpl: tpl
        }, onAjaxSuccess)

        function onAjaxSuccess(data) 
        {
            $('.summaryy').html(" "+data);
            $('.loading-vspl').toggleClass('open');
            
        }
    })


    if ($('#small-basket-content').length > 0)
    {
       small_basket();
   }

   $('.action-basket').on('click', function(e){
    e.preventDefault(); 

    var data = $(this).data('date');

    $('.loading-vspl').toggleClass('open');
    $('.action-basket').removeClass('active');
    $(this).addClass('active');

    $('.dicart_item').removeClass('active');
    if ($('.dicart_item[order = "'+data+'"]'))
    {
        $('.dicart_item[order = "'+data+'"]').addClass('active');
    }
    else{

    }
    $('.loading-vspl').toggleClass('open');

});

   $('.action-catalog').on('click', function(e){
    e.preventDefault(); 

    $('.loading-vspl').toggleClass('open');

    $('.action-catalog').removeClass('active');
    $(this).addClass('active');

    var data = {}, 
    data = $(this).data('date'),
    action = 'catalog',
    id = $(this).data('id');

    $('.basket .top .h2').html('ЗАКАЗ НА '+data[2]);

    $('.ui-tabs-nav li').eq(id).children('a').trigger('click');

    $.ajax({
        url: '/ajax/catalog.php',
        method: 'POST',
            //parameters: { evalJS: true},
            data: {
                action: action,
                data: data,
            },
            //dataType: 'json',
            beforeSend: function(res){

            }
            ,
            success: function(res)
            {
                document.getElementById('catalog-ajax').innerHTML = '';
                document.getElementById('catalog-ajax').innerHTML = res;

                $('.lazy').lazy({
                    effect: "fadeIn",
                    effectTime: 200,
                    threshold: 0
                });

                $.getScript('/bitrix/templates/LunchTime/js/catalog.js');
                $.getScript('/bitrix/templates/LunchTime/js/catalog-1.js');
                
                $('.loading-vspl').toggleClass('open');

                
                
            }
        })



});

   $('#nav-kategoriya .jelect-option').click(function(e){

    var href = $(this).data('cat'),
    offsetTop = href === "#" ? 0 : ( $(href).offset().top - $('header').height() );

    $('html, body').stop().animate({ 
        scrollTop: offsetTop
    }, 850);

    e.preventDefault();
})

   $('.lazy').lazy({
    effect: "fadeIn",
    effectTime: 200,
    threshold: 0
});

   $('body').on('click','#reg_submit',function(e) 
   {
    e.preventDefault();
    var company = $('#company').val();
    var name = $('#name').val();
    var code = $('#code').val();
    var phone = $('#phone').val();
    var email = $('#email').val();
    var pass = $('#pass').val();
    var confirm_pass = $('#confirm_pass').val();
    var adress = $('#adress').val();
    var orderstr = $('#orderstr').val();
    var error = [0];
    if (name == '' || name.length < 2) {
        $('#name').addClass('inp-error');
        error.push(1);
    } else {
        $('#name').removeClass('inp-error');
        error.push(0);
    }
    if (email == '' || email.length < 2) {
        $('#email').addClass('inp-error');
        error.push(1);
    } else {
        $('#email').removeClass('inp-error');
        error.push(0);
    }
    if (company == '' || company.length < 2) {
        $('#company').addClass('inp-error');
        error.push(1);
    } else {
        $('#company').removeClass('inp-error');
        error.push(0);
    }
    if (phone == '' || phone.length < 7) {
        $('#phone').addClass('inp-error');
        error.push(1);
    } else {
        $('#phone').removeClass('inp-error');
        error.push(0);
    }
    if (code == '' || code.length < 3) {
        $('#code').addClass('inp-error');
        error.push(1);
    } else {
        $('#code').removeClass('inp-error');
        error.push(0);
    }
    if (adress == '' || adress.length < 2) {
        $('#adress').addClass('inp-error');
        error.push(1);
    } else {
        $('#adress').removeClass('inp-error');
        error.push(0);
    }
    if (confirm_pass == '' || confirm_pass.length < 2) {
        $('#confirm_pass').addClass('inp-error');
        error.push(1);
    } else {
        $('#confirm_pass').removeClass('inp-error');
        error.push(0);
    }
    var errorpasskol = 0;
    var errorpass_confirm = 0;
    if (pass == '' || pass.length < 6) {
        $('#pass').addClass('inp-error');
        error.push(1);
        errorpasskol = 1;
    } else {
        $('#pass').removeClass('inp-error');
        error.push(0);
        errorpasskol = 0;
        if (pass != confirm_pass) {
            errorpass_confirm = 1;
        }
    }
    var err = 0;
    for (i in error) {
        if (error[i] == 1) {
            err = 1;
        }
    }
    var registration_politika = $('#registration-politika').is(':checked');

    if (err == 0 && errorpasskol == 0 && errorpass_confirm == 0) {
        $('#error-reg').css('display', 'none')
        $('#err2').css('display', 'none');
        $('#err3').css('display', 'none');
        $('#err4').css('display', 'none');
        $('#err5').css('display', 'none');
        $('.reg-vspl .otvet_script_reg').html('');
        $.ajax({
            url: '/ajax/function.php',
            type: 'post',
            data: '&registration_politika='+registration_politika+'&company=' + company + '&name=' + name + '&code=' + code + '&phone=' + phone + '&email=' + email + '&pass=' + pass + '&confirm_pass=' + confirm_pass + '&adress=' + adress + '&orderstr=' + orderstr + '&action=reg',
            success: function(data) {
                $('body').append(data);
                    /*if (!data) 
                    {
                    $('.reg-vspl .otvet_script_reg').html(data);
                    $('#registration  .registration-form').hide()
                    $('#registration .otvet_script_reg').html(data);
                    }
                    */
                }
            });
    }
    else
    {
        $('#error-reg').css('display', 'block');

        if (err == 1) {
            $('#err2').css('display', 'block');
        } else {
            $('#err2').css('display', 'none');
        }
        if (errorpasskol == 1) {
            $('#err3').css('display', 'block');
        } else {
            $('#err3').css('display', 'none');
        }
        if (errorpass_confirm == 1) {
            $('#err4').css('display', 'block');
        } else {
            $('#err4').css('display', 'none');
        }
    }

});


$('.modal').on('shown.bs.modal', function() { 

    var id = $(this).attr('id');
    $('.zvonokbot').html('');
    $('#error-reg, #error-reg div').hide();
    $('.modal').each(function(i,el){
        if ($(el).attr('id') != id)
        {
            $('#'+$(el).attr('id')+'.modal.show').trigger('click');
            $('body').addClass('modal-open');
            
        }

    });

});

$('form').on('submit',function(){

    if (!$(this).data('action')) return true;
    if ($(this).data('action') != 'auth') return true;

    var form =  $(this), dataForm = {}, action = $(this).data('action');

    form.find('input').each(function(i, el)
    {
        var name = $(el).attr('name');
        dataForm[name] = $(el).val();
    })

    $.ajax({
        url: '/ajax/function.php',
        method: 'POST',
        data: {
            action: action,
            data: dataForm,
        },
        dataType: 'json',
        beforeSend: function(data){

        },
        success: function(data)
        {

            if (data.status == 'error') 
            {

                form.prev('.zvonokbot').html('<p class="konsuccess alert alert-danger">' + data.msg + '</p>');

            }
            else
            {
                form.prev('.zvonokbot').html('<p class="konsuccess alert alert-success">' + data.msg + '</p>');
                form.trigger('reset');

                if (data.reload)
                {
                    setTimeout(function(){
                        window.location.reload();
                    }, data.reload)
                }
            }

            form.children('[name="NAME"]').val(data.service_val);

            if (dataForm.POPUP == 'N')
            {
                $(window).scrollTop(form.prevUntil('.konsuccess').offset().top - 54);
            }

        }

    });
    return false;


});

$('form').on('submit',function(e) {

    if (!$(this).data('action')) return true;
    if ($(this).data('action') != 'infoblock') return true;
    e.preventDefault()

    var form =  $(this), dataForm = {}, action = $(this).data('action');

    form.find('input, textarea, select').each(function(i, el)
    {

        if ($(el).attr('name'))
        {

            var name = $(el).attr('name'),
            type = $(el).attr('type'),
            val = $(el).val(),
            A = false;

            if (name.indexOf('_A') != -1)
            {

                A = true;
                name = name.replace('_A','');
                if (!dataForm[name])
                    dataForm[name] = {};

            }

            if (type == 'checkbox' || type == 'radio' )
            {

                if ($(el).is(":checked"))
                {

                    if (A)
                    {

                        dataForm[name][val] = val;

                    }
                    else
                    {
                        dataForm[name] = val;
                    }

                }
                else
                {

                    if (A)
                    {
                        if (!dataForm[name])
                            dataForm[name] = '';
                    }
                    else
                    {
                        dataForm[name]
                    }

                }

            }
            else
            {

                dataForm[name] = $(el).val();

            }
        }
    })

    $.ajax({
        url: '/ajax/function.php',
        method: 'POST',
        data: {
            action: action,
            data: dataForm,
        },
        dataType: 'json',
        beforeSend: function(data){

        },
        success: function(data)
        {

            if (data.status == 'service_error') {

                form.prev('.zvonokbot').html('<p class="konsuccess alert alert-danger">' + data.msg + ' <span id="timer_inp">3</span> секунды.</p>');
                setTimeout(timer,1000,form.prev('.zvonokbot'));

            }
            else if (data.status == 'error') {

                form.prev('.zvonokbot').html('<p class="konsuccess alert alert-danger">' + data.msg + '</p>');

            }
            else{


                form.prev('.zvonokbot').html('<p class="konsuccess alert alert-success">' + data.msg + '</p>');
                form.trigger('reset');

                if (data.reload)
                {
                    setTimeout(function(){
                        window.location.reload();
                    }, data.reload)
                }
            }

            form.children('[name="NAME"]').val(data.service_val);

            if (dataForm.POPUP == 'N')
            {
                $(window).scrollTop(form.prevUntil('.konsuccess').offset().top - 54);
            }

        }

    });

    return false;

});

var date = new Date();
var hour = date.getHours();
if (hour >= 17) {

    $('#clock').attr('style', 'display:none');
    $('.h8hour').attr('style', 'display:block');
    $('.h16hour').attr('style', 'display:none');

        //$('.header-bottom .header-bottom-center .phone div.text.h16').attr('style', 'opacity: 0.40;');
    }
    if (hour < 8) {

        $('#clock').attr('style', 'display:none');
        $('.h8hour').attr('style', 'display:block');
        $('.h16hour').attr('style', 'display:none');
        //$('.header-bottom .header-bottom-center .phone div.text.h16').attr('style', 'opacity: 1;');
    }

})



function timer(data)
{
    var obj=document.getElementById('timer_inp');
    obj.innerHTML--;

    if(obj.innerHTML==0){
        setTimeout(function(){
            data.html('');
        },1000);
    }
    else{
        setTimeout(timer,1000);
    }
}


function small_basket(){

 $.post("/include/sale_order_ajax-popup.php", {

 }, 
 function onAjaxSuccess(data) {
    $('#small-basket-content').html(data);
    $('.small-basket-info').text($('.item-ord').length)
})
}