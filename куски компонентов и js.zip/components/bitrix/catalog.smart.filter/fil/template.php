<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();
$this->setFrameMode(true);
?>
<div class="catalog-filter">
	<form name="<?echo $arResult["FILTER_NAME"]."_form"?>" action="<?echo $arResult["FORM_ACTION"]?>" method="get" class="smartfilter">

		<?foreach($arResult["HIDDEN"] as $arItem){?>
			<input type="hidden" name="<?echo $arItem["CONTROL_NAME"]?>" id="<?echo $arItem["CONTROL_ID"]?>" value="<?echo $arItem["HTML_VALUE"]?>" />
			<?};?>


			<?foreach($arResult["ITEMS"] as $key=>$arItem)//prices
			{

				?>
					<div class='h2 subtitle'><?=$arItem['NAME']?>:</div>
					<ul class="blude-menu filter<?=$arItem['ID']?>">

						<?if($arItem['DISPLAY_TYPE']=='K'){

							foreach($arItem["VALUES"] as $val => $ar):

								?>
								<li>
									<input
									class="item"
									type="radio"
									value="<? echo $ar["HTML_VALUE_ALT"] ?>"
									name="<? echo $ar["CONTROL_NAME_ALT"] ?>"
									id="<? echo $ar["CONTROL_ID"] ?>"
									<? echo $ar["CHECKED"]? 'checked="checked"': '' ?>

									/>
									<label for="<? echo $ar["CONTROL_ID"] ?>"><span></span><?=$ar["VALUE"]?></label>
								</li>
							<? endforeach ?>
							<?
						}else
						{
							?>
								<?foreach($arItem["VALUES"] as $val => $ar):?>
								<?if ($ar["CONTROL_ID"]!='arrFilter1_1075_2493104223' 
									and $ar["CONTROL_ID"]!='arrFilter1_1075_4154333563' 
									and $ar["CONTROL_ID"]!='arrFilter1_1075_484857772' 
									and $ar["CONTROL_ID"]!='arrFilter1_1075_2060183001' 
									and $ar["CONTROL_ID"]!='arrFilter1_1075_3751768343' 
									and $ar["CONTROL_ID"]!='arrFilter1_1075_3946466013' 
									and $ar["CONTROL_ID"]!='arrFilter1_1075_1884125398' 
									and $ar["CONTROL_ID"]!='arrFilter1_1075_3746820392' 
									and $ar["CONTROL_ID"]!='arrFilter1_1075_3712764743' 
									and $ar["CONTROL_ID"]!='arrFilter1_1075_1207514384' 
									and $ar["CONTROL_ID"]!='arrFilter1_1075_2941559045' 
									and $ar["CONTROL_ID"]!='arrFilter1_1075_3716384135' 
									and $ar["CONTROL_ID"]!='arrFilter1_1075_1736062355' 
									and $ar["CONTROL_ID"]!='arrFilter1_1075_1002502540' 
									and $ar["CONTROL_ID"]!='arrFilter1_1075_1563601080'  
									and $ar["CONTROL_ID"]!='arrFilter1_1075_3868030403'  
									and $ar["CONTROL_ID"]!='arrFilter1_1075_545441675'  
									and $ar["CONTROL_ID"]!='arrFilter1_1075_1132797615'  
									and $ar["CONTROL_ID"]!='arrFilter1_1075_1044801142'  
									and $ar["VALUE"]!='') 
								{

									if($arItem['NAME']=='Ингредиенты')
									{
										$arFilter = Array("IBLOCK_ID"=>40, "ACTIVE"=>"Y", "PROPERTY_DNI"=>$GLOBALS['arrFilter1']["PROPERTY_DNI"], "PROPERTY_INGREDIENTY"=>$ar["VALUE"]);
										$res = CIBlockElement::GetList(Array("ID"=>"ASC"), $arFilter, false, Array(), array('ID','NAME'));
										$idpr = '';
										while($ob = $res->GetNextElement())
										{
											$arFields = $ob->GetFields();  
											$idpr = $arFields['ID'];
											break;
										}
										if ($idpr == ''){
											continue;
										}
									}
									$css = '';
									if ($arItem[ID] == 1083)
									{
										$css = "
											style='background-image:url(".$arResult['MOD']['TIP'][$ar['VALUE']]['ICO'].");background-color:".$arResult['MOD']['TIP'][$ar['VALUE']]['BG'].";'

										";
									}

									?>
									<li>
										<input
										class="item"
										type="checkbox"
										value="<? echo $ar["HTML_VALUE"] ?>"
										name="<? echo $ar["CONTROL_NAME"] ?>"
										id="<? echo $ar["CONTROL_ID"] ?>"
										<? echo $ar["CHECKED"]? 'checked="checked"': '' ?>

										/><label <?=$css?> for="<? echo $ar["CONTROL_ID"] ?>"><span></span><?=$ar["VALUE"]?> <?=($ar["VALUE"]=='Новинка')?'(-20%)':''?></label>
									</li>
									<?}
								endforeach ?>    	<?}?>

							</ul>

							<?if($arItem['ID']==1056){					?>
							</div>	
							<?}?>	
							<?}?>
							<input
							class="btn btn-themes"
							type="submit"
							id="set_filter"
							name="set_filter"
							value="<?=GetMessage("CT_BCSF_SET_FILTER")?>"
							/>
							<input
							class="btn btn-link"
							type="submit"
							id="del_filter"
							name="del_filter"
							value="Сбросить фильтр"
							/>
						</form>
					</div>
					<script>

						$( document ).ready(function() {
							$('.item').change(function() {
								$('.btn-themes').click();

							})
	//smart filter выводим 7 значений остальное по клику
	var ifl=1;
	$('.filter1080 li').each(function(){
		if (ifl==7){
			$(this).after('<div class="ezhe_ingridienty">Показать больше</div>');
			
		}
		if (ifl>7){
			$(this).addClass('fdnone');
		}
		ifl++;
	})
	$('.ezhe_ingridienty').click(function(){
		$(this).addClass('fdnone');
		$('.filter1080 li').removeClass('fdnone');
	})
});

</script>