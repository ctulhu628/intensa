<?
$MESS ['MENU_HORIZONT_MULTI_NAME'] = "Горизонтальное многоуровневое выпадающее меню";
$MESS ['MENU_HORIZONT_MULTI_DESC'] = "Горизонтальное многоуровневое выпадающее меню";
?>