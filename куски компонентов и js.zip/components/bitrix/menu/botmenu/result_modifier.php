<?

	/*
	CModule::IncludeModule("iblock");
	$arSelect = Array("ID", "IBLOCK_ID", "NAME","PROPERTY_DNI");//IBLOCK_ID и ID обязательно должны быть указаны, см. описание arSelectFields выше
	$tree = false;
	$four = true;



	$d = strtotime("this monday", mktime()+604800);
	for ($i = 0, $j = 7; $i < $j; $i++)
	{
		
		$s = date("d", $d+24*60*60*$i).".".date("m", $d+24*60*60*$i);
		$week[] = $s;
		$week_Y[] = $s.".".date("Y", $d+24*60*60*$i);
	}
	

	$arFilter = Array("IBLOCK_ID" => IntVal(40),array("LOGIC" => "OR","PROPERTY_DNI" => array_merge($week,$week_Y)));
	$res = CIBlockElement::GetList(Array(), $arFilter, false, array('nTopcount' => 1), $arSelect);
	while($ob = $res->Fetch())
	{
		$tree = true;
	}


	$week = array();
	$week_Y = array();

	$d = strtotime("this monday", mktime()+604800*2);
	for ($i = 0, $j = 7; $i < $j; $i++)
	{
		
		$s = date("d", $d+24*60*60*$i).".".date("m", $d+24*60*60*$i);
		$week[] = $s;
		$week_Y[] = $s.".".date("Y", $d+24*60*60*$i);
	}
	
	if ($tree) 
	{
		$arFilter = Array("IBLOCK_ID" => IntVal(40),array("LOGIC" => "OR","PROPERTY_DNI" => array_merge($week,$week_Y)));
		$res = CIBlockElement::GetList(Array(), $arFilter, false, array('nTopcount' => 1), $arSelect);
		while($ob = $res->Fetch())
		{
			$four = true;
		}
	
		$p = $APPLICATION->GetCurPage();
		foreach ($arResult as $key => $value) 
		{
			$tmp[] = $value;

			if ($value['TEXT'] == 'Меню на следующую неделю')
			{
				if ($p != '/catalog/tretya_nedelya/')
					$value["SELECTED"] = false;
				else{
					$value["SELECTED"] = true;
				}
				$value['TEXT'] =  'Меню на третью неделю';
				$value['LINK'] = "/catalog/tretya_nedelya/";
				$tmp[] = $value;
				if ($four) 
				{
					
					if ($p != '/catalog/chetvyortaia_nedelya/')
						$value["SELECTED"] = false;
					else{
						$value["SELECTED"] = true;
					}
					$value['TEXT'] =  'Меню на четвертую неделю';
					$value['LINK'] = "/catalog/chetvyortaia_nedelya/";
					$tmp[] = $value;
				}
			}
		}
	}


	if($tmp)
		$arResult=$tmp;
	*/
?>