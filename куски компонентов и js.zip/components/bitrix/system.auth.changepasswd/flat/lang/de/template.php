<?
$MESS["AUTH_AUTH"] = "Anmeldung";
$MESS["AUTH_CHANGE"] = "Passwort ändern";
$MESS["AUTH_CHECKWORD"] = "Kontrollmeldung";
$MESS["AUTH_LOGIN"] = "Login";
$MESS["AUTH_NEW_PASSWORD_REQ"] = "Neues Passwort";
$MESS["AUTH_CHANGE_PASSWORD"] = "Passwort ändern";
$MESS["AUTH_NEW_PASSWORD_CONFIRM"] = "Passwortbestätigung";
$MESS["AUTH_SECURE_NOTE"] = "Das Passwort wird verschlüsselt, bevor es versendet wird. So wird das Passwort während der Übertragung nicht offen angezeigt.";
$MESS["system_auth_captcha"] = "Geben Sie die Symbole ein, die Sie auf dem Bild sehen:";
?>