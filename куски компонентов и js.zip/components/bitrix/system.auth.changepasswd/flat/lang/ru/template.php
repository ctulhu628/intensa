<?
$MESS ['AUTH_CHANGE_PASSWORD'] = "Смена пароля";
$MESS ['AUTH_LOGIN'] = "Логин";
$MESS ['AUTH_CHECKWORD'] = "Контрольная строка";
$MESS ['AUTH_NEW_PASSWORD_CONFIRM'] = "Подтверждение пароля";
$MESS ['AUTH_CHANGE'] = "Изменить пароль";
$MESS ['AUTH_AUTH'] = "Авторизация";
$MESS ['AUTH_NEW_PASSWORD_REQ'] = "Новый пароль";
$MESS["AUTH_SECURE_NOTE"]="Перед отправкой формы пароль будет зашифрован в браузере. Это позволит избежать передачи пароля в открытом виде.";
$MESS["system_auth_captcha"] = "Введите символы с картинки";
?>