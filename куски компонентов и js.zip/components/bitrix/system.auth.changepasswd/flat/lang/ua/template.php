<?
$MESS["AUTH_AUTH"] = "Авторизація";
$MESS["AUTH_CHANGE_PASSWORD"] = "Зміна паролю";
$MESS["AUTH_CHANGE"] = "Змінити пароль";
$MESS["AUTH_CHECKWORD"] = "Контрольний рядок";
$MESS["AUTH_LOGIN"] = "Логін";
$MESS["AUTH_NEW_PASSWORD_REQ"] = "Новий пароль";
$MESS["AUTH_NEW_PASSWORD_CONFIRM"] = "Підтвердження паролю";
$MESS["AUTH_SECURE_NOTE"] = "Перед відправкою форми пароль буде зашифрований в браузері. Це дозволить уникнути передачі пароля у відкритому вигляді.";
$MESS["system_auth_captcha"] = "Введіть символи з картинки";
?>