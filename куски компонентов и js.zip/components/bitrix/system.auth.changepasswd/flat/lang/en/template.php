<?
$MESS["AUTH_CHANGE_PASSWORD"] = "Password changing";
$MESS["AUTH_LOGIN"] = "Login";
$MESS["AUTH_CHECKWORD"] = "Check string";
$MESS["AUTH_NEW_PASSWORD_CONFIRM"] = "Password Confirmation";
$MESS["AUTH_CHANGE"] = "Change password";
$MESS["AUTH_AUTH"] = "Authorization";
$MESS["AUTH_NEW_PASSWORD_REQ"] = "New Password";
$MESS["AUTH_SECURE_NOTE"] = "The password will be encrypted before it is sent. This will prevent the password from appearing in open form over data transmission channels.";
$MESS["system_auth_captcha"] = "Enter the characters you see on the picture";
?>