<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();?>


<?
if ($arResult['SHOW_ERRORS'] == 'Y' && $arResult['ERROR'])
	ShowMessage($arResult['ERROR_MESSAGE']);
?>

<?if($arResult["FORM_TYPE"] == "login"){?>

<form name="system_auth_form<?=$arResult["RND"]?>" method="post" target="_top" action="<?=$arResult["AUTH_URL"]?>">
<?if($arResult["BACKURL"] <> ''):?>
	<input type="hidden" name="backurl" value="<?=$arResult["BACKURL"]?>" />
<?endif?>
<?foreach ($arResult["POST"] as $key => $value):?>
	<input type="hidden" name="<?=$key?>" value="<?=$value?>" />
<?endforeach?>
	<input type="hidden" name="AUTH_FORM" value="Y" />
	<input type="hidden" name="TYPE" value="AUTH" />
	
			
			<input type="text" placeholder="Логин*" id="login" name="USER_LOGIN" value="<?=$arResult["USER_LOGIN"]?>"/>
		
			
			<br />
				<input type="password" placeholder="Пароль*" id="password" name="USER_PASSWORD" autocomplete="off"/>

			
			<p>* Поля для обязательного заполнения</p>
				
				<input type="submit" name="Login"  value="<?=GetMessage("AUTH_LOGIN_BUTTON")?>" />

		

	
	
	
</form>


<?}?>

