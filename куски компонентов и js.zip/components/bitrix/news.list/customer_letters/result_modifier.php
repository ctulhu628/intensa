<?
	foreach($arResult["ITEMS"] as $key => $arItem)
	{
		$img = CFile::ResizeImageGet($arItem["PREVIEW_PICTURE"], Array("width" => 569, "height" => 900),BX_RESIZE_IMAGE_PROPORTIONAL_ALT, false, false, false, 60);
		$arResult["ITEMS"][$key]['src'] = $img['src'];
		
	}
?>