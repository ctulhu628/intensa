<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();
/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */
/** @var CBitrixComponent $component */
$this->setFrameMode(true);

?>

<div class="customer_letters-list">
	<div class="block-1">
		
		<?
		$active = ' active';
		foreach($arResult["ITEMS"] as $key => $arItem)
		{
			?>
			<div class="block-1-1<?=$active;$active=''?>" id='tab<?=$arItem['ID']?>' data-eq="<?=++$key?>">
				<?=$arItem['NAME']?>
			</div>
			<?
		}

		?>

	</div>
	<div class="block-2">
		<div class="swiper-container">
			<!-- Additional required wrapper -->
			<div class="swiper-wrapper">

				<?
				foreach($arResult["ITEMS"] as $arItem)
				{

					$this->AddEditAction($arItem['ID'], $arItem['EDIT_LINK'], CIBlock::GetArrayByID($arItem["IBLOCK_ID"], "ELEMENT_EDIT"));
					$this->AddDeleteAction($arItem['ID'], $arItem['DELETE_LINK'], CIBlock::GetArrayByID($arItem["IBLOCK_ID"], "ELEMENT_DELETE"), array("CONFIRM" => GetMessage('CT_BNL_ELEMENT_DELETE_CONFIRM')));
					?>
					<div class="swiper-slide" id="<?=$this->GetEditAreaId($arItem['ID']);?>" data-id="tab<?=$arItem['ID']?>">
<?/*?>
						<div>
							<?=$arItem['NAME']?>

						</div>
						<?*/?>
						<a href="<?=$arItem['src']?>" class='fancy-gallery-1' rel='fancy-gallery-1'>
							<img src="<?=$arItem['src']?>" alt="<?=$arItem['NAME']?>">
						</a>
					</div>

					<?
				}
				?>




			</div>
		</div>
		<div class="swiper-button-prev"></div>
		<div class="swiper-button-next"></div>
	</div>
</div>

