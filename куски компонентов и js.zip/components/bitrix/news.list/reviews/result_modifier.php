<?
foreach($arResult["ITEMS"] as $arItem) 
{
	$IDS[$arItem['CREATED_BY']] = 1;
}



$rsUsers = CUser::GetList(($by="personal_country"), ($order="desc"), array(''), array('FIELDS' => array('ID','NAME'))) ;

while($arItem = $rsUsers->NavNext(true, "f_"))
{	
	$U[$arItem['ID']] = $arItem;
}

foreach($arResult["ITEMS"] as $key => $arItem) 
{
	$arResult["ITEMS"][$key]['USER_NAME'] = $U[$arItem['CREATED_BY']]['NAME'];
}
?>