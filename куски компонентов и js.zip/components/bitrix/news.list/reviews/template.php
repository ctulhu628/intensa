<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();
/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */
/** @var CBitrixComponent $component */
$this->setFrameMode(true);
?>
<div class="reviews-list">

	<?
	foreach($arResult["ITEMS"] as $key => $arItem)
	{

		
		$this->AddEditAction($arItem['ID'], $arItem['EDIT_LINK'], CIBlock::GetArrayByID($arItem["IBLOCK_ID"], "ELEMENT_EDIT"));
		$this->AddDeleteAction($arItem['ID'], $arItem['DELETE_LINK'], CIBlock::GetArrayByID($arItem["IBLOCK_ID"], "ELEMENT_DELETE"), array("CONFIRM" => GetMessage('CT_BNL_ELEMENT_DELETE_CONFIRM')));
		?>
		<div class="reviews-item" id="<?=$this->GetEditAreaId($arItem['ID']);?>">
			<div class="reviews-item-name">
				<?=$arItem['PROPERTIES']['NAME']['VALUE']?:$arItem['USER_NAME']?:$arItem['PROPERTIES']['FIO']['VALUE']?> 
				<?if ($arItem['PROPERTIES']['COMPANY']['VALUE'])
				{
					?>
					<span class="reviews-item-company">
						(<?=$arItem['PROPERTIES']['COMPANY']['VALUE'];?>)
					</span>
					<?
				}
				?>
			</div>
			<div class="reviews-item-time">
				<?=$arItem['TIMESTAMP_X']?>
			</div>
			<div class="reviews-item-raiting">
				<div class="reviews-item-raiting-close"></div>
				<div id="rating<?=$arItem['ID']?>" data-raiting="<?=$arItem['PROPERTIES']['RAITING']['VALUE']?:''?>">
					
				</div>
			</div>
			<div class="reviews-item-review">
				<img class="fa-quote-left" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADgAAAA4CAMAAACfWMssAAAAzFBMVEUAAAAAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAOj7rAAAAQ3RSTlMAAQIEBQYHCA4PFBcaHiAhIiQnKCorMDFETVFWV1hbXV5jZGZnbXl7fn+AhYmanrTDxcfP09XX2eDm6Onr7e/z9ff9dJWruwAAAS9JREFUSEvt1slWg0AQheEiRlGD85yIcUgkSiLOGtEYrfd/JxemoemuukcXruQu+c4Ph2EB0f9asHI0up8wvxz8Spu9NzZb9jJVG4dTLrfrZLouPbK9vWqn65Z9Qi/UdZOdVUJdF99d2rY6XRsPruRzZQe0Yx18HZ602/sL1gV1bZa3frtB7oD2CkkCrwMaTIyc+xnSVSM3wvWQHhtaFzqkVzPJhQyq+QyHPmE138WpT1hnwh2fsBrq+4TV0J30NpAa4oFUAi2I81H6vSSOfqAsLgvd0FOZeByCkMehSpyhkDOdOEIhRzrFMIx1SmCY6JTCMK3DOlTpj8JPjS6JCGn1h8LaGREhvdBoh4iQthR5DogIal+mNSIirJJ9FD8sSFuDp8rTm15356kY1nrSvgBwHsZc034YMgAAAABJRU5ErkJggg==" alt="">
				
				<?=$arItem['PROPERTIES']['MSG']['VALUE']?>
				
				<img  class="fa-quote-right" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADgAAAA4CAMAAACfWMssAAABIFBMVEUAAAAAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAwAfAw5/u5yAAAAX3RSTlMAAQIDBAUGBwgJCgsNDg8SExQXHB8gIiMmJystLjA1Nzg7PD1ERUpLTE1XXl9hY2RoaW1zeXt8foCGiYuOj5iam52eo6WrrbC1vL7HyMrX2tze4Ojp6+3v8fP19/n7/YzKWsoAAAGdSURBVEjH7dVXW8IwGIbhl6p1VIQiOBDFvfceOHGCOBBBVJr//y88oKFpki+XR57Id9jnupsUUgD+yzhxV5ioFYpWvxjjThBWqiw8Xi6oTs6TanW1eWO7xNSpJ32XrGvqow0ABaabenNN51NbHwBkmX5yAIAcUbNAnkieBcDyiJoHKkRiUQBRKr4BVGIuAJesbdiGfw49E4wb4IsJOgZ4ZIKo0XDQCNdoiH0TtEo0pKTb/A0s0BCDRy8eBYHJ6woFhbE3FCjMwDUJgR0DRKREw5gJYomGXUaYoWEPTzEdnPDjl2Grjg7yrb6qaYZDSwfP/Hijpls/lXWus+HXbSWl+IJ7OrjJa1oudpmnUY0b5tHrlEpvkaf3iMa1/p1PpDIVnMo59fla+2RsgF/sS2fGZ3eFw/wsLpgYy0wsnjeCesBLUnk5xgS3LsePbp5O5LQl7vFbrkOtdCmVK9FFZDcPCp5GTHABFFwOf5phWEuJ7UIodwkY4J6tP0nsfkT93p9a5+U4KqWOswZrvBUOp7Wvkltk7Kt8u53uQHt+Nz+Ox25Knhbs2QAAAABJRU5ErkJggg==" alt="">
			</div>
			<?
			if ($arItem['PROPERTIES']['ANSWER']['VALUE'])
			{
				?>

				<div class="reviews-item-answer">
					<?=$arItem['PROPERTIES']['ANSWER']['VALUE']['TEXT']?>
				</div>

				<?
			}
			?>
			<?/*
				if ($key == 0)
				{
					?>
					<div class="reviews-item-answer">
						<span class="reviews-item-answer-name">
							Администрация:
						</span>
						<span class="reviews-item-answer-text">
							Добрый день! Ирина, благодарим Вас за оставленный отзыв! Будем стараться и дальше радовать Вас вкусными обедами!
						</span>
					</div>
					<?
				}
			*/
				?>
				

			</div>
			<?
		}
		?>

		<br />
		<?=$arResult["NAV_STRING"]?>

	</div>
