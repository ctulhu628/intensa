<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();
/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */
/** @var CBitrixComponent $component */

?>
<div class="article">
<?foreach($arResult["ITEMS"] as $arItem){?>
	<div class="article-item">
		<img src="<?=$arItem["PREVIEW_PICTURE"]["SRC"]?>" />
		<div class="date"><img src="/img/article-date.png" /> <?echo $arItem["DISPLAY_ACTIVE_FROM"]?></div>
		<div class="title"><?echo $arItem["NAME"]?></div>
		<div class="view"><img src="/img/article-view.png" /> <?=$arItem["SHOW_COUNTER"]?> просмотров</div>
		<a href="<?=$arItem["DETAIL_PAGE_URL"]?>">Читать дальше</a>
	</div>
<?}?>	
</div>	