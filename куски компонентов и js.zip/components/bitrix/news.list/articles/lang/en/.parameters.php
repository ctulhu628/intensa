<?
$MESS["TP_BND_DISPLAY_DATE"] = "Display element date";
$MESS["TP_BND_DISPLAY_NAME"] = "Display element title";
$MESS["TP_BND_DISPLAY_PICTURE"] = "Display element preview picture";
$MESS["TP_BND_DISPLAY_PREVIEW_TEXT"] = "Display element preview text";
$MESS["TP_BND_USE_RATING"] = "Enable Rating";
$MESS["TP_BND_DISPLAY_AS_RATING"] = "Show in rating";
$MESS["TP_BND_AVERAGE"] = "Average value";
$MESS["TP_BND_RATING"] = "Rating value";
$MESS["TP_BND_MAX_VOTE"] = "Maximum Rating";
$MESS["TP_BND_VOTE_NAMES"] = "Rating Legend";
$MESS["TP_BND_USE_SHARE"] = "Show Social Network Bookmarks Bar";
$MESS["TP_BND_SHARE_TEMPLATE"] = "Social Network Bookmarks Template";
$MESS["TP_BND_SHARE_HANDLERS"] = "Use Social Networks And Bookmarks";
$MESS["TP_BND_SHARE_SHORTEN_URL_LOGIN"] = "bit.ly Login";
$MESS["TP_BND_SHARE_SHORTEN_URL_KEY"] = "bit.ly Key";
$MESS["TP_BND_MEDIA_PROPERTY"] = "Media property";
$MESS["TP_BND_SLIDER_PROPERTY"] = "Property containing slider images";
$MESS["TP_BND_SEARCH_PAGE"] = "Search page path";
$MESS["TP_BND_THEME_SITE"] = "Use site theme (for bitrix.eshop)";
$MESS["TP_BND_THEME_BLUE"] = "blue (default theme)";
$MESS["TP_BND_THEME_GREEN"] = "green";
$MESS["TP_BND_THEME_RED"] = "red";
$MESS["TP_BND_THEME_WOOD"] = "wood";
$MESS["TP_BND_THEME_YELLOW"] = "yellow";
$MESS["TP_BND_THEME_BLACK"] = "dark";
$MESS["TP_BND_TEMPLATE_THEME"] = "Color theme";
?>