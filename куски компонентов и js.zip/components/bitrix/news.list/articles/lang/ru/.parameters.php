<?
$MESS["TP_BND_DISPLAY_DATE"] = "Выводить дату элемента";
$MESS["TP_BND_DISPLAY_NAME"] = "Выводить название элемента";
$MESS["TP_BND_DISPLAY_PICTURE"] = "Выводить изображение для анонса";
$MESS["TP_BND_DISPLAY_PREVIEW_TEXT"] = "Выводить текст анонса";
$MESS["TP_BND_USE_RATING"] = "Разрешить голосование";
$MESS["TP_BND_DISPLAY_AS_RATING"] = "В качестве рейтинга показывать";
$MESS["TP_BND_AVERAGE"] = "Среднее значение";
$MESS["TP_BND_RATING"] = "Рейтинг";
$MESS["TP_BND_MAX_VOTE"] = "Максимальный балл";
$MESS["TP_BND_VOTE_NAMES"] = "Подписи к баллам";
$MESS["TP_BND_USE_SHARE"] = "Отображать панель соц. закладок";
$MESS["TP_BND_SHARE_TEMPLATE"] = "Шаблон компонента панели соц. закладок";
$MESS["TP_BND_SHARE_HANDLERS"] = "Используемые соц. закладки и сети";
$MESS["TP_BND_SHARE_SHORTEN_URL_LOGIN"] = "Логин для bit.ly";
$MESS["TP_BND_SHARE_SHORTEN_URL_KEY"] = "Ключ для для bit.ly";
$MESS["TP_BND_MEDIA_PROPERTY"] = "Свойство для отображения медиа";
$MESS["TP_BND_SLIDER_PROPERTY"] = "Свойство с изображениями для слайдера";
$MESS["TP_BND_SEARCH_PAGE"] = "Путь к странице поиска";
$MESS["TP_BND_THEME_SITE"] = "Брать тему из настроек сайта (для решения bitrix.eshop)";
$MESS["TP_BND_THEME_BLUE"] = "синяя (тема по умолчанию)";
$MESS["TP_BND_THEME_GREEN"] = "зеленая";
$MESS["TP_BND_THEME_RED"] = "красная";
$MESS["TP_BND_THEME_WOOD"] = "дерево";
$MESS["TP_BND_THEME_YELLOW"] = "желтая";
$MESS["TP_BND_THEME_BLACK"] = "темная";
$MESS["TP_BND_TEMPLATE_THEME"] = "Цветовая тема";
?>