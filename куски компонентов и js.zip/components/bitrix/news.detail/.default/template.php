<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();
/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */
/** @var CBitrixComponent $component */
// Увеличиваем количество просмотров элемента:
//if(CModule::IncludeModule("iblock"))
  //  CIBlockElement::CounterInc($arResult["DETAIL_PICTURE"]);

 

?>
<h1>Полезные статьи</h1>
  								<div class="zag-bg">
  									<?if($arParams["DISPLAY_PICTURE"]!="N" && is_array($arResult["DETAIL_PICTURE"])):?>
										<img
											class="detail_picture"
											border="0"
											src="<?=$arResult["DETAIL_PICTURE"]["SRC"]?>"
											width="<?=$arResult["DETAIL_PICTURE"]["WIDTH"]?>"
											height="<?=$arResult["DETAIL_PICTURE"]["HEIGHT"]?>"
											alt="<?=$arResult["DETAIL_PICTURE"]["ALT"]?>"
											title="<?=$arResult["DETAIL_PICTURE"]["TITLE"]?>"
											/>
											
  									<div></div>
									<?endif?>
  									
  								</div>
  								
  								<div class="article-text">
  									<h5><?=$arResult["NAME"]?></h5>
  									<div class="info"><img src="/img/article-date.png" /> <?=$arResult["DISPLAY_ACTIVE_FROM"]?><img src="/img/article-view.png" /> <?=$arResult["SHOW_COUNTER"]?> просмотр</div>
  									<div class="text">
  										<p><?=$arResult["DETAIL_TEXT"]?></p>
  									</div>
  									<a class="return" href="/nasha-kuhnya/">Вернуться назад</a>
  								</div>