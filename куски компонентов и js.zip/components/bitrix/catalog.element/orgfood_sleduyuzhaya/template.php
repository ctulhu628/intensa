<?

$_SESSION['Week']=date('W')+1;

if ($_REQUEST['day']!=NULL) {
	$_SESSION['datasec']=strtotime($_REQUEST['day']);
} else {
	$_SESSION['datasec']=strtotime('next Monday');
} 
if ($_REQUEST['day']!=NULL) {
	$_SESSION['dayint']=date('N',strtotime($_REQUEST['day']));
} else {
	$_SESSION['dayint']=date('N',strtotime('next Monday'));
}
if ($_REQUEST['day']!=NULL) {
$_SESSION['dey']=date('l',strtotime($_REQUEST['day']));
} else {
	$_SESSION['dey']=date('l',strtotime('next Monday'));
}
if ($_REQUEST['day']!=NULL) {
  $_SESSION['dey2']=date('d.m.Y',strtotime($_REQUEST['day']));
} else {
  $_SESSION['dey2']=date('d.m.Y',strtotime('next Monday'));
}
$_SESSION['dataMonday']= time() - ( -7 + date("N")-1) * 24*60*60; //понедельник след. недели - дата
$_SESSION['urlcatalog']= '/orgfood'.$arResult['CODE'].'/?sl=1'; 
?><div class="left infobliddop">
<div class="bread" >
			 <?$APPLICATION->IncludeComponent("bitrix:breadcrumb", "", Array(
							"COMPONENT_TEMPLATE" => ".default",
							"START_FROM" => "0",	// Номер пункта, начиная с которого будет построена навигационная цепочка
							"PATH" => "",	// Путь, для которого будет построена навигационная цепочка (по умолчанию, текущий путь)
							"SITE_ID" => "s1",	// Cайт (устанавливается в случае многосайтовой версии, когда DOCUMENT_ROOT у сайтов разный)
					 ),
					false
					);?>
			
			
			
			
		</div>
<div class="connewbl forstroitel">
		<div class="fg forstroitel2">
<?

$GLOBALS['arrFilter1']=array();
    		  if ($_REQUEST['day']!=NULL) {
			 // $GLOBALS['arrFilter1']+=  array('PROPERTY_DNI' =>$_REQUEST['day'] );
		  }else{
    	  
    	  // $GLOBALS['arrFilter1']+=  array('PROPERTY_DNI' => date('d.m.Y', strtotime('next Monday')) ); 
		  }
		  
    	
 ?>	
<div id="tabs">
  		<?   	

if($_REQUEST['sv']!=NULL){
    		
			$GLOBALS['arrFilter1']+=  array($_REQUEST['sv'] => $_REQUEST['val'] );
			
    	};
$days= array(0=>'next Monday',1=>'next Tuesday',2=>'next Wednesday',3=>'next Thursday',4=>'next Friday',5=>'next Saturday',6=>'next Sunday');
$days_rus= array('next Monday'=>'Пн','next Tuesday'=>'Вт','next Wednesday'=>'Ср','next Thursday'=>'Чт','next Friday'=>'Пт','next Saturday'=>'Сб','next Sunday'=>'Вс');

//echo date('l');
foreach ($days as  $value) { 
	
	if($value==date('l')){
		
		$pref='';
		$dis='';
		$oc='';
	}
	
	$week_day[]=array('day'=>$pref.$value,
	'dis'=>$dis,
		'oc'=>$oc,
		'rus'=>$days_rus[$value]
		);
}
?>

  <div class="cl"></div>
  <div id="tabs-1" class="tabs">
  <div class="tabs-bg">
  <div class="chik">
    <div class="kompleks">
		<div class="calend">
				<div class="hr"></div>
		<? 
		$first_day = strtotime($week_day[0]['day']);
	$day_sl = date($first_day);
		foreach ($week_day as  $value) {
		
		?>
        
 
    <div>
		<input type="radio" id="item-1" name="calend" <?=$value['dis']?> <?if(date('d.m.Y', $day_sl)==date('d.m.Y', strtotime('next Monday')) or date('d.m.Y', $day_sl)==$_REQUEST['day']){?> checked="checked"<?}?>  value="1">
		
		<label for="item-1">
			<a onclick="<?=$value['oc']?>" href="?sl=1&day=<?echo date('d.m.Y', $day_sl)?>"><span></span><?=$value['rus']?><br /><?echo date('d.m.y', $day_sl)?></a>
		</label>
    </div>
     <?
	 $day_sl = $day_sl+86400;
	 } ?>
	</div>
		
			<a href="/orgfood/<?=$arResult['CODE']?>/" class="next-week">Текущая неделя</a>
			
			<div class="cl"></div>
	<h1><?=$arResult['NAME']?></h1>	
<div class="infoline ">
					<div class="seonewtext">
						<?=$arResult['PREVIEW_TEXT']?>
					</div>
				</div>	
			<? 
$codcat = $arResult['PROPERTIES']['CODCAT']['VALUE'];			
$GLOBALS['arrFilter1'] +=  array("PROPERTY_KATEGORIYA" => $codcat );	
	$APPLICATION->IncludeComponent(
	"bitrix:catalog.section", 
	"orgfood", 
	array(
		"ACTION_VARIABLE" => "action",
		"ADD_PICT_PROP" => "-",
		"ADD_PROPERTIES_TO_BASKET" => "Y",
		"ADD_SECTIONS_CHAIN" => "N",
		"ADD_TO_BASKET_ACTION" => "ADD",
		"AJAX_MODE" => "N",
		"AJAX_OPTION_ADDITIONAL" => "",
		"AJAX_OPTION_HISTORY" => "N",
		"AJAX_OPTION_JUMP" => "N",
		"AJAX_OPTION_STYLE" => "Y",
		"BACKGROUND_IMAGE" => "-",
		"BASKET_URL" => "/personal/basket.php",
		"BROWSER_TITLE" => "-",
		"CACHE_FILTER" => "N",
		"CACHE_GROUPS" => "Y",
		"CACHE_TIME" => "36000000",
		"CACHE_TYPE" => "A",
		"COMPONENT_TEMPLATE" => "plitka",
		"CONVERT_CURRENCY" => "N",
		"DETAIL_URL" => "",
		"DISABLE_INIT_JS_IN_COMPONENT" => "N",
		"DISPLAY_BOTTOM_PAGER" => "Y",
		"DISPLAY_TOP_PAGER" => "N",
		"ELEMENT_SORT_FIELD" => "catalog_PRICE_1",
		"ELEMENT_SORT_FIELD2" => "sort",
		"ELEMENT_SORT_ORDER" => "asc",
		"ELEMENT_SORT_ORDER2" => "asc",
		"FILE_404" => "",
		"FILTER_NAME" => "arrFilter1",
		"HIDE_NOT_AVAILABLE" => "N",
		"IBLOCK_ID" => "40",
		"IBLOCK_TYPE" => "1c_catalog",
		"INCLUDE_SUBSECTIONS" => "Y",
		"LABEL_PROP" => "-",
		"LINE_ELEMENT_COUNT" => "3",
		"MESSAGE_404" => "",
		"MESS_BTN_ADD_TO_BASKET" => "В корзину",
		"MESS_BTN_BUY" => "Купить",
		"MESS_BTN_DETAIL" => "Подробнее",
		"MESS_BTN_SUBSCRIBE" => "Подписаться",
		"MESS_NOT_AVAILABLE" => "Нет в наличии",
		"META_DESCRIPTION" => "-",
		"META_KEYWORDS" => "-",
		"OFFERS_LIMIT" => "5",
		"PAGER_BASE_LINK_ENABLE" => "N",
		"PAGER_DESC_NUMBERING" => "N",
		"PAGER_DESC_NUMBERING_CACHE_TIME" => "36000",
		"PAGER_SHOW_ALL" => "N",
		"PAGER_SHOW_ALWAYS" => "N",
		"PAGER_TEMPLATE" => ".default",
		"PAGER_TITLE" => "Товары",
		"PAGE_ELEMENT_COUNT" => "100",
		"PARTIAL_PRODUCT_PROPERTIES" => "Y",
		"PRICE_CODE" => array(
			0 => "Розничная",
		),
		"PRICE_VAT_INCLUDE" => "Y",
		"PRODUCT_ID_VARIABLE" => "id",
		"PRODUCT_PROPERTIES" => array(
			0 => "SOSTAV",
		),
		"PRODUCT_PROPS_VARIABLE" => "prop",
		"PRODUCT_QUANTITY_VARIABLE" => "",
		"PRODUCT_SUBSCRIPTION" => "N",
		"PROPERTY_CODE" => array(
			0 => "GRUPPA",
			1 => "VES_OBEM",
			2 => "SOSTAV",
			3 => "VIP_BLYUDO",
			4 => "CML2_ARTICLE",
			5 => "CML2_BASE_UNIT",
			6 => "DNI",
			7 => "INGREDIENTY",
			8 => "NED",
			9 => "PREDLOZHENIE_DNYA",
			10 => "CML2_MANUFACTURER",
			11 => "CML2_TRAITS",
			12 => "CML2_TAXES",
			13 => "TIP",
			14 => "CML2_ATTRIBUTES",
			15 => "HOR",
			16 => "CML2_BAR_CODE",
			17 => "REYTING_POPULYARNOSTI_NEDELYA",
			18 => "REYTING_POPULYARNOSTI_MESYATS",
			19 => "KALORIYNOST",
			20 => "INGREDIENT_1",
			21 => "INGREDIENT_2",
			22 => "INGREDIENT_3",
			23 => "INGREDIENT_4",
			24 => "INGREDIENT_5",
			25 => "INGREDIENT_6",
			26 => "INGREDIENT_7",
			27 => "PERIOD_AKTIVNOSTI",
			28 => "SOSTAV_SAYT",
			29 => "INGREDIENTY_SAYT",
			30 => "PO_TIPU_SAYT",
			31 => "PO_KHARAKTERU_SAYT",
			32 => "NOVINKA",
			33 => "KATEGORIYA",
			34 => "POSTNOE",
			35 => "VEGETARIANSKOE",
			36 => "DIETICHESKOE",
			37 => "KOMPLEKSNYY_OBED",
			38 => "",
		),
		"SECTION_CODE" => "",
		"SECTION_ID" => "",
		"SECTION_ID_VARIABLE" => "SECTION_ID",
		"SECTION_URL" => "",
		"SECTION_USER_FIELDS" => array(
			0 => "",
			1 => "",
		),
		"SEF_MODE" => "N",
		"SET_BROWSER_TITLE" => "Y",
		"SET_LAST_MODIFIED" => "N",
		"SET_META_DESCRIPTION" => "Y",
		"SET_META_KEYWORDS" => "Y",
		"SET_STATUS_404" => "Y",
		"SET_TITLE" => "Y",
		"SHOW_404" => "Y",
		"SHOW_ALL_WO_SECTION" => "Y",
		"SHOW_CLOSE_POPUP" => "N",
		"SHOW_DISCOUNT_PERCENT" => "N",
		"SHOW_OLD_PRICE" => "N",
		"SHOW_PRICE_COUNT" => "1",
		"TEMPLATE_THEME" => "blue",
		"USE_MAIN_ELEMENT_SECTION" => "N",
		"USE_PRICE_COUNT" => "N",
		"CATEGORY" =>$codcat,
		"USE_PRODUCT_QUANTITY" => "N"
	),
	false
);?>
<?
								if(isset($arResult['PROPERTIES']['GALL1']['VALUE'][0]) and $arResult['PROPERTIES']['GALL1']['VALUE'][0]!=''){
								?>				
			
<div class="infoline33 " id="oborud">
									<h2><?=$arResult['PROPERTIES']['NAMEGALL1']['VALUE'];?></h2>
									<p class="prdline"><span>Предоставляемое оборудование</span></p>
									<div class="sliderblockk">
										<div class="sliderblockk2">
											<div class="fg-gallery ">
											<?
												
														$i=1;		
														
														foreach ($arResult['PROPERTIES']['GALL1']['VALUE'] as $rpid)
															{
																
																//print_r($ob1) ;
																	 $img = CFile::ResizeImageGet($rpid, array('width'=>265, 'height'=>177), BX_RESIZE_IMAGE_EXACT, true);  	
																		?>
																		
																		<div>
																			<a class="gallery" rel="group" href="<?=CFile::GetPath($rpid)?>">
																				<img src="<?=$img['src']?>" />
																				<span class="hover"></span>
																			</a>
																			
																		</div>
																		<?
															$i++;
																	
															}
															
											?>
												
												
												
												
											</div>
										</div>
									</div>
									<div class="seonewtext">
										<?=$arResult['DETAIL_TEXT']?>
									</div>
									
								</div>
								<?}?>
  								<?
								if(isset($arResult['PROPERTIES']['PREIM']['VALUE'][0]) and $arResult['PROPERTIES']['CODCAT']['VALUE'][0]!=''){
								?>
  								<div class="infoline33">
									<p class="prdline"><span>Преимущества работы с нами</span></p>
									<div class="preimblock"> 
										<div class="preimleft">
										<?
										$prei=1;
										$countpreim = count($arResult['PROPERTIES']['PREIM']['VALUE']);
										$countpreimrazdelit = $countpreim/2;
										foreach($arResult['PROPERTIES']['PREIM']['VALUE'] as $preim){
											$chi=$prei;
											if(strlen($prei)<2){
												$chi='0'.$prei;
											}
											?>
											<div><span><?=$chi?></span> <p><?=$preim?></p></div>
											
										<?if($prei==$countpreimrazdelit){?>
											</div>
											<div class="preimright">
										<?}?>	
										
											
										<?
										$prei++;
										}?>
									</div>
  								</div>	
							</div>		
								<?}?>
<div class="fg-bottom">
  									<div class="fg-left myfgleft">
  										<div class="success_res"></div>
  										<div class="fg-form">
  											<p>Если у вас остались вопросы, заполните заявку, мы свяжемся с вами в ближайшее время.</p>
  											
  											<input id="data_pit" type="text" placeholder="Желаемая дата и время питания группы*" />
  											<input id="kompanyr" type="text" placeholder="Наименование компании-организатора*" />
  											<input id="namer" type="text" placeholder="Контактное лицо*" />
  											<input id="phoner" type="text" class="fg-phone phonemask" placeholder="Введите телефон*" />
  											<input id="emailr" type="text" class="fg-email" placeholder="Введите E-mail*" />
  											<textarea id="commentr" placeholder="Комментарии по заявке"></textarea>
											<input id="nameform" type="hidden" value="Заявка на обед" />
  											
  										</div>
  										<span id="err1">Заполните обязательные поля</span>
  										<a class="filter-but2 btndd" id="zayavka_ex2" href="">Сделать заявку на обед</a>
  									</div>
  									
  								</div>			
		
		
	</div>
    					<div class="cl"></div>
   </div>
    </div>
  </div>
  
</div>

</div>
</div>
</div>