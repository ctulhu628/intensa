<? if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

use \Bitrix\Main\Localization\Loc;

/**
 * @global CMain $APPLICATION
 * @var array $arParams
 * @var array $arResult
 * @var CatalogSectionComponent $component
 * @var CBitrixComponentTemplate $this
 * @var string $templateName
 * @var string $componentPath
 * @var string $templateFolder
 */

$this->setFrameMode(true);

global $USER, $DB; 
if($USER->GetID()!=1){
	LocalRedirect("/");
}
?><div class="infobliddop left">
	<div class="connewbl forstroitel">
		<div class="fg forstroitel2">
			<h1>Обеды для строителей</h1>
			<div class="infoline komplcopyblock">
				<div class="infoline ">
					<div class="seonewtext">
						<p>
							Организуем питание на стройку – идеальное решение для работодателей и строителей. Обеды с доставкой на стройплощадку помогают обеспечивать полноценное питание для рабочих.&nbsp;
						</p>
						<p>
							 Горячие обеды на стройплощадке всегда актуальны для застройщика. Большой выбор блюд позволит подобрать меню. Недорогие обеды строителям с доставкой из первого и второго блюд, гарнира, салата.&nbsp; <br>
 <br>
							 У нас Вы сможете заказать комплексные обеды для рабочих в любом количестве
						</p>
					</div>
				</div>
				<div id="tabs">
					<div id="tabs-1" class="tabs">
						<div class="tabs-bg">
							<div class="chik">
								<div class="kompleks">
									<div class="plitka el64300">
										<h4>Сытный обед(первое + второе с гарниром; хлеб и приборы)</h4>
										<div class="item">
											<div class="col col-2 kopmsostav">
												<div class="top">
													 Состав обеда
												</div>
 <span class="prev64300 prevkompleks"></span>
												<div class="bottom sostavlistkopleks " id="sostavlistkopleksslide64300">
													<ul>
														<li class="ind-item select itemforim64381 osntextindex1 osncatid83642ac3-04bf-11e6-afd0-901b0e6067a7"> <img src="/upload/iblock/093/09358f46023363a09a1d6bd21f5928d7.jpeg" class="komlimgizmen">
														<!--div class="new"></div-->
														<h5>Борщ с сельдереем; со сметаной (350 мл.)</h5>
														<p class="sosansosizmen">
															 Овощные/фруктовые
														</p>
														<p class="info">
															 Вес <span vesajax="350" class="vesajax kopnew">350</span> гр, Ккал <span kkalajax="29.53" class="kkalajax kopnew">29.53</span>
														</p>
														<div class="price_div">
															 Цена: <span class="price_individ kopnew kompprice">60.00</span> руб.
														</div>
 <span cat="83642ac3-04bf-11e6-afd0-901b0e6067a7" id_kompleks="64300" index="1" catname="Первое блюдо" idr="64381" max_price="60" idr_name="ccc41502-e5ee-11e5-8ea5-60e3270c0c46" day="31.08.2017" class="izm index1 izm83642ac3-04bf-11e6-afd0-901b0e6067a7">изменить</span>
														<p class="dnone sostav_p textindex1 catid83642ac3-04bf-11e6-afd0-901b0e6067a7">
 <a id="example1" href="/upload/iblock/093/09358f46023363a09a1d6bd21f5928d7.jpeg">Борщ с сельдереем; со сметаной (350 мл.)</a>
														</p>
 </li>
														<li class="ind-item select itemforim66308 osntextindex2 osncatid83642ac4-04bf-11e6-afd0-901b0e6067a7"> <img src="/upload/iblock/85b/85babd034e62c087487629b3124a24cb.jpeg" class="komlimgizmen">
														<!--div class="new"></div-->
														<h5>Куры, жареные в чесночном соусе (110/30 гр.)</h5>
														<p class="sosansosizmen">
															 Мясные/мясо птицы
														</p>
														<p class="info">
															 Вес <span vesajax="110" class="vesajax kopnew">110</span> гр, Ккал <span kkalajax="185.13" class="kkalajax kopnew">185.13</span>
														</p>
														<div class="price_div">
															 Цена: <span class="price_individ kopnew kompprice">103.00</span> руб.
														</div>
 <span cat="83642ac4-04bf-11e6-afd0-901b0e6067a7" id_kompleks="64300" index="2" catname="Второе блюдо" idr="66308" max_price="103" idr_name="3b7bd370-227d-11e6-827c-d0bf9c618e39" day="31.08.2017" class="izm index2 izm83642ac4-04bf-11e6-afd0-901b0e6067a7">изменить</span>
														<p class="dnone sostav_p textindex2 catid83642ac4-04bf-11e6-afd0-901b0e6067a7">
 <a id="example1" href="/upload/iblock/85b/85babd034e62c087487629b3124a24cb.jpeg">Куры, жареные в чесночном соусе (110/30 гр.)</a>
														</p>
 </li>
														<li class="ind-item select itemforim64306 osntextindex3 osncatid8bf83290-6892-11e6-a1b8-901b0e6067a7"> <img src="/upload/iblock/7d3/7d3cb643ae47db4147038eb24cb21690.jpeg" class="komlimgizmen">
														<!--div class="new"></div-->
														<h5>Рис</h5>
														<p class="sosansosizmen">
															 Крупяные
														</p>
														<p class="info">
															 Вес <span vesajax="170" class="vesajax kopnew">170</span> гр, Ккал <span kkalajax="162.12" class="kkalajax kopnew">162.12</span>
														</p>
														<div class="price_div">
															 Цена: <span class="price_individ kopnew kompprice">35.00</span> руб.
														</div>
 <span cat="8bf83290-6892-11e6-a1b8-901b0e6067a7" id_kompleks="64300" index="3" catname="Простые гарниры" idr="64306" max_price="35" idr_name="d748c45e-ef71-11e5-8269-d0bf9c618e39" day="31.08.2017" class="izm index3 izm8bf83290-6892-11e6-a1b8-901b0e6067a7">изменить</span>
														<p class="dnone sostav_p textindex3 catid8bf83290-6892-11e6-a1b8-901b0e6067a7">
 <a id="example1" href="/upload/iblock/7d3/7d3cb643ae47db4147038eb24cb21690.jpeg">Рис</a>
														</p>
 </li>
														<li class="ind-item select itemforim64319 osntextindex4 osncatidbb3295e1-1800-11e6-a63e-901b0e581578"> <img src="/upload/iblock/a52/a52ce8959141aa59532f06849d716e21.png" class="komlimgizmen">
														<!--div class="new"></div-->
														<h5>Хлеб белый ,1 шт.</h5>
														<p class="sosansosizmen">
															 Мучные
														</p>
														<p class="info">
															 Вес <span vesajax="15" class="vesajax kopnew">15</span> гр, Ккал <span kkalajax="246" class="kkalajax kopnew">246</span>
														</p>
														<div class="price_div">
															 Цена: <span class="price_individ kopnew kompprice">2.00</span> руб.
														</div>
 <span cat="bb3295e1-1800-11e6-a63e-901b0e581578" id_kompleks="64300" index="4" catname="Хлеб" idr="64319" max_price="2" idr_name="8d81423a-a0fc-11e5-8116-001fc6bf8349" day="31.08.2017" class="izm index4 izmbb3295e1-1800-11e6-a63e-901b0e581578">изменить</span>
														<p class="dnone sostav_p textindex4 catidbb3295e1-1800-11e6-a63e-901b0e581578">
 <a id="example1" href="/upload/iblock/a52/a52ce8959141aa59532f06849d716e21.png">Хлеб белый ,1 шт.</a>
														</p>
 </li>
														<li class="ind-item select itemforim64320 osntextindex5 osncatidbb3295e1-1800-11e6-a63e-901b0e581578"> <img src="/upload/iblock/bf1/bf168f081eb05267534f20d79c680213.jpeg" class="komlimgizmen">
														<!--div class="new"></div-->
														<h5>Хлеб чёрный, 1 шт.</h5>
														<p class="sosansosizmen">
															 Мучные
														</p>
														<p class="info">
															 Вес <span vesajax="15" class="vesajax kopnew">15</span> гр, Ккал <span kkalajax="254" class="kkalajax kopnew">254</span>
														</p>
														<div class="price_div">
															 Цена: <span class="price_individ kopnew kompprice">2.00</span> руб.
														</div>
 <span cat="bb3295e1-1800-11e6-a63e-901b0e581578" id_kompleks="64300" index="5" catname="Хлеб" idr="64320" max_price="2" idr_name="8d814238-a0fc-11e5-8116-001fc6bf8349" day="31.08.2017" class="izm index5 izmbb3295e1-1800-11e6-a63e-901b0e581578">изменить</span>
														<p class="dnone sostav_p textindex5 catidbb3295e1-1800-11e6-a63e-901b0e581578">
 <a id="example1" href="/upload/iblock/bf1/bf168f081eb05267534f20d79c680213.jpeg">Хлеб чёрный, 1 шт.</a>
														</p>
 </li>
														<li class="ind-item select itemforim65820 osntextindex6 osncatid099d8821-32a9-11e6-93dd-901b0e6067a7"> <img src="/upload/iblock/85a/85a020f86d037b8064058349e9427616.jpeg" class="komlimgizmen">
														<!--div class="new"></div-->
														<h5>Приборы разовые (набор): вилка, ложка, нож, салфетка</h5>
														<p class="sosansosizmen">
															 Посуда, приборы
														</p>
														<p class="info">
															 Вес <span vesajax="4" class="vesajax kopnew">4</span> гр, Ккал <span kkalajax="" class="kkalajax kopnew"></span>
														</p>
														<div class="price_div">
															 Цена: <span class="price_individ kopnew kompprice">5.00</span> руб.
														</div>
 <span cat="099d8821-32a9-11e6-93dd-901b0e6067a7" id_kompleks="64300" index="6" catname="Одноразовая посуда" idr="65820" max_price="5" idr_name="8d814264-a0fc-11e5-8116-001fc6bf8349" day="31.08.2017" class="izm index6 izm099d8821-32a9-11e6-93dd-901b0e6067a7">изменить</span>
														<p class="dnone sostav_p textindex6 catid099d8821-32a9-11e6-93dd-901b0e6067a7">
 <a id="example1" href="/upload/iblock/85a/85a020f86d037b8064058349e9427616.jpeg">Приборы разовые (набор): вилка, ложка, нож, салфетка</a>
														</p>
 </li>
													</ul>
												</div>
 <span class="next64300 nextkompleks"></span>
											</div>
											<div class="col col-3" style="display :none;">
												<div class="top">
													 Вес
												</div>
												<div class="bottom">
													<div class="ver-hr">
													</div>
													<p>
														 1000 гр
													</p>
												</div>
											</div>
											<div class="col col-4" style="display :none;">
												<div class="top">
													 Ккал.
												</div>
												<div class="bottom">
													<div class="ver-hr">
													</div>
													<p>
														 6696 ккал
													</p>
												</div>
											</div>
											<div class="col col-5">
												<div class="top">
													 Количество
												</div>
												<div class="bottom">
													<div class="ver-hr">
													</div>
													<div class="quantity">
 <img src="/img/plus.png" class="plus"><input class="qn" type="text" value="1"><img src="/img/minus.png" class="minus">
													</div>
												</div>
											</div>
										</div>
										<div class="cl">
										</div>
										<div class="price">
											<div class="pricekompl">
												 Цена: <span class="summkompleksa">165.00 </span>руб.
											</div>
											<div class="economtext">
												 Экономия: <span class="econsumm">42 </span> руб.
											</div>
											<div class="CATALOG_PRICE_1" style="display: none;">
												 165.00
											</div>
											<div class="product_id" style="display: none;">
												 64300
											</div>
											<div class="week" style="display: none;">
												 35
											</div>
											<div class="day" style="display: none;">
												 Thursday
											</div>
											<div class="dayint" style="display: none;">
												 4
											</div>
											<div class="datasec" style="display: none;">
												 1504126800
											</div>
											<div class="date" style="display: none;">
												 31.08.2017
											</div>
											<div class="kat" style="display: none;">
												 058713ab-0ded-11e6-a63e-901b0e581578
											</div>
 <a class="add-plitka" href="" id_el="64300">Добавить</a>
										</div>
									</div>
									 <script type="text/javascript">
								jQuery(function(){
									
									jQuery("#sostavlistkopleksslide64300").jCarouselLite({
										visible: 5,
										start: 0,
										btnNext: ".next64300",
										btnPrev: ".prev64300",
										circular:false,
										scroll: 1
									});
									
										
									
								});
						</script>
									<div class="cl">
									</div>
									<div class="plitka el64585">
										<h4>Сытный ужин</h4>
										<div class="item">
											<div class="col col-2 kopmsostav">
												<div class="top">
													 Состав ужина
												</div>
 <span class="prev64585 prevkompleks"></span>
												<div class="bottom sostavlistkopleks " id="sostavlistkopleksslide64585">
													<ul>
														<li class="ind-item select itemforim64397 osntextindex1 osncatidce96029e-2f35-11e6-93dd-901b0e6067a7"> <img src="/upload/iblock/430/430832c8158a99fe7b33c8c6a808df6d.jpeg" class="komlimgizmen">
														<!--div class="new"></div-->
														<h5>Морковь по-корейски (150 г.) </h5>
														<p class="sosansosizmen">
															 Овощные/фруктовые
														</p>
														<p class="info">
															 Вес <span vesajax="150" class="vesajax kopnew">150</span> гр, Ккал <span kkalajax="217.85" class="kkalajax kopnew">217.85</span>
														</p>
														<div class="price_div">
															 Цена: <span class="price_individ kopnew kompprice">50.00</span> руб.
														</div>
 <span cat="ce96029e-2f35-11e6-93dd-901b0e6067a7" id_kompleks="64585" index="1" catname="Салаты и закуски" idr="64397" max_price="50" idr_name="238464b5-b563-11e5-94e5-901b0e6067a7" day="31.08.2017" class="izm index1 izmce96029e-2f35-11e6-93dd-901b0e6067a7">изменить</span>
														<p class="dnone sostav_p textindex1 catidce96029e-2f35-11e6-93dd-901b0e6067a7">
 <a id="example1" href="/upload/iblock/430/430832c8158a99fe7b33c8c6a808df6d.jpeg">Морковь по-корейски (150 г.) </a>
														</p>
 </li>
														<li class="ind-item select itemforim64307 osntextindex2 osncatiddf980378-3641-11e6-93dd-901b0e6067a7"> <img src="/upload/iblock/06f/06f995b64de283205680578b7e391458.jpeg" class="komlimgizmen">
														<!--div class="new"></div-->
														<h5>Блинчики с курицей и грибами, 250 гр.</h5>
														<p class="sosansosizmen">
															 Мучные
														</p>
														<p class="info">
															 Вес <span vesajax="250" class="vesajax kopnew">250</span> гр, Ккал <span kkalajax="245.9" class="kkalajax kopnew">245.9</span>
														</p>
														<div class="price_div">
															 Цена: <span class="price_individ kopnew kompprice">132.00</span> руб.
														</div>
 <span cat="df980378-3641-11e6-93dd-901b0e6067a7" id_kompleks="64585" index="2" catname="Блины и блинчики" idr="64307" max_price="132" idr_name="7cb4abdb-a106-11e5-8116-001fc6bf8349" day="31.08.2017" class="izm index2 izmdf980378-3641-11e6-93dd-901b0e6067a7">изменить</span>
														<p class="dnone sostav_p textindex2 catiddf980378-3641-11e6-93dd-901b0e6067a7">
 <a id="example1" href="/upload/iblock/06f/06f995b64de283205680578b7e391458.jpeg">Блинчики с курицей и грибами, 250 гр.</a>
														</p>
 </li>
														<li class="ind-item select itemforim64319 osntextindex3 osncatidbb3295e1-1800-11e6-a63e-901b0e581578"> <img src="/upload/iblock/a52/a52ce8959141aa59532f06849d716e21.png" class="komlimgizmen">
														<!--div class="new"></div-->
														<h5>Хлеб белый ,1 шт.</h5>
														<p class="sosansosizmen">
															 Мучные
														</p>
														<p class="info">
															 Вес <span vesajax="15" class="vesajax kopnew">15</span> гр, Ккал <span kkalajax="246" class="kkalajax kopnew">246</span>
														</p>
														<div class="price_div">
															 Цена: <span class="price_individ kopnew kompprice">2.00</span> руб.
														</div>
 <span cat="bb3295e1-1800-11e6-a63e-901b0e581578" id_kompleks="64585" index="3" catname="Хлеб" idr="64319" max_price="2" idr_name="8d81423a-a0fc-11e5-8116-001fc6bf8349" day="31.08.2017" class="izm index3 izmbb3295e1-1800-11e6-a63e-901b0e581578">изменить</span>
														<p class="dnone sostav_p textindex3 catidbb3295e1-1800-11e6-a63e-901b0e581578">
 <a id="example1" href="/upload/iblock/a52/a52ce8959141aa59532f06849d716e21.png">Хлеб белый ,1 шт.</a>
														</p>
 </li>
														<li class="ind-item select itemforim64320 osntextindex4 osncatidbb3295e1-1800-11e6-a63e-901b0e581578"> <img src="/upload/iblock/bf1/bf168f081eb05267534f20d79c680213.jpeg" class="komlimgizmen">
														<!--div class="new"></div-->
														<h5>Хлеб чёрный, 1 шт.</h5>
														<p class="sosansosizmen">
															 Мучные
														</p>
														<p class="info">
															 Вес <span vesajax="15" class="vesajax kopnew">15</span> гр, Ккал <span kkalajax="254" class="kkalajax kopnew">254</span>
														</p>
														<div class="price_div">
															 Цена: <span class="price_individ kopnew kompprice">2.00</span> руб.
														</div>
 <span cat="bb3295e1-1800-11e6-a63e-901b0e581578" id_kompleks="64585" index="4" catname="Хлеб" idr="64320" max_price="2" idr_name="8d814238-a0fc-11e5-8116-001fc6bf8349" day="31.08.2017" class="izm index4 izmbb3295e1-1800-11e6-a63e-901b0e581578">изменить</span>
														<p class="dnone sostav_p textindex4 catidbb3295e1-1800-11e6-a63e-901b0e581578">
 <a id="example1" href="/upload/iblock/bf1/bf168f081eb05267534f20d79c680213.jpeg">Хлеб чёрный, 1 шт.</a>
														</p>
 </li>
														<li class="ind-item select itemforim65820 osntextindex5 osncatid099d8821-32a9-11e6-93dd-901b0e6067a7"> <img src="/upload/iblock/85a/85a020f86d037b8064058349e9427616.jpeg" class="komlimgizmen">
														<!--div class="new"></div-->
														<h5>Приборы разовые (набор): вилка, ложка, нож, салфетка</h5>
														<p class="sosansosizmen">
															 Посуда, приборы
														</p>
														<p class="info">
															 Вес <span vesajax="4" class="vesajax kopnew">4</span> гр, Ккал <span kkalajax="" class="kkalajax kopnew"></span>
														</p>
														<div class="price_div">
															 Цена: <span class="price_individ kopnew kompprice">5.00</span> руб.
														</div>
 <span cat="099d8821-32a9-11e6-93dd-901b0e6067a7" id_kompleks="64585" index="5" catname="Одноразовая посуда" idr="65820" max_price="5" idr_name="8d814264-a0fc-11e5-8116-001fc6bf8349" day="31.08.2017" class="izm index5 izm099d8821-32a9-11e6-93dd-901b0e6067a7">изменить</span>
														<p class="dnone sostav_p textindex5 catid099d8821-32a9-11e6-93dd-901b0e6067a7">
 <a id="example1" href="/upload/iblock/85a/85a020f86d037b8064058349e9427616.jpeg">Приборы разовые (набор): вилка, ложка, нож, салфетка</a>
														</p>
 </li>
													</ul>
												</div>
 <span class="next64585 nextkompleks"></span>
											</div>
											<div class="col col-3" style="display :none;">
												<div class="top">
													 Вес
												</div>
												<div class="bottom">
													<div class="ver-hr">
													</div>
													<p>
														 1000 гр
													</p>
												</div>
											</div>
											<div class="col col-4" style="display :none;">
												<div class="top">
													 Ккал.
												</div>
												<div class="bottom">
													<div class="ver-hr">
													</div>
													<p>
														 6944.8 ккал
													</p>
												</div>
											</div>
											<div class="col col-5">
												<div class="top">
													 Количество
												</div>
												<div class="bottom">
													<div class="ver-hr">
													</div>
													<div class="quantity">
 <img src="/img/plus.png" class="plus"><input class="qn" type="text" value="1"><img src="/img/minus.png" class="minus">
													</div>
												</div>
											</div>
										</div>
										<div class="cl">
										</div>
										<div class="price">
											<div class="pricekompl">
												 Цена: <span class="summkompleksa">175.00 </span>руб.
											</div>
											<div class="economtext">
												 Экономия: <span class="econsumm">16 </span> руб.
											</div>
											<div class="CATALOG_PRICE_1" style="display: none;">
												 175.00
											</div>
											<div class="product_id" style="display: none;">
												 64585
											</div>
											<div class="week" style="display: none;">
												 35
											</div>
											<div class="day" style="display: none;">
												 Thursday
											</div>
											<div class="dayint" style="display: none;">
												 4
											</div>
											<div class="datasec" style="display: none;">
												 1504126800
											</div>
											<div class="date" style="display: none;">
												 31.08.2017
											</div>
											<div class="kat" style="display: none;">
												 058713ab-0ded-11e6-a63e-901b0e581578
											</div>
 <a class="add-plitka" href="" id_el="64585">Добавить</a>
										</div>
									</div>
									 <script type="text/javascript">
								jQuery(function(){
									
									jQuery("#sostavlistkopleksslide64585").jCarouselLite({
										visible: 5,
										start: 0,
										btnNext: ".next64585",
										btnPrev: ".prev64585",
										circular:false,
										scroll: 1
									});
									
										
									
								});
						</script>
									<div class="cl">
									</div>
									<div class="plitka el64585">
										<h4>Сытный завтрак</h4>
										<div class="item">
											<div class="col col-2 kopmsostav">
												<div class="top">
													 Состав завтрака
												</div>
 <span class="prev64585 prevkompleks"></span>
												<div class="bottom sostavlistkopleks " id="sostavlistkopleksslide64585">
													<ul>
														<li class="ind-item select itemforim64397 osntextindex1 osncatidce96029e-2f35-11e6-93dd-901b0e6067a7"> <img src="/upload/iblock/430/430832c8158a99fe7b33c8c6a808df6d.jpeg" class="komlimgizmen">
														<!--div class="new"></div-->
														<h5>Морковь по-корейски (150 г.) </h5>
														<p class="sosansosizmen">
															 Овощные/фруктовые
														</p>
														<p class="info">
															 Вес <span vesajax="150" class="vesajax kopnew">150</span> гр, Ккал <span kkalajax="217.85" class="kkalajax kopnew">217.85</span>
														</p>
														<div class="price_div">
															 Цена: <span class="price_individ kopnew kompprice">50.00</span> руб.
														</div>
 <span cat="ce96029e-2f35-11e6-93dd-901b0e6067a7" id_kompleks="64585" index="1" catname="Салаты и закуски" idr="64397" max_price="50" idr_name="238464b5-b563-11e5-94e5-901b0e6067a7" day="31.08.2017" class="izm index1 izmce96029e-2f35-11e6-93dd-901b0e6067a7">изменить</span>
														<p class="dnone sostav_p textindex1 catidce96029e-2f35-11e6-93dd-901b0e6067a7">
 <a id="example1" href="/upload/iblock/430/430832c8158a99fe7b33c8c6a808df6d.jpeg">Морковь по-корейски (150 г.) </a>
														</p>
 </li>
														<li class="ind-item select itemforim64307 osntextindex2 osncatiddf980378-3641-11e6-93dd-901b0e6067a7"> <img src="/upload/iblock/06f/06f995b64de283205680578b7e391458.jpeg" class="komlimgizmen">
														<!--div class="new"></div-->
														<h5>Блинчики с курицей и грибами, 250 гр.</h5>
														<p class="sosansosizmen">
															 Мучные
														</p>
														<p class="info">
															 Вес <span vesajax="250" class="vesajax kopnew">250</span> гр, Ккал <span kkalajax="245.9" class="kkalajax kopnew">245.9</span>
														</p>
														<div class="price_div">
															 Цена: <span class="price_individ kopnew kompprice">132.00</span> руб.
														</div>
 <span cat="df980378-3641-11e6-93dd-901b0e6067a7" id_kompleks="64585" index="2" catname="Блины и блинчики" idr="64307" max_price="132" idr_name="7cb4abdb-a106-11e5-8116-001fc6bf8349" day="31.08.2017" class="izm index2 izmdf980378-3641-11e6-93dd-901b0e6067a7">изменить</span>
														<p class="dnone sostav_p textindex2 catiddf980378-3641-11e6-93dd-901b0e6067a7">
 <a id="example1" href="/upload/iblock/06f/06f995b64de283205680578b7e391458.jpeg">Блинчики с курицей и грибами, 250 гр.</a>
														</p>
 </li>
														<li class="ind-item select itemforim64319 osntextindex3 osncatidbb3295e1-1800-11e6-a63e-901b0e581578"> <img src="/upload/iblock/a52/a52ce8959141aa59532f06849d716e21.png" class="komlimgizmen">
														<!--div class="new"></div-->
														<h5>Хлеб белый ,1 шт.</h5>
														<p class="sosansosizmen">
															 Мучные
														</p>
														<p class="info">
															 Вес <span vesajax="15" class="vesajax kopnew">15</span> гр, Ккал <span kkalajax="246" class="kkalajax kopnew">246</span>
														</p>
														<div class="price_div">
															 Цена: <span class="price_individ kopnew kompprice">2.00</span> руб.
														</div>
 <span cat="bb3295e1-1800-11e6-a63e-901b0e581578" id_kompleks="64585" index="3" catname="Хлеб" idr="64319" max_price="2" idr_name="8d81423a-a0fc-11e5-8116-001fc6bf8349" day="31.08.2017" class="izm index3 izmbb3295e1-1800-11e6-a63e-901b0e581578">изменить</span>
														<p class="dnone sostav_p textindex3 catidbb3295e1-1800-11e6-a63e-901b0e581578">
 <a id="example1" href="/upload/iblock/a52/a52ce8959141aa59532f06849d716e21.png">Хлеб белый ,1 шт.</a>
														</p>
 </li>
														<li class="ind-item select itemforim64320 osntextindex4 osncatidbb3295e1-1800-11e6-a63e-901b0e581578"> <img src="/upload/iblock/bf1/bf168f081eb05267534f20d79c680213.jpeg" class="komlimgizmen">
														<!--div class="new"></div-->
														<h5>Хлеб чёрный, 1 шт.</h5>
														<p class="sosansosizmen">
															 Мучные
														</p>
														<p class="info">
															 Вес <span vesajax="15" class="vesajax kopnew">15</span> гр, Ккал <span kkalajax="254" class="kkalajax kopnew">254</span>
														</p>
														<div class="price_div">
															 Цена: <span class="price_individ kopnew kompprice">2.00</span> руб.
														</div>
 <span cat="bb3295e1-1800-11e6-a63e-901b0e581578" id_kompleks="64585" index="4" catname="Хлеб" idr="64320" max_price="2" idr_name="8d814238-a0fc-11e5-8116-001fc6bf8349" day="31.08.2017" class="izm index4 izmbb3295e1-1800-11e6-a63e-901b0e581578">изменить</span>
														<p class="dnone sostav_p textindex4 catidbb3295e1-1800-11e6-a63e-901b0e581578">
 <a id="example1" href="/upload/iblock/bf1/bf168f081eb05267534f20d79c680213.jpeg">Хлеб чёрный, 1 шт.</a>
														</p>
 </li>
														<li class="ind-item select itemforim65820 osntextindex5 osncatid099d8821-32a9-11e6-93dd-901b0e6067a7"> <img src="/upload/iblock/85a/85a020f86d037b8064058349e9427616.jpeg" class="komlimgizmen">
														<!--div class="new"></div-->
														<h5>Приборы разовые (набор): вилка, ложка, нож, салфетка</h5>
														<p class="sosansosizmen">
															 Посуда, приборы
														</p>
														<p class="info">
															 Вес <span vesajax="4" class="vesajax kopnew">4</span> гр, Ккал <span kkalajax="" class="kkalajax kopnew"></span>
														</p>
														<div class="price_div">
															 Цена: <span class="price_individ kopnew kompprice">5.00</span> руб.
														</div>
 <span cat="099d8821-32a9-11e6-93dd-901b0e6067a7" id_kompleks="64585" index="5" catname="Одноразовая посуда" idr="65820" max_price="5" idr_name="8d814264-a0fc-11e5-8116-001fc6bf8349" day="31.08.2017" class="izm index5 izm099d8821-32a9-11e6-93dd-901b0e6067a7">изменить</span>
														<p class="dnone sostav_p textindex5 catid099d8821-32a9-11e6-93dd-901b0e6067a7">
 <a id="example1" href="/upload/iblock/85a/85a020f86d037b8064058349e9427616.jpeg">Приборы разовые (набор): вилка, ложка, нож, салфетка</a>
														</p>
 </li>
													</ul>
												</div>
 <span class="next64585 nextkompleks"></span>
											</div>
											<div class="col col-3" style="display :none;">
												<div class="top">
													 Вес
												</div>
												<div class="bottom">
													<div class="ver-hr">
													</div>
													<p>
														 1000 гр
													</p>
												</div>
											</div>
											<div class="col col-4" style="display :none;">
												<div class="top">
													 Ккал.
												</div>
												<div class="bottom">
													<div class="ver-hr">
													</div>
													<p>
														 6944.8 ккал
													</p>
												</div>
											</div>
											<div class="col col-5">
												<div class="top">
													 Количество
												</div>
												<div class="bottom">
													<div class="ver-hr">
													</div>
													<div class="quantity">
 <img src="/img/plus.png" class="plus"><input class="qn" type="text" value="1"><img src="/img/minus.png" class="minus">
													</div>
												</div>
											</div>
										</div>
										<div class="cl">
										</div>
										<div class="price">
											<div class="pricekompl">
												 Цена: <span class="summkompleksa">175.00 </span>руб.
											</div>
											<div class="economtext">
												 Экономия: <span class="econsumm">16 </span> руб.
											</div>
											<div class="CATALOG_PRICE_1" style="display: none;">
												 175.00
											</div>
											<div class="product_id" style="display: none;">
												 64585
											</div>
											<div class="week" style="display: none;">
												 35
											</div>
											<div class="day" style="display: none;">
												 Thursday
											</div>
											<div class="dayint" style="display: none;">
												 4
											</div>
											<div class="datasec" style="display: none;">
												 1504126800
											</div>
											<div class="date" style="display: none;">
												 31.08.2017
											</div>
											<div class="kat" style="display: none;">
												 058713ab-0ded-11e6-a63e-901b0e581578
											</div>
 <a class="add-plitka" href="" id_el="64585">Добавить</a>
										</div>
									</div>
									 <script type="text/javascript">
								jQuery(function(){
									
									jQuery("#sostavlistkopleksslide64585").jCarouselLite({
										visible: 5,
										start: 0,
										btnNext: ".next64585",
										btnPrev: ".prev64585",
										circular:false,
										scroll: 1
									});
									
										
									
								});
						</script>
									<div class="cl">
									</div>
									 <script>
	
$( document ).ready(function() {
	//добавить товар в корзину
    $('.add-plitka').click(function() {
			var id = $(this).attr('id_el');
			var qn=$('.el'+id+' .qn').val();
			var day=$(this).siblings('.day').text();
			var limit = 300;
			var stop = 0;
			var priceOrderDat = 0;
			if(limit>0){
				var datasecsumm = $('.sum'+day+' span').text();
				if(!datasecsumm){
					datasecsumm = 0;
				}
				datasecsumm = parseFloat(datasecsumm)+parseFloat(priceOrderDat);
				
				var sumca = $('.el'+id+' .CATALOG_PRICE_1').text()*qn;
				var sumcaplus = parseFloat(datasecsumm)+parseFloat(sumca);
				//alert(parseFloat(datasecsumm));
				if(sumcaplus>limit){
					//alert('Вы превысили дневной лимит '+sumca+'-'+sumcaplus+'-'+limit);
					$('.limit-vspl, .allfon').attr('style','display:block;');
					stop = 1;
				}
			}
		if (stop==0){
				$('.loading-vspl, .allfon').attr('style','display:block;');
				
				var sostavArr = [];
				$('.el'+id+' .izm').each(function(i){
					sostavArr[i] = $(this).attr('idr_name');
					//sostavArr[i] = $(this).attr('idr');
				})
				sostav = sostavArr.join('; ');
				$.post(
			  "/ajax/addpr.php",
			  {
				product_id: $(this).siblings('.product_id').text(),
				week: $(this).siblings('.week').text(),
				 day: $(this).siblings('.day').text(),
				 dayint: $(this).siblings('.dayint').text(),
				 datasec: $(this).siblings('.datasec').text(),
				 qn:$('.el'+id+' .qn').val(),
				 day_for_cart:$("[aria-hidden=false]").attr('id'),
				 date:$(this).siblings('.date').text(),
				 kat: $(this).siblings('.kat').text(),
				 sostav: sostav,
				 action:'add'
				 
			  },
			  onAjaxSuccess
			)
			 
			function onAjaxSuccess(data)
			{
			  // Здесь мы получаем данные, отправленные сервером и выводим их на экран.
			  $('.cart').html(data);
			  $('.el'+id+' .add-plitka').addClass('seriybutton').text('Добавлено');
			  $('.loading-vspl, .allfon').attr('style','display:none;');
			}
			 //$('.cart').html(data);
		}
    	return false ;
})


		
		
	

//бизнес ланчи - в корзину
$('.add_bl').click(
	function(){
		var limit = $('#limit').val();
		var id_bl = $(this).attr('ids');
		var qn = $('.blid'+id_bl+' .bl-info .quantity input').val();
		var day = 'Thursday';
		var priceOrderDat = 0;
		var stop = 0;
		
		if(limit>0){
				var datasecsumm = $('.sum'+day+' span').text();
				if(!datasecsumm){
					datasecsumm = 0;
				}
				datasecsumm = parseFloat(datasecsumm)+parseFloat(priceOrderDat);
				var sumca = $('.el'+id_bl+' .CATALOG_PRICE_1').text()*qn;
				var sumcaplus = parseFloat(datasecsumm)+parseFloat(sumca);
				//alert('Вы превысили дневной лимит '+sumca+'-'+sumcaplus+'-'+limit);
				//alert(parseFloat(datasecsumm));
				if(sumcaplus>limit){
					//alert('Вы превысили дневной лимит '+sumca+'-'+sumcaplus+'-'+limit);
					$('.limit-vspl, .allfon').attr('style','display:block;');
					stop = 1;
				}
			}
		if (stop==0){
			var cat = $(this).attr('cat');
			var idArr2 = [];		
			$('.blid'+id_bl+' .bl-item .metclick1 .podrbl').each(function(){
				var id_bllist = $(this).attr('idbl');
				
				
				idArr2.push(id_bllist) 
				
				id_list = idArr2.join(';');
				
			})
			
			
				$.post(
						  "/ajax/addpr.php",
						  {
							id: id_bl,
							sostav: id_list,
							week: '35',
							 day: day,
							dayint: '4',
							 datasec: '1504126800',
							 qn:qn,
							 day_for_cart:'Thursday',
							 date:'31.08.2017',
							 kat: cat,
							 action:'add_bl'
							 
						  },
						  function onAjaxSuccess(data)
							{
								
								  // Здесь мы получаем данные, отправленные сервером и выводим их на экран.
								  $('.cart').html(data);
								
							}
					)
		}		
		 
	return false;	
	}
	
);

}); 

</script>
								</div>
							</div>
							<div class="cl">
							</div>
						</div>
					</div>
				</div>
			</div>
			<div>
				<div class="infoline " id="oborud">
									<h2>Аренда оборудования</h2>
									<p class="prdline"><span>Предоставляемое оборудование</span></p>
									<div class="sliderblockk">
										<div class="sliderblockk2">
											<div class="fg-gallery ">
												<div>
													<a id="example1" href="/img/s11.jpg">
														<img src="/img/s11.jpg" />
														<span class="hover"></span>
													</a>
													
												</div>
												<div>
													<a id="example1" href="/img/s22.jpg">
														<img src="/img/s22.jpg" />
														<span class="hover"></span>
													</a>
													
												</div>
												<div>
													<a id="example1" href="/img/s33.jpg">
														<img src="/img/s33.jpg" />
														<span class="hover"></span>
													</a>
												</div>
												<div>
													<a id="example1" href="/img/s44.jpg">
														<img src="/img/s44.jpg" />
														<span class="hover"></span>
													</a>
													
												</div>
												
												
												
											</div>
										</div>
									</div>
									<div class="seonewtext">
										<p>Описательный текст</p>
									</div>
									
								</div>
  								<div class="infoline">
									<p class="prdline"><span>Преимущества работы с нами</span></p>
									<div class="preimblock"> 
										<div class="preimleft">
											<div><span>01</span> <p>Доход от арендной платы</p></div>
											<div><span>02</span> <p>Берем на себя согласование с инстанциями
</p></div>
											<div><span>03</span> <p>Дополнительная привлекательность бизнес-центра</p></div>
											<div><span>04</span> <p>Профессиональный и оперативный сервис, высокое качество обслуживания
</p></div>
											<div><span>05</span> <p>Отлаженный технологический процесс
</p></div>
											
										</div>
										<div class="preimright">
											<div><span>06</span> <p>Возможность подключиться к проекту на любом этапе
</p></div>
											<div><span>07</span> <p>Ориентированность на клиента, гибкая клиентская политика
</p></div>
											<div><span>08</span> <p>Программа скидок и специальных предложений для современного потребителя</p></div>
											<div><span>09</span> <p>Широкий диапазон услуг
</p></div>
											<div><span>10</span> <p>Квалифицированные повара и менеджеры
</p></div>
										</div>
									</div>
  								</div>
				<div class="fg-bottom">
					<div class="fg-left myfgleft">
						 <!--a class="filter-but" href="">Посмотреть блюда по выбранным фильтрам</a-->
						<div class="fg-form">
							<p>
								 Если у вас остались вопросы, заполните заявку, мы свяжемся с вами в ближайшее время.
							</p>
 <input id="data_pit" type="text" placeholder="Желаемая дата и время питания группы*"> <input id="kompany" type="text" placeholder="Наименование компании-организатора*"> <input id="name" type="text" placeholder="Контактное лицо*"> <input id="phone" type="text" class="fg-phone phonemask" placeholder="Введите телефон*"> <input id="email" type="text" class="fg-email" placeholder="Введите E-mail*"> <textarea id="comment" placeholder="Комментарии по заявке"></textarea>
						</div>
 <span id="err1">Заполните обязательные поля</span> <a class="filter-but2" id="zayavka_ex" href="">Сделать заявку на обед</a>
					</div>
				</div>
			</div>
		</div>
		<div class="cl">
		</div>
	</div>
	 <script type="text/javascript">
    		
			$(document).on('ready', function() {
     			$(".sliderblockk2 .fg-gallery").slick({
       				dots: false,
        			infinite: true,
        			slidesToShow: 3,
        			slidesToScroll: 1
      			});
				
				
      		});
 		 </script> <script type="text/javascript">
 		 $(document).ready(function() {
			/*
			*   Examples - images
			*/

			$("a#example1").fancybox();
			});
		
		</script> <style>
.time-up {
   display: none;
}

</style>
</div>
<br>