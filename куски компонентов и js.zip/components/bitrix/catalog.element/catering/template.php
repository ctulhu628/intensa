<? if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

use \Bitrix\Main\Localization\Loc;

/**
 * @global CMain $APPLICATION
 * @var array $arParams
 * @var array $arResult
 * @var CatalogSectionComponent $component
 * @var CBitrixComponentTemplate $this
 * @var string $templateName
 * @var string $componentPath
 * @var string $templateFolder
 */

$this->setFrameMode(true);
$date = date('d.m.Y');
$date_plus3 = date('d.m.Y', strtotime("+72 hours", strtotime($date)));
global $USER, $DB; 
if($USER->GetID()!=1){
	LocalRedirect("/");
}
$IBLOCK_ID = $arResult['IBLOCK_ID'];
$ID = $arResult['ID'];
/*$arSelect = Array("ID", "IBLOCK_ID", "NAME", "PREVIEW_PICTURE", "PREVIEW_TEXT", "DETAIL_TEXT","PROPERTY_LINK","PROPERTY_NAMEGALL1","PROPERTY_NAMEGALL2","PROPERTY_TEXT3","PROPERTY_TEXT4","PROPERTY_TEXT5");
				$arFilter = array('IBLOCK_ID' => $IBLOCK_ID, 'ID' => $ID);
				$rsElement = CIBlockElement::GetList(array(), $arFilter, false, false, $arSelect);
				while ($arElement = $rsElement->Fetch())
				{
					//print_r($arElement) ;
					$NAME = $arElement['NAME'];
					$banner = CFile::GetPath($arElement['PREVIEW_PICTURE']);
					$TEXT1 = $arElement['PREVIEW_TEXT'];
					$TEXT2 = $arElement['DETAIL_TEXT'];
					$TEXT3 = $arElement['PROPERTY_TEXT3_VALUE']['TEXT'];
					$TEXT4 = $arElement['PROPERTY_TEXT4_VALUE']['TEXT'];
					$TEXT5 = $arElement['PROPERTY_TEXT5_VALUE']['TEXT'];
					$LINK = $arElement['PROPERTY_LINK_VALUE'];
					$NAMEGALL1 = $arElement['PROPERTY_NAMEGALL1_VALUE'];
					$NAMEGALL2 = $arElement['PROPERTY_NAMEGALL2_VALUE'];
					
				}*/
$NAME = $arResult['NAME'];
//echo $arResult['PREVIEW_PICTURE'];
$banner = CFile::GetPath($arResult['PREVIEW_PICTURE']['SRC']);
$TEXT1 = $arResult['PREVIEW_TEXT'];
$TEXT2 = $arResult['DETAIL_TEXT'];
$TEXT3 = $arResult['PROPERTIES']['TEXT3']['VALUE'];
$TEXT4 = $arResult['PROPERTIES']['TEXT4']['VALUE'];
$TEXT5 = $arResult['PROPERTIES']['TEXT5']['VALUE'];
$LINK = $arResult['PROPERTIES']['LINK']['VALUE'];
$minstoimost = $arResult['PROPERTIES']['MINPRICE']['VALUE'];
$dopusl = $arResult['PROPERTIES']['DOPUSL']['VALUE'];

if($arResult['ID']==69881){
	$rodpadezh = ' фуршета';
}else if($arResult['ID']==69880){
	$rodpadezh = ' банкета';
}else{
	$rodpadezh = ' мероприятия';
}		
?>
<div class="bread">
			 <?$APPLICATION->IncludeComponent("bitrix:breadcrumb", "", Array(
							"COMPONENT_TEMPLATE" => ".default",
							"START_FROM" => "0",	// Номер пункта, начиная с которого будет построена навигационная цепочка
							"PATH" => "",	// Путь, для которого будет построена навигационная цепочка (по умолчанию, текущий путь)
							"SITE_ID" => "s1",	// Cайт (устанавливается в случае многосайтовой версии, когда DOCUMENT_ROOT у сайтов разный)
					 ),
					false
					);?>
			
			
			
			
		</div>
<div class="infobliddop cateringelement"> 
				<div class="connewbl">  
  					
  						
  							
  							<div class="fg">
  								<h1><?=$NAME?></h1>
  								
  								<div class="infoline">
									<div class="bonblock" style="background: #E7FFA7 url(<?=$banner?>);">  
										<div class="bonblockright"> <a href="#" class="zayavnabanket banmena zazacall btndd" nameform="Заявка на <?=$arResult['PROPERTIES']['CHTO']['VALUE']?>">Оставить заявку</a><a href="#banmen" class="smnenu banmena btndd">Смотреть <?=$arResult['PROPERTIES']['NAME_MENU']['VALUE']?></a></div>
									</div>
  								</div>
  								
								<div class="infoline prostoformbanket">
									<form method="post" action="">
										<div class="lefftformp">
											<label><p>Укажите кол-во человек</p><input value="10" type="text" id="kol" value="" name="kol"/></label>
											<label><p>Стоимость на человека, руб.</p><input value="2500" type="text" id="st" value="" name="st"/></label>
											<label><p>Выберите дату <?=$rodpadezh?></p><input disabled value="<?=$date_plus3?>" type="text" id="datalite" value="" name="data"/></label>
										</div>
										<div class="rightformp">
											<input type="submit" class="banketzak btndd" rodpadezh="<?=$rodpadezh?>" nameform="Заявка на <?=$arResult['PROPERTIES']['CHTO']['VALUE']?>" value="Заказать <?=($arResult['ID']!=69882)?$arResult['PROPERTIES']['CHTO']['VALUE']:'мероприятие'?>">
											<p class="stitog">Стоимость итого <span id="stiotog"><span>25000</span> руб</span></p>
											<p class="minsumsukk">Минимальная стоимость <?=$rodpadezh?> <?=$minstoimost?> руб.<?=($dopusl!='')?'*':''?></p>
											<?=($dopusl!='')?'<p class="uslmin">'.$dopusl.'</p>':''?>
											
										</div>
									</form>
  								</div>
								<div class="infoline prostotext">
									<p><?=$TEXT1?></p>
  								</div>
								<div class="infoline" id="banmen">
									<h2><?=$arResult['PROPERTIES']['NAME_MENU']['VALUE']?></h2>
									<div class="menulistpit">
									<?
									$arFilter = array('IBLOCK_ID' => 40, 'CODE' => $arResult['PROPERTIES']['SCOD']['VALUE']);
									$rsSections = CIBlockSection::GetList(array(), $arFilter);
									while ($arSection = $rsSections->Fetch())
									{
										 $SECTION_ID = $arSection['ID'];
									}
									//echo $SECTION_ID; exit ;
									if(!$SECTION_ID){
										 $SECTION_ID = 21;
									}
									$arFilter2 = array('IBLOCK_ID' => 40, 'SECTION_ID' => $SECTION_ID);
									$rsSections2 = CIBlockSection::GetList(array(), $arFilter2);
									while ($arSection2 = $rsSections2->Fetch())
									{
										//$id_section = $arSection['ID'];
										//print_r($arSection2) ;
										?>
										<div class="menulistpitcat ">
											<div class="menulistitemtop">
												<a href="<?=SITE_TEMPLATE_PATH?>/img/blus1.jpg" class="imgcatbanket gallery" style="background:  url(<?=SITE_TEMPLATE_PATH?>/img/blus1.jpg) no-repeat 0 0;"></a>
												<p class="namecatbanket"><?=$arSection2['NAME']?></p>
												<p class="textsostavbl">Состав</p>
												<p class="textcenabl">Цена</p>
												<p class="textkolbl">Количество</p>
												<p class="textkstbl">Стоимость</p>
												<p class="textpustobbl"></p>
											</div>
											<div class="menulistitemblock">
												<?
												$price = '';
												$arFields = array();
												$arSelect = Array("ID", "NAME", "PROPERTY_KALORIYNOST", "PROPERTY_VES_OBEM", "PREVIEW_PICTURE", "DETAIL_PICTURE");
												$arFilter = Array("IBLOCK_ID"=>40, "SECTION_ID"=>$arSection2['ID'], "ACTIVE"=>"Y");
												$res = CIBlockElement::GetList(Array(), $arFilter, false, false, $arSelect);
												while($ob = $res->GetNextElement())
												{
												 $arFields = $ob->GetFields();
												 //print_r($arFields) ;
												// $link = $arFields['PROPERTY_LINK_VALUE'];
												$imgsrc = CFile::ResizeImageGet($arFields['DETAIL_PICTURE'], array('width'=>43, 'height'=>35), BX_RESIZE_IMAGE_EXACT, true);  
													
												 //$bgf = CFile::GetPath($arFields['PREVIEW_PICTURE']);
												
												$db_res = CPrice::GetList(	array(),array('PRODUCT_ID' => $arFields['ID'],'CATALOG_GROUP_ID' => 1));

												if ($ar_res = $db_res->Fetch())
												{
													$price = str_replace('.00','',$ar_res['PRICE']);
													
												}
												?>
												
												<div class="menulistitem item<?=$arFields['ID']?>" cat="<?=$arSection2['ID']?>" catname="<?=$arSection2['NAME']?>" id_el="<?=$arFields['ID']?>" bg="<?=SITE_TEMPLATE_PATH?>/img/blus1.jpg">
													<a href="<?=CFile::GetPath($arFields['DETAIL_PICTURE'])?>" class="menulistitemves gallery" style="background:  url(<?=$imgsrc['src']?>) no-repeat 0 center;">
														
														
													</a>
													<div class="menulistitemname">
														<?=$arFields['NAME']?>
													</div>
													<div class="menulistitemsostav">
															<?
														$ingr = array();	
														$res1 = CIBlockElement::GetProperty(40, $arFields['ID'], "sort", "asc", array("CODE" => "INGREDIENTY"));
														while ($ob1 = $res1->GetNext())
															{	
														//print_r($ob1['VALUE']) ;
																$ingr[] = $ob1['VALUE'];
															}
															//print_r($ingr) ;
															if(isset($ingr[0]) and $ingr[0]!=''){
																echo implode(', ',$ingr).'. ' ;
															}
															
													?>
													<?=($arFields['PROPERTY_VES_OBEM_VALUE']!='')?' '.$arFields['PROPERTY_VES_OBEM_VALUE'].' гр. ':''?> 
													<?=($arFields['PROPERTY_KALORIYNOST_VALUE']!='')?' '.$arFields['PROPERTY_KALORIYNOST_VALUE'].' ккал':''?>
													</div>
													<div class="menulistitempr menulistitemnameprice">
														<span class="indprice"><?=$price?></span> руб.
													</div>
													<div class="menulistitemkol">
														<div class="quantity">
															<img class="plus"  src="/bitrix/templates/LunchTime/img/plus.png" priceorderdat="140" sumca="35" timesec="1506027600">
															<input disabled="disabled" price="<?=$price?>"  id_el="<?=$arFields['ID']?>" value="1" type="text">
															<img class="minus"  priceorderdat="140" src="/bitrix/templates/LunchTime/img/minus.png">
														</div>
													</div>
													<div class="menulistitempr menulistitemnamepricetotal">
														<span class="totalprice"><?=$price?></span> руб.
													</div>
													<div class="menulistitemadd">
														<a href="" class="addkorban btndd dobavit" price="<?=$price?>" id_el="<?=$arFields['ID']?>">Добавить</a>
													</div>
												</div>	
												<?}?>	
											</div>
										</div>
										<?
									}
									?>
										
										
									</div>
									<div class="divformbottom">
										<div class="kalendcal">
											<p>Выберите дату банкета:</p>
											<div class="calendalblock">
												<input type="text" disabled id="datepicker" value="<?=$date_plus3?>" />
												<!--<button></button>-->
											</div>
										</div>
										<div class="itogostoimban">
											<p class="sukpoity">Стоимость итого:</p>
											<div class="calendalblock2">
												<p class="priceitogopan"><span>0</span> руб.</p>
											</div>
										</div>
										<div class="botomoformban">
											<a href="/" class="btndd">Сформировать заказ</a>
										</div>
									</div>
								</div>
								<div class=" vashzakaz">
  								<div class="infoline ">
									<h2>Ваш заказ</h2>
									<div class="menulistpit vashzakazlist">
									
										
										
										
										
									</div>
									<div class="divformbottomcenter">
										<div class="izmenzaka">
											<a href="/" class="btndd">Изменить заказ</a>
										</div>
										<div class="izmenzakadatya">
											<p>Дата банкета: <span></span></p>
										</div>
										<div class="izmenzakaprice">
											<p>Стоимость итого: <span></span> руб.</p>
										</div>
									</div>
								</div>
  								
  								
  								
  								<div class="fg-bottom">
								<h2>Для отправки заявки введите контактные данные</h2>
  									<div class="fg-left myfgleft">
  										<div class="success_res"></div>
  										<div class="fg-form">
  											
  											
  											<!--input id="data_pit" type="text" placeholder="Желаемая дата и время питания группы*" /-->
  											<input id="kompanyr" type="text" placeholder="Наименование компании-организатора" />
  											<input id="namer" type="text" placeholder="Контактное лицо*" />
  											<input id="phoner" type="text" class="fg-phone phonemask" placeholder="Введите телефон*" />
  											<input id="emailr" type="text" class="fg-email" placeholder="Введите E-mail*" />
  											<textarea id="commentr" placeholder="Комментарии по заявке"></textarea>
											<input id="nameform" type="hidden" value="Заявка на <?=$arResult['PROPERTIES']['CHTO']['VALUE']?>" />
  											
  										</div>
  										<span id="err1">Заполните обязательные поля</span>
  										<a class="filter-but2 btndd" id="zayavka_ex3" href="">Сделать заявку на <?=($arResult['ID']!=69882)?$arResult['PROPERTIES']['CHTO']['VALUE']:'мероприятие'?></a>
  									</div>
  									
  								</div>
								</div>
								<div class="infoline prostotext">
									<p><?=$TEXT2?></p>
  								</div>
  								<div class="infoline ">
									<h2><?=$arResult['PROPERTIES']['VWTEXT']['VALUE']?></h2>
									<div class="vmestezakbl ">
										<?
										//echo $arFields['ID'];
										$res2 = CIBlockElement::GetProperty($IBLOCK_ID, $ID, "sort", "asc", array("CODE" => "VW"));
										$ad4=1;		
										
										while ($ob2 = $res2->GetNext())
											{
												//print_r($ob2) ;
												if(isset($ob2['VALUE']) and $ob2['VALUE']!=''){
													$arSelect2 = Array("ID", "IBLOCK_ID", "NAME", "PREVIEW_PICTURE","PROPERTY_LINK");
													$arFilter2 = array('IBLOCK_ID' => 43, 'ID' => $ob2['VALUE']);
													$rsElement2 = CIBlockElement::GetList(array(), $arFilter2, false, false, $arSelect2);
													
													while ($arElement2 = $rsElement2->Fetch())
													{
														$img = CFile::ResizeImageGet($arElement2['PREVIEW_PICTURE'], array('width'=>300, 'height'=>200), BX_RESIZE_IMAGE_EXACT, true);  
													
														?>
														 <div class="vmestezakblitem vmestezakblitem1">
															 <div class="vmestezakitem" style="background:url(<?=$img['src'];?>) no-repeat 0 0">
																
																<a class="btnahuy btndd" href="<?=$arElement2['PROPERTY_LINK_VALUE']?>">Подробнее</a>
															</div>
															<p><a class="btnahuy2" href="<?=$arElement2['PROPERTY_LINK_VALUE']?>"><?=$arElement2['NAME']?></a></p>
														</div>
														<?
														$ad4++;
													}
												}
											}
											
										
										//print_r($arResult['PROPERTIES']['ADVANATGUSL']['VALUE']) ;
									?>
										
									</div>
  								</div>
  								
  								
  							</div>
  						
  					
  					
				</div>
				
				<div class="cl"></div>
				
			</div>
<style>
.time-up {
   display: none;
}
.content .right {
   display: none;
}
</style>
<?
if(date('H')>=16){
	$new_date_zavtraDatapicker = date('Y,m-1,d', strtotime("+72 hours", strtotime($date)));
} else {
	$new_date_zavtraDatapicker = date('Y,m-1,d', strtotime("+72 hours", strtotime($date)));
}
//$new_date_zavtraDatapicker = '2017,00,02';
?>
<script type="text/javascript">
    		$(document).on('ready', function() {
     			
				///////////////////////////////////////
				$( "#datepicker" ).datepicker({
					showOn: "button",
				    dateFormat: 'dd.mm.yy',
					minDate: new Date(<?=$new_date_zavtraDatapicker?>),
					onSelect : function(dateText, inst){
						//window.location.replace("/catalog/prazdnichie-bluda/?day="+dateText); 
					},
				  //buttonImage: "img/cal-img2.png",
				 // buttonImageOnly: true,
				  showOtherMonths: true,
				  buttonText: ""
				});
				$( "#datalite" ).datepicker({
					showOn: "button",
				    dateFormat: 'dd.mm.yy',
					minDate: new Date(<?=$new_date_zavtraDatapicker?>),
					onSelect : function(dateText, inst){
						//window.location.replace("/catalog/prazdnichie-bluda/?day="+dateText); 
					},
				  //buttonImage: "img/cal-img2.png",
				 // buttonImageOnly: true,
				  showOtherMonths: true,
				  buttonText: ""
				});
      		});
 		 </script>
		 <script type="text/javascript">
 		 $(document).ready(function() {
			/*
			*   Examples - images
			*/

			$("a.gallery").fancybox();
			});
		
		</script>