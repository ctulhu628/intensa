<?
$MESS ['calend_title'] = "Select date in calendar";
?>