<?if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();
use Bitrix\Sale\DiscountCouponsManager;
//получим все содержимое корзины и удалим заказы если время заказа прошло
//данные корзины
/*$arBasketItems = array();
$dbBasketItems = CSaleBasket::GetList(
				  array("NAME" => "ASC","ID" => "ASC"),
				  array("FUSER_ID" => CSaleBasket::GetBasketUserID(), "LID" => SITE_ID, "ORDER_ID" => "NULL"),
				  false,
				  false,
				  array("ID","MODULE","PRODUCT_ID","QUANTITY","CAN_BUY","PRICE"));
   while ($arItems=$dbBasketItems->Fetch())
   {
		$db_res = CSaleBasket::GetPropsList(array("SORT" => "ASC","NAME" => "ASC"),
			array("BASKET_ID" => $arItems['ID'])
		);
		while ($ar_res = $db_res->Fetch())
		{
		  print_r($ar_res) ;
		}
		  //print_r($arItems) ;
	}*/
////////////////////////END//////////получим все содержимое корзины и удалим заказы если время заказа прошло//////////END////////////////////////// 
	CModule::IncludeModule('highloadblock');
	
	$hlblock_id = 4; 
	$hlblock   = Bitrix\Highloadblock\HighloadBlockTable::getById( $hlblock_id )->fetch(); 
	$entity   = Bitrix\Highloadblock\HighloadBlockTable::compileEntity( $hlblock );  
	$entity_data_class = $entity->getDataClass(); 
	$entity_table_name = $hlblock['TABLE_NAME']; 
	$sTableID = 'tbl_'.$entity_table_name; 
	$arSelect = array('*'); 
	$arOrder = array("UF_NAME"=>"ASC"); 

	if (!empty($arResult["ERROR_MESSAGE"]))
	{
		ShowError($arResult["ERROR_MESSAGE"]);
	}

	foreach ($arResult['ITEMS']['AnDelCanBuy'] as $k=> $value) 
	{
		foreach ($value['PROPS'] as  $value2) 
		{
			$arResult['ITEMS']['AnDelCanBuy'][$k]['PROPS2'][$value2['CODE']]=$value2['VALUE'];

			if ($value2['CODE']=='KAT') {
				$cat_val[]=$value2['VALUE'];
			}
		}
	}
	

	$week = strtotime('this week', $_SESSION['datasec']);
	$cat=array_unique($cat_val);
	$days_rus= array('Monday'=>'Пн','Tuesday'=>'Вт','Wednesday'=>'Ср','Thursday'=>'Чт','Friday'=>'Пт','Saturday'=>'Сб','Sunday'=>'Вс');
	$days_int= array('Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday');
	
	$days_data_nedel = array(

		'Monday' => date ("d.m.Y", strtotime("day", $week)),
		'Tuesday' => date ("d.m.Y", strtotime("+1 day", $week)),
		'Wednesday' => date ("d.m.Y", strtotime("+2 day", $week)),
		'Thursday' => date ("d.m.Y", strtotime("+3 day", $week)),
		'Friday' => date ("d.m.Y", strtotime("+4 day", $week)),
		'Saturday' => date ("d.m.Y", strtotime("+5 day", $week)),
		'Sunday' => date ("d.m.Y", strtotime("+6 day", $week))
	);


	/*
	if (isset($_REQUEST['day'])) 
	{
		$nedel_day = date('N',strtotime($_REQUEST['day']));
	}
	else 
	{
		$nedel_day = date('N');
		if (isset($_SESSION['dey2']) and $_SESSION['dey2']!='')
		{
			$nedel_day=date('N',strtotime($_SESSION['dey2']));
		}
	}
	*/

	$nedel_day = date('N', $_SESSION['datasec']);

	$nedel_day = $nedel_day-1;
	
	$_REQUEST['day_for_cart'] = date('l', $_SESSION['datasec']);

	?>



	<div class="bottom">	
		<div id="tabs2">
			<ul>
				<? 
				foreach ($days_rus as $key => $value) 
				{
					?>
					<li denendelatr="<?=$key?>" 
						class="
						prdenn 
						<?=$key == $_REQUEST['day_for_cart']?"ui-tabs-active2":""?>
						<?=$days_int[$nedel_day] == $key?"ui-tabs-active":""?>
						"
					>
						<?

						$tmp = explode('.', $days_data_nedel[$key]);
						?>
						<a data-date='<?=json_encode(array('1' => $tmp[0].'.'.$tmp[1]))?>' url="<?=$_SESSION['urlcatalog']?>?day=<?=$days_data_nedel[$key]?>" href="#<?=$key?>">
							<?=$value?>
						</a>
					</li>
					<? 
				}

				?>
			</ul>

			<div class="cl"></div>
			<? 

			foreach ($days_rus as $key => $value) 
			{
				$sum = 0;
				$qn = 0;
				$n = 0;

				?>

				<div id="<?=$key?>" class="list_tabs_sder tabs">
					<div class='basket-list-day'>
						<?	

						$k=1;

						foreach ($cat as $kat) 
						{
							$n=0;


							foreach ($arResult['ITEMS']['AnDelCanBuy'] as $item) 
							{


								if (intval($item['PROPS2']['WEEK'])==intval($_SESSION['Week'])) 
								{

									if (trim($item['PROPS2']['DAY'])==trim($key)) 
									{
										if (trim($item['PROPS2']['KAT'])==trim($kat)) 
										{
											$n=1;

										}
									}
								}

								foreach($item['PROPS'] as $PROPS3)
								{
									if ($PROPS3['CODE']=='GARNIR_YES')
									{
										if ($PROPS3['VALUE']!='')
										{

											$arOrForGarnir[trim($PROPS3['VALUE'])] = $item['ID'];
										}

									}
								}
							}


							if($n == 1)
							{
								$indclass="";
								$arFilter = array("UF_XML_ID" =>trim ($kat)); 
								$rsData = $entity_data_class::getList(
									array(
										"select" => $arSelect,
										"filter" => $arFilter,
										"order" => $arOrder
									)
								);
								$rsData = new CDBResult($rsData, $sTableID); 
								if ($arRes = $rsData->Fetch())
								{
									?>
									<div class='h5'><?=$arRes['UF_NAME']?></div>
									<?
								} 
								else 
								{
									if ($kat=='individ')
									{
										$indclass="indivbasket";
										?>
										<h5>Индивидуальный обед</h5>
										<?
									}
								}


								?>

								<div class="basket-item itempr <?=$indclass?> ">

									<?
									$danon = '';
									$df = 1;
									$dfcl = '';
									foreach ($arResult['ITEMS']['AnDelCanBuy'] as $item) 
									{
										$NAME = $item['~NAME'];
										$NAME2 ='';
										$arrName = array();
										preg_match_all("/\((.*)\)/", $NAME, $arrName);
										if ($arrName[0])
										{
											$NAME = str_replace($arrName[0][0], '', $NAME);
											$NAME2 = $arrName[1][0];
										}

										$item['NAME'] = $NAME; 


									// зачем то скрывают название если больше 7-ми
										if ($k>7)
									{/*
										if (!isset($_SESSION['tid']) or $_SESSION['tid']==0)
										{
											$danon = 'danon';
											$dfcl = 'df'.$df;
										}
										*/
									}

									$cat_pr = $kat;
									foreach($item['PROPS'] as $PROPS2)
									{
									if ($PROPS2['CODE']=='GARNIR_KAT')//получим категорию блюда из свойств товара в корзины
									{
										$cat_pr = $PROPS2['VALUE'];
									}
									if ($PROPS2['CODE']=='GARNIR')//получим гарнир из свойств товара в корзины, если есть
									{
										$dopGarnirProductId = (int)$PROPS2['VALUE'];
									}
								}

								if (intval($item['PROPS2']['WEEK'])==intval($_SESSION['Week'])) 
								{
									
									if (trim($item['PROPS2']['DAY'])==trim($key)) 
									{
										if (trim($item['PROPS2']['KAT'])==trim($kat)) 
										{


											$sum+=$item['PRICE']*$item['QUANTITY'];
											$qn+=$item['QUANTITY'];
											$date_incart = $item['PROPS2']['DATASEC'];  //дата создания заказа - в секундах
											$date_segodnya = strtotime(date("d.m.Y 00:00:00", time())); //дата сегодня время 00:00:00 - в секундах
											//удаляем старые закзаы
											if ($date_segodnya>$date_incart)
											{
												CSaleBasket::Delete($item['ID']);
												echo $item['ID'];
											}
											
											if ($kat=='individ')
											{
												$quantity_i = $item['QUANTITY'];
												$daydate_i = $item['PROPS2']['DATE'];
												$idArr[] = $item['ID'];
												$arrSumm += $item['PRICE'];
											}
											else
											{
												?>
												<div class="item_basketm_small bludolist catgorbas<?=$cat_pr?>">

													<div class="text <?=$danon?> <?=$dfcl?>" idnf="<?=$k?>">
														<?=$item['NAME']?>
													</div>

													<div class="quantity product_in_cart <?=$danon?> product<?=$item['PRODUCT_ID']?>" id="qn<?=$item['ID']?>"  daydate="<?=$item['PROPS2']['DATE']?>">
														<? 
														
														if ($cat_pr=='8bf83290-6892-11e6-a1b8-901b0e6067a7'){//если простой гарнир
															?>
															<span idbludd="<?=$item['ID']?>" idprfored="<?=$item['PRODUCT_ID']?>"  class="delbudo osnblud" ></span>
															<span class="osnblud plus"></span>
															<input disabled id="<?=$item['ID']?>" type="text" value="<?=$item['QUANTITY']?>" />
															<span class="osnblud plus"></span>
															
															

															<?
														} 
														else 
														{//$basketIdGarnir = $arOrForGarnir[$dopGarnirProductId];
															
															$basketIdGarnir = $arOrForGarnir[$item['PRODUCT_ID']];
															$priceOrderDat = priceOrderDat($item['PROPS2']['DATE']);
															?>
															<span garnir_id="<?=$basketIdGarnir?>" idbludd="<?=$item['ID']?>" idprfored="<?=$item['PRODUCT_ID']?>"  class="delbudo osnblud"></span>
															<span class="osnblud plus" id_el='<?=$item['ID']?>' idprfored="<?=$item['PRODUCT_ID']?>" dayprfored="<?=trim($key)?>" src="/img/plus.png" priceOrderDat="<?=$priceOrderDat?>"></span>
															<input  garnir_id="<?=$basketIdGarnir?>" disabled id="<?=$item['ID']?>" type="text" value="<?=$item['QUANTITY']?>" />
															<span class="osnblud minus"  id_el='<?=$item['ID']?>' idprfored="<?=$item['PRODUCT_ID']?>" dayprfored="<?=trim($key)?>" src="/img/minus.png" priceOrderDat="<?=$priceOrderDat?>"></span>
															

															<?
														}
														?>
														<div class="block-1">
															<?=$item['PRICE']?> р.
														</div>
													</div>
													<input type="hidden" name="skr" class="tid" value="0">
												</div>	
												<?
											}

											$df++;
											$k++;
										}

									}

								}

							}
							if ($kat=='individ')
							{
								?>
								<div class="item_basketm_small bludolist">
									<span ids="<?=implode(',',$idArr)?>" class="delbudo indv">
										
									</span>
									<div id="individ_q" class="quantity product_in_cart"  daydate="<?=$daydate_i?>">

										<?
										$priceOrderDat = priceOrderDat($item['PROPS2']['DATE']);
										?>
										<img  idprfored="<?=$item['PRODUCT_ID']?>" price="<?=$arrSumm?>" dayprfored="<?=trim($key)?>" priceOrderDat="<?=$priceOrderDat?>"  class="plus indv" src="/img/plus.png" />
										<input ids="<?=implode(',',$idArr)?>" disabled type="text" value="<?=$quantity_i?>" />
										<img  idprfored="<?=$item['PRODUCT_ID']?>" dayprfored="<?=trim($key)?>"  priceOrderDat="<?=$priceOrderDat?>" class="minus indv" src="/img/minus.png" />
									</div>
									<input type="hidden" name="skr" class="tid" value="0">
								</div>		
								<?
							}
							?>

						</div>
						<?
					}
				}
				?>
			</div>
			<div class="hr"></div> 
			<div class="sum sum<?=trim($key)?>">Сумма:&nbsp;&nbsp;<span><?=$sum?></span> руб.</div>

			<!--<div class="zak-info">Калл. в заказе: 5000 калл.</div>-->
			<div class="zak-info">Количество блюд: <?=$qn?></div>
			<!--<div class="zak-info">Начисленно баллов: 500</div>-->

			<!--<div class="gift"><img src="/img/gift.png" /><div>Ваш подарок: Напиток к заказу бесплатно!</div></div>-->
			<?if(!isset($_SESSION['tid']) or $_SESSION['tid']==0)
				{/*
					?><a class="podr" href="<?=$key?>">Подробнее</a>
					<?
				*/
				}

				?>
				
				<div class="zakzaksuaspan">
					<a class="zak" href="/personal/order/make/">Перейти к оформлению</a>
					<span class="zznezz">Ваш заказ не оформлен</span>	</div>					


				</div>
				<?
			}

			?>
			<?
			global $USER;
			if ($USER->IsAuthorized())
			{
				$rsUser = CUser::GetByID($USER->GetID());
				$arUser = $rsUser->Fetch();

				if(isset($arUser['UF_LIMIT']) and $arUser['UF_LIMIT']!='' and $arUser['UF_LIMIT']!=0)
				{
					echo '<input type="hidden" name="limit" id="limit" value="'.$arUser['UF_LIMIT'].'">
					<p class="limitorder">Предупреждение!<br>Ваш дневной лимит заказа<br> '.$arUser['UF_LIMIT'].' руб.</p>';
				}
				else
				{
					echo '<input type="hidden" name="limit" id="limit" value="0">';
				}
			} 
			else
			{
				echo '<input type="hidden" name="limit" id="limit" value="0">';
			}
			?>


		</div>

	</div>

	<script>

		$(document).ready(function() 
		{

			$('.prdenn').each(function() 
			{
				var dondik = $(this).attr('denendelatr');

				if($('#'+dondik+' h5').text() && $('#'+dondik+' h5').text()!='')
				{
					$(this).addClass('countbol');
				}		
			})


			var limmi = $('#limit').val();
			$('#ldim').text(limmi);

		})	

	</script>
