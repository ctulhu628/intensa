<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();
/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */
/** @var CBitrixComponent $component */
$this->setFrameMode(true);

$day = $GLOBALS['arrFilter1']['PROPERTY_DNI'];


$limit = 0;
global $USER;
if ($USER->IsAuthorized())
{
	$rsUser = CUser::GetByID($USER->GetID());
	$arUser = $rsUser->Fetch();

	if(isset($arUser['UF_LIMIT']) and $arUser['UF_LIMIT']!='' and $arUser['UF_LIMIT']!=0){
		$limit = $arUser['UF_LIMIT'];
	} 
}

if (!empty($arResult['MOD']['ITEMS']))
{

	foreach($arResult['MOD']['ITEMS'] as $cat => $KATEGORIYA)
	{

		if ($cat=='058713ab-0ded-11e6-a63e-901b0e581578')
		{
			?>
			<div class="set-list">
				<div class="swiper-container">
					<div class="swiper-wrapper">
						<?
						foreach($KATEGORIYA as $arItem)
						{
							?>
							<div class="swiper-slide">
								<?

								$kkal=0;
								$sosatvArrPoDatam = explode('~',$arItem['DETAIL_TEXT']);

								foreach($sosatvArrPoDatam as $sosatvArrPoDatamProver)
								{
									$DataPoDatam = explode(':',$sosatvArrPoDatamProver);
									$sosatvArr = ''; 
									if ($DataPoDatam[0]==$_SESSION['dey2'])
									{
										$sosatvArr = explode('*',$DataPoDatam[1]); 
										break ;
									}
								}
								if (!$sosatvArr) continue;
								?>

								<div class="plitka el<?=$arItem['ID']?>">

									<div class="item">

										<div class="col col-2 kopmsostav">
											<div class="top">
												<div class="block-name">
													<h4>
														<?
														$NAME = $arItem['~NAME'];
														$arrName = array();
														preg_match_all("/\((.*)\)/", $NAME, $arrName);
														if ($arrName[0])
														{
															$NAME = str_replace($arrName[0][0], '', $NAME);
															$NAME2 = $arrName[1][0];
														}
														?>
														<?=$NAME?>
													</h4>
													
												</div>
											</div>
											<div class="price block-price">
												<div class="pricekompl"> <span class="summkompleksa"><?=$arItem['CATALOG_PRICE_1']?> </span><span>руб.</span></div> 
												<div class="economtext">
													Экономия: <span class="econsumm " id="econsumm<?=$arItem['ID']?>"><?=$economsumm?> </span><span> руб.</span>
												</div>
												
												

												
											</div>


											<div class="bottom sostavlistkopleks " id="sostavlistkopleksslide<?=$arItem['ID']?>">

												<ul>
													<?

													$idx = 1;
													$price_for_econom = 0;

													foreach($sosatvArr as $XML_ID)
													{

														$catname='Без категории';
														$arFields = $arResult['MOD']['SET'][$XML_ID];


														$kkal+=$kkal+$arFields['PROPERTY_KALORIYNOST_VALUE'];

														$catname = $arResult['MOD']['KATEGORIYA'][$arFields['PROPERTY_KATEGORIYA_VALUE']];


														
														$img = CFile::ResizeImageGet($arFields["DETAIL_PICTURE"], Array("width" => 113, "height" => 90),BX_RESIZE_IMAGE_PROPORTIONAL_ALT, false, false, false, 60);
														$rsFile = $img['src'];
														$ar_res = $arResult['MOD']['PRICE'][$arFields['ID']];

														$NAME = $arFields['NAME'];
														$arrName = array();
														preg_match_all("/\((.*)\)/", $NAME, $arrName);
														if ($arrName[0])
														{
															$NAME = str_replace($arrName[0][0], '', $NAME);
															$NAME2 = $arrName[1][0];
														}

														?>

														<li class="ind-item select itemforim<?=$arFields['ID']?> osntextindex<?=$idx?> osncatid<?=$arFields['PROPERTY_KATEGORIYA_VALUE']?>">
															<h5>
																<?
																echo 
																str_replace(" шт","&nbsp;шт",
																	str_replace(" мл.","&nbsp;мл",
																		str_replace(" гр","&nbsp;гр",$NAME
																	)));

																	?>

																</h5>
																<div class="data">
																	<?

																	if($rsFile=='')
																	{
																		?>
																		<img class="komlimgizmen" src="/images/no_foto/<?=$cat?>.jpg" />
																		<?
																	} 
																	else 
																	{
																		?>
																		<img class="komlimgizmen" src="<?=$rsFile?>" />
																		<?
																	}

																	?>

																	<div>
																		<div class="info-block">
																			<p class="sosansosizmen">
																				<?=$arProps['SOSTAV']['VALUE']?>
																			</p>
																			<p class="info">
																				Вес <span vesajax="<?=$arFields['PROPERTY_VES_OBEM_VALUE']?>"  class="vesajax kopnew"><?=$arFields['PROPERTY_VES_OBEM_VALUE']?></span> гр, Ккал 
																				<span kkalajax="<?=$arFields['PROPERTY_KALORIYNOST_VALUE']?>" class="kkalajax kopnew"><?=$arFields['PROPERTY_KALORIYNOST_VALUE']?></span>
																			</p>

																			<div class="block-price-change">
																				<div class="price_div">
																					<span class="price_individ kopnew kompprice"><?=$ar_res["PRICE"]?></span><span> руб.</span>
																				</div>
																				<span cat="<?=$arFields['PROPERTY_KATEGORIYA_VALUE']?>" id_kompleks = "<?=$arItem['ID']?>" index=<?=$idx?> catname="<?=$catname?>" idr=<?=$arFields['ID']?> max_price="<?=(int)$ar_res['PRICE']?>" idr_name="<?=$arFields['XML_ID']?>" day='<?=json_encode($day)?>' class="izm index<?=$idx?> izm<?=$arFields['PROPERTY_KATEGORIYA_VALUE']?>">

																				</span>
																			</div>

																			<p class="dnone sostav_p textindex<?=$idx?> catid<?=$arFields['PROPERTY_KATEGORIYA_VALUE']?>"><a id="example1" href="<?=$rsFile?>"><?=$NAME?></a></p>
																		</div>
																	</div>
																</div>




															</li>
															<?
															$price_for_econom += $ar_res["PRICE"];

															$idx++;

														}


														$economsumm = 0;
														if ($price_for_econom > $arItem['CATALOG_PRICE_1'])
														{
															$economsumm = $price_for_econom-$arItem['CATALOG_PRICE_1'];
															?>
															<script>
																document.getElementById('econsumm<?=$arItem['ID']?>').innerHTML = <?=$economsumm?>;
															</script>
															<?
														}
														?>
													</ul>
													<?/*?>
													<div class="add-review">
														<a href="/catalog/kompleks-menu-tekushchaya/#set-<?=$arItem['ID']?>">Заказать</a>
													</div>
													<?*/?>
													<div class="add-count">
														
														<div class="dni">
															<select name="dni" data-id="block-button<?=$arItem['ID']?>">
																<?


																$DNI = $arItem['PROPERTIES']['DNI']['VALUE'];
																foreach ($DNI as $item)
																{

																	if (strtotime($item.".".date("Y")) >= strtotime($day[0].".".date("Y")))
																	{
																		?>
																		<option value="<?=strtotime($item.".".date("Y"))?>">
																			<?=$item?> 
																		</option>
																		<?
																	}
																}

																?>
															</select>
														</div>

														<div class="block-quantity">
															<div class="quantity flex-row">
																<img class="plus" src="/img/plus.png" />
																<input class="qn" type="text" value="1" />
																<img class="minus" src="/img/minus.png" />
															</div>
														</div>
														<div class="block-button" id="block-button<?=$arItem['ID']?>">


															<div class='CATALOG_PRICE_1' style="display: none;" ><?=$arItem['CATALOG_PRICE_1']?> </div>

															<div class='product_id' style="display: none;" ><?=$arItem['ID']?> </div>
															<div class='week' style="display: none;" ><?=$_SESSION['Week']?> </div>
															<div class='day' style="display: none;" ><?=$_SESSION['dey']?></div>
															<div class='dayint' style="display: none;" ><?=$_SESSION['dayint']?></div>
															<div class='datasec' style="display: none;" ><?=$_SESSION['datasec']?></div>
															<div class='date' style="display: none;" ><?=$_SESSION['dey2']?></div>
															<div class='kat' style="display: none;" ><?=$arItem['PROPERTIES']['KATEGORIYA']['VALUE']?> </div>

															<?
															$timeZavtra = $_SESSION['datasec'];
															$timeSegodnyaPlus86400 = time()+86400;
															$timeSegodnyaPlus86400 = strtotime(date('d.m.Y',$timeSegodnyaPlus86400));
															$timeHour = date('H',time());
															if ($_SESSION['dey2']==date('d.m.Y') or ($timeHour>=17 and $timeZavtra==$timeSegodnyaPlus86400))
															{

																?>
																<a class="a_blocked">Добавить</a>
																<?
															}
															else
															{
																?>
																<a class="add-plitka" href="" id_el=<?=$arItem['ID']?>>Добавить</a>
																<?
															}
															?>

														</div>
														

													</div>



												</div>
											</div>
											<div class="img-add-count">

												<img src="<?=SITE_TEMPLATE_PATH?>/img/1974.jpg" alt="">
												
											</div>


											<div class="col col-3" style="display :none;">
												<div class="top">Вес</div>
												<div class="bottom">
													<div class="ver-hr"></div>
													<p><?=$arItem['PROPERTIES']['VES_OBEM']['VALUE']?> гр</p>
												</div>
											</div>
											<div class="col col-4" style="display :none;">
												<div class="top">Ккал.</div>
												<div class="bottom">
													<div class="ver-hr"></div>
													<p><?=$kkal?> ккал</p>
												</div>
											</div>


										</div>



									</div>

								</div>
								<?
							}
							?>
						</div>
					</div>

					<div class="swiper-button-prev"></div>
					<div class="swiper-button-next"></div>
				</div>
				<?

			}

		}

	}

	$_SESSION['tid']=0;
	$limit = 0;
	global $USER;
	if ($USER->IsAuthorized())
	{
		$rsUser = CUser::GetByID($USER->GetID());
		$arUser = $rsUser->Fetch();

		if(isset($arUser['UF_LIMIT']) and $arUser['UF_LIMIT']!='' and $arUser['UF_LIMIT']!=0)
		{
			$limit = $arUser['UF_LIMIT'];
		}

	}

	$priceOrderDat = priceOrderDat($_SESSION['dey2']);
	?>

	<script>

		$( document ).ready(function() {

			$('.add-plitka').click(function() {
				var id = $(this).attr('id_el');
				var qn=$('.el'+id+' .qn').val();
				var day=$(this).siblings('.day').text();
				var limit = <?=$limit?>;
				var stop = 0;
				var priceOrderDat = <?=$priceOrderDat?>;
				if(limit>0){
					var datasecsumm = $('.sum'+day+' span').text();
					if(!datasecsumm){
						datasecsumm = 0;
					}
					datasecsumm = parseFloat(datasecsumm)+parseFloat(priceOrderDat);

					var sumca = $('.el'+id+' .CATALOG_PRICE_1').text()*qn;
					var sumcaplus = parseFloat(datasecsumm)+parseFloat(sumca);

					if(sumcaplus>limit){

						$('.limit-vspl, .allfon').attr('style','display:block;');
						stop = 1;
					}
				}
				if (stop==0){
					$('.loading-vspl, .allfon').attr('style','display:block;');

					var sostavArr = [];
					$('.el'+id+' .izm').each(function(i){
						sostavArr[i] = $(this).attr('idr_name');

					})
					sostav = sostavArr.join('; ');
					$.post(
						"/ajax/addpr.php",
						{
							product_id: $(this).siblings('.product_id').text(),
							week: $(this).siblings('.week').text(),
							day: $(this).siblings('.day').text(),
							dayint: $(this).siblings('.dayint').text(),
							datasec: $(this).siblings('.datasec').text(),
							qn:$('.el'+id+' .qn').val(),
							day_for_cart:$("[aria-hidden=false]").attr('id'),
							date:$(this).siblings('.date').text(),
							kat: $(this).siblings('.kat').text(),
							sostav: sostav,
							action:'add'

						},
						onAjaxSuccess
						)

					function onAjaxSuccess(data)
					{

						$('.cart').html(data);
						$('.el'+id+' .add-plitka').addClass('seriybutton').text('Добавлено');
						$('.loading-vspl, .allfon').attr('style','display:none;');
					}

				}
				return false ;
			})


			$('.add_individ').click(
				function(){
					var lenght = $('.individ .izmindiv').length;
					var il = 1;
					var idArr = [];
					var day=$(this).attr('dayden');
					var limit = <?=$limit?>;
					var stop = 0;

					if(limit>0){
						var datasecsumm = $('.sum'+day+' span').text();
						if(!datasecsumm){
							datasecsumm = 0;
						}
						var sumca = $('#summ_individ').text();
						var sumcaplus = parseFloat(datasecsumm)+parseFloat(sumca);

						if(sumcaplus>limit){

							$('.limit-vspl, .allfon').attr('style','display:block;');
							stop = 1;
						}
					}

					if (stop==0){
						$('.individ .izmindiv').each(function(){


							var id = $(this).attr('idr');
							if (id!=0){	
								idArr.push(id) 
							}
							product_id_list = idArr.join(',');
							il++;
						})
						if (product_id_list!=''){
							$.post(
								"/ajax/addpr.php",
								{
									product_id_list: product_id_list,
									week: '<?=$_SESSION['Week']?>',
									day: '<?=$_SESSION['dey']?>',
									dayint: '<?=$_SESSION['dayint']?>',
									datasec: '<?=$_SESSION['datasec']?>',
									qn:$('.individ-info .quantity input').val(),
									day_for_cart:'<?=$_SESSION['dey']?>',
									date:'<?=$_SESSION['dey2']?>',
									kat: 'individ',
									limit: limit,
									action:'add_individ'

								},
								function onAjaxSuccess(data)
								{


									$('.cart').html(data);

								}
								)
						}		
					} 
					return false;	
				}

				);


			$('.add_bl').click(
				function(){
					var limit = $('#limit').val();
					var id_bl = $(this).attr('ids');
					var qn = $('.blid'+id_bl+' .bl-info .quantity input').val();
					var day = '<?=$_SESSION['dey']?>';
					var priceOrderDat = <?=$priceOrderDat?>;
					var stop = 0;

					if(limit>0){
						var datasecsumm = $('.sum'+day+' span').text();
						if(!datasecsumm){
							datasecsumm = 0;
						}
						datasecsumm = parseFloat(datasecsumm)+parseFloat(priceOrderDat);
						var sumca = $('.el'+id_bl+' .CATALOG_PRICE_1').text()*qn;
						var sumcaplus = parseFloat(datasecsumm)+parseFloat(sumca);


						if(sumcaplus>limit){

							$('.limit-vspl, .allfon').attr('style','display:block;');
							stop = 1;
						}
					}
					if (stop==0){
						var cat = $(this).attr('cat');
						var idArr2 = [];		
						$('.blid'+id_bl+' .bl-item .metclick1 .podrbl').each(function(){
							var id_bllist = $(this).attr('idbl');


							idArr2.push(id_bllist) 

							id_list = idArr2.join(';');

						})


						$.post(
							"/ajax/addpr.php",
							{
								id: id_bl,
								sostav: id_list,
								week: '<?=$_SESSION['Week']?>',
								day: day,
								dayint: '<?=$_SESSION['dayint']?>',
								datasec: '<?=$_SESSION['datasec']?>',
								qn:qn,
								day_for_cart:'<?=$_SESSION['dey']?>',
								date:'<?=$_SESSION['dey2']?>',
								kat: cat,
								action:'add_bl'

							},
							function onAjaxSuccess(data)
							{


								$('.cart').html(data);

							}
							)
					}		

					return false;	
				}

				);

		}); 

	</script>
