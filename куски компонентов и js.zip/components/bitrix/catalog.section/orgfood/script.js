$(document).ready(function(){
	
$(".cal .text a").hover(
function(){
  $(this).parent().prev().find('img').attr('src','/img/cal-img-hover.png'); 
},
function(){
  $(this).parent().prev().find('img').attr('src','/img/cal-img.png');
});

$(".tel .text a").hover(
function(){
  $(this).parent().prev().find('img').attr('src','/img/tel-img-hover.png'); 
},
function(){
  $(this).parent().prev().find('img').attr('src','/img/tel-img.png');
});

$(".scoot .text a").hover(
function(){
  $(this).parent().prev().find('img').attr('src','/img/scoot-img-hover.png'); 
},
function(){
  $(this).parent().prev().find('img').attr('src','/img/scoot-img.png');
});

$(".help .text a").hover(
function(){
 $(this).parent().prev().find('img').attr('src','/img/help-img-hover.png'); 
},
function(){
  $(this).parent().prev().find('img').attr('src','/img/help-img.png');
});



$(".p-menu").hover(
function(){
  $(this).children().children('.white-bg').attr('style','display:none;'); 
  $(this).children('.link-text').attr('style','background: url(img/menu-bg-hover.png) no-repeat;'); 
},
function(){
 $(this).children().children('.white-bg').attr('style','display:block;'); 
 $(this).children('.link-text').attr('style','background: url(img/menu-bg-pass.png) no-repeat;'); 
});



	
	
	
	
	
	
	
	
	
$('.content .plitka .item .col-5 .bottom .quantity .plus, .individ-info .quantity .plus, .zhel-col .quantity .plus').click(
	function(){
		
		/*var a = $(this).siblings('input').val();
		var sum = Number(a)+1;
		$(this).siblings('input').val(sum);*/
	
		
		var a = $(this).next('input').val();
			//alert(a) ;
			var sum = parseInt(a)+1;
			$(this).next('input').val(sum);
	
	}
);
	
	
$('.content .plitka .item .col-5 .bottom .quantity .minus, .individ-info .quantity .minus, .zhel-col .quantity .minus').click(
	function(){
			
		/*var a = $(this).siblings('input').val();
		if(Number(a)!=0) {
		var sum = Number(a)-1;
		$(this).siblings('input').val(sum);*/
		var a = $(this).prev('input').val();
		//alert(a) ;
		if(parseInt(a)>1) {
				var sum = parseInt(a)-1;
				$(this).prev('input').val(sum);
			
			}
	}
);
	
	
	
	
	$('.content .right .item-spisok .quantity .plus').click(
		function(){
			
			/*var a = $(this).siblings('input').val();
			var sum = Number(a)+1;
			$(this).siblings('input').val(sum);*/
			
			var a = $(this).next('input').val();
			
			var sum = parseInt(a)+1;
			$(this).next('input').val(sum);
		
		}
	);
	
	
	$('.content .right .item-spisok .quantity .minus').click(
		function(){
			
			/*var a = $(this).siblings('input').val();
			if(Number(a)!=0) {
				var sum = Number(a)-1;
				$(this).siblings('input').val(sum);
			}*/
			
			var a = $(this).prev('input').val();
		
			if(parseInt(a)>1) {
				var sum = parseInt(a)-1;
				$(this).prev('input').val(sum);
			
			}
		}
	);
	
	
	
	
	$('.content .chik .bl .bl-info .quantity .plus').click(
	function(){
		
	var a = $(this).siblings('input').val();
	var sum = Number(a)+1;
	$(this).siblings('input').val(sum);
	
	});
	
	
	$('.content .chik .bl .bl-info .quantity .minus').click(
	function(){
		
	var a = $(this).siblings('input').val();
	if(Number(a)!=0) {
	var sum = Number(a)-1;
	$(this).siblings('input').val(sum);
	}
	});
	
	
	
	
	$('.order-page .quantity .plus').click(function(){
		
	var a = $(this).siblings('input').val();
	var garnir_id = $(this).siblings('input').attr('garnir_id');
	var sum = Number(a)+1;
	
	var limit = $('#limit').val();
	var priceOrderDat = $(this).attr('priceOrderDat');
	var stop = 0;
	if(limit>0){
		var timesec = $(this).attr('timesec');
		var datasecsumm = parseFloat($('.summordday'+timesec+' span').text())+parseFloat(priceOrderDat);
		var sumca = $(this).attr('sumca');
		var sumcaplus = datasecsumm+parseFloat(sumca);
		//alert(limit);
		if(sumcaplus>limit){
			//alert('Вы превысили дневной лимит '+sumca+'-'+sumcaplus+'-'+limit);
			$('.limit-vspl, .allfon').attr('style','display:block;');
			stop = 1;
		}
	} 
	if (stop==0){
		$(this).siblings('input').val(sum);
			  $.post(
			  "/ajax/cart_function.php",
			  {
				action:'edit_quantity',
				id: $(this).attr('id_edit'),
				garnir_id:garnir_id,
				qn: $(this).siblings('input').val()

				 
			  },
			  function onAjaxSuccess(data)
				{	
				  // Здесь мы получаем данные, отправленные сервером и выводим их на экран.
				   $('.summaryy').html(data);
				}
			)
	}	 
		
	});
	
	
	$('.order-page .quantity .minus').click(function(){
			
		var a = $(this).siblings('input').val();
		var garnir_id = $(this).siblings('input').attr('garnir_id');
		if(Number(a)!=1) {
			var sum = Number(a)-1;
			$(this).siblings('input').val(sum);
				  $.post(
			  "/ajax/cart_function.php",
			  {
				action:'edit_quantity',
				id: $(this).attr('id_edit'),
			    garnir_id:garnir_id,
				qn: $(this).siblings('input').val()

				 
			  },
			  function onAjaxSuccess(data)
				{

				  // Здесь мы получаем данные, отправленные сервером и выводим их на экран.
				   $('.summaryy').html(data);
				}
			)
			 
			
		}
	});
	
	
	//удаление товара из корзины
	$('.summaryy .del').click(function() {  
		var iddel = $(this).attr('id_or');
		var garnir_id = $(this).attr('garnir_id');
		//var garnir_id2 = $(this).attr('garnir_id2');
		var garnir = $(this).attr('garnir');
		$.post(
		  "/ajax/cart_function.php",
		  {
			id: iddel,
			action:'delete',
			garnir_id:garnir_id
			
		  },
		  onAjaxSuccess
		)
	 
		function onAjaxSuccess(data)
		{
		  // Здесь мы получаем данные, отправленные сервером и выводим их на экран.
		  $('.summaryy').html(data);
		  
		  
		}
				
		})	
	
	
	
		
//регистрация с корзины
	$('.reg-order').click(function() {
		var iddel = $(this).attr('id_or');
		var name = $('#ORDER_PROP_1').val();
		var phone = $('#ORDER_PROP_3').val();
		var email = $('#ORDER_PROP_2').val();
		var adress = $('#ORDER_PROP_7').val();
		var company = $('#ORDER_PROP_12').val();
		var error = [0];
			
		if(name=='' || name.length<2){
			$('#ORDER_PROP_1').css('border','1px solid red');
			error.push(1);
		} else {
			$('#ORDER_PROP_1').css('border','1px solid #ddded6');
			error.push(0);
			
		}
		if(company=='' || company.length<2){
			$('#ORDER_PROP_12').css('border','1px solid red');
			error.push(1);
		} else {
			$('#ORDER_PROP_12').css('border','1px solid #ddded6');
			error.push(0);
			
		}
		if(phone=='' || phone.length<2 || phone=='+7 (___) ___-__-__'){
			$('#ORDER_PROP_3').css('border','1px solid red');
			error.push(1);
		} else {
			$('#ORDER_PROP_3').css('border','1px solid #ddded6');
			error.push(0);
			
		}
		
		var emailisset = 0;
		var pattern = /^([a-z0-9_\.-])+@[a-z0-9-]+\.([a-z]{2,4}\.)?[a-z]{2,4}$/i;
		if(pattern.test(email)){
			var emailerr=0;
		} else {
			var emailerr=1;
		}
		if(email=='' || email.length<2 || emailerr==1){
			$('#ORDER_PROP_2').css('border','1px solid red');
			error.push(1);
		} else {
			
			$('#ORDER_PROP_2').css('border','1px solid #CCCCCC');
			error.push(0);
		}
		
		if(adress=='' || adress.length<2){
			$('#ORDER_PROP_7').css('border','1px solid red');
			error.push(1);
		} else {
			$('#ORDER_PROP_7').css('border','1px solid #ddded6');
			error.push(0);
			
		}
		var err=0;
		for (i in error){ 
			//console.log(error[i]);
			if (error[i]==1){
				err=1;
			}
		}
		if (err==0 && emailisset==0){ 
			$.post(
			  "/ajax/cart_function.php",
			  {
				name:$('#ORDER_PROP_1').val(),
				phone:$('#ORDER_PROP_3').val(),
				email:$('#ORDER_PROP_2').val(),
				company:$('#ORDER_PROP_12').val(),
				adress:$('#ORDER_PROP_7').val(),
				action:'reg_order'
				 
			  },function onAjaxSuccess(data)
				{
				  // Здесь мы получаем данные, отправленные сервером и выводим их на экран.
				  $('.summaryy').html(data);
				  //$('.auth_ok').html('<p>Вы успешно зарегистрированы на сайте и можете продлжить оформление заказа</p>');
				  
				}
			  
			)
		 
			/*function onAjaxSuccess(data)
			{
			  // Здесь мы получаем данные, отправленные сервером и выводим их на экран.
			  $('.summaryy').html(data);
			  $('.auth_ok').html('<p>Вы успешно зарегистрированы на сайте и можете продлжить оформление заказа</p>');
			  
			}*/
		}	
			return false;	
	})	
//авторизация 
	$('#auth_button_order').click(function() {
		
		
			$.post(
			  "/ajax/cart_function.php",
			  {
				login:$('#login_order').val(),
				pass:$('#password_order').val(),
				action:'login'
				 
			  },function onAjaxSuccess(data){
				  // Здесь мы получаем данные, отправленные сервером и выводим их на экран.
				  $('.summaryy').html(data);
				  
				   
				  
			  }
			  
			  )
		 
			
		
			return false;	
	})		

		
	$('.content .right .plitka .item .col .bottom').hover(
function(){
 // $(this).children('.lupa').attr('style','position: absolute; margin: -150px 0px 0px 0px; display: block;');
},
function(){
  //$(this).children('.lupa').attr('style','position: absolute; margin: -150px 0px 0px 0px; display: none;');
});
	
	
$('.content .right .itemitemproduct').hover(
function(){
 // $(this).children('.lupa2').css('display','block');
 // $(this).children('.lupa').css('display','block');
},
function(){
//  $(this).children('.lupa2').css('display: none');
 // $(this).children('.lupa').css('display: none');
});
	


$('.content .chik .bl .bl-item img.list').hover(
function(){
  $(this).attr('src','/img/bl-item-list-hover.png');
},
function(){
  $(this).attr('src','/img/bl-item-list.png');
});



$('.content .chik .kompleks .plitka .item .col .bottom').hover(
function(){
  //$(this).children('.lupa').attr('style','position: absolute; margin: -150px 0px 0px 0px; display: block;');
},
function(){
 // $(this).children('.lupa').attr('style','position: absolute; margin: -150px 0px 0px 0px; display: none;');
});



//////////      ВСПЛЫВАЮЩИЕ ОКНА      //////////


/*$('.reg-order').click(
	function(){
		$('.reg-vspl, .allfon').attr('style','display:block;');
		});*/
$('.est-rega').click(
	function(){
		$('.order_vspl, .allfon').attr('style','display:block;');
		$('#action').val('order');
		return false;	
		});		

$('.login-vspl .top .close, .allfon').click(
	function(){
		$('.login-vspl, .allfon').attr('style','display:none;');
		});

$('.header-center .login .text a.log').click(
	function(){
		$('.auth_vspl, .allfon').attr('style','display:block;');
		$('#action').val('');
		});
	
	
		

$('.reg-vspl .top .close, .allfon').click(
	function(){
		$('.reg-vspl, .allfon').attr('style','display:none;');
		});




$('.header-center .login .text a.reg').click(
	function(){
		$('.reg-vspl, .allfon').attr('style','display:block;');
		});


$('.reg-th-vspl .top .close, .allfon').click(
	function(){
		$('.reg-th-vspl, .allfon').attr('style','display:none;');
		});



$('.podr-vspl .top .close, .allfon').click(
	function(){
		$('.podr-vspl, .allfon').attr('style','display:none;');
		return false;	
		});

$('.content .chik .bl .bl-item a').click(function(){
	$('.podr-vspl, .allfon').attr('style','display:block;');
	var id = $(this).attr('idbl');
	var kkal = $('#kkal'+id).val();
	var ves = $('#ves'+id).val();
	var sostav = $('#sostav'+id).val();
	var img = $('#imgval'+id).attr('src');
	var price = $('#price'+id).val();
	var idname = $('#idname'+id).text();
	
	$('.podr-vspl h1').text(idname);
	$('.podr-vspl .bottom .info .sostavvspl').text(sostav);
	$('.podr-vspl .bottom .info .vesvspl span').text(ves);
	$('.podr-vspl .bottom .info .kkalvspl span').text(kkal);
	$('.podr-vspl .bottom .info .price span').text(price+' руб.');
	$('.podr-vspl .bottom img').attr('src',img);
	return false;	
});
		
		
		


$('.content .chik .kompleks .individ .item a').click(function(){
	$('.ind-vspl, .allfon').attr('style','display:block;');
});

$('.content .chik .kompleks  .izm').on('click',function(){
	var cat = $(this).attr('cat');
	var catname = $(this).attr('catname');
	var idr = $(this).attr('idr');
	var index = $(this).attr('index');
	var id_kompleks = $(this).attr('id_kompleks');
	var day = $(this).attr('day');
	var max_price = $(this).attr('max_price');
	$('.ind-vspl, .allfon').attr('style','display:block;');	
			$.post(
			  "/ajax/ajax_function.php",
			  {
				cat:cat,
				catname:catname,
				idr:idr,
				index:index,
				id_kompleks:id_kompleks,
				day:day,
				max_price:max_price,
				action:'kompleks_izm'
				 
			  },function onAjaxSuccess(data){
				  // Здесь мы получаем данные, отправленные сервером и выводим их на экран.
				  $('.ind-vspl').html(data);
				  
				  
				  $('.ind-vspl .top .close, .allfon').click(function(){
					$('.ind-vspl, .allfon').attr('style','display:none;');
				  });	
			  }
			  
			);
			
		
});
$('.content .chik .kompleks  .individ .izmindiv').on('click',function(){
	var cat = $(this).attr('cat');
	var catname = $(this).attr('catname');
	var day = $(this).attr('day');
	var idr = $(this).attr('idr');
	var limit = $(this).attr('limit');
	
	$('.ind-vspl, .allfon').attr('style','display:block;');	
			$.post(
			  "/ajax/ajax_function.php",
			  {
				cat:cat,
				catname:catname,
				day:day,
				idr:idr,
				limit:limit,
				action:'individ'
				 
			  },function onAjaxSuccess(data){
				  // Здесь мы получаем данные, отправленные сервером и выводим их на экран.
				  $('.ind-vspl').html(data);
				  
				  
				  $('.ind-vspl .top .close, .allfon').click(function(){
					$('.ind-vspl, .allfon').attr('style','display:none;');
				  });	
			  }
			  
			);
			
		
});
	

var date = new Date();
var hour = date.getHours();
//var minutes = date.getMinutes();
//var seconds = date.getSeconds();
//var time = +hour+":"+minutes+":"+seconds
 

if(hour>=17) {
	$('#clock-none').attr('style','display:block');
	$('#clock').attr('style','display:none');
	$('.content .right .time-up h4.8hour').attr('style','display:block');
	$('.content .right .time-up h4.16hour').attr('style','display:none');
	$('.header-bottom .header-bottom-center .phone div.text.h16').attr('style','opacity: 0.40;');
}

if(hour<8) {
	$('#clock-none').attr('style','display:block');
	$('#clock').attr('style','display:none');
	$('.content .right .time-up h4.8hour').attr('style','display:block');
	$('.content .right .time-up h4.16hour').attr('style','display:none');
	$('.header-bottom .header-bottom-center .phone div.text.h16').attr('style','opacity: 1;');
}





	
	$('.bl').on('click','.blicon',function(){
		var blbl = $(this).attr('blbl');
		var blbludo = $(this).attr('blbludo');
		
		var blitin =  $('.bl'+blbl+' .blbludo'+blbludo+' .blitin.metclick1');
		var tuzap = $('.bl'+blbl+' .blbludo'+blbludo+' .blitin.metclick2');
		var tuzap_html = tuzap.html();
		if (tuzap_html){//alert(tuzap_html);
			
			var new_blitin_html =  tuzap_html;
			tuzap.html(blitin.html());
		} else {
			if (blbl==1){
				
				var blbl2 = 2; 
			} else {
				
				var blbl2 = 1;
			}
			var new_blitin1_p =  $('.bl'+blbl+' .blbludo'+blbludo+' .blitin.metclick1 p').html();
			var new_blitin_p =  $('.bl'+blbl2+' .blbludo'+blbludo+' .blitin.metclick1 p').html();
			
			var new_blitin =  $('.bl'+blbl2+' .blbludo'+blbludo+' .blitin.metclick1');
			var new_blitin33_html =  $('.bl'+blbl2+' .blbludo'+blbludo+' .blitin.metclick2').html();
			var new_blitin_html =  new_blitin.html();
			var blitin_html =  blitin.html();
			if (new_blitin_p==new_blitin1_p){
				blitin_html = new_blitin_html;
				new_blitin_html =  new_blitin33_html;
				if (!new_blitin_html){
					new_blitin_html =  new_blitin.html();
				} 
			} else {
				//alert(new_blitin_htm) ;
			}
			blitin.after('<div class="blitin metclick2 blitin_none">'+blitin_html+'</div>');
		}
		
		
				
		$('.bl'+blbl+' .blbludo'+blbludo+' .blitin.metclick1').html(new_blitin_html);
		$('.bl'+blbl+' .blbludo'+blbludo+' .blitin.metclick1 .blicon').attr('blbl',blbl);
		
		
		return false;	
	});
	
	$('.lk .history-item .top-item .close-zakaz img').click( function () {
	
	if($(this).parents().siblings('.togle').attr('style')=='display: none;') {
		
		$(this).parents().siblings('.togle').slideDown('slow');
		$(this).attr('src','/img/close-zakaz.png');
		$(this).siblings('span').html('Закрыть заказ');
		}
		
		else {
			$(this).parents().siblings('.togle').slideUp('slow');
			$(this).attr('src','/img/close-zakaz-2.png');
			$(this).siblings('span').html('Открыть заказ');
		}	
});



//$('.lk .history-item .top-item .close-zakaz img').toggle(function () {
      //$(this).parents().siblings('.togle').slideUp('slow');
  //  },
    
   // function () {
     // $(this).parents().siblings('.togle').slideDown('slow');
   // }
    
    
   // );
   
   $('.kitchen .gallery div a, .rd .rd-gallery div a, .fg .fg-gallery div a').hover(function() {
   	
   	$(this).children('.hover').attr('style','display:block;');
   	
   },
   
   function() {
   	
   	$(this).children('.hover').attr('style','display:none;');
   	
   });
   
   
   
     $('.site-help .help-item a.lh').hover(function() {
   	
   	$(this).children('.lupa').attr('style','display:block;');
   	
   },
   
   function() {
   	
   	$(this).children('.lupa').attr('style','display:none;');
   	
   });
   
   
   
   
   
   // Категории в рецептах //
   
   $(".recepts .recept-cat span.rc-1 a").hover(
		function(){
  			$(this).siblings('img').attr('src','/img/recepts-img-hover-1.png'); 
			},
		function(){
  			$(this).siblings('img').attr('src','/img/recepts-img-1.png');
		});
		
	$(".recepts .recept-cat span.rc-2 a").hover(
		function(){
  			$(this).siblings('img').attr('src','/img/recepts-img-hover-2.png'); 
			},
		function(){
  			$(this).siblings('img').attr('src','/img/recepts-img-2.png');
		});
		
		$(".recepts .recept-cat span.rc-3 a").hover(
		function(){
  			$(this).siblings('img').attr('src','/img/recepts-img-hover-3.png'); 
			},
		function(){
  			$(this).siblings('img').attr('src','/img/recepts-img-3.png');
		});
		
		$(".recepts .recept-cat span.rc-4 a").hover(
		function(){
  			$(this).siblings('img').attr('src','/img/recepts-img-hover-4.png'); 
			},
		function(){
  			$(this).siblings('img').attr('src','/img/recepts-img-4.png');
		});
		
		$(".recepts .recept-cat span.rc-5 a").hover(
		function(){
  			$(this).siblings('img').attr('src','/img/recepts-img-hover-5.png'); 
			},
		function(){
  			$(this).siblings('img').attr('src','/img/recepts-img-5.png');
		});
		
		$(".recepts .recept-cat span.rc-6 a").hover(
		function(){
  			$(this).siblings('img').attr('src','/img/recepts-img-hover-6.png'); 
			},
		function(){
  			$(this).siblings('img').attr('src','/img/recepts-img-6.png');
		});
    
   
		//страница стать клиентом
		$('.listkompany label').click(function(){
			var this_name = $(this).text(); 
			$('.listkompany label').removeClass('listkompanyactiv');
			$(this).addClass('listkompanyactiv');
			$('#kto').val(this_name);
		})
		
		$('.clientmymmenu a').click(function(){
			if($(this).attr('vibrano')==0){
				$(this).addClass('check');
				$(this).text('Выбрано');
				$(this).attr('vibrano',1);
			} else {
				$(this).removeClass('check');
				$(this).text('Выбрать');
				$(this).attr('vibrano',0);
			}
			
			return false;	
		})
		
		 $('#summa_client').keyup(function() {
			var summ = parseInt(($(this).val()));
			var qn = parseInt(($('.zhel-col .quantity .qn').val()));
			if (summ!=0){
				var ob_summ = summ*qn;
				var summ_nachel = summ/qn;
				
			}else {
				var ob_summ =0;
				var summ_nachel = 0;
			}
			var summ_napitok = qn;
			$('#ob_summ').text(ob_summ);
			$('#summ_nachel').text(summ.toFixed());
			$('#summ_napitok').text(summ_napitok);
			
		});
		
		
		$('.zhel-col .quantity .plus,.zhel-col .quantity .minus').click(function(){
			var summ = parseInt(($('#summa_client').val()));
			var qn = parseInt(($('.zhel-col .quantity .qn').val()));
			if (summ && summ!=0){
				var ob_summ = summ*qn;
				var summ_nachel = summ/qn;
				
			}else {
				var ob_summ =0;
				var summ_nachel = 0;
			}
			var summ_napitok = qn;
			$('#ob_summ').text(ob_summ);
			$('#summ_nachel').text(summ.toFixed());
			$('#summ_napitok').text(summ_napitok);
			
			return false;	
		})
		
		//стать клиентом
		$('#otpr_zlient').click(function(){
			var kto = $('#kto').val(); 
			var summa_client = $('#summa_client').val(); 
			
			var qn = parseInt(($('.zhel-col .quantity .qn').val()));
			var ob_summ = summa_client*qn;
			var summ_nachel = summa_client;
		
			var clientmymmenuArr = [];
			$('.clientmymmenu a').each(function(){
				var vibrano = $(this).attr('vibrano');
				var vibrano_name = $(this).attr('href');
				if (vibrano==1){
					clientmymmenuArr.push(vibrano_name);
				}
			})
			
			var clientmymmenu = clientmymmenuArr.join(', '); 
			var posostavuArr = [];
			$('.posostavu li input').each(function(){
				
				if ($(this).prop('checked')){
					posostavuArr.push($(this).val());
				}
			})
			var posostavu = posostavuArr.join(', '); 
			var tolkobludaArr = [];
			$('.tolkobluda li input').each(function(){
				
				if ($(this).prop('checked')){
					tolkobludaArr.push($(this).val());
				}
			})
			var tolkobluda = tolkobludaArr.join(', '); 
			var ingridienttArr = [];
			$('.ingridientt li input').each(function(){
				
				if ($(this).prop('checked')){
					ingridienttArr.push($(this).val());
				}
			})
			var ingridientt = ingridienttArr.join(', '); 
			var nameclient = $('#nameclient').val();
			var code_tel = $('#code_tel').val();
			var tel_client = $('#tel_client').val();
			var email_client = $('#email_client').val();
			var error = [0];
			
			if(summa_client=='' || summa_client.length<2){
				$('#summa_client').css('border','1px solid red');
				error.push(1);
			} else {
				$('#summa_client').css('border','1px solid #ddded6');
				error.push(0);
				
			}
			
			if(nameclient=='' || nameclient.length<2){
				$('#nameclient').css('border','1px solid red');
				error.push(1);
			} else {
				$('#nameclient').css('border','1px solid #ddded6');
				error.push(0);
				
			}
			
			
			var pattern = /^([a-z0-9_\.-])+@[a-z0-9-]+\.([a-z]{2,4}\.)?[a-z]{2,4}$/i;
			if(pattern.test(email_client)){
				var emailerr=0;
			} else {
				var emailerr=1;
			}
			if(email_client=='' || email_client.length<2 || emailerr==1){
				$('#email_client').css('border','1px solid red');
				error.push(1);
			} else {
				
				$('#email_client').css('border','1px solid #CCCCCC');
				error.push(0);
				
				
			}
			
			var err=0;
			for (i in error){ 
				//console.log(error[i]);
				if (error[i]==1){
					err=1;
				}
			}
			if (err==0){ 
				$('#err1').css('opacity',0);	
				$.ajax({
					url: '/ajax/ajax_function.php', 
					type: 'post',
					data: '&kto='+kto+'&summa_client='+summa_client+'&summ_nachel='+summ_nachel+'&qn='+qn+'&clientmymmenu='+clientmymmenu+'&posostavu='+posostavu+'&ingridientt='+ingridientt+'&nameclient='+nameclient+'&tolkobluda='+tolkobluda+'&code_tel='+code_tel+'&tel_client='+tel_client+'&email_client='+email_client+'&ob_summ='+ob_summ+'&action=stat_clientom',
					success: function(data){
						
						$('#otpr_zlient').val('Заявка отправлена').css('background','#d4d2d3');
						
					}
				 });
			} else {
				
				$('#err1').css('opacity',1);
			}
			
			
			return false;	
		})
		
		//регистрация
		
		$('.reg-vspl #reg_submit').click(function(){
			var company = $('#company').val(); 
			var name = $('#name').val(); 
			var code = $('#code').val(); 
			var phone = $('#phone').val(); 
			var email = $('#email').val(); 
			var pass = $('#pass').val(); 
			var confirm_pass = $('#confirm_pass').val(); 
			var adress = $('#adress').val(); 
			
			var error = [0];
			if(name=='' || name.length<2){
				$('#name').addClass('inp-error');
				error.push(1);
			} else {
				$('#name').removeClass('inp-error');
				error.push(0);
				
			}
			
			/*var pattern = /^([a-z0-9_\.-])+@[a-z0-9-]+\.([a-z]{2,4}\.)?[a-z]{2,4}$/i;
			if(pattern.test(email)){
				var emailerr=0;
			} else {
				var emailerr=1;
			}*/
			//if(email=='' || email.length<2 || emailerr==1){
			if(email=='' || email.length<2){	
				$('#email').addClass('inp-error');
				error.push(1);
			} else {
				
				$('#email').removeClass('inp-error');
				error.push(0);
			}
			if(company=='' || company.length<2){
				$('#company').addClass('inp-error');
				error.push(1);
			} else {
				$('#company').removeClass('inp-error');
				error.push(0);
				
			}
			if(adress=='' || adress.length<2){
				$('#adress').addClass('inp-error');
				error.push(1);
			} else {
				$('#adress').removeClass('inp-error');
				error.push(0);
				
			}
			if(confirm_pass=='' || confirm_pass.length<2){
				$('#confirm_pass').addClass('inp-error');
				error.push(1);
			} else {
				$('#confirm_pass').removeClass('inp-error');
				error.push(0);
				
			}
			var errorpasskol = 0;
			var errorpass_confirm = 0;
			if(pass=='' || pass.length<6){
				$('#pass').addClass('inp-error');
				error.push(1);
				errorpasskol = 1;
			} else {
				$('#pass').removeClass('inp-error');
				error.push(0);
				errorpasskol = 0;
				if (pass!=confirm_pass){
					errorpass_confirm = 1;
				}
			}
			
			var err=0;
			for (i in error){ 
				//console.log(error[i]);
				if (error[i]==1){
					err=1;
				}
			}
			if (err==0 && errorpasskol==0 && errorpass_confirm==0){ 
				$('#err2').css('display','none');
				$('#err3').css('display','none');
				$('#err4').css('display','none');
				$('#err5').css('display','none');
				$('.reg-vspl .otvet_script_reg').html('');
				$.ajax({
					url: '/ajax/ajax_function.php', 
					type: 'post',
					data: '&company='+company+'&name='+name+'&code='+code+'&phone='+phone+'&email='+email+'&pass='+pass+'&confirm_pass='+confirm_pass+'&adress='+adress+'&action=reg',
					success: function(data){
						
						$('.reg-vspl .otvet_script_reg').html(data);
						
					}
				 });
			} else {
				if (err==1){
					$('#err2').css('display','block');
				} else {
					$('#err2').css('display','none');
				}
				if (errorpasskol==1){
					$('#err3').css('display','block');
				}else {
					$('#err3').css('display','none');
				}
				if (errorpass_confirm==1){
					$('#err4').css('display','block');
				}else {
					$('#err4').css('display','none');
				}
				
			}
			
			
			return false;
		})
		
		//авторизация
	$('#auth_button').click(function(){
			
		
			var login = $("#login").val();
			var pass = $("#password").val();
			
			var error = [0];
			if(login==''){
				$('#login').addClass('inp-error');
				error.push(1);
			} else {
				$('#login').removeClass('inp-error');
				error.push(0);
				
			}
			if(pass==''){
				$('#password').addClass('inp-error');
				error.push(1);
			} else {
				$('#password').removeClass('inp-error');
				error.push(0);
				
			}
			var err=0;
			for (i in error){ 
				//console.log(error[i]);
				if (error[i]==1){
					err=1;
				}
			}
			if (err==0){ 
				$('#err_auth').html('');
				  $.post(
				  "/ajax/ajax_function.php",
				  {
					action:'auth',
					login: login,
					pass: pass

					 
				  },
				  function onAjaxSuccess(data)
					{

					  if (data==1){
						  window.location.href = "http://obed-office.ru/";
					  }else {
						$('#err_auth').html(data);
					  }
					  
					}
				)
			} else {
				$('#err_auth').html('Заполните обязательне поля');
			}
			 
		return false;	
		
	});
		
		$('.add_individ,.add_bl').click(function(){
			if($(this).hasClass('garnir_add')){
				
			} else {
				$(this).addClass('seriybutton').text('Добавлено');
			}
		})
		
	//для личного кабинета
	$('.zakaz-body-future .quantity .plus').click(function(){
		
	var a = $(this).siblings('input').val();
	var qn = Number(a)+1;
	//$(this).siblings('input').val(sum);
	var id_edit = $(this).attr('id_edit');
	var price = $(this).attr('price');
	
		  $.post(
		  "/ajax/cart_function_lk.php",
		  {
			action:'edit_quantity_lk',
			id: id_edit,

			qn: qn

			 
		  },
		  function onAjaxSuccess(data)
			{	
			  // Здесь мы получаем данные, отправленные сервером и выводим их на экран.
			   $('.idor'+id_edit+' .quantity input').val(data);
			   
			    $('.idor'+id_edit+' .col-4').html((price*data)+' <span>руб</span>');
			}
		)
		 
		
	});
	
	
	$('.zakaz-body-future .quantity .minus').click(function(){
			
		/*var a = $(this).siblings('input').val();
		if(Number(a)!=1) {
			var qn = Number(a)-1;
			var id_edit = $(this).attr('id_edit');
			var price = $(this).attr('price');
			  $.post(
			  "/ajax/cart_function_lk.php",
			  {
				action:'edit_quantity_lk',
				id: id_edit,
			  
				qn: qn

				 
			  },
			  function onAjaxSuccess(data)
				{

				  // Здесь мы получаем данные, отправленные сервером и выводим их на экран.
				  $('.idor'+id_edit+' .quantity input').val(data);
			      $('.idor'+id_edit+' .col-4').html((price*data)+' <span>руб</span>');
				}
			)
			 
			
		}*/
	});
	
	
	//удаление товара из лк
	$('.summary_lk .del').click(function() {
		
		var iddel = $(this).attr('id_or');
		
		$.post(
		  "/ajax/cart_function_lk.php",
		  {
			id: iddel,
			action:'delete_lk'
			 
		  },
		  onAjaxSuccess
		)
	 
		function onAjaxSuccess(data)
		{
		  // Здесь мы получаем данные, отправленные сервером и выводим их на экран.
		   $('.idor'+iddel).html('');
		  
		}
				
		})		
	//сохранить перс данные]	
	$('.edit_pd').click(function() {
		var user_id = $(this).attr('user_id');
		var NAME = $('#NAME').val();
		var LAST_NAME = $('#LAST_NAME').val();
		var WORK_COMPANY = $('#WORK_COMPANY').val();
		var EMAIL = $('#EMAIL').val();
		var PERSONAL_BIRTHDAY = $('#PERSONAL_BIRTHDAY').val();
		var PERSONAL_GENDER = $('#PERSONAL_GENDER').val();
		
		
		$.post(
		  "/ajax/ajax_function.php",
		  {
			user_id: user_id,
			NAME: NAME,
			LAST_NAME: LAST_NAME,
			WORK_COMPANY: WORK_COMPANY,
			EMAIL: EMAIL,
			PERSONAL_BIRTHDAY: PERSONAL_BIRTHDAY,
			PERSONAL_GENDER: PERSONAL_GENDER,
			action:'edit_pd'
			 
		  },
		  onAjaxSuccess
		)
	 
		function onAjaxSuccess(data)
		{
		  // Здесь мы получаем данные, отправленные сервером и выводим их на экран.
		  $('.res_edit').html(data);
		  setTimeout (function(){
			$('.res_edit').html('');
		  },3000)
		  
		}
	return false;			
	})
//сохранить телефон	
	$('.edit_phone').click(function() {
		var user_id = $(this).attr('user_id');
		var WORK_PHONE = $('#WORK_PHONE').val();
		var PERSONAL_PHONE = $('#PERSONAL_PHONE').val();
		
		
		
		$.post(
		  "/ajax/ajax_function.php",
		  {
			user_id: user_id,
			PERSONAL_PHONE: PERSONAL_PHONE,
			WORK_PHONE: WORK_PHONE,
			action:'edit_phone'
			 
		  },
		  onAjaxSuccess
		)
	 
		function onAjaxSuccess(data)
		{
		  // Здесь мы получаем данные, отправленные сервером и выводим их на экран.
		  $('.res_edit2').html(data);
		  setTimeout (function(){
			$('.res_edit2').html('');
		  },3000)
		  
		}
	return false;			
	})	
//сохранить адресс	
	$('.edit_adress').click(function() {
		var user_id = $(this).attr('user_id');
		var PERSONAL_CITY = $('#PERSONAL_CITY').val();
		var PERSONAL_STREET = $('#PERSONAL_STREET').val();
		var UF_HOUSE = $('#UF_HOUSE').val();
		var UF_KVARTIRA = $('#UF_KVARTIRA').val();
		var UF_PODEZD = $('#UF_PODEZD').val();
		var UF_DOMOFON = $('#UF_DOMOFON').val();
		var UF_ETAZH = $('#UF_ETAZH').val();
		
		
		
		$.post(
		  "/ajax/ajax_function.php",
		  {
			user_id: user_id,
			PERSONAL_CITY: PERSONAL_CITY,
			PERSONAL_STREET: PERSONAL_STREET,
			UF_HOUSE: UF_HOUSE,
			UF_KVARTIRA: UF_KVARTIRA,
			UF_PODEZD: UF_PODEZD,
			UF_DOMOFON: UF_DOMOFON,
			UF_ETAZH: UF_ETAZH,
			action:'edit_adress'
			 
		  },
		  onAjaxSuccess
		)
	 
		function onAjaxSuccess(data)
		{
		  // Здесь мы получаем данные, отправленные сервером и выводим их на экран.
		  $('.res_edit3').html(data);
		  setTimeout (function(){
			$('.res_edit3').html('');
		  },3000)
		  
		}
	return false;			
	})	

	//изменить сотрудника
	$('.edit_sotr').click(function() {
		var user_id = $(this).attr('user_id');
		var UF_SOTRUDNIK_VALUE = $('#SOTRUDNIKI').val();
		
		
		$.post(
		  "/ajax/ajax_function.php",
		  {
			user_id: user_id,
			UF_SOTRUDNIK_VALUE: UF_SOTRUDNIK_VALUE,
			action:'edit_sotr'
			 
		  },
		  onAjaxSuccess
		)
	 
		function onAjaxSuccess(data)
		{
		  // Здесь мы получаем данные, отправленные сервером и выводим их на экран.
		  $('.res_edit4').html(data);
		  setTimeout (function(){
			$('.res_edit4').html('');
		  },3000)
		  
		}
	return false;			
	})	
//добавить сотрудника
	$('.add_sotr').click(function() {
		var user_id = $(this).attr('user_id');
		var ADD_SOTR = $('#ADD_SOTR').val();
		if (ADD_SOTR!='' &&  ADD_SOTR.length>5){
			
		
			$.post(
			  "/ajax/ajax_function.php",
			  {
				user_id: user_id,
				ADD_SOTR: ADD_SOTR,
				action:'add_sotr'
				 
			  },
			  function onAjaxSuccess(data)
				{
				  // Здесь мы получаем данные, отправленные сервером и выводим их на экран.
				  $('.res_edit5').html(data);
				  setTimeout (function(){
					$('.res_edit5').html('');
				  },3000)
				  
				}
			)
		 
			
		} else {
			
		}
	return false;			
	})	
	//стать клиентом в 1 клик
	$('#onestat').click(function() { 
		
		var onename = $('#onename').val();
		var onephone = $('#onephone').val();
		if(onename=='' || onephone=='' ){
			if (onename==''){
				$('#onename').addClass('inp-error');
			} else {
				$('#onename').removedClass('inp-error');
			}
			if (onephone==''){
				$('#onephone').addClass('inp-error');
			} else {
				$('#onephone').removedClass('inp-error');
			}
			
		} else {
			
			$.post(
			  "/ajax/ajax_function.php",
			  {
				onename: onename,
				onephone: onephone,
				action:'onestat'
				 
			  },
			  function onAjaxSuccess(data)
				{
				  // Здесь мы получаем данные, отправленные сервером и выводим их на экран.
				  $('.res_stat').html(data);
				  setTimeout (function(){
					$('.res_stat').html('');
				  },3000)
				  
				}
			)
		}
		
			
		
			
		 
			
		
	return false;			
	})

	//меню скачать
	$('.xls-vspl .close, .allfon').click(
		function(){
			$('.xls-vspl, .allfon').attr('style','display:none;');
			return false;	
			});
	$('.limit-vspl .close, .allfon').click(
		function(){
			$('.limit-vspl, .allfon').attr('style','display:none;');
			return false;	
			});		
	
	$('.xsldonw').click(function(){
		$('.xls-vspl, .allfon').attr('style','display:block;');
		
		return false;	
	});
	//гарнир выбирать да или нет окно
	$('.garnir-vspl .close, .allfon').click(
		function(){
			$('.garnir-vspl, .allfon').attr('style','display:none;');
			return false;	
			});

	/*$('.add-plitka.garnir_add').click(function(){
		$('.garnir-vspl, .allfon').attr('style','display:block;');
		
		return false;	
	});*/
	//экскурсионная группа
	$('#zayavka_ex').click(function(){
			
			var summa_ex = $('#summa_ex').val(); 
			var data_pit = $('#data_pit').val(); 
			var kompany = $('#kompany').val(); 
			var name = $('#name').val(); 
			var phone = $('#phone').val(); 
			var email = $('#email').val(); 
			var comment = $('#comment').val(); 
		
			var radiobut = '';
			$('#radiobut input').each(function(){
				if ($(this).prop('checked')){
					radiobut = $(this).val();
				}
			})
			
			
			var posostavuArr = [];
			$('.posostavu li input').each(function(){
				
				if ($(this).prop('checked')){
					posostavuArr.push($(this).val());
				}
			})
			var posostavu = posostavuArr.join(', '); 
			var tolkobludaArr = [];
			$('.tolkobluda li input').each(function(){
				
				if ($(this).prop('checked')){
					tolkobludaArr.push($(this).val());
				}
			})
			var tolkobluda = tolkobludaArr.join(', '); 
			var ingridienttArr = [];
			$('.ingridientt li input').each(function(){
				
				if ($(this).prop('checked')){
					ingridienttArr.push($(this).val());
				}
			})
			var ingridientt = ingridienttArr.join(', '); 
			
			var error = [0];
			
			if(summa_ex=='' || summa_ex.length<2){
				$('#summa_ex').css('border','1px solid red');
				error.push(1);
			} else {
				$('#summa_ex').css('border','1px solid #ddded6');
				error.push(0);
				
			}
			
			if(data_pit=='' || data_pit.length<2){
				$('#data_pit').css('border','1px solid red');
				error.push(1);
			} else {
				$('#data_pit').css('border','1px solid #ddded6');
				error.push(0);
				
			}
			
			if(kompany=='' || kompany.length<2){
				$('#kompany').css('border','1px solid red');
				error.push(1);
			} else {
				$('#kompany').css('border','1px solid #ddded6');
				error.push(0);
				
			}
			
			if(name=='' || name.length<2){
				$('#name').css('border','1px solid red');
				error.push(1);
			} else {
				$('#name').css('border','1px solid #ddded6');
				error.push(0);
				
			}
			
			if(phone=='' || phone.length<2){
				$('#phone').css('border','1px solid red');
				error.push(1);
			} else {
				$('#phone').css('border','1px solid #ddded6');
				error.push(0);
				
			}
			
			
			var pattern = /^([a-z0-9_\.-])+@[a-z0-9-]+\.([a-z]{2,4}\.)?[a-z]{2,4}$/i;
			if(pattern.test(email)){
				var emailerr=0;
			} else {
				var emailerr=1;
			}
			if(email=='' || email.length<2 || emailerr==1){
				$('#email').css('border','1px solid red');
				error.push(1);
			} else {
				
				$('#email').css('border','1px solid #CCCCCC');
				error.push(0);
				
				
			}
			
			var err=0;
			for (i in error){ 
				//console.log(error[i]);
				if (error[i]==1){
					err=1;
				}
			}
			if (err==0){ 
				$('#err1').css('opacity',0);	
				$.ajax({
					url: '/ajax/ajax_function.php', 
					type: 'post',
					data: '&summa_ex='+summa_ex+'&data_pit='+data_pit+'&kompany='+kompany+'&name='+name+'&phone='+phone+'&posostavu='+posostavu+'&ingridientt='+ingridientt+'&email='+email+'&tolkobluda='+tolkobluda+'&comment='+comment+'&radiobut='+radiobut+'&action=eskurs_groupp',
					success: function(data){
						
						$('.filter-but2').text('Заявка отправлена').css('background','#d4d2d3');
						
					}
				 });
			} else {
				
				$('#err1').css('opacity',1);
			}
			
			
			return false;	
		})
		
		$(".phonemask").inputmask("+7(999)999-99-99");//маска для телефона полностью
		$(".cod_phonemask").inputmask("+7(999)");//маска для телефона КОД
		$(".sostav_phonemask").inputmask("999-99-99");//маска для телефона СОСТАВ
		
		$('.pay1').click(function(){
			$('#oplata').val(1);
		})
		$('.pay2').click(function(){
			$('#oplata').val(2);
		})
		$('.pay3').click(function(){
			$('#oplata').val(4);
		})
		$('.pay4').click(function(){
			$('#oplata').val(5);
		})
		
		//оценка и коммент заказов
		$('.zakaz_cabitem').on('click','.ocnenkaorderbtn',function() {
			var ordertime = $(this).attr('ordertime');
			var comment = $('.den'+ordertime+' textarea').val();
			var id_order = $(this).attr('id_order');
			
			var id_basket = '';
			var ocenka = '';
			var idArr2 = [];
			$('.den'+ordertime+' .item-ordz').each(function(){
				id_basket = $(this).attr('id_bask');
				ocenka = $('#ocenkaval'+id_basket+' input:checked').val();
						
					if(ocenka){
						idArr2.push(id_basket+'|'+ocenka) 
						}
				
			})
			id_list = idArr2.join(';');
			console.log(id_list) ;	
			
				$.post(
				  "/ajax/ajax_function.php",
				  {
					id_list: id_list,
					id_order:id_order,
					comment: comment,
					action:'ocenka'
					 
				  },
				  function onAjaxSuccess(data)
					{
					  $('.ocnenkaorderbtn').val('Оценка отправлена').addClass('otprocenka');
					  // Здесь мы получаем данные, отправленные сервером и выводим их на экран.
					  $('.res_edit5').html(data);
					  setTimeout (function(){
						$('.res_edit5').html('');
					  },3000)
					  
					}
				)
			 
				
			
			return false;			
		})	
		
		//оценка и коммент заказов комплексных блюд
		$('.zakaz_cabitem').on('click','.kompleksocnenkaorderbtn',function() {
			var ordertime = $(this).attr('ordertime');
			var comment = $('.den'+ordertime+' textarea').val();
			var id_order = $(this).attr('id_order');
			
			var id_basket = '';
			var ocenka = '';
			var idArr2 = [];
			$('.den'+ordertime+' .item-ordzkompl').each(function(){
				var id_bludo = '';
				var ocenka_idbl = [];
				id_basket = $(this).attr('id_bask');
				$('.den'+ordertime+' .idorkompl'+id_basket+' .itemordzkomplbludo').each(function(){
					id_bludo = $(this).attr('id_bludo');
					ocenka = parseInt($('#ocenkaval'+id_basket+'_'+id_bludo+' input:checked').val());
						
					if(ocenka){
						ocenka = ocenka;
					} else{
						ocenka = '0';
					}
					
					ocenka_idbl.push(id_bludo+'-'+ocenka); 
				})		
				
				idArr2.push(id_basket+'|'+ocenka_idbl.join('*')) ;
				
			})
			
			id_list = idArr2.join(';');
			
			console.log(id_list) ;	
			
				$.post(
				  "/ajax/ajax_function.php",
				  {
					id_list: id_list,
					id_order:id_order,
					comment: comment,
					action:'ocenka_kompleks'
					 
				  },
				  function onAjaxSuccess(data)
					{
					  $('.kompleksocnenkaorderbtn').val('Оценка отправлена').addClass('otprocenka');
					  // Здесь мы получаем данные, отправленные сервером и выводим их на экран.
					  $('.res_edit5').html(data);
					  setTimeout (function(){
						$('.res_edit5').html('');
					  },3000)
					  
					}
				)
			 
				
			
			return false;			
		})
		//заблокируем кнопку после первого клика
		$('.bx_ordercart_order_pay_center').on('click','#order_button_cart',function() {
			$(this).addClass('disabledclass');
			//$(this).attr('disabled','disabled');
			$('.bx_ordercart_order_pay_center').on('click','#order_button_cart.disabledclass',function() {
				return false;		
				
			})
			
			
			
		})
		$('.bx_ordercart_order_pay_center').on('click','#order_button_cart.disabledclass',function() {
			return false;		
			
		})
		
		
		//скролл
		$(window).scroll(function() {
			if ($(this).scrollTop() > 200) {
				$('#arrowup').fadeIn(300); //скорость исчезновения кнопки
			} else {
		$('#arrowup').fadeOut(200); //скорость появления кнопки
			}
		});
		$('#arrowup').click(function() {
			$('body,html').animate({
				scrollTop: 0
			}, 200); //скорость прокрутки
			return false;
		});
		//выводим меню категорий на висячку при скроллинге
		var topdel_filter = 1;
		var formst = 1;
		var sect1075 = $('#sect1075').height(); 
		if(sect1075){
			//alert(topdel_filter);
			$(window).scroll(function() {
				 topdel_filter = $('#del_filter').offset().top;
				 formst = $('#formst').offset().top;
				 
				
				 if ($(this).scrollTop() >= topdel_filter) {
					$('#sect1075').addClass('absolutsec'); 
					
					console.log(parseInt($(this).scrollTop())+parseInt(sect1075)+'-'+formst);
					if((parseInt($(this).scrollTop())+parseInt(sect1075))>=formst){
						$('#sect1075.absolutsec').css({position:'absolute',top:(parseInt(formst)-parseInt(sect1075)-580)+'px'}); 
					} else {
						$('#sect1075.absolutsec').css({position:'fixed',top:'2px'}); 
					}
				 } else {
					$('#sect1075').removeClass('absolutsec').css({position:'static',top:'2px'}); 
					
					
				 }
			});
		}		
		
});