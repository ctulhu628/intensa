<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();
/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */
/** @var CBitrixComponent $component */
$this->setFrameMode(true);
?>

<?
$day = $GLOBALS['arrFilter1']['PROPERTY_DNI'];

					$limit = 0;
						global $USER;
						if ($USER->IsAuthorized()){ 
							$rsUser = CUser::GetByID($USER->GetID());
							$arUser = $rsUser->Fetch();
							
							if(isset($arUser['UF_LIMIT']) and $arUser['UF_LIMIT']!='' and $arUser['UF_LIMIT']!=0){
									$limit = $arUser['UF_LIMIT'];
							} 
						}
	///print_r($arResult['ITEMS']) ;
	
if (!empty($arResult['ITEMS']))
{
	$DATA_ARR = array();
		foreach($arResult['ITEMS'] as $itr){
			$dart = explode(' ',$itr['TIMESTAMP_X']);
			$DATA_ARR[] = strtotime($dart[0]);
		}
		$max_dat = max($DATA_ARR);
		//print_r(date('d.m.Y', $max_dat));
$cur_page_no_index = $APPLICATION->GetCurPage(false);


$uriusArr_plitka = array();
$uriusArr_spisok = array();
foreach($_GET as $key=>$get){
	$uriusArr_plitka[]= $key.'='.$get;
	$uriusArr_spisok[]= $key.'='.$get;
}
$uriusArr_spisok[] = 'p=spisok';
$uriusArr_plitka[]= 'p=plitka';
$urius_spisok = implode('&',$uriusArr_spisok);
$urius_plitka = implode('&',$uriusArr_plitka);

 ?>


	<? 
	//print_r($arResult['KATN']) ;
foreach($arResult['KATN'] AS $cat){
		
CModule::IncludeModule('highloadblock');
$hlblock_id = 4; // ID вашего Highload-блока
$hlblock = Bitrix\Highloadblock\HighloadBlockTable::getById( $hlblock_id )->fetch(); // получаем объект вашего HL блока
$entity = Bitrix\Highloadblock\HighloadBlockTable::compileEntity( $hlblock );  // получаем рабочую сущность
$entity_data_class = $entity->getDataClass(); // получаем экземпляр класса
$entity_table_name = $hlblock['TABLE_NAME']; // присваиваем переменной название HL таблицы
$sTableID = 'tbl_'.$entity_table_name; // добавляем префикс и окончательно формируем название
$arFilter = array("UF_XML_ID" => $cat); // зададим фильтр по ID пользователя
$arSelect = array('*'); // выбираем все поля
$arOrder = array("UF_SORT"=>"ASC"); // сортировка будет по возрастанию ID статей
 
// подготавливаем данные
$rsData = $entity_data_class::getList(array(
    "select" => $arSelect,
    "filter" => $arFilter,
 //ограничим выборку пятью элементами
    "order" => $arOrder
));
 
// выполняем запрос. Передаем в него наши данные и название таблицы, которое мы получили в самом начале
$rsData = new CDBResult($rsData, $sTableID); // записываем в переменную объект CDBResult

//echo $cat;echo '<br>';
// а далее простой цикл и знакомый нам метод Fetch (или GetNext, кому что нравится)
//if ($cat=='058713ab-0ded-11e6-a63e-901b0e581578'){
	
	?>
 
 <div class="sort_block">
	

	<div class="cl"></div>   
 </div>

<?
	foreach ($arResult['ITEMS'] as $item) {
  //print_r($item['DETAIL_TEXT']) ;
	$dart2 = explode(' ',$item['TIMESTAMP_X']);
			$datbl = strtotime($dart2[0]);
   if($max_dat==$datbl){
	if($item['PROPERTIES']['KATEGORIYA']['VALUE']==$cat){
		?>
		 

		<div class="cl"></div>
    						
    						
    						<div class="plitka el<?=$item['ID']?>">
    							<h4><?=$item['NAME']?></h4>
    							<div class="item">
    								<?/*?><div class="col col-1">
    									<div class="top">Фото</div>
    									<div class="bottom">
											<?if($item['PREVIEW_PICTURE']['SRC']==''){
												?>
												<img src="/images/no_foto/<?=$cat?>.jpg" />
												<?
											} else {
												?>
												
												<img src="<?=$item['PREVIEW_PICTURE']['SRC']?>" />
												<!--div class="hit"></div-->
												<div class="new" style="display: none;"></div>
												<a id="example1" class="lupa" href="<?=$item['PREVIEW_PICTURE']['SRC']?>"><img src="/img/lupa.png" /></a>
												<?
											}?>
    										
    									</div>
    								</div><?*/?>
    								<div class="col col-2 kopmsostav">
    									<div class="top">Состав обеда</div>
										<span class="prev<?=$item['ID']?> prevkompleks"></span>
    									<div class="bottom sostavlistkopleks " id="sostavlistkopleksslide<?=$item['ID']?>">
											
											<ul>
											<?
											//echo $item['DETAIL_TEXT'];
											$kkal=0;
											
												$sosatvArr = '';
											
												
													$sosatvArr = explode('*',$item['DETAIL_TEXT']); 
													
											
											$idx = 1;
											$price_for_econom = 0;
											foreach($sosatvArr as $XML_ID){
												$arSelect2 = Array();
												$arFilter2 = Array("IBLOCK_ID"=>40, "XML_ID"=>$XML_ID);
												$res = CIBlockElement::GetList(Array(), $arFilter2, false, Array(), $arSelect2);
												$catname='Без категории';
												
												while($ob = $res->GetNextElement())
												{
												 $arFields = $ob->GetFields();
												  $arProps = $ob->GetProperties();
												 //print_r($arFields);
												  $kkal+=$kkal+$arProps['KALORIYNOST']['VALUE'];
												  // подготавливаем данные
													$rsData2 = $entity_data_class::getList(array(
														"select" => array('*'),
														"filter" => array("UF_XML_ID" => $arProps['KATEGORIYA']['VALUE']),
													 //ограничим выборку пятью элементами
														"order" => $arOrder
													));
													 
													// выполняем запрос. Передаем в него наши данные и название таблицы, которое мы получили в самом начале
													$rsData2 = new CDBResult($rsData2, $sTableID); // записываем в переменную объект CDBResult
													IF($arRes2 = $rsData2->Fetch()){
														$catname=$arRes2['UF_NAME'];
														
													}
												  $ar_resPrice = CPrice::GetBasePrice($arFields['ID']); 
												   $rsFile =  CFile::GetPath($arFields['DETAIL_PICTURE']);
												   $ar_res = CPrice::GetBasePrice($arFields['ID']);
													
												?>	
													<li class="ind-item select itemforim<?=$arFields['ID']?> osntextindex<?=$idx?> osncatid<?=$arProps['KATEGORIYA']['VALUE']?>">
														<?if($rsFile==''){
															?>
															<img class="komlimgizmen" src="/images/no_foto/<?=$cat?>.jpg" />
															<?
														} else {?>
															<img class="komlimgizmen" src="<?=$rsFile?>" />
														<?}?>
														
														<!--div class="new"></div-->
														<h5><?=$arFields['NAME']?></h5>
														<p class="sosansosizmen"><?=$arProps['SOSTAV']['VALUE']?></p>
														<p class="info">Вес <span vesajax="<?=$arProps['VES_OBEM']['VALUE']?>"  class="vesajax kopnew"><?=$arProps['VES_OBEM']['VALUE']?></span> гр, Ккал 
														<span kkalajax="<?=$arProps['KALORIYNOST']['VALUE']?>" class="kkalajax kopnew"><?=$arProps['KALORIYNOST']['VALUE']?></span></p>
														<div class="price_div">Цена: <span class="price_individ kopnew kompprice"><?=$ar_res["PRICE"]?></span><span> руб.</span></div>
														<span cat="<?=$arProps['KATEGORIYA']['VALUE']?>" id_kompleks = "<?=$item['ID']?>" index=<?=$idx?> catname="<?=$catname?>" idr=<?=$arFields['ID']?> max_price="<?=(int)$ar_resPrice['PRICE']?>" idr_name="<?=$arFields['XML_ID']?>" day="<?=$day?>" class="izm index<?=$idx?> izm<?=$arProps['KATEGORIYA']['VALUE']?>">изменить</span>
														<p class="dnone sostav_p textindex<?=$idx?> catid<?=$arProps['KATEGORIYA']['VALUE']?>"><a id="example1" href="<?=$rsFile?>"><?=$arFields['NAME']?></a></p>
													
														
													</li>
												 <?
												 $price_for_econom += $ar_res["PRICE"];
												}
												$idx++;
												
											}
											//echo $price_for_econom;
											$economsumm = 0;
											if ($price_for_econom>$item['CATALOG_PRICE_1']){
												$economsumm = $price_for_econom-$item['CATALOG_PRICE_1'];
											}
											?>
											</ul>
											
											
    									</div>
										<span class="next<?=$item['ID']?> nextkompleks"></span>
    								</div>
    								<div class="col col-3" style="display :none;">
    									<div class="top">Вес</div>
    									<div class="bottom">
    										<div class="ver-hr"></div>
    										<p><?=$item['PROPERTIES']['VES_OBEM']['VALUE']?> гр</p>
    									</div>
    								</div>
    								<div class="col col-4" style="display :none;">
    									<div class="top">Ккал.</div>
    									<div class="bottom">
    										<div class="ver-hr"></div>
    										<p><?=$kkal?> ккал</p>
    									</div>
    								</div>
    								<div class="col col-5">
    									<div class="top">Количество</div>
    									<div class="bottom">
    										<div class="ver-hr"></div>
    										<div class="quantity"><img class="plus" src="/img/plus.png" /><input class="qn" type="text" value="1" /><img class="minus" src="/img/minus.png" /></div>
    									</div>
    								</div>
    							</div>
    							
    							<div class="cl"></div>
    							
    							<div class="price">
    								<div class="pricekompl">Цена: <span class="summkompleksa"><?=$item['CATALOG_PRICE_1']?> </span><span>руб.</span></div>
									<div class="economtext">Экономия: <span class="econsumm"><?=$economsumm?> </span><span> руб.</span></div>
									<div class='CATALOG_PRICE_1' style="display: none;" ><?=$item['CATALOG_PRICE_1']?> </div>
									
									<div class='product_id' style="display: none;" ><?=$item['ID']?> </div>
									<div class='week' style="display: none;" ><?=$_SESSION['Week']?> </div>
									 <div class='day' style="display: none;" ><?=$_SESSION['dey']?></div>
									  <div class='dayint' style="display: none;" ><?=$_SESSION['dayint']?></div>
									   <div class='datasec' style="display: none;" ><?=$_SESSION['datasec']?></div>
									<div class='date' style="display: none;" ><?=$_SESSION['dey2']?></div>
									<div class='kat' style="display: none;" ><?=$item['PROPERTIES']['KATEGORIYA']['VALUE']?> </div>
    								
									<? $timeZavtra = $_SESSION['datasec'];
										$timeSegodnyaPlus86400 = time()+86400;
										$timeSegodnyaPlus86400 = strtotime(date('d.m.Y',$timeSegodnyaPlus86400));
										$timeHour = date('H',time());
										if ($_SESSION['dey2']==date('d.m.Y') or ($timeHour>=17 and $timeZavtra==$timeSegodnyaPlus86400)){
										//if ($_SESSION['dey2']==date('d.m.Y')){	
											?>
											<a class="a_blocked">Добавить</a>
											
									<?} else {?>
											<a class="add-plitka" href="" id_el=<?=$item['ID']?>>Добавить</a>
									<?}?>
									
    							</div>
    							
    						</div>
							<script type="text/javascript">
								jQuery(function(){
									
									jQuery("#sostavlistkopleksslide<?=$item['ID']?>").jCarouselLite({
										visible: 5,
										start: 0,
										btnNext: ".next<?=$item['ID']?>",
										btnPrev: ".prev<?=$item['ID']?>",
										circular:false,
										scroll: 1
									});
									
										
									
								});
						</script>
			<?
	  }
	} 
	}
  //}
}?>   
<?}?>

				
				
				
			
			
			
		
		
			
			
		
		
		
		
		
		
		
		
		
<?

$_SESSION['tid']=0;
?> 
<?						$limit = 0;
						global $USER;
						if ($USER->IsAuthorized()){ 
							$rsUser = CUser::GetByID($USER->GetID());
							$arUser = $rsUser->Fetch();
							
							if(isset($arUser['UF_LIMIT']) and $arUser['UF_LIMIT']!='' and $arUser['UF_LIMIT']!=0){
									$limit = $arUser['UF_LIMIT'];
							}
						
						}
					if($_SESSION['dey2']!=''){
						$priceOrderDat = priceOrderDat($_SESSION['dey2']);
						}
					?>
		
<script>
	
$( document ).ready(function() {
	//добавить товар в корзину
    $('.add-plitka').click(function() {
			var id = $(this).attr('id_el');
			var qn=$('.el'+id+' .qn').val();
			var day=$(this).siblings('.day').text();
			var limit = <?=$limit?>;
			var stop = 0;
			var priceOrderDat = <?=$priceOrderDat?>;
			if(limit>0){
				var datasecsumm = $('.sum'+day+' span').text();
				if(!datasecsumm){
					datasecsumm = 0;
				}
				datasecsumm = parseFloat(datasecsumm)+parseFloat(priceOrderDat);
				
				var sumca = $('.el'+id+' .CATALOG_PRICE_1').text()*qn;
				var sumcaplus = parseFloat(datasecsumm)+parseFloat(sumca);
				//alert(parseFloat(datasecsumm));
				if(sumcaplus>limit){
					//alert('Вы превысили дневной лимит '+sumca+'-'+sumcaplus+'-'+limit);
					$('.limit-vspl, .allfon').attr('style','display:block;');
					stop = 1;
				}
			}
		if (stop==0){
				$('.loading-vspl, .allfon').attr('style','display:block;');
				
				var sostavArr = [];
				$('.el'+id+' .izm').each(function(i){
					sostavArr[i] = $(this).attr('idr_name');
					//sostavArr[i] = $(this).attr('idr');
				})
				sostav = sostavArr.join('; ');
				$.post(
			  "/ajax/addpr.php",
			  {
				product_id: $(this).siblings('.product_id').text(),
				week: $(this).siblings('.week').text(),
				 day: $(this).siblings('.day').text(),
				 dayint: $(this).siblings('.dayint').text(),
				 datasec: $(this).siblings('.datasec').text(),
				 qn:$('.el'+id+' .qn').val(),
				 day_for_cart:$("[aria-hidden=false]").attr('id'),
				 date:$(this).siblings('.date').text(),
				 kat: $(this).siblings('.kat').text(),
				 sostav: sostav,
				 action:'add'
				 
			  },
			  onAjaxSuccess
			)
			 
			function onAjaxSuccess(data)
			{
			  // Здесь мы получаем данные, отправленные сервером и выводим их на экран.
			  $('.cart').html(data);
			  $('.el'+id+' .add-plitka').addClass('seriybutton').text('Добавлено');
			  $('.loading-vspl, .allfon').attr('style','display:none;');
			}
			 //$('.cart').html(data);
		}
    	return false ;
})

//индивидуальные - в корзину
$('.add_individ').click(
	function(){
		var lenght = $('.individ .izmindiv').length;
		var il = 1;
		var idArr = [];
		var day=$(this).attr('dayden');
		var limit = <?=$limit?>;
		var stop = 0;
		
		if(limit>0){
			var datasecsumm = $('.sum'+day+' span').text();
			if(!datasecsumm){
				datasecsumm = 0;
			}
			var sumca = $('#summ_individ').text();
			var sumcaplus = parseFloat(datasecsumm)+parseFloat(sumca);
			//alert(parseFloat(sumcaplus)+'--'+limit);
			if(sumcaplus>limit){
				//alert('Вы превысили дневной лимит '+sumca+'-'+sumcaplus+'-'+limit);
				$('.limit-vspl, .allfon').attr('style','display:block;');
				stop = 1;
			}
		}
		
		if (stop==0){
			$('.individ .izmindiv').each(function(){
				
			
				var id = $(this).attr('idr');
				if (id!=0){	
					idArr.push(id) 
				}
				product_id_list = idArr.join(',');
				il++;
			})
			if (product_id_list!=''){
				$.post(
						  "/ajax/addpr.php",
						  {
							product_id_list: product_id_list,
							week: '<?=$_SESSION['Week']?>',
							 day: '<?=$_SESSION['dey']?>',
							dayint: '<?=$_SESSION['dayint']?>',
							 datasec: '<?=$_SESSION['datasec']?>',
							 qn:$('.individ-info .quantity input').val(),
							 day_for_cart:'<?=$_SESSION['dey']?>',
							 date:'<?=$_SESSION['dey2']?>',
							 kat: 'individ',
							 limit: limit,
							 action:'add_individ'
							 
						  },
						  function onAjaxSuccess(data)
							{
								
								  // Здесь мы получаем данные, отправленные сервером и выводим их на экран.
								  $('.cart').html(data);
								
							}
					)
			}		
		} 
	return false;	
	}
	
);

//бизнес ланчи - в корзину
$('.add_bl').click(
	function(){
		var limit = $('#limit').val();
		var id_bl = $(this).attr('ids');
		var qn = $('.blid'+id_bl+' .bl-info .quantity input').val();
		var day = '<?=$_SESSION['dey']?>';
		var priceOrderDat = <?=$priceOrderDat?>;
		var stop = 0;
		
		if(limit>0){
				var datasecsumm = $('.sum'+day+' span').text();
				if(!datasecsumm){
					datasecsumm = 0;
				}
				datasecsumm = parseFloat(datasecsumm)+parseFloat(priceOrderDat);
				var sumca = $('.el'+id_bl+' .CATALOG_PRICE_1').text()*qn;
				var sumcaplus = parseFloat(datasecsumm)+parseFloat(sumca);
				//alert('Вы превысили дневной лимит '+sumca+'-'+sumcaplus+'-'+limit);
				//alert(parseFloat(datasecsumm));
				if(sumcaplus>limit){
					//alert('Вы превысили дневной лимит '+sumca+'-'+sumcaplus+'-'+limit);
					$('.limit-vspl, .allfon').attr('style','display:block;');
					stop = 1;
				}
			}
		if (stop==0){
			var cat = $(this).attr('cat');
			var idArr2 = [];		
			$('.blid'+id_bl+' .bl-item .metclick1 .podrbl').each(function(){
				var id_bllist = $(this).attr('idbl');
				
				
				idArr2.push(id_bllist) 
				
				id_list = idArr2.join(';');
				
			})
			
			
				$.post(
						  "/ajax/addpr.php",
						  {
							id: id_bl,
							sostav: id_list,
							week: '<?=$_SESSION['Week']?>',
							 day: day,
							dayint: '<?=$_SESSION['dayint']?>',
							 datasec: '<?=$_SESSION['datasec']?>',
							 qn:qn,
							 day_for_cart:'<?=$_SESSION['dey']?>',
							 date:'<?=$_SESSION['dey2']?>',
							 kat: cat,
							 action:'add_bl'
							 
						  },
						  function onAjaxSuccess(data)
							{
								
								  // Здесь мы получаем данные, отправленные сервером и выводим их на экран.
								  $('.cart').html(data);
								
							}
					)
		}		
		 
	return false;	
	}
	
);

}); 

</script>
