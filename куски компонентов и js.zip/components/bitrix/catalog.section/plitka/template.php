<?
if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();
/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */ 
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */
/** @var CBitrixComponent $component */
$this->setFrameMode(true);
?>
<?

if (!empty($arResult['ITEMS']))
{
	
	$cur_page_no_index = $APPLICATION->GetCurPage(false);
	$urlPath = explode('/',$cur_page_no_index);
//print_r($cur_page_no_index) ;
	$uriusArr_plitka = array();
	$uriusArr_spisok = array();
	foreach($_GET as $key=>$get){
		if ($key!='p'){
			$uriusArr_plitka[]= $key.'='.$get;
			$uriusArr_spisok[]= $key.'='.$get;
		}
	}
	$uriusArr_spisok[] = 'p=spisok';
	$uriusArr_plitka[]= 'p=plitka';
	$urius_spisok = implode('&',$uriusArr_spisok);
	$urius_plitka = implode('&',$uriusArr_plitka);
	?>
 <?/*
$arSelect = Array("ID", "NAME", "DATE_ACTIVE_FROM","PROPERTY_KATEGORIYA","PROPERTY_DNI");
$arFilter = Array("IBLOCK_ID"=>$arParams['IBLOCK_ID'], "ACTIVE"=>"Y","PROPERTY_KATEGORIYA"=>"099d8821-32a9-11e6-93dd-901b0e6067a7","PROPERTY_DNI"=>"15.07.2016");
$res = CIBlockElement::GetList(Array(), $arFilter, false, Array("nPageSize"=>50), $arSelect);
while($ob = $res->GetNextElement())
{
 $arFields = $ob->GetFields();
//echo '<div style="display:none">'; print_r($arFields);echo '</div>';
}*/
CModule::IncludeModule('sale');
 // Выберем актуальную корзину для текущего пользователя
$arBasketItems = array();
$dbBasketItems = CSaleBasket::GetList(
	array(
		"NAME" => "ASC",
		"ID" => "ASC"
	),
	array(
		"FUSER_ID" => CSaleBasket::GetBasketUserID(),
		"LID" => SITE_ID,
		"ORDER_ID" => "NULL"
	),
	false,
	false,
	array("ID","PRODUCT_ID")
);
$arBasketItems='';	
$arBasketItemsProps = array();	
while ($arItems = $dbBasketItems->Fetch())
{
	
	//print_r($arItems) ;
	$arBasketItems[] = $arItems['PRODUCT_ID'];
	// Выведем все свойства элемента корзины с кодом $basketID
	$db_res = CSaleBasket::GetPropsList(
		array(
			"SORT" => "ASC",
			"NAME" => "ASC"
		),
		array("BASKET_ID" => $arItems['ID'])
	);
	while ($PROPS = $db_res->Fetch())
	{
		if ($PROPS['CODE']=='GARNIR'){
			
			$dopGarnirProductId = (int)$PROPS['VALUE'];
			$arBasketItemsProps[$arItems['PRODUCT_ID']] = $dopGarnirProductId;

			
			break;
		}
		
	  // echo $ar_res["NAME"]."=".$ar_res["VALUE"]."<br>";
	}
}
//print_r($arBasketItems) ;
?> 
<div>
	<h1 style="color:#4b850b">ОБЕДЫ В ОФИС</h1>
</div>
<div class="sort_block">
	<select>
		<option selected="selected">Выбрать по популярности</option>
		<option>популярное за неделю</option>
		<option>популярное за месяц</option>
		<option>хит продаж</option>
		<option>новинки</option>
	</select>

	<div class="vivod-menu">
		<a href="?<?=$urius_plitka?>" class="spisok"><img src="/img/spisok-img.png" /></a>
		<a href="?<?=$urius_spisok?>" class="plitka"><img src="/img/plitka-img.png" /></a>
	</div>

	<div class="down-print">
		<div class="xsldonw"><img src="/img/xls.png"><a href="">Скачать xls</a></div>
		<!--div class="xslprint"><img src="/img/print.png"><a href="">Распечатать</a></div-->
	</div>

	<div class="cl"></div>   
</div>
<? 
	 //print_r($arResult['KATN']);
CModule::IncludeModule('highloadblock');

foreach($arResult['KATN'] AS $cat)
{
	if($cat=='058713ac-0ded-11e6-a63e-901b0e581578' or $cat=='058713ab-0ded-11e6-a63e-901b0e581578' or $cat=='8bf83290-6892-11e6-a1b8-901b0e6067a7' or $cat=='315fb2fe-99d1-11e7-a6b0-901b0e6067a7' or $cat=='315fb306-99d1-11e7-a6b0-901b0e6067a7' or $cat=='315fb309-99d1-11e7-a6b0-901b0e6067a7' or $cat=='d8389b4c-9a00-11e7-a6b0-901b0e6067a7' or $cat=='56f2d1ef-9e7c-11e7-a6b0-901b0e6067a7' or $cat=='d8389b44-9a00-11e7-a6b0-901b0e6067a7' or $cat=='d8389b44-9a00-11e7-a6b0-901b0e6067a7' or $cat=='d8389b49-9a00-11e7-a6b0-901b0e6067a7' or $cat=='d8389b4f-9a00-11e7-a6b0-901b0e6067a7' or $cat=='d8389b52-9a00-11e7-a6b0-901b0e6067a7' or $cat=='dafa525a-a4ee-11e7-a6b0-901b0e6067a7')
	{
		continue;
	}

	$hlblock_id = 4; // ID вашего Highload-блока
	$hlblock = Bitrix\Highloadblock\HighloadBlockTable::getById( $hlblock_id )->fetch(); // получаем объект вашего HL блока
	$entity = Bitrix\Highloadblock\HighloadBlockTable::compileEntity( $hlblock );  // получаем рабочую сущность
	$entity_data_class = $entity->getDataClass(); // получаем экземпляр класса
	$entity_table_name = $hlblock['TABLE_NAME']; // присваиваем переменной название HL таблицы
	$sTableID = 'tbl_'.$entity_table_name; // добавляем префикс и окончательно формируем название
	$arFilter = array("UF_XML_ID" => $cat); // зададим фильтр по ID пользователя
	$arSelect = array('*'); // выбираем все поля
	$arOrder = array("UF_SORT"=>"ASC"); // сортировка будет по возрастанию ID статей

	//подготавливаем данные
	$rsData = $entity_data_class::getList(array(
		"select" => $arSelect,
		"filter" => $arFilter,
	 //ограничим выборку пятью элементами
		"order" => $arOrder
	));

	// выполняем запрос. Передаем в него наши данные и название таблицы, которое мы получили в самом начале
	$rsData = new CDBResult($rsData, $sTableID); // записываем в переменную объект CDBResult


// а далее простой цикл и знакомый нам метод Fetch (или GetNext, кому что нравится) d8389b44-9a00-11e7-a6b0-901b0e6067a7 
	if($arRes = $rsData->Fetch())
	{
		?>
		<div class="h2-h2"><?=$arRes['UF_NAME']?><?if($cat=='83642ac4-04bf-11e6-afd0-901b0e6067a7'){echo ' <span>(гарнир заказывается отдельно)</span>';}?></div>
		<?
	}

	foreach ($arResult['ITEMS'] as $item) 
	{
		if($item['PROPERTIES']['KATEGORIYA']['VALUE']==$cat)
		{
			
			if(isset($_GET['p']) and $_GET['p']=='spisok')
			{
				?>
				<div class="plitka el<?=$item['ID']?> vstroku_item itemitemproduct">
					<div class="item">
						<div class="col col-1">
							<div class="top">Фото</div>
							<div class="bottom bottom_imgbk_osn">
								<div class="bottom_imgbk">
									<?if($item['PREVIEW_PICTURE']['SRC']=='')
									{


										?>
										<img class='lazy' data-src="/images/no_foto/<?=$cat?>.jpg" />
										<?
									}
									else
									{
										$file = CFile::ResizeImageGet($item['PREVIEW_PICTURE']['ID'], array('width'=>170, 'height'=>135), BX_RESIZE_IMAGE_EXACT, true);         
										?>

										<img class='lazy' data-src="<?=$file['src']?>" />
										<!--div class="hit"></div-->
										<a id="example1" class="lupa" href="<?=$item['PREVIEW_PICTURE']['SRC']?>"><img  class='lazy'data-src="/img/lupa.png" /></a>
										<?
									}
									?>
								</div>
								<?

								$timeZavtra = $_SESSION['datasec'];
								$timeSegodnyaPlus86400 = time()+86400;
								$timeSegodnyaPlus86400 = strtotime(date('d.m.Y',$timeSegodnyaPlus86400));
								$timeHour = date('H',time());
								if ($_SESSION['dey2']==date('d.m.Y') or ($timeHour>=17 and $timeZavtra==$timeSegodnyaPlus86400))
								{

								}
								else 
								{
									if($item['PROPERTIES']['VTOROE_BLYUDO_S_GARNIROM']['VALUE']=='Да')
									{
										if ($cat=='83642ac4-04bf-11e6-afd0-901b0e6067a7')
										{
											if($arBasketItemsProps[$item['ID']]!='')
											{
												?>
												<div class="garnir_val vibran_garnir"><a idr="<?=$item['ID']?>" day="<?=$_SESSION['dey2']?>"  href="#">Гарнир выбран</a></div>
												<div class="garnir<?=$item['ID']?>" style="display: none;"><?=$arBasketItemsProps[$item['ID']]?></div>
												<?
											}
											else 
											{
												?> 
												<div class="garnir_val vibrat_garnir"><a idr="<?=$item['ID']?>" day="<?=$_SESSION['dey2']?>"  href="#">1Выбрать гарнир</a></div>
												<div class="garnir<?=$item['ID']?>" style="display: none;"></div>
												<?
											}
										}
									}
								}	
								?>		

							</div>
						</div>
						<div class="col col-2">
							<div class="top">Название, состав</div>
							<div class="bottom">
								<h2><?=str_replace('&quot;','"',$item['NAME'])?></h2>
								<?
						/*if ($item['PROPERTIES']['SOSTAV']['VALUE']!='' and $arRes['UF_NAME']!='Буфетная продукция'){?>
							<p><?=$item['PROPERTIES']['SOSTAV']['VALUE']?></p>
							<?}*/
							?>



						</div>
					</div>
					<div class="col col-3">
						<div class="top">Вес</div>
						<div class="bottom">
							<div class="ver-hr"></div>
							<p><?=$item['PROPERTIES']['VES_OBEM']['VALUE']?> гр</p>
						</div>
					</div>
					<div class="col col-4">
						<div class="top">Ккал.</div>
						<div class="bottom">
							<div class="ver-hr"></div>
							<p><?=$item['PROPERTIES']['KALORIYNOST']['VALUE']?> ккал</p>
						</div>
					</div>
					<div class="col col-5">
						<div class="top">Количество</div>
						<div class="bottom">
							<div class="ver-hr"></div>
							<div class="quantity"><img class="plus" src="/img/plus.png" /><input type="text" class="qn" value="1" /><img class="minus" src="/img/minus.png" /></div>
						</div>
					</div>
				</div>

				<div class="cl"></div>

				<div class="price">
					<div>Цена: <span><?=$item['CATALOG_PRICE_1']?> руб.</span></div>
					<div class='CATALOG_PRICE_1' style="display: none;" ><?=$item['CATALOG_PRICE_1']?> </div>
					<div class='product_id' style="display: none;" ><?=$item['ID']?> </div>
					<div class='week' style="display: none;" ><?=$_SESSION['Week']?> </div>
					<div class='day' style="display: none;" ><?=$_SESSION['dey']?></div>
					<div class='dayint' style="display: none;" ><?=$_SESSION['dayint']?></div>
					<div class='datasec' style="display: none;" ><?=$_SESSION['datasec']?></div>
					<div class='date' style="display: none;" ><?=$_SESSION['dey2']?></div>
					<div class='kat' style="display: none;" ><?=$item['PROPERTIES']['KATEGORIYA']['VALUE']?> </div>
					<? 
					if ($_SESSION['dey2']==date('d.m.Y') or ($timeHour>=17 and $timeZavtra==$timeSegodnyaPlus86400))
					{
				//if ($_SESSION['dey2']==date('d.m.Y')){
						?>

						<a class="a_blocked" id_el=<?=$item['ID']?>>Добавить</a>
						<?} else {?>
							<a href="" class="add-plitka <?if ($cat=='83642ac4-04bf-11e6-afd0-901b0e6067a7' and $arBasketItemsProps[$item['ID']]=='' and $item['PROPERTIES']['VTOROE_BLYUDO_S_GARNIROM']['VALUE']=='Да'){echo ' garnir_add';}?>" id_el=<?=$item['ID']?>>Добавить</a>
							<?}


			//echo $cat;
							?>

						</div>

					</div>

					<div class="cl"></div>



				<?  } else {
					?>
					<div itemscope itemtype="http://schema.org/Product" class="item-spisok el<?=$item['ID']?> plitka_item itemitemproduct" id_el="<?=$item['ID']?>">
						<div class="imgh2 ">
							<?if($item['PREVIEW_PICTURE']['SRC']=='')
							{
								?>
								<img class='lazy in-img' data-src="/images/no_foto/<?=$cat?>.jpg" />
								<?
							}
							else
							{ 
		//print_r($item['PREVIEW_PICTURE']) ;


								$file = CFile::ResizeImageGet($item['PREVIEW_PICTURE']['ID'], array('width'=>204, 'height'=>150), BX_RESIZE_IMAGE_EXACT, true);                
                //print_r($file) ;
								?>

								<img class="in-img lazy" itemprop="image"  data-src="<?=$file['src']?>" />
								<!--div class="hit"></div-->
								<a id="example1" class="lupa2" href="<?=$item['PREVIEW_PICTURE']['SRC']?>"><img class='lazy'data-src="/img/lupa.png" /></a>
								<?
							}

							$NAME = $item['NAME'];
							$NAME2 ='';
							$arrName = array();
							preg_match_all("/\((.*)\)/", $NAME, $arrName);
							if ($arrName[0])
							{
								$NAME = str_replace($arrName[0][0], '', $NAME);
								$NAME2 = $arrName[1][0];
							}



							$strlen = (int)mb_strlen($item['NAME']);

							/*if($strlen>=98){

								$NAME = mb_substr($NAME, 0, 90).'...';
							}*/
							$ingr = implode(', ',$item['PROPERTIES']['INGREDIENTY']['VALUE']);
							$ingr2 = $ingr;
							$strlen_ingr = (int)mb_strlen($ingr);
							if ($strlen_ingr>82)
							{

								$ingr = mb_substr($ingr, 0, 82).'...';
							}

							if($urlPath[2]=='prazdnichie-bluda')
							{

							}



							?>
							<div class="hsos">
								<div class='h2' itemprop="name"><?=str_replace('&quot;','"',$NAME)?></div>
								<span class="dnone dh2">
									<?=str_replace('&quot;','"',$item['NAME'])?>
								</span>
								<div class="ingr" itemprop="description"><?=$NAME2?:$ingr2?></div>
								<span class="dnone ingr2"><?=$NAME2?:$ingr2?></span>
							</div>
						</div>
						<?
						if (
							$item['PROPERTIES']['PROTEIN']['VALUE'] &&
							$item['PROPERTIES']['FAT']['VALUE'] &&
							$item['PROPERTIES']['CARBOHYDRATE']['VALUE']
						)
						{
							?>
							<div class="wt">
								Белки:&nbsp;<?=$item['PROPERTIES']['PROTEIN']['VALUE']?>, 
								Жиры:&nbsp;<?=$item['PROPERTIES']['FAT']['VALUE']?>, 
								Углеводы:&nbsp;<?=$item['PROPERTIES']['CARBOHYDRATE']['VALUE']?>

							</div>
							<?
						}
						?>
						<div class="wt"> Вес <?=$item['PROPERTIES']['VES_OBEM']['VALUE']?> гр, Ккал <?=$item['PROPERTIES']['KALORIYNOST']['VALUE']?></div>
						<div class="quant">Количество</div> <div class="quantity"><img class="plus" src="/img/plus.png" /><input class="qn" type="text" value="1" /><img class="minus" src="/img/minus.png" /></div>
						<div class="cena"  itemprop="offers" itemscope itemtype="http://schema.org/Offer">Цена: <span itemprop="price"><?=$item['CATALOG_PRICE_1']?></span> <span>руб.<span style='display:none;' itemprop="priceCurrency">RUB</span></span></div>
						

						<div class='product_id' style="display: none;" ><?=$item['ID']?> </div>
						<div class='CATALOG_PRICE_1' style="display: none;" ><?=$item['CATALOG_PRICE_1']?> </div>
						<div class='week' style="display: none;" ><?=$_SESSION['Week']?> </div>
						<div class='day' style="display: none;" ><?=$_SESSION['dey']?></div>
						<div class='dayint' style="display: none;" ><?=$_SESSION['dayint']?></div>
						<div class='datasec' style="display: none;" ><?=$_SESSION['datasec']?></div>
						<div class='date' style="display: none;" ><?=$_SESSION['dey2']?></div>
						<div class='kat' style="display: none;" ><?=$item['PROPERTIES']['KATEGORIYA']['VALUE']?> </div>
						<? 
						$timeZavtra = $_SESSION['datasec'];
						$timeSegodnyaPlus86400 = time()+86400;
						$timeSegodnyaPlus86400 = strtotime(date('d.m.Y',$timeSegodnyaPlus86400));
						$timeHour = date('H',time());
						if ($_SESSION['dey2']==date('d.m.Y') or ($timeHour>=17 and $timeZavtra==$timeSegodnyaPlus86400))
						{

							?>

							<a class="a_blocked" id_el=<?=$item['ID']?>>Добавить</a>
							<?}
							else 
							{

								?>
								<a style="cursor: pointer;" class="add-plitka <?if ($cat=='83642ac4-04bf-11e6-afd0-901b0e6067a7' and $arBasketItemsProps[$item['ID']]=='' and $item['PROPERTIES']['VTOROE_BLYUDO_S_GARNIROM']['VALUE']=='Да'){echo ' garnir_add';}?>" id_el=<?=$item['ID']?>>Добавить</a>

								<?if($item['PROPERTIES']['VTOROE_BLYUDO_S_GARNIROM']['VALUE']=='Да')
								{
									if ($cat=='83642ac4-04bf-11e6-afd0-901b0e6067a7')
									{

										?> 
										<div class="garnir_val vibrat_garnir"><a idr="<?=$item['ID']?>" day="<?=$_SESSION['dey2']?>"  href="#">Выбрать гарнир</a></div>
										<div class="garnir<?=$item['ID']?>" style="display: none;"></div>
										<?
									}
								}
								else
								{
									?>
									<div class="garnir_val vibrat_garnir"><a idr="<?=$item['ID']?>" day="<?=$_SESSION['dey2']?>"  href="#" style='text-decoration:none'>&nbsp;</a></div>
									<?
								}	
							}

							?>

						</div>


						<?
					}
				}
			}
			
			?>
			<div class="cl"></div>
			<?
		}
	}
	$_SESSION['tid']=0;
	?>
	<?						$limit = 0;
	global $USER;
	if ($USER->IsAuthorized()){ 
		$rsUser = CUser::GetByID($USER->GetID());
		$arUser = $rsUser->Fetch();

		if(isset($arUser['UF_LIMIT']) and $arUser['UF_LIMIT']!='' and $arUser['UF_LIMIT']!=0){
			$limit = $arUser['UF_LIMIT'];
		}

	}

	$priceOrderDat = priceOrderDat($_SESSION['dey2']);
	?>
	<script>

		$( document ).ready(function() {
			$('.lazy').lazy();
	//добавить товар в корзину
	$('.add-plitka').click(function(e) {
		
		var id = $(this).attr('id_el');
		var limit = <?=$limit?>;
		var priceOrderDat = <?=$priceOrderDat?>;

		if($(this).hasClass('garnir_add')){
			$('.da_dagar1').attr('id_garr',id);
			$('.da_dagar2').attr('id_garr',id);
			$('.garnir-vspl, .allfon').attr('style','display:block;');
		} else{



			var product_id = $(this).siblings('.product_id').text();
			var week = $(this).siblings('.week').text();
			var day = $(this).siblings('.day').text();
				//alert(day) ;
				var dayint = $(this).siblings('.dayint').text();
				var datasec = $(this).siblings('.datasec').text();
				var date = $(this).siblings('.date').text();
				var kat = $(this).siblings('.kat').text();
				
				var datasecsumm = $('.sum'+day+' span').text();
				if(!datasecsumm){
					datasecsumm = 0;
				}
				datasecsumm = parseFloat(datasecsumm)+parseFloat(priceOrderDat);
				//alert(limit) ;
				add_plitka(id,product_id,week,day,dayint,datasec,date,kat,limit,datasecsumm);
				
			}
			

			return false ;
		}) 

	$('.garnir_val a').on('click',function(){//выбрать гарнир ко вторым блюдам
		var idr = $(this).attr('idr');
		var day = $(this).attr('day');

		var limit = $('#limit').val();
		var priceOrderDat = <?=$priceOrderDat?>;
		var day2 = $('.el'+idr+' .day').text();
		var datasecsumm = $('.sum'+day2+' span').text();
		if(!datasecsumm){
			datasecsumm = 0;
		}
			//alert(day) ;
			datasecsumm = parseFloat(datasecsumm)+parseFloat(priceOrderDat);
			garnir_ajax(idr,day,limit,datasecsumm);		
			return false;	
		});

	$('.da_dagar1').on('click',function() {
		var id = $(this).attr('id_garr');
		$('.garnir-vspl, .allfon').attr('style','display:none;');
		var idr = id;
		var day = $('.el'+id+' .garnir_val a').attr('day');
		var limit = $('#limit').val();
		var priceOrderDat = <?=$priceOrderDat?>;
		var day2 = $('.el'+idr+' .day').text();
		var datasecsumm = $('.sum'+day2+' span').text();
		if(!datasecsumm){
			datasecsumm = 0;
		}
		datasecsumm = parseFloat(datasecsumm)+parseFloat(priceOrderDat);
		//alert(datasecsumm) ;
		garnir_ajax(idr,day,limit,datasecsumm);
		//$('.el'+id+' .garnir_val a').click();
		
		return false ;
	});
	$('.da_dagar2').on('click',function() {
		var id = $(this).attr('id_garr');
		$('.garnir-vspl, .allfon').attr('style','display:none;');
		var limit = $('#limit').val();
		var priceOrderDat = <?=$priceOrderDat?>;
		//$('.el'+id+' .add-plitka').click();
		var product_id = $('.el'+id+' .product_id').text();
		var week = $('.el'+id+' .week').text();
		var day = $('.el'+id+' .day').text();
		var dayint = $('.el'+id+' .dayint').text();
		var datasec = $('.el'+id+' .datasec').text();
		var date = $('.el'+id+' .date').text();
		var kat = $('.el'+id+' .kat').text();
		
		//alert(day) ;
		var datasecsumm = $('.sum'+day+' span').text();
		if(!datasecsumm){
			datasecsumm = 0;
		}
		datasecsumm = parseFloat(datasecsumm)+parseFloat(priceOrderDat);
		add_plitka(id,product_id,week,day,dayint,datasec,date,kat,limit,datasecsumm);
		
		return false ; 
	})
	
	

	function garnir_ajax(idr,day,limit,datasecsumm){
		var cat = '8bf83290-6892-11e6-a1b8-901b0e6067a7';
		var catname = 'Гарниры';
		var id_garnir = $('.garnir'+idr).text();
			//alert(id_garnir) ;
			$('.ind-vspl, .allfon').attr('style','display:block;');	
			$.post(
				"/ajax/ajax_function.php",
				{
					cat:cat,
					catname:catname,
					idr:idr,
					id_garnir:id_garnir,
					day:day,
					limit:limit,
					datasecsumm:datasecsumm,
					action:'garnir_val'

				},function onAjaxSuccess(data){
						  // Здесь мы получаем данные, отправленные сервером и выводим их на экран.
						  $('.ind-vspl').html(data);
						  
						  
						  $('.ind-vspl .top .close, .allfon').click(function(){
						  	$('.ind-vspl, .allfon').attr('style','display:none;');
						  });	
						}

						);
			return false;
		}
		function add_plitka(id,product_id,week,day,dayint,datasec,date,kat,limit,datasecsumm){
			
			var qn = $('.el'+id+' .qn').val();
			var stop = 0;
			
			if(limit>0){
				
				var sumca = $('.el'+id+' .CATALOG_PRICE_1').text()*qn;
				var sumcaplus = parseFloat(datasecsumm)+parseFloat(sumca);
				//alert('Вы превысили дневной лимит '+sumca+'-'+sumcaplus+'-'+limit);
				//alert(parseFloat(datasecsumm));
				if(sumcaplus>limit){
					//alert('Вы превысили дневной лимит '+sumca+'-'+sumcaplus+'-'+limit);
					$('.limit-vspl, .allfon').attr('style','display:block;');
					stop = 1;
				}
			}
			if (stop==0){
				$('.loading-vspl, .allfon').attr('style','display:block;');
				$.post(
					"/ajax/addpr.php",
					{
						product_id: product_id,
						week: week,
						day: day,
						dayint: dayint,
						datasec: datasec,
						qn:qn,
						day_for_cart:$("[aria-hidden=false]").attr('id'),
						date:date,
						kat: kat,
						limit: limit,
						garnir: $('.garnir'+id).text(),
						action:'add'

					},function onAjaxSuccess(data){
					  // Здесь мы получаем данные, отправленные сервером и выводим их на экран.
					  $('.cart').html(data);
					 // $('.el'+id+' .add-plitka').removeClass('garnir_add').addClass('seriybutton').text('Добавлено');
					 $('.el'+id+' .add-plitka').addClass('seriybutton').text('Добавлено');
					 $('.loading-vspl, .allfon').attr('style','display:none;');
					}

					)
			}


			
			
		}
	});

</script>
<div class="acht">Заказы на будний день принимаются до 16:00 предыдущего буднего дня.</div>
<div class="acht">Заказы на выходной день принимаются до 13:00 пятницы</div>