<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();
/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */ 
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */
/** @var CBitrixComponent $component */
$this->setFrameMode(true);

if (!empty($arResult['ITEMS']))
{

	?>
	
	<?

	$cur_page_no_index = $APPLICATION->GetCurPage(false);
	$urlPath = explode('/',$cur_page_no_index);

	
	?>
	<?
	CModule::IncludeModule('sale');

 	// Выберем актуальную корзину для текущего пользователя
	$arBasketItems = '';	
	$arBasketItemsProps = array();	
	$dbBasketItems = CSaleBasket::GetList(
		array(
			"NAME" => "ASC",
			"ID" => "ASC"
		),
		array(
			// 
			"FUSER_ID" => CSaleBasket::GetBasketUserID(),
			"LID" => SITE_ID,
			"ORDER_ID" => '',
		),
		false,
		false,
		array("ID","PRODUCT_ID", "QUANTITY")
	);

	while ($arItem = $dbBasketItems->Fetch())
	{
		$arBasketItems[] = $arItem['PRODUCT_ID'];
		/**
			список корзинных идешников товаров
			ID - идешник товара в корзине
		*/

		// корзинные идешники товаров чьи значения свойств надо получить
			$BasketItemID[] = $arItem['ID'];
			$PRODUCT_ID[$arItem['ID']] = $arItem['PRODUCT_ID'];
			$QUANTITY[$arItem['ID']] = $arItem['QUANTITY'];
		}

	// данные по товару в корзине, в том числе идешник товара корзинный и значения свойств.
		$db_res = CSaleBasket::GetPropsList(
			array(
				"BASKET_ID" => "ASC",
				"NAME" => "ASC"
			),
			array("BASKET_ID" => $BasketItemID)
		);
	// BASKET_ID - идешник товара корзинный
		while ($PROPS = $db_res->Fetch())
		{
			if ($PROPS['CODE'] == 'DATASEC' && $PROPS['CODE'] == 'GARNIR') continue;

			if ($PROPS['CODE'] == 'DATASEC')
			{
				$DATASEC[$PRODUCT_ID[$PROPS['BASKET_ID']]][$PROPS['VALUE']] = $PROPS['BASKET_ID'];
			}
			elseif ($PROPS['CODE'] == 'GARNIR')
			{
				$dopGarnirProductId = (int)$PROPS['VALUE'];
				$arBasketItemsProps[$arItems['PRODUCT_ID']] = $dopGarnirProductId;
			}
		}
		
		?> 
		<div class="cl"></div>
		<div class="sort_block">
		<?/*?>
		<select>
			<option selected="selected">Выбрать по популярности</option>
			<option>популярное за неделю</option>
			<option>популярное за месяц</option>
			<option>хит продаж</option>
			<option>новинки</option>
		</select>
		<?*/?>
		<div class="cl"></div>   
	</div>

	<div class="item-list">
		<?
		global $USER;
		foreach ($arResult['ITEMS'] as $item) 
		{
			if ($item['PROPERTIES']['PROMO_PRODUKTSIYA']['VALUE'] == 'Да')
				$PROMO[] = $item['ID'];
			

			

			if (!$cat || $cat != $item['PROPERTIES']['KATEGORIYA']['VALUE'])
			{
				$size = false;
				$cat = $item['PROPERTIES']['KATEGORIYA']['VALUE'];
				
				

				if (file_exists($_SERVER['DOCUMENT_ROOT']."/images/no_foto/".$cat.".jpg"))
				{
					
					$size = getimagesize($_SERVER['DOCUMENT_ROOT']."/images/no_foto/".$cat.".jpg");
					if ($size[1] > 140)
						$size[1] = 170*$size[1]/$size[0];
					

				}

				?>
				<div class="cl"></div>
			</div>

			<div id='id-<?=$cat?>' class="h2-h2"><?=$arResult['MOD']['KATEGORIYA'][$cat]?><?if($cat=='83642ac4-04bf-11e6-afd0-901b0e6067a7'){echo ' <span>(гарнир заказывается отдельно)</span>';}?></div>
			<div class="item-list">
				<?
			}

			$NAME = $item['~NAME'];
			$NAME2 ='';
			$arrName = array();
			preg_match_all("/\((.*)\)/", $NAME, $arrName);
			if ($arrName[0])
			{
				$NAME = str_replace($arrName[0][0], '', $NAME);
				$NAME2 = $arrName[1][0];
			}
			$item['NAME'] = $NAME;

			if (!$_GET['p']) $_GET['p'] = 'spisok';
			if(isset($_GET['p']) and $_GET['p']=='spisok')
			{
				?>
				<div id='el<?=$item['ID']?>' class="plitka-item flex-row el<?=$item['ID']?> <?=$DATASEC[$item['ID']][$_SESSION['datasec']]?" active":""?>" itemscope itemtype="http://schema.org/Product" >
					<?

					foreach ($item['PROPERTIES']['TIP']['VALUE'] as $tip)
					{

					}
					?>
					<div class="block-1 flex">

						<?if($item['PREVIEW_PICTURE']['SRC']=='')
						{
							?>
							<img class='lazy' height = "<?=$size[1]?>" data-src="/images/no_foto/<?=$cat?>.jpg?d<?=rand(1,10000)?>=<?=rand(1,10000)?>" />
							<?
						}
						else
						{	
							$img = false;
							if ($item['PREVIEW_PICTURE']['HEIGHT'] > 150)
							{
								$file = CFile::ResizeImageGet($item['PREVIEW_PICTURE']['ID'], array('width'=>170, 'height'=>135), BX_RESIZE_IMAGE_PROPORTIONAL_ALT, true);         
								$file['height'] = $file['height'] < 150 ? $file['height'] : 170*$file['height']/$file['width'];

								$img = CFile::ResizeImageGet($item['PREVIEW_PICTURE']['ID'], array('width'=>600, 'height'=>900), BX_RESIZE_IMAGE_PROPORTIONAL_ALT, true);
							}
							else
							{

								$file['src'] = $item['PREVIEW_PICTURE']['SRC'];
								$file['height'] = $item['PREVIEW_PICTURE']['HEIGHT'];
							}

							
							?>

							<img class='lazy' <?=$file['height']?>  height = "<?=$file['height'] < 150?$file['height']:'150'?>" data-src="<?=$file['src']?>" />
							<a class='fancy' href="<?=$img['src']?:$item['PREVIEW_PICTURE']['SRC']?>" class='flex-center'>

							</a>
							<?
						}
						?>


					</div>
					<div class="block-2 flex-between-col">
						<div class="block-2-1 flex-between">
							<div class="block-2-11"  itemprop="name">
								<?=str_replace('&quot;','"',$NAME)?>
							</div>
							<meta itemprop="description" content="<?=$NAME." ".$NAME2?>">

							<div class="block-2-1-2" itemprop="offers" itemscope="" itemtype="http://schema.org/Offer">
								<?=$item['CATALOG_PRICE_1']?> руб.
								<meta itemprop="price" content="<?=$item['CATALOG_PRICE_1']?>">
								<meta itemprop="priceCurrency" content="RUR">
							</div>
							
							<div class="block-2-1-3">
								<div class="quantity  flex-row">
									<span class="plus" idprfored="<?=$item['ID']?>"></span>
									
									<input type="text" class="qn" idprfored="<?=$item['ID']?>" value="<?=$QUANTITY[$DATASEC[$item['ID']][$_SESSION['datasec']]]?:0?>" />
									<span class="minus osnblud" idprfored="<?=$item['ID']?>" ></span>
								</div>
							</div>
						</div>
						<div class="block-2-2">
							<?=$NAME2?>
						</div>
						<div class="block-2-3 flex-between">
							<div class="block-2-3-1">
								<?if ($item['PROPERTIES']['VES_OBEM']['VALUE']){?> 
									Вес <?=$item['PROPERTIES']['VES_OBEM']['VALUE']?> гр
									<?}?>

									<?if ($item['PROPERTIES']['KALORIYNOST']['VALUE']){?> 
										<?=$item['PROPERTIES']['KALORIYNOST']['VALUE']?> ккал
										<?}?>

										<?
										if (
											$item['PROPERTIES']['PROTEIN']['VALUE'] &&
											$item['PROPERTIES']['FAT']['VALUE'] &&
											$item['PROPERTIES']['CARBOHYDRATE']['VALUE']
										)
										{
											?>

											Белки:&nbsp;<?=$item['PROPERTIES']['PROTEIN']['VALUE']?>, 
											Жиры:&nbsp;<?=$item['PROPERTIES']['FAT']['VALUE']?>, 
											Углеводы:&nbsp;<?=$item['PROPERTIES']['CARBOHYDRATE']['VALUE']?>


											<?
										}
										?>
									</div>
									<div class="block-2-3-20  flex-end">
										<?

										if ($item['PROPERTIES']['TIP']['VALUE'])
										{
											foreach ($item['PROPERTIES']['TIP']['VALUE'] as $tip){
												?>
												<img src="<?=$arResult['MOD']['TIP'][$tip]['ICO']?>" alt="<?=$tip?>"  title="<?=$tip?>">
												<?
											}
										}
										?>
									</div>
									<div class="block-2-3-2 ">
										<div class="block-2-3-2-1">
											<?
											$timeZavtra = $_SESSION['datasec'];
											$timeSegodnyaPlus86400 = time()+86400;
											$timeSegodnyaPlus86400 = strtotime(date('d.m.Y',$timeSegodnyaPlus86400));
											$timeHour = date('H',time());
											if ($_SESSION['dey2']==date('d.m.Y') or ($timeHour>=17 and $timeZavtra==$timeSegodnyaPlus86400))
											{

											}
											else 
											{
												if($item['PROPERTIES']['VTOROE_BLYUDO_S_GARNIROM']['VALUE']=='Да')
												{
													if ($cat=='83642ac4-04bf-11e6-afd0-901b0e6067a7')
													{
														?>
														<div class="info-garnir">
															Не забудьте добавить гарнир
														</div>
														<?
													/*
													if($arBasketItemsProps[$item['ID']]!='')
													{
														?>
														<div class="garnir_val vibran_garnir"><a idr="<?=$item['ID']?>" day="<?=$_SESSION['dey2']?>"  href="#">Гарнир выбран</a></div>
														<div class="garnir<?=$item['ID']?>" style="display: none;"><?=$arBasketItemsProps[$item['ID']]?></div>
														<?
													}
													else 
													{
														?> 
														<div class="garnir_val vibrat_garnir"><a idr="<?=$item['ID']?>" day="<?=$_SESSION['dey2']?>"  href="#">Выбрать гарнир</a></div>
														<div class="garnir<?=$item['ID']?>" style="display: none;"></div>
														<?
													}
													*/
												}
											}
										}	
										?>
									</div>

									<div class="block-2-3-2-2 flex-center">


										<div class='CATALOG_PRICE_1' style="display: none;" ><?=$item['CATALOG_PRICE_1']?> </div>
										<div class='product_id'  style="display: none;" ><?=$item['ID']?> </div>
										<div class='week' style="display: none;" ><?=$_SESSION['Week']?> </div>
										<div class='day' style="display: none;" ><?=$_SESSION['dey']?></div>
										<div class='dayint' style="display: none;" ><?=$_SESSION['dayint']?></div>
										<div class='datasec' style="display: none;" ><?=$_SESSION['datasec']?></div>
										<div class='basketitemid' style="display: none;" ><?=$DATASEC[$item['ID']][$_SESSION['datasec']]?></div>

										<div class='date' style="display: none;" ><?=$_SESSION['dey2']?></div>
										<div class='kat' style="display: none;" ><?=$item['PROPERTIES']['KATEGORIYA']['VALUE']?> </div>
										<div class='promo' style="display: none;" ><?=$item['PROPERTIES']['PROMO_PRODUKTSIYA']['VALUE']?"Да":"Нет"?></div>
										<? 
										if ($_SESSION['dey2']==date('d.m.Y') or ($timeHour>=17 and $timeZavtra==$timeSegodnyaPlus86400))
										{

											?>

											<a class="a_blocked" id_el=<?=$item['ID']?>>Добавить</a>
											<?
										} 
										else 
										{
											?>
											<a href="" class="add-plitka <?=$QUANTITY[$DATASEC[$item['ID']][$_SESSION['datasec']]]? 'update':false?> <?/*if ($cat=='83642ac4-04bf-11e6-afd0-901b0e6067a7' and $arBasketItemsProps[$item['ID']]=='' and $item['PROPERTIES']['VTOROE_BLYUDO_S_GARNIROM']['VALUE']=='Да'){echo ' garnir_add';}*/?>" id_el=<?=$item['ID']?>>Добавить</a>
											<?
										}
										?></div>
									</div>

								</div>

							</div>
						</div>
						<div class="clear"></div>
						<?  
					}
					else 
					{

						?>
						<div itemscope itemtype="http://schema.org/Product" 
						class="item-spisok el<?=$item['ID']?> plitka-item itemitemproduct <?=$DATASEC[$item['ID']][$_SESSION['datasec']]?" active":""?>" 
						id_el="<?=$item['ID']?>">

						<div class="imgh2 ">
							<?if($item['PREVIEW_PICTURE']['SRC']=='')
							{
								?>
								<img class='lazy in-img' data-src="/images/no_foto/<?=$cat?>.jpg?d<?=rand(1,10000)?>=<?=rand(1,10000)?>" />
								<?
							}
							else
							{ 

								$file = CFile::ResizeImageGet($item['PREVIEW_PICTURE']['ID'], array('width'=>204, 'height'=>150), BX_RESIZE_IMAGE_EXACT, true);                

								?>

								<img class="in-img lazy" itemprop="image"  data-src="<?=$file['src']?>" />
								<!--div class="hit"></div-->
								<a class="lupa2 fancy" href="<?=$item['PREVIEW_PICTURE']['SRC']?>"></a>
								<?
							}

							
							$strlen = (int)mb_strlen($item['NAME']);


							$ingr = implode(', ',$item['PROPERTIES']['INGREDIENTY']['VALUE']);
							$ingr2 = $ingr;
							$strlen_ingr = (int)mb_strlen($ingr);
							if ($strlen_ingr>82)
							{

								$ingr = mb_substr($ingr, 0, 82).'...';
							}

							if($urlPath[2]=='prazdnichie-bluda')
							{

							}



							?>
							<div class="hsos">
								<div class='h2' itemprop="name"><?=str_replace('&quot;','"',$NAME)?></div>
								<span class="dnone dh2">
									<?=str_replace('&quot;','"',$item['NAME'])?>
								</span>
								<div class="ingr" itemprop="description"><?=$NAME2?:$ingr2?></div>
								<span class="dnone ingr2"><?=$NAME2?:$ingr2?></span>
							</div>
						</div>
						<div class="wt">
							<?
							if (
								$item['PROPERTIES']['PROTEIN']['VALUE'] &&
								$item['PROPERTIES']['FAT']['VALUE'] &&
								$item['PROPERTIES']['CARBOHYDRATE']['VALUE']
							)
							{
								?>
								
								Белки:&nbsp;<?=$item['PROPERTIES']['PROTEIN']['VALUE']?>, 
								Жиры:&nbsp;<?=$item['PROPERTIES']['FAT']['VALUE']?>, 
								Углеводы:&nbsp;<?=$item['PROPERTIES']['CARBOHYDRATE']['VALUE']?>, 

								
								<?
							}
							?>
							Вес <?=$item['PROPERTIES']['VES_OBEM']['VALUE']?> гр, Ккал <?=$item['PROPERTIES']['KALORIYNOST']['VALUE']?></div>
							
							<div class="quantity-cena">
								<div class="quantity">
									<span class="plus" idprfored='<?=$item['ID']?>'></span>
									<input class="qn"  idprfored='<?=$item['ID']?>'  type="text" value="<?=$QUANTITY[$DATASEC[$item['ID']][$_SESSION['datasec']]]?:0?>" />
									<span class="minus" idprfored='<?=$item['ID']?>'></span>
									
								</div>
								<div class="cena"  itemprop="offers" itemscope itemtype="http://schema.org/Offer">
									<span itemprop="price"><?=$item['CATALOG_PRICE_1']?></span> <span>руб.<span style='display:none;' itemprop="priceCurrency">RUB</span></span>
								</div>
							</div>

							<div class='CATALOG_PRICE_1' style="display: none;" ><?=$item['CATALOG_PRICE_1']?> </div>
							<div class='product_id'  style="display: none;" ><?=$item['ID']?> </div>
							<div class='week' style="display: none;" ><?=$_SESSION['Week']?> </div>
							<div class='day' style="display: none;" ><?=$_SESSION['dey']?></div>
							<div class='dayint' style="display: none;" ><?=$_SESSION['dayint']?></div>
							<div class='datasec' style="display: none;" ><?=$_SESSION['datasec']?></div>
							<div class='basketitemid' style="display: none;" ><?=$DATASEC[$item['ID']][$_SESSION['datasec']]?></div>

							<div class='date' style="display: none;" ><?=$_SESSION['dey2']?></div>
							<div class='kat' style="display: none;" ><?=$item['PROPERTIES']['KATEGORIYA']['VALUE']?> </div>
							<div class='promo' style="display: none;" ><?=$item['PROPERTIES']['PROMO_PRODUKTSIYA']['VALUE']?"Да":"Нет"?></div>
							<? 
							$timeZavtra = $_SESSION['datasec'];
							$timeSegodnyaPlus86400 = time()+86400;
							$timeSegodnyaPlus86400 = strtotime(date('d.m.Y',$timeSegodnyaPlus86400));
							$timeHour = date('H',time());
							if ($_SESSION['dey2']==date('d.m.Y') or ($timeHour>=17 and $timeZavtra==$timeSegodnyaPlus86400))
							{

								?>

								<a class="a_blocked" id_el=<?=$item['ID']?>>Добавить</a>
								<?
							}
							else 
							{

								?>
								<a 
								style="cursor: pointer;"  
								class="add-plitka 
								<?/*if ($cat=='83642ac4-04bf-11e6-afd0-901b0e6067a7' and $arBasketItemsProps[$item['ID']]=='' and $item['PROPERTIES']['VTOROE_BLYUDO_S_GARNIROM']['VALUE']=='Да'){echo ' garnir_add';}*/?>" 
								id_el=<?=$item['ID']?>
								>
								Добавить
							</a>
							<div class="info-garnir">

								<?if($item['PROPERTIES']['VTOROE_BLYUDO_S_GARNIROM']['VALUE']=='Да')
								{
									if ($cat=='83642ac4-04bf-11e6-afd0-901b0e6067a7')
									{
										?>
										
										Не забудьте добавить гарнир
										

										<?

										/*
										?> 
										<div class="garnir_val vibrat_garnir"><a idr="<?=$item['ID']?>" day="<?=$_SESSION['dey2']?>"  href="#">Выбрать гарнир</a></div>
										<div class="garnir<?=$item['ID']?>" style="display: none;"></div>
										<?
										*/
									}
									else{
										?>&nbsp;<?
									}
								}
								else
								{
									
									?>&nbsp;<?

								/*
									?>
									<div class="garnir_val vibrat_garnir"><a idr="<?=$item['ID']?>" day="<?=$_SESSION['dey2']?>"  href="#" style='text-decoration:none'>&nbsp;</a></div>
									<?
								*/}	
								}

								?>
							</div>


						</div>


						<?
					}

				} 


				?>
			</div>
			<?
			if ($PROMO)
			{
				?>

				<div id="id-PROMO" class="h2-h2">Промо продукция</div>
				<div class="item-list">

				</div>

				<?
			}
			?>
			<div class="cl"></div>
			<?

			$_SESSION['tid']=0;
			$limit = 0;

			global $USER;
			if ($USER->IsAuthorized()){ 
				$rsUser = CUser::GetByID($USER->GetID());
				$arUser = $rsUser->Fetch();

				if(isset($arUser['UF_LIMIT']) and $arUser['UF_LIMIT']!='' and $arUser['UF_LIMIT']!=0){
					$limit = $arUser['UF_LIMIT'];
				}

			}

			$priceOrderDat = priceOrderDat($_SESSION['dey2']);

			?>


			

			<?
			if ($arParams['AJAX'] == 'N' || !$arParams['AJAX'])
			{
				?>
				<script>
					var tipJson = {}, PROMO = {};

					<?

					if ($arResult['MOD']['TIP_JSON'])
					{
						?>	
						//var tipJson = {},PROMO = {};
						$(function(){

							$('.tip').on('click',function()
							{
								var tip = $(this).data('tip');

								$('.loading-vspl, .allfon').show();
								if ($(this).hasClass('active'))
								{
									
									$(this).removeClass('active');
									$('.plitka-item').show();
									setTimeout(function(){
										$('.loading-vspl, .allfon').hide();
									},500);
									return;
								}

								$('.tip').removeClass('active');
								$('.plitka-item').show();

								$(this).addClass('active');

								var res = [];
								for (k in tipJson)
								{
									var disabled = true;
									for (kk in tipJson[k])
									{

										if (tip == tipJson[k][kk])
										{	
											disabled = false;

											continue;
										}

									}

									if (disabled)
									{
										res.push(k);

									}

								}

								res.forEach(function(item, i, arr) {
									$("#el"+item).hide();
								});

								setTimeout(function(){
									$('.loading-vspl, .allfon').hide();
								},500);
								


							});
						});

						<?
					}

					?>



					var click_plus = false,
					click_minus = false;

					$( document ).ready(function() {
						if (PROMO)
						{
							var where = $("#id-PROMO").next('.item-list');
							for(key in PROMO)
							{
								$('.el'+PROMO[key]).clone().addClass('clone').appendTo(where); 

							}

						};

						$('.item-list .qn').on('focusout', function()
						{
							// if ($(this).closest('.clone'))
							// 	var clone = '.clone'
							var idprfored = $(this).attr('idprfored'),
							val = parseInt($(this).val());

							$('.el'+idprfored+' .qn').val(val);

							if (!$('.el'+idprfored).hasClass('active'))
							{
								click_plus = false,
								click_minus = false;
							}

							if (val)
							{	
								$('.add-plitka[id_el="'+idprfored+'"]').trigger('click');
							}
							

						})

						$(document).on('click','.item-list .plus',function() {

							// if ($(this).closest('.clone'))
							// 	var clone = '.clone'

							click_plus = true;
							click_minus = false;
							var a = $(this).next('input').val(),
							idprfored = parseInt($(this).attr('idprfored'));

							var sum = parseInt(a) + 1;
							$('.el'+idprfored+' .qn').val(sum);

							$('.add-plitka[id_el="'+idprfored+'"]').trigger('click');

						});

						$('.item-list .minus').click(function() {
							// if ($(this).closest('.clone'))
							// 	var clone = '.clone'

							click_plus = false;
							click_minus = true;

							var a = $(this).prev('input').val(),
							idprfored = parseInt($(this).attr('idprfored'));
							if (parseInt(a) > 0) {
								var sum = parseInt(a) - 1;
								$('.el'+idprfored+' .qn').val(sum);
								$('.add-plitka[id_el="'+idprfored+'"]').trigger('click');

								if (sum == 0)
								{	

									$('.el'+idprfored).removeClass('active');
								} 

							}

						});

						$(document).on('click','.add-plitka', function(e) {

							var id = $(this).attr('id_el');
							var limit = <?=$limit?>;
							var priceOrderDat = <?=$priceOrderDat?>,
							update = $('.el'+id).hasClass('active')? true : false ;

							if($(this).hasClass('garnir_add') && !click_minus)
							{
								$('.da_dagar1').attr('id_garr',id);
								$('.da_dagar2').attr('id_garr',id);
								$('.garnir-vspl, .allfon').attr('style','display:block;');
							}
							else
							{
								var product_id = update? $(this).siblings('.basketitemid').text() :$(this).siblings('.product_id').text();
								var week = $(this).siblings('.week').text();
								var day = $(this).siblings('.day').text();

								var dayint = $(this).siblings('.dayint').text();
								var datasec = $(this).siblings('.datasec').text();
								var date = $(this).siblings('.date').text();
								var kat = $(this).siblings('.kat').text();
								var promo = $(this).siblings('.promo').text();

								var datasecsumm = $('.sum'+day+' span').text();
								if(!datasecsumm)
								{
									datasecsumm = 0;
								}

								datasecsumm = parseFloat(datasecsumm)+parseFloat(priceOrderDat);

								add_plitka(id,product_id,week,day,dayint,datasec,date,kat,limit,datasecsumm,promo, update);
								$('.el'+id).addClass('active');

							}


							return false ;
						}) 

						$('.garnir_val a').on('click',function(){/*выбрать гарнир ко вторым блюдам*/
							var idr = $(this).attr('idr');
							var day = $(this).attr('day');

							var limit = $('#limit').val();
							var priceOrderDat = <?=$priceOrderDat?>;
							var day2 = $('.el'+idr+' .day').text();
							var datasecsumm = $('.sum'+day2+' span').text();
							if(!datasecsumm){
								datasecsumm = 0;
							}

							datasecsumm = parseFloat(datasecsumm)+parseFloat(priceOrderDat);
							garnir_ajax(idr,day,limit,datasecsumm);		
							return false;	
						});

						$('.da_dagar1').on('click',function() {
							var id = $(this).attr('id_garr');
							$('.garnir-vspl, .allfon').attr('style','display:none;');
							var idr = id;
							var day = $('.el'+id+' .garnir_val a').attr('day');
							var limit = $('#limit').val();
							var priceOrderDat = <?=$priceOrderDat?>;
							var day2 = $('.el'+idr+' .day').text();
							var datasecsumm = $('.sum'+day2+' span').text();
							if(!datasecsumm){
								datasecsumm = 0;
							}
							datasecsumm = parseFloat(datasecsumm)+parseFloat(priceOrderDat);

							garnir_ajax(idr,day,limit,datasecsumm);


							return false ;
						});

						$('.da_dagar2').on('click',function() {
							var id = $(this).attr('id_garr');
							$('.garnir-vspl, .allfon').attr('style','display:none;');
							var limit = $('#limit').val();
							var priceOrderDat = <?=$priceOrderDat?>;

							var product_id = $('.el'+id+' .product_id').text();
							var week = $('.el'+id+' .week').text();
							var day = $('.el'+id+' .day').text();
							var dayint = $('.el'+id+' .dayint').text();
							var datasec = $('.el'+id+' .datasec').text();
							var date = $('.el'+id+' .date').text();
							var kat = $('.el'+id+' .kat').text();
							var promo = $('.el'+id+' .promo').text();


							var datasecsumm = $('.sum'+day+' span').text();
							if(!datasecsumm){
								datasecsumm = 0;
							}

							datasecsumm = parseFloat(datasecsumm)+parseFloat(priceOrderDat);
							add_plitka(id,product_id,week,day,dayint,datasec,date,kat,limit,datasecsumm,promo);

							return false ; 
						})



						function garnir_ajax(idr,day,limit,datasecsumm)
						{
							var cat = '8bf83290-6892-11e6-a1b8-901b0e6067a7';
							var catname = 'Гарниры';
							var id_garnir = $('.garnir'+idr).text();

							$('.ind-vspl, .allfon').attr('style','display:block;');	
							$.post(
								"/ajax/ajax_function.php",
								{
									cat:cat,
									catname:catname,
									idr:idr,
									id_garnir:id_garnir,
									day:day,
									limit:limit,
									datasecsumm:datasecsumm,
									action:'garnir_val'

								},function onAjaxSuccess(data){


									$('.ind-vspl').html(data);


									$('.ind-vspl .top .close, .allfon').click(function(){
										$('.ind-vspl, .allfon').attr('style','display:none;');
									});	
								}

								);
							return false;
						}

						function add_plitka(id,product_id,week,day,dayint,datasec,date,kat,limit,datasecsumm,promo )
						{

							var update = $('.el'+id).hasClass('active');
							var qn = update ? $('.el'+id+' .qn').val() : !click_plus && !click_minus? $('.el'+id+' .qn').val() : 1,
							stop = 0;


							if(limit>0)
							{ 

								var sumca = $('.el'+id+' .CATALOG_PRICE_1').text()*qn;
								var sumcaplus = parseFloat(datasecsumm)+parseFloat(sumca);
								/*alert('Вы превысили дневной лимит '+sumca+'-'+sumcaplus+'-'+limit);alert(parseFloat(datasecsumm));*/
								if(sumcaplus>limit){/*alert('Вы превысили дневной лимит '+sumca+'-'+sumcaplus+'-'+limit);*/
								$('.limit-vspl, .allfon').attr('style','display:block;');
								stop = 1;
							}
						}

						if (stop==0)
						{
							$('.loading-vspl, .allfon').attr('style','display:block;');
							$.post(
								"/ajax/addpr.php",
								{
									product_id: product_id,
									week: week,
									day: day,
									dayint: dayint,
									datasec: datasec,
									qn:qn,
									day_for_cart:$("[aria-hidden=false]").attr('id'),
									date:date,
									kat: kat,
									promo: promo,
									limit: limit,
									garnir: $('.garnir'+id).text(),
									action: update ? 'update' : 'add'

								},

								function onAjaxSuccess(data)
								{
						// Здесь мы получаем данные, отправленные сервером и выводим их на экран.
						$('.cart').html(data);
						// $('.el'+id+' .add-plitka').removeClass('garnir_add').addClass('seriybutton').text('Добавлено');
						$('.el'+id+' .add-plitka').addClass('seriybutton').text('Добавлено');
						$('.loading-vspl, .allfon').attr('style','display:none;');
						if (basketitemid)
						{
							
							$('.el'+product_id+' .basketitemid').html(basketitemid);
							
						}
						
					}

					)
						}




					}
				});

			</script>

			<?
		}
		
		$js = "

		tipJson = ".$arResult['MOD']['TIP_JSON'].";
		PROMO = ".json_encode($PROMO).";
		console.log(1);
		";

		file_put_contents($_SERVER['DOCUMENT_ROOT'].SITE_TEMPLATE_PATH."/js_min/catalog.js", $js);
		if ($arParams['AJAX'] == 'N') 
		{
			?>
			<script src='<?=SITE_TEMPLATE_PATH?>/js_min/catalog.js'></script>
			<script src='<?=SITE_TEMPLATE_PATH?>/js_min/catalog-1.js'></script>

			<?
		}


	}
	?>
	
	<?$this->SetViewTarget('ShowCondTitle');?>
	<div id='nav-kategoriya' class=''>
		<div class="h1">КАТЕГОРИИ</div>
		<?
		foreach ($arResult['MOD']['KATEGORIYA'] as $key => $arItem)
		{
			?>
			<div>
				<a class='block-1' href='#id-<?=$key?>'><?=$arItem?></a>
			</div>

			<?
		}
		if ($PROMO){
			?>
			<div>
				<a href='#id-PROMO'>Промо</a>
			</div>
			<?
		}

		?>
		<?$APPLICATION->IncludeComponent("bitrix:main.include", ".default", array(
			"AREA_FILE_SHOW" => "file",
			"PATH" => '/include/rating_popular_dishes.php',
			"EDIT_TEMPLATE" => ""
		),
		false
	);?>
</div>
<?$this->EndViewTarget();?> 

<div class="acht">Заказы на будний день принимаются до 16:00 предыдущего буднего дня.</div>
<div class="acht">Заказы на выходной день принимаются до 13:00 пятницы</div>
