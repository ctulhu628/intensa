<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();
/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */
/** @var CBitrixComponent $component */
$this->setFrameMode(true);

$day = $GLOBALS['arrFilter1']['PROPERTY_DNI'];

$limit = 0;
global $USER;
if ($USER->IsAuthorized())
{
	$rsUser = CUser::GetByID($USER->GetID());
	$arUser = $rsUser->Fetch();

	if(isset($arUser['UF_LIMIT']) and $arUser['UF_LIMIT']!='' and $arUser['UF_LIMIT']!=0){
		$limit = $arUser['UF_LIMIT'];
	} 
}

if (!empty($arResult['MOD']['ITEMS']))
{

	foreach($arResult['MOD']['ITEMS'] as $cat => $KATEGORIYA)
	{
		if ($cat=='058713ac-0ded-11e6-a63e-901b0e581578')
		{
			?>
			<h1>Бизнес-ланчи</h1>
			<div class="combo">Скомбинируй свой бизнес ланч одним кликом <a href=""><img src="/img/combo-img.png" /></a></div>
			<?
			foreach($KATEGORIYA as $item)
			{
				?>
				
				<h2><?=$item['NAME']?></h2>
				<div class="bl bl<?=$bl?> blid<?=$item['ID']?>">
					<?
					$sosatvArrPoDatam2 = explode('~',$item['DETAIL_TEXT']); 

					foreach($sosatvArrPoDatam2 as $sosatvArrPoDatamProver2){
						$DataPoDatam2 = explode(':',$sosatvArrPoDatamProver2);

						if ($DataPoDatam2[0]==$_SESSION['dey2']){
							$sosatvArr3 = explode('*',$DataPoDatam2[1]); 
							break ;
						}
					}

					$blb=1;
					foreach($sosatvArr3 as $XML_ID3)
					{
						$arSelect3 = Array();
						$arFilter3 = Array("IBLOCK_ID" => 40, "XML_ID"=>$XML_ID3);
						$res3 = CIBlockElement::GetList(Array(), $arFilter3, false, Array(), $arSelect3);


						while($ob3 = $res3->GetNextElement())
						{
							$arFields3 = $ob3->GetFields();
							$arProps3 = $ob3->GetProperties();


							$rsFile =  CFile::GetPath($arFields3['DETAIL_PICTURE']);

							?>
							<div class="bl-item blbludo<?=$blb?>">
								<div class="blitin metclick1">
									<?if($rsFile=='')
									{
										?>
										<img id="imgval<?=$arFields3['ID']?>" src="/images/no_foto/<?=$arProps3['KATEGORIYA']['VALUE']?>.jpg" />
										<?
									}
									else 
									{
										?>
										<img  id="imgval<?=$arFields3['ID']?>" src="<?=$rsFile?>" />
										<?
									}
									$ar_res = CPrice::GetBasePrice($arFields3['ID']);
									?>

									<img blbludo="<?=$blb?>" blbl="<?=$bl?>" class="list blicon" src="/img/bl-item-list.png" />
									<p class="name_bl" id="idname<?=$arFields3['ID']?>"><?=$arFields3['NAME']?></p>

									<input type="hidden" value="<?=$arProps3['KALORIYNOST']['VALUE']?>" name="kkall" id="kkal<?=$arFields3['ID']?>">
									<input type="hidden" value="<?=$arProps3['VES_OBEM']['VALUE']?>" name="vess" id="ves<?=$arFields3['ID']?>">
									<input type="hidden" value="<?=$arProps3['SOSTAV']['VALUE']?>" name="sostav" id="sostav<?=$arFields3['ID']?>">
									<input type="hidden" value="<?=$ar_res["PRICE"]?>" name="pricce" id="price<?=$arFields3['ID']?>">
									<a class="podrbl" href="" idbl="<?=$arFields3['ID']?>">подробнее</a>

								</div>
							</div>


							<?

						}
						$blb++;
					}
					?>

					<div class="bl-info">
						<p>Количество</p>
						<div class="quantity">
							<img class="plus" src="/img/plus.png" />
							<input type="text" value="1" /><img class="minus" src="/img/minus.png" />
						</div>
						<div class="price">
							Цена: <span><?=$item['CATALOG_PRICE_1']?> руб.</span>
						</div>
						<? 
						$timeZavtra = $_SESSION['datasec'];
						$timeSegodnyaPlus86400 = time()+86400;
						$timeSegodnyaPlus86400 = strtotime(date('d.m.Y',$timeSegodnyaPlus86400));
						$timeHour = date('H',time());
						if ($_SESSION['dey2']==date('d.m.Y') or ($timeHour>=17 and $timeZavtra==$timeSegodnyaPlus86400))
						{

							/*
							?>
							<a class="a_blocked">Добавить</a>

							<?
							*/
						} 
						else 
						{
							?>	
							<a cat="<?=$item['PROPERTIES']['KATEGORIYA']['VALUE']?>" class="add_bl" href="" ids=<?=$item['ID']?>>Добавить</a>
							<?
						}
						?>

					</div>


				</div>

				<?
				$bl++;

			}
		}
		else if ($cat=='058713ab-0ded-11e6-a63e-901b0e581578')
		{

			foreach($KATEGORIYA as $item)
			{

				$kkal=0;
				$sosatvArrPoDatam = explode('~',$item['DETAIL_TEXT']);

				foreach($sosatvArrPoDatam as $sosatvArrPoDatamProver)
				{
					$DataPoDatam = explode(':',$sosatvArrPoDatamProver);
					$sosatvArr = ''; 
					if ($DataPoDatam[0]==$_SESSION['dey2'])
					{
						$sosatvArr = explode('*',$DataPoDatam[1]); 
						break ;
					}
				}
				if (!$sosatvArr) continue;
				?>

				<div class="plitka el<?=$item['ID']?>">

					<div class="item">
						<div class="kopmsostav">
							<div class="top block-name d-flex align-items-center justify-content-between mb-3">
								<div>
									
										<?
										$NAME = $item['~NAME'];
										$arrName = array();
										preg_match_all("/\((.*)\)/", $NAME, $arrName);
										if ($arrName[0])
										{
											$NAME = str_replace($arrName[0][0], '', $NAME);
											$NAME2 = $arrName[1][0];
										}
										?>
										<?=$NAME?>
									
								</div>
								
								<div class="price block-price">
									<div class="pricekompl">
										<span class="summkompleksa"><?=round($item['CATALOG_PRICE_1'])?> </span><span>руб.</span>
									</div>
								</div>
							</div>
							<div class="bottom sostavlistkopleks mb-3" id="sostavlistkopleksslide<?=$item['ID']?>">
								<div class="swiper-container">
									<div class="swiper-wrapper">
										<?
										$idx = 1;
										foreach($sosatvArr as $XML_ID)
										{

											$catname='Без категории';
											$arFields = $arResult['MOD']['SET'][$XML_ID];

											$kkal+=$kkal+$arFields['PROPERTY_KALORIYNOST_VALUE'];

											$catname = $arResult['MOD']['KATEGORIYA'][$arFields['PROPERTY_KATEGORIYA_VALUE']]['UF_NAME'];

											$img = CFile::ResizeImageGet($arFields["DETAIL_PICTURE"], Array("width" => 250, "height" => 250),BX_RESIZE_IMAGE_PROPORTIONAL_ALT, false, false, false, 90);
											$rsFile = $img['src'];
											$ar_res = $arResult['MOD']['PRICE'][$arFields['ID']];

											$NAME = $arFields['NAME'];
											$arrName = array();
											preg_match_all("/\((.*)\)/", $NAME, $arrName);
											if ($arrName[0])
											{
												$NAME = str_replace($arrName[0][0], '', $NAME);
												$NAME2 = $arrName[1][0];
											}

											?>


											<div class="swiper-slide  ind-item select itemforim<?=$arFields['ID']?> osntextindex<?=$idx?> osncatid<?=$arFields['PROPERTY_KATEGORIYA_VALUE']?>">
												
													<?if($rsFile=='')
													{
														$bg = SITE_TEMPLATE_PATH.'/img/no-photo/'.$cat.'.jpg';
														/*
														?>
														<img class="komlimgizmen" src="<?=SITE_TEMPLATE_PATH?>/img/no-photo/<?=$cat?>.jpg" />
														<?
														*/
													} 
													else 
													{
														$bg = $rsFile;
														/*
														?>
														<img class="komlimgizmen" src="<?=$rsFile?>" />
														<?
														*/
													}


													?>
												<div class='img' style='background-image: url(<?=$bg?>);'>
												</div>
												<div class='block-info'>

													<div  class='block-info-name'>
														<?=$NAME?>
													</div>
													<div >
														<?/*?>
														<span class="sosansosizmen">
															<?=$arProps['SOSTAV']['VALUE']?>
														</span>
														<?*/?>
														<span class="info">
															Вес <span vesajax="<?=$arFields['PROPERTY_VES_OBEM_VALUE']?>"  class="vesajax kopnew"><?=$arFields['PROPERTY_VES_OBEM_VALUE']?></span> гр, Ккал 
															<span kkalajax="<?=$arFields['PROPERTY_KALORIYNOST_VALUE']?>" class="kkalajax kopnew"><?=$arFields['PROPERTY_KALORIYNOST_VALUE']?></span>
														</span>

														<div class="block-price-change d-flex align-items-center justify-content-between ">
															
															<div class="price_div">
																<span class="price_individ kopnew kompprice">
																	<?=round($ar_res["PRICE"])?></span><span> руб.
																</span>
															</div>

															<span cat="<?=$arFields['PROPERTY_KATEGORIYA_VALUE']?>" id_kompleks = "<?=$item['ID']?>" index=<?=$idx?> catname="<?=$catname?>" idr=<?=$arFields['ID']?> max_price="<?=(int)$ar_res['PRICE']?>" idr_name="<?=$arFields['XML_ID']?>" day='<?=json_encode($day)?>' class="izm index<?=$idx?> izm<?=$arFields['PROPERTY_KATEGORIYA_VALUE']?>">

															</span>

														</div>

													</div>
												</div>


											</div>
											<?
										$idx++;	
										}
										?>
										

									</div>
								</div>
								<div class="swiper-button-prev"></div>
								<div class="swiper-button-next"></div>
							</div>
							
							<div class="top">

								<div class="block-button">

									

									<?
									$timeZavtra = $_SESSION['datasec'];
									$timeSegodnyaPlus86400 = time()+86400;
									$timeSegodnyaPlus86400 = strtotime(date('d.m.Y',$timeSegodnyaPlus86400));
									$timeHour = date('H',time());
									if ($_SESSION['dey2']==date('d.m.Y') or ($timeHour>=17 and $timeZavtra==$timeSegodnyaPlus86400))
									{

										?>
										<a class="a_blocked">Добавить</a>
										<?
									}
									else
									{
										?>
										<div class="row">
											<div class="col-6">
												<div aria-label="Basic example" class="btn-group quantity" role="group">
													<button class="btn btn-primary minus" type="button" idprfored="<?=$item['ID']?>">
													</button>
													<div class="form-group">
														<input class="form-control qn" type="text" idprfored="<?=$item['ID']?>" value="1"/>
													</div>
													<button class="btn btn-primary  plus" type="button" idprfored="<?=$item['ID']?>">
													</button>
												</div>
											</div>
											<div class="col-6 price d-flex align-items-center justify-content-end">
												<div class='CATALOG_PRICE_1' style="display: none;" ><?=$item['CATALOG_PRICE_1']?> </div>
												<div class='product_id' style="display: none;" ><?=$item['ID']?> </div>
												<div class='week' style="display: none;" ><?=$_SESSION['Week']?> </div>
												<div class='day' style="display: none;" ><?=$_SESSION['dey']?></div>
												<div class='dayint' style="display: none;" ><?=$_SESSION['dayint']?></div>
												<div class='datasec' style="display: none;" ><?=$_SESSION['datasec']?></div>
												<div class='date' style="display: none;" ><?=$_SESSION['dey2']?></div>
												<div class='kat' style="display: none;" ><?=$item['PROPERTIES']['KATEGORIYA']['VALUE']?> </div>

												<a class="add-plitka btn btn-primary" href="" id_el=<?=$item['ID']?>>Добавить</a>
											</div>
										</div>
										
										<?
									}
									?>

								</div>
							</div>
						</div>
					</div>
				</div>

				<hr>

				
				<script type="text/javascript">
					$(function(){

						mySwiperKomplex<?=$item['ID']?> = new Swiper('#sostavlistkopleksslide<?=$item['ID']?> .swiper-container', {
							slidesPerView: 2,
							spaceBetween: 5,
							navigation: {
								nextEl: '#sostavlistkopleksslide<?=$item['ID']?> .swiper-button-next',
								prevEl: '#sostavlistkopleksslide<?=$item['ID']?> .swiper-button-prev',
							},
								/*
								breakpoints: {
									576: {
										slidesPerView: 3,
										spaceBetween: 5
									},
									768: {
										slidesPerView: 5,
										spaceBetween: 5
									},
									992: {
										slidesPerView: 8,
										spaceBetween: 5
									},
									1200: {
										slidesPerView: 10,
										spaceBetween: 5
									},
								}
								*/
							});
					})

				</script>
				<?
				


			}

		}

	}

}

$_SESSION['tid']=0;
$limit = 0;
global $USER;
if ($USER->IsAuthorized())
{
	$rsUser = CUser::GetByID($USER->GetID());
	$arUser = $rsUser->Fetch();

	if(isset($arUser['UF_LIMIT']) and $arUser['UF_LIMIT']!='' and $arUser['UF_LIMIT']!=0)
	{
		$limit = $arUser['UF_LIMIT'];
	}

}

$priceOrderDat = priceOrderDat($_SESSION['dey2']);
?>

<script>

	$( document ).ready(function() {

		$('.add-plitka').click(function() {

			var id = $(this).attr('id_el');
			var qn=$('.el'+id+' .qn').val();
			var day=$(this).siblings('.day').text();
			var limit = <?=$limit?>;
			var stop = 0;
			var priceOrderDat = <?=$priceOrderDat?>;
			
			if(limit > 0)
			{
				var datasecsumm = $('.sum'+day+' span').text();
				if(!datasecsumm)
				{
					datasecsumm = 0;
				}
				datasecsumm = parseFloat(datasecsumm)+parseFloat(priceOrderDat);

				var sumca = $('.el'+id+' .CATALOG_PRICE_1').text()*qn;
				var sumcaplus = parseFloat(datasecsumm)+parseFloat(sumca);

				if(sumcaplus>limit){

					$('.limit-vspl, .allfon').attr('style','display:block;');
					stop = 1;
				}
			}

			if (stop==0){

				$('.loading-vspl').toggleClass('open');
				

				var sostavArr = [];
				$('.el'+id+' .izm').each(function(i){
					sostavArr[i] = $(this).attr('idr_name');

				})
				sostav = sostavArr.join('; ');
				$.post(
					"/ajax/addpr.php",
					{
						product_id: $(this).siblings('.product_id').text(),
						week: $(this).siblings('.week').text(),
						day: $(this).siblings('.day').text(),
						dayint: $(this).siblings('.dayint').text(),
						datasec: $(this).siblings('.datasec').text(),
						qn:$('.el'+id+' .qn').val(),
						day_for_cart:$("[aria-hidden=false]").attr('id'),
						date:$(this).siblings('.date').text(),
						kat: $(this).siblings('.kat').text(),
						sostav: sostav,
						action:'add'

					}
					,
					onAjaxSuccess
					)

				function onAjaxSuccess(data)
				{

					$('.cart').html(data);
					$('.el'+id+' .add-plitka').addClass('seriybutton').text('Добавлено');
					small_basket();
					$('.loading-vspl').toggleClass('open');

				}

			}
			return false ;
		})


		$('.add_individ').click(
			function(){
				var lenght = $('.individ .izmindiv').length;
				var il = 1;
				var idArr = [];
				var day=$(this).attr('dayden');
				var limit = <?=$limit?>;
				var stop = 0;

				if(limit>0){
					var datasecsumm = $('.sum'+day+' span').text();
					if(!datasecsumm){
						datasecsumm = 0;
					}
					var sumca = $('#summ_individ').text();
					var sumcaplus = parseFloat(datasecsumm)+parseFloat(sumca);

					if(sumcaplus>limit){

						$('.limit-vspl, .allfon').attr('style','display:block;');
						stop = 1;
					}
				}

				if (stop==0){
					$('.individ .izmindiv').each(function(){


						var id = $(this).attr('idr');
						if (id!=0){	
							idArr.push(id) 
						}
						product_id_list = idArr.join(',');
						il++;
					})
					if (product_id_list!=''){
						$.post(
							"/ajax/addpr.php",
							{
								product_id_list: product_id_list,
								week: '<?=$_SESSION['Week']?>',
								day: '<?=$_SESSION['dey']?>',
								dayint: '<?=$_SESSION['dayint']?>',
								datasec: '<?=$_SESSION['datasec']?>',
								qn:$('.individ-info .quantity input').val(),
								day_for_cart:'<?=$_SESSION['dey']?>',
								date:'<?=$_SESSION['dey2']?>',
								kat: 'individ',
								limit: limit,
								action:'add_individ'

							},
							function onAjaxSuccess(data)
							{


								$('.cart').html(data);

							}
							)
					}		
				} 
				return false;	
			}

			);


		$('.add_bl').click(	
			function(){
				var limit = $('#limit').val();
				var id_bl = $(this).attr('ids');
				var qn = $('.blid'+id_bl+' .bl-info .quantity input').val();
				var day = '<?=$_SESSION['dey']?>';
				var priceOrderDat = <?=$priceOrderDat?>;
				var stop = 0;

				if(limit>0){
					var datasecsumm = $('.sum'+day+' span').text();
					if(!datasecsumm){
						datasecsumm = 0;
					}
					datasecsumm = parseFloat(datasecsumm)+parseFloat(priceOrderDat);
					var sumca = $('.el'+id_bl+' .CATALOG_PRICE_1').text()*qn;
					var sumcaplus = parseFloat(datasecsumm)+parseFloat(sumca);


					if(sumcaplus>limit){

						$('.limit-vspl, .allfon').attr('style','display:block;');
						stop = 1;
					}
				}
				if (stop==0){
					var cat = $(this).attr('cat');
					var idArr2 = [];		
					$('.blid'+id_bl+' .bl-item .metclick1 .podrbl').each(function(){
						var id_bllist = $(this).attr('idbl');


						idArr2.push(id_bllist) 

						id_list = idArr2.join(';');

					})


					$.post(
						"/ajax/addpr.php",
						{
							id: id_bl,
							sostav: id_list,
							week: '<?=$_SESSION['Week']?>',
							day: day,
							dayint: '<?=$_SESSION['dayint']?>',
							datasec: '<?=$_SESSION['datasec']?>',
							qn:qn,
							day_for_cart:'<?=$_SESSION['dey']?>',
							date:'<?=$_SESSION['dey2']?>',
							kat: cat,
							action:'add_bl'

						},
						function onAjaxSuccess(data)
						{


							$('.cart').html(data);

						}
						)
				}		

				return false;	
			}

			);

	}); 

</script>
