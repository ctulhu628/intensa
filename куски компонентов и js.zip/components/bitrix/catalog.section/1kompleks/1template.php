<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();
/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */
/** @var CBitrixComponent $component */
$this->setFrameMode(true);
?>

<?
$day = $GLOBALS['arrFilter1']['PROPERTY_DNI'];
//print_r($GLOBALS['arrFilter1']['PROPERTY_DNI']);


$limit = 0;
global $USER;
if ($USER->IsAuthorized()){ 
	$rsUser = CUser::GetByID($USER->GetID());
	$arUser = $rsUser->Fetch();

	if(isset($arUser['UF_LIMIT']) and $arUser['UF_LIMIT']!='' and $arUser['UF_LIMIT']!=0){
		$limit = $arUser['UF_LIMIT'];
	} 
}

if (!empty($arResult['ITEMS']))
{
	$cur_page_no_index = $APPLICATION->GetCurPage(false);
//print_r($_GET) ;
	$uriusArr_plitka = array();
	$uriusArr_spisok = array();
	foreach($_GET as $key=>$get){
		$uriusArr_plitka[]= $key.'='.$get;
		$uriusArr_spisok[]= $key.'='.$get;
	}
	$uriusArr_spisok[] = 'p=spisok';
	$uriusArr_plitka[]= 'p=plitka';
	$urius_spisok = implode('&',$uriusArr_spisok);
	$urius_plitka = implode('&',$uriusArr_plitka);

	?>


	<? 
	//print_r($arResult['KATN']) ;
	foreach($arResult['KATN'] AS $cat){
		
		CModule::IncludeModule('highloadblock');
$hlblock_id = 4; // ID вашего Highload-блока
$hlblock = Bitrix\Highloadblock\HighloadBlockTable::getById( $hlblock_id )->fetch(); // получаем объект вашего HL блока
$entity = Bitrix\Highloadblock\HighloadBlockTable::compileEntity( $hlblock );  // получаем рабочую сущность
$entity_data_class = $entity->getDataClass(); // получаем экземпляр класса
$entity_table_name = $hlblock['TABLE_NAME']; // присваиваем переменной название HL таблицы
$sTableID = 'tbl_'.$entity_table_name; // добавляем префикс и окончательно формируем название
$arFilter = array("UF_XML_ID" => $cat); // зададим фильтр по ID пользователя
$arSelect = array('*'); // выбираем все поля
$arOrder = array("UF_SORT"=>"ASC"); // сортировка будет по возрастанию ID статей

// подготавливаем данные
$rsData = $entity_data_class::getList(array(
	"select" => $arSelect,
	"filter" => $arFilter,
 //ограничим выборку пятью элементами
	"order" => $arOrder
));

// выполняем запрос. Передаем в него наши данные и название таблицы, которое мы получили в самом начале
$rsData = new CDBResult($rsData, $sTableID); // записываем в переменную объект CDBResult

//echo $cat;echo '<br>';
// а далее простой цикл и знакомый нам метод Fetch (или GetNext, кому что нравится)
if ($cat=='058713ac-0ded-11e6-a63e-901b0e581578'){
	IF($arRes = $rsData->Fetch()){

		?>
		<h1>Бизнес-ланчи</h1>
		<div class="combo">Скомбинируй свой бизнес ланч одним кликом <a href=""><img src="/img/combo-img.png" /></a></div>
		<?} $bl=1;
		foreach ($arResult['ITEMS'] as $item) {
			if($item['PROPERTIES']['KATEGORIYA']['VALUE']==$cat){ 
				?>
				<div class="cl"></div>
				<h2><?=$item['NAME']?></h2>
				<div class="bl bl<?=$bl?> blid<?=$item['ID']?>">
					<?
					$sosatvArrPoDatam2 = explode('~',$item['DETAIL_TEXT']); 
		//print_r($sosatvArrPoDatam) ;
					foreach($sosatvArrPoDatam2 as $sosatvArrPoDatamProver2){
						$DataPoDatam2 = explode(':',$sosatvArrPoDatamProver2);

						if ($DataPoDatam2[0]==$_SESSION['dey2']){
							$sosatvArr3 = explode('*',$DataPoDatam2[1]); 
							break ;
						}
					}
		//$sosatvArr3 = explode('*',$item['PROPERTIES']['SOSTAV_DLYA_SAYTA']['VALUE']); 
					$blb=1;
					foreach($sosatvArr3 as $XML_ID3){
						$arSelect3 = Array();
						$arFilter3 = Array("IBLOCK_ID"=>40, "XML_ID"=>$XML_ID3);
						$res3 = CIBlockElement::GetList(Array(), $arFilter3, false, Array(), $arSelect3);


						while($ob3 = $res3->GetNextElement())
						{
							$arFields3 = $ob3->GetFields();
							$arProps3 = $ob3->GetProperties();
			  //print_r($arFields3);

							$rsFile =  CFile::GetPath($arFields3['DETAIL_PICTURE']);

							?>
							<div class="bl-item blbludo<?=$blb?>">
								<div class="blitin metclick1">
									<?if($rsFile==''){
										?>
										<img id="imgval<?=$arFields3['ID']?>" src="/images/no_foto/<?=$arProps3['KATEGORIYA']['VALUE']?>.jpg" />
										<?
									} else {?>
										<img  id="imgval<?=$arFields3['ID']?>" src="<?=$rsFile?>" />
										<?}
										$ar_res = CPrice::GetBasePrice($arFields3['ID']);
										?>

										<img blbludo="<?=$blb?>" blbl="<?=$bl?>" class="list blicon" src="/img/bl-item-list.png" />
										<p class="name_bl" id="idname<?=$arFields3['ID']?>"><?=$arFields3['NAME']?></p>

										<input type="hidden" value="<?=$arProps3['KALORIYNOST']['VALUE']?>" name="kkall" id="kkal<?=$arFields3['ID']?>">
										<input type="hidden" value="<?=$arProps3['VES_OBEM']['VALUE']?>" name="vess" id="ves<?=$arFields3['ID']?>">
										<input type="hidden" value="<?=$arProps3['SOSTAV']['VALUE']?>" name="sostav" id="sostav<?=$arFields3['ID']?>">
										<input type="hidden" value="<?=$ar_res["PRICE"]?>" name="pricce" id="price<?=$arFields3['ID']?>">
										<a class="podrbl" href="" idbl="<?=$arFields3['ID']?>">подробнее</a>
									</div>
								</div>


								<?

							}
							$blb++;
						}
						?>

						<div class="bl-info">
							<p>Количество</p>
							<div class="quantity"><img class="plus" src="/img/plus.png" /><input type="text" value="1" /><img class="minus" src="/img/minus.png" /></div>
							<div class="price">Цена: <span><?=$item['CATALOG_PRICE_1']?> руб.</span></div>
							<? $timeZavtra = $_SESSION['datasec'];
							$timeSegodnyaPlus86400 = time()+86400;
							$timeSegodnyaPlus86400 = strtotime(date('d.m.Y',$timeSegodnyaPlus86400));
							$timeHour = date('H',time());
							if ($_SESSION['dey2']==date('d.m.Y') or ($timeHour>=17 and $timeZavtra==$timeSegodnyaPlus86400)){
					//if ($_SESSION['dey2']==date('d.m.Y')){
								?>
								<a class="a_blocked">Добавить</a>

								<?} else {?>
									<a cat="<?=$item['PROPERTIES']['KATEGORIYA']['VALUE']?>" class="add_bl" href="" ids=<?=$item['ID']?>>Добавить</a>
									<?}?>

								</div>


							</div>

							<?
							$bl++;
						}?>
						<?}?>
						<div class="hr"></div>

						<div class="cl"></div>
						<?} else if ($cat=='058713ab-0ded-11e6-a63e-901b0e581578'){

							?>
							<h1>Комплексные обеды</h1>
							<div class="sort_block">
								<select>
									<option selected="selected">Выбрать по популярности</option>
									<option>популярное за неделю</option>
									<option>популярное за месяц</option>
									<option>хит продаж</option>
									<option>новинки</option>
								</select>


								<div class="down-print">
									<div class="xsldonw"><img src="/img/xls.png"><a href="">Скачать xls</a></div>
									<!--div class="xslprint"><img src="/img/print.png"><a href="">Распечатать</a></div-->
								</div>

								<div class="cl"></div>   
							</div>

							<?
							foreach ($arResult['ITEMS'] as $item) {
  							//print_r($item['DETAIL_TEXT']) ;

								if($item['PROPERTIES']['KATEGORIYA']['VALUE']==$cat)
								{
									$kkal=0;
									$sosatvArrPoDatam = explode('~',$item['DETAIL_TEXT']);
									//print_r($sosatvArrPoDatam) ;
									foreach($sosatvArrPoDatam as $sosatvArrPoDatamProver)
									{
										$DataPoDatam = explode(':',$sosatvArrPoDatamProver);
										$sosatvArr = ''; 
										if ($DataPoDatam[0]==$_SESSION['dey2'])
										{
											$sosatvArr = explode('*',$DataPoDatam[1]); 
											break ;
										}
									}
									if (!$sosatvArr) continue;
									?>


									<div class="cl"></div>


									<div class="plitka el<?=$item['ID']?>">
										<h4><?=$item['NAME']?> 1</h4>
										<div class="item">
											<?/*?><div class="col col-1">
												<div class="top">Фото</div>
												<div class="bottom">
													<?if($item['PREVIEW_PICTURE']['SRC']==''){
														?>
														<img src="/images/no_foto/<?=$cat?>.jpg" />
														<?
													} else {
														?>

														<img src="<?=$item['PREVIEW_PICTURE']['SRC']?>" />
														<!--div class="hit"></div-->
														<div class="new" style="display: none;"></div>
														<a id="example1" class="lupa" href="<?=$item['PREVIEW_PICTURE']['SRC']?>"><img src="/img/lupa.png" /></a>
														<?
													}?>

												</div>
												</div><?*/?>
												<div class="col col-2 kopmsostav">
													<div class="top">Состав обеда</div>
													<span class="prev<?=$item['ID']?> prevkompleks"></span>
													<div class="bottom sostavlistkopleks " id="sostavlistkopleksslide<?=$item['ID']?>">

														<ul>
															<?


															$idx = 1;
															$price_for_econom = 0;
															foreach($sosatvArr as $XML_ID){
																$arSelect2 = Array();
																$arFilter2 = Array("IBLOCK_ID"=>40, "XML_ID"=>$XML_ID);
																$res = CIBlockElement::GetList(Array(), $arFilter2, false, Array(), $arSelect2);
																$catname='Без категории';

																while($ob = $res->GetNextElement())
																{
																	$arFields = $ob->GetFields();
																	$arProps = $ob->GetProperties();
							  //print_r($arFields);
																	$kkal+=$kkal+$arProps['KALORIYNOST']['VALUE'];
							  // подготавливаем данные
																	$rsData2 = $entity_data_class::getList(array(
																		"select" => array('*'),
																		"filter" => array("UF_XML_ID" => $arProps['KATEGORIYA']['VALUE']),
								 //ограничим выборку пятью элементами
																		"order" => $arOrder
																	));

								// выполняем запрос. Передаем в него наши данные и название таблицы, которое мы получили в самом начале
								$rsData2 = new CDBResult($rsData2, $sTableID); // записываем в переменную объект CDBResult
								IF($arRes2 = $rsData2->Fetch()){
									$catname=$arRes2['UF_NAME'];
									
								}
								$ar_resPrice = CPrice::GetBasePrice($arFields['ID']); 
								$rsFile =  CFile::GetPath($arFields['DETAIL_PICTURE']);
								$img = CFile::ResizeImageGet($arFields["DETAIL_PICTURE"], Array("width" => 113, "height" => 90),BX_RESIZE_IMAGE_PROPORTIONAL_ALT, false, false, false, 60);
								$rsFile = $img['src'];
								$ar_res = CPrice::GetBasePrice($arFields['ID']);
								
								?>	
								<li class="ind-item select itemforim<?=$arFields['ID']?> osntextindex<?=$idx?> osncatid<?=$arProps['KATEGORIYA']['VALUE']?>">
									<?if($rsFile==''){
										?>
										<img class="komlimgizmen" src="/images/no_foto/<?=$cat?>.jpg" />
										<?
									} else {?>
										<img class="komlimgizmen" src="<?=$rsFile?>" />
										<?}?>

										<!--div class="new"></div-->
										<h5><?=$arFields['NAME']?></h5>
										<p class="sosansosizmen"><?=$arProps['SOSTAV']['VALUE']?></p>
										<p class="info">Вес <span vesajax="<?=$arProps['VES_OBEM']['VALUE']?>"  class="vesajax kopnew"><?=$arProps['VES_OBEM']['VALUE']?></span> гр, Ккал 
											<span kkalajax="<?=$arProps['KALORIYNOST']['VALUE']?>" class="kkalajax kopnew"><?=$arProps['KALORIYNOST']['VALUE']?></span></p>
											<div class="price_div">Цена: <span class="price_individ kopnew kompprice"><?=$ar_res["PRICE"]?></span><span> руб.</span></div>
											<span cat="<?=$arProps['KATEGORIYA']['VALUE']?>" id_kompleks = "<?=$item['ID']?>" index=<?=$idx?> catname="<?=$catname?>" idr=<?=$arFields['ID']?> max_price="<?=(int)$ar_resPrice['PRICE']?>" idr_name="<?=$arFields['XML_ID']?>" day='<?=json_encode($day)?>' class="izm index<?=$idx?> izm<?=$arProps['KATEGORIYA']['VALUE']?>">изменить</span>
											<p class="dnone sostav_p textindex<?=$idx?> catid<?=$arProps['KATEGORIYA']['VALUE']?>"><a id="example1" href="<?=$rsFile?>"><?=$arFields['NAME']?></a></p>


										</li>
										<?
										$price_for_econom += $ar_res["PRICE"];
									}
									$idx++;

								}
						//echo $price_for_econom;
								$economsumm = 0;
								if ($price_for_econom>$item['CATALOG_PRICE_1']){
									$economsumm = $price_for_econom-$item['CATALOG_PRICE_1'];
								}
								?>
							</ul>


						</div>
						<span class="next<?=$item['ID']?> nextkompleks"></span>
					</div>
					<div class="col col-3" style="display :none;">
						<div class="top">Вес</div>
						<div class="bottom">
							<div class="ver-hr"></div>
							<p><?=$item['PROPERTIES']['VES_OBEM']['VALUE']?> гр</p>
						</div>
					</div>
					<div class="col col-4" style="display :none;">
						<div class="top">Ккал.</div>
						<div class="bottom">
							<div class="ver-hr"></div>
							<p><?=$kkal?> ккал</p>
						</div>
					</div>
					<div class="col col-5">
						<div class="top">Количество</div>
						<div class="bottom">
							<div class="ver-hr"></div>
							<div class="quantity"><img class="plus" src="/img/plus.png" /><input class="qn" type="text" value="1" /><img class="minus" src="/img/minus.png" /></div>
						</div>
					</div>
				</div>

				<div class="cl"></div>

				<div class="price">
					<div class="pricekompl">Цена: <span class="summkompleksa"><?=$item['CATALOG_PRICE_1']?> </span><span>руб.</span></div>
					<div class="economtext">Экономия: <span class="econsumm"><?=$economsumm?> </span><span> руб.</span></div>
					<div class='CATALOG_PRICE_1' style="display: none;" ><?=$item['CATALOG_PRICE_1']?> </div>

					<div class='product_id' style="display: none;" ><?=$item['ID']?> </div>
					<div class='week' style="display: none;" ><?=$_SESSION['Week']?> </div>
					<div class='day' style="display: none;" ><?=$_SESSION['dey']?></div>
					<div class='dayint' style="display: none;" ><?=$_SESSION['dayint']?></div>
					<div class='datasec' style="display: none;" ><?=$_SESSION['datasec']?></div>
					<div class='date' style="display: none;" ><?=$_SESSION['dey2']?></div>
					<div class='kat' style="display: none;" ><?=$item['PROPERTIES']['KATEGORIYA']['VALUE']?> </div>

					<? $timeZavtra = $_SESSION['datasec'];
					$timeSegodnyaPlus86400 = time()+86400;
					$timeSegodnyaPlus86400 = strtotime(date('d.m.Y',$timeSegodnyaPlus86400));
					$timeHour = date('H',time());
					if ($_SESSION['dey2']==date('d.m.Y') or ($timeHour>=17 and $timeZavtra==$timeSegodnyaPlus86400)){
					//if ($_SESSION['dey2']==date('d.m.Y')){	
						?>
						<a class="a_blocked">Добавить</a>
						
						<?} else {?>
							<a class="add-plitka" href="" id_el=<?=$item['ID']?>>Добавить</a>
							<?}?>

						</div>

					</div>
					<script type="text/javascript">
						jQuery(function(){

							jQuery("#sostavlistkopleksslide<?=$item['ID']?>").jCarouselLite({
								visible: 5,
								start: 0,
								btnNext: ".next<?=$item['ID']?>",
								btnPrev: ".prev<?=$item['ID']?>",
								circular:false,
								scroll: 1
							});



						});
					</script>
					<?
				}
			} 
		}
	}?>   
	<?}?>




	<div class="hr2"></div>



	<h1>Индивидуальные обеды</h1>

	<div class="combo2">Впишите сумму, которую Вы хотите потратить на обед и выберите из списков нужные блюда. <a><img src="/img/combo-img.png" /></a></div>


	<div class="sum-inp">
		<input type="text" id="stop_summ" value="" placeholder="Введите сумму  не менее  200 руб*" />
		<label summ="0" id="summ_individ">Сумма по выбранным блюдам</label>
	</div>



	<div class="individ">
		<?
		$arSelect2 = Array("ID", "NAME", "DATE_ACTIVE_FROM",'PROPERTY_KATEGORIYA');
		$arFilter2 = Array("IBLOCK_ID"=>IntVal(40), "ACTIVE_DATE"=>"Y", "ACTIVE"=>"Y");
		$res2 = CIBlockElement::GetList(Array(), $arFilter2, false, false, $arSelect2);
		while($ob2 = $res2->GetNextElement())
		{
			$arFields2 = $ob2->GetFields();
			if($arFields2['PROPERTY_KATEGORIYA_VALUE']!=NULL)
			{
				$XID_val[]=$arFields2['PROPERTY_KATEGORIYA_VALUE'];
				$cat_valid[]=array(
					'VALUE'=>$arFields2['PROPERTY_KATEGORIYA_VALUE'],
					'ID'=>$arFields2['PROPERTY_KATEGORIYA_VALUE_ID']

				);
			}
		}

		$XID=array_unique($XID_val);


		CModule::IncludeModule('highloadblock');
				$hlblock_id = 4; // ID вашего Highload-блока
				$hlblock   = Bitrix\Highloadblock\HighloadBlockTable::getById( $hlblock_id )->fetch(); // получаем объект вашего HL блока
				$entity   = Bitrix\Highloadblock\HighloadBlockTable::compileEntity( $hlblock );  // получаем рабочую сущность
				$entity_data_class = $entity->getDataClass(); // получаем экземпляр класса
				$entity_table_name = $hlblock['TABLE_NAME']; // присваиваем переменной название HL таблицы
				$sTableID = 'tbl_'.$entity_table_name; // добавляем префикс и окончательно формируем название
				$arFilter = array("UF_XML_ID" => $XID); // зададим фильтр по ID пользователя
				$arSelect = array('*'); // выбираем все поля
				$arOrder = array("UF_SORT"=>"ASC"); // сортировка будет по возрастанию ID статей

				// подготавливаем данные
				$rsData = $entity_data_class::getList(array(
					"select" => $arSelect,
					"filter" => $arFilter,
				 //ограничим выборку пятью элементами
					"order" => $arOrder
				));

				// выполняем запрос. Передаем в него наши данные и название таблицы, которое мы получили в самом начале
				$rsData = new CDBResult($rsData, $sTableID); // записываем в переменную объект CDBResult

				// а далее простой цикл и знакомый нам метод Fetch (или GetNext, кому что нравится)
				while($arRes = $rsData->Fetch())
				{
					$category[]=$arRes;
				}
				//...

				$catArr = array(
					'ce96029e-2f35-11e6-93dd-901b0e6067a7'=>'ind-img-1.png',
					'83642ac4-04bf-11e6-afd0-901b0e6067a7'=>'ind-img-3.png',
					'83642ac5-04bf-11e6-afd0-901b0e6067a7'=>'ind-img-4.png',
					'bb3295e1-1800-11e6-a63e-901b0e581578'=>'ind-img-6.png',
					'83642ac6-04bf-11e6-afd0-901b0e6067a7'=>'ind-img-7.png',
					'83642ac7-04bf-11e6-afd0-901b0e6067a7'=>'ind-img-5.png',
					'83642ac3-04bf-11e6-afd0-901b0e6067a7'=>'ind-img-2.png'
				);
				
				$cc = 1;
				foreach($category as $cat)
				{
					if($cat['UF_NAME']=='Комплексные обеды' or $cat['UF_NAME']=='Бизнес-ланч' or $cat['UF_NAME']=='Холодные блюда' or $cat['UF_NAME']=='Буфетная продукция')
					{
						continue;
					}

					if($cat['UF_XML_ID']=='ce96029e-2f35-11e6-93dd-901b0e6067a7' or $cat['UF_XML_ID']=='83642ac3-04bf-11e6-afd0-901b0e6067a7' or $cat['UF_XML_ID']=='83642ac4-04bf-11e6-afd0-901b0e6067a7' or $cat['UF_XML_ID']=='83642ac5-04bf-11e6-afd0-901b0e6067a7' or $cat['UF_XML_ID']=='83642ac7-04bf-11e6-afd0-901b0e6067a7' or $cat['UF_XML_ID']=='bb3295e1-1800-11e6-a63e-901b0e581578' or $cat['UF_XML_ID']=='83642ac6-04bf-11e6-afd0-901b0e6067a7')
					{


						foreach ($cat_valid as $value) 
						{
							if ($value['VALUE']==$cat['UF_XML_ID']) 
							{

								$kid=$value['VALUE'];
								$crc=abs(crc32(htmlspecialcharsex($kid))); 
								break;
							}
						}
						?>
						<div class="item" id="itemid<?=$cat['UF_XML_ID']?>">
							<div class="individualka">
								<img class="ind-img" src="<?=SITE_TEMPLATE_PATH?>/img/<?=$catArr[$cat['UF_XML_ID']]?>" />
								<p><?=$cat['UF_NAME']?></p>
							</div>
							<a price="0" ves="0" kkal="0" cat="<?=$cat['UF_XML_ID']?>" catname="<?=$cat['UF_NAME']?>" idr="0" day='<?=json_encode($day)?>' limit="<?=$limit?>" class="izmindiv izmindiv<?=$cat['UF_XML_ID']?>">Выбрать из меню</a>
						</div>
						<?
					}
					
					$cc++;
				}

				?>
			</div>

			<div class="individ-info">
				<span style="margin-right: 23px;">Вес: <span vesind="0" id="vesind">0</span> гр</span>
				<span style="margin-right: 23px;">Ккал: <span kkalind="0" id="kkalind">0</span> ккал</span>
				<span>Количество: 
					<span style="display: inline-block; position: relative; top: 8px; left: -36px;">
						<div class="quantity"><img class="plus" src="/img/plus.png" />
							<input type="text" value="1" />
							<img class="minus" src="/img/minus.png" />
						</div>
					</span>
				</span>

				<?
				$timeZavtra = $_SESSION['datasec'];
				$timeSegodnyaPlus86400 = time()+86400;
				$timeSegodnyaPlus86400 = strtotime(date('d.m.Y',$timeSegodnyaPlus86400));
				$timeHour = date('H',time());
				if ($_SESSION['dey2']==date('d.m.Y') or ($timeHour>=17 and $timeZavtra==$timeSegodnyaPlus86400))
				{

					?><a class="a_blocked">Добавить</a><?

				}
				else
				{
					?><a class="add_individ" dayden="<?=$_SESSION['dey']?>" href="">Добавить</a><?
				}
				?>
			</div>
			<?

			$_SESSION['tid']=0;
			$limit = 0;
			global $USER;
			if ($USER->IsAuthorized())
			{
				$rsUser = CUser::GetByID($USER->GetID());
				$arUser = $rsUser->Fetch();

				if(isset($arUser['UF_LIMIT']) and $arUser['UF_LIMIT']!='' and $arUser['UF_LIMIT']!=0)
				{
					$limit = $arUser['UF_LIMIT'];
				}

			}

			$priceOrderDat = priceOrderDat($_SESSION['dey2']);
			?>
			
			<script>

				$( document ).ready(function() {
	//добавить товар в корзину
	$('.add-plitka').click(function() {
		var id = $(this).attr('id_el');
		var qn=$('.el'+id+' .qn').val();
		var day=$(this).siblings('.day').text();
		var limit = <?=$limit?>;
		var stop = 0;
		var priceOrderDat = <?=$priceOrderDat?>;
		if(limit>0){
			var datasecsumm = $('.sum'+day+' span').text();
			if(!datasecsumm){
				datasecsumm = 0;
			}
			datasecsumm = parseFloat(datasecsumm)+parseFloat(priceOrderDat);

			var sumca = $('.el'+id+' .CATALOG_PRICE_1').text()*qn;
			var sumcaplus = parseFloat(datasecsumm)+parseFloat(sumca);
				//alert(parseFloat(datasecsumm));
				if(sumcaplus>limit){
					//alert('Вы превысили дневной лимит '+sumca+'-'+sumcaplus+'-'+limit);
					$('.limit-vspl, .allfon').attr('style','display:block;');
					stop = 1;
				}
			}
			if (stop==0){
				$('.loading-vspl, .allfon').attr('style','display:block;');
				
				var sostavArr = [];
				$('.el'+id+' .izm').each(function(i){
					sostavArr[i] = $(this).attr('idr_name');
					//sostavArr[i] = $(this).attr('idr');
				})
				sostav = sostavArr.join('; ');
				$.post(
					"/ajax/addpr.php",
					{
						product_id: $(this).siblings('.product_id').text(),
						week: $(this).siblings('.week').text(),
						day: $(this).siblings('.day').text(),
						dayint: $(this).siblings('.dayint').text(),
						datasec: $(this).siblings('.datasec').text(),
						qn:$('.el'+id+' .qn').val(),
						day_for_cart:$("[aria-hidden=false]").attr('id'),
						date:$(this).siblings('.date').text(),
						kat: $(this).siblings('.kat').text(),
						sostav: sostav,
						action:'add'

					},
					onAjaxSuccess
					)

				function onAjaxSuccess(data)
				{
			  // Здесь мы получаем данные, отправленные сервером и выводим их на экран.
			  $('.cart').html(data);
			  $('.el'+id+' .add-plitka').addClass('seriybutton').text('Добавлено');
			  $('.loading-vspl, .allfon').attr('style','display:none;');
			}
			 //$('.cart').html(data);
			}
			return false ;
		})

//индивидуальные - в корзину
$('.add_individ').click(
	function(){
		var lenght = $('.individ .izmindiv').length;
		var il = 1;
		var idArr = [];
		var day=$(this).attr('dayden');
		var limit = <?=$limit?>;
		var stop = 0;
		
		if(limit>0){
			var datasecsumm = $('.sum'+day+' span').text();
			if(!datasecsumm){
				datasecsumm = 0;
			}
			var sumca = $('#summ_individ').text();
			var sumcaplus = parseFloat(datasecsumm)+parseFloat(sumca);
			//alert(parseFloat(sumcaplus)+'--'+limit);
			if(sumcaplus>limit){
				//alert('Вы превысили дневной лимит '+sumca+'-'+sumcaplus+'-'+limit);
				$('.limit-vspl, .allfon').attr('style','display:block;');
				stop = 1;
			}
		}
		
		if (stop==0){
			$('.individ .izmindiv').each(function(){
				

				var id = $(this).attr('idr');
				if (id!=0){	
					idArr.push(id) 
				}
				product_id_list = idArr.join(',');
				il++;
			})
			if (product_id_list!=''){
				$.post(
					"/ajax/addpr.php",
					{
						product_id_list: product_id_list,
						week: '<?=$_SESSION['Week']?>',
						day: '<?=$_SESSION['dey']?>',
						dayint: '<?=$_SESSION['dayint']?>',
						datasec: '<?=$_SESSION['datasec']?>',
						qn:$('.individ-info .quantity input').val(),
						day_for_cart:'<?=$_SESSION['dey']?>',
						date:'<?=$_SESSION['dey2']?>',
						kat: 'individ',
						limit: limit,
						action:'add_individ'

					},
					function onAjaxSuccess(data)
					{

								  // Здесь мы получаем данные, отправленные сервером и выводим их на экран.
								  $('.cart').html(data);

								}
								)
			}		
		} 
		return false;	
	}
	
	);

//бизнес ланчи - в корзину
$('.add_bl').click(
	function(){
		var limit = $('#limit').val();
		var id_bl = $(this).attr('ids');
		var qn = $('.blid'+id_bl+' .bl-info .quantity input').val();
		var day = '<?=$_SESSION['dey']?>';
		var priceOrderDat = <?=$priceOrderDat?>;
		var stop = 0;
		
		if(limit>0){
			var datasecsumm = $('.sum'+day+' span').text();
			if(!datasecsumm){
				datasecsumm = 0;
			}
			datasecsumm = parseFloat(datasecsumm)+parseFloat(priceOrderDat);
			var sumca = $('.el'+id_bl+' .CATALOG_PRICE_1').text()*qn;
			var sumcaplus = parseFloat(datasecsumm)+parseFloat(sumca);
				//alert('Вы превысили дневной лимит '+sumca+'-'+sumcaplus+'-'+limit);
				//alert(parseFloat(datasecsumm));
				if(sumcaplus>limit){
					//alert('Вы превысили дневной лимит '+sumca+'-'+sumcaplus+'-'+limit);
					$('.limit-vspl, .allfon').attr('style','display:block;');
					stop = 1;
				}
			}
			if (stop==0){
				var cat = $(this).attr('cat');
				var idArr2 = [];		
				$('.blid'+id_bl+' .bl-item .metclick1 .podrbl').each(function(){
					var id_bllist = $(this).attr('idbl');


					idArr2.push(id_bllist) 

					id_list = idArr2.join(';');

				})


				$.post(
					"/ajax/addpr.php",
					{
						id: id_bl,
						sostav: id_list,
						week: '<?=$_SESSION['Week']?>',
						day: day,
						dayint: '<?=$_SESSION['dayint']?>',
						datasec: '<?=$_SESSION['datasec']?>',
						qn:qn,
						day_for_cart:'<?=$_SESSION['dey']?>',
						date:'<?=$_SESSION['dey2']?>',
						kat: cat,
						action:'add_bl'

					},
					function onAjaxSuccess(data)
					{

								  // Здесь мы получаем данные, отправленные сервером и выводим их на экран.
								  $('.cart').html(data);

								}
								)
			}		

			return false;	
		}

		);

}); 

</script>
