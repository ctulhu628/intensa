<?
$MESS["RZ_NET__VIBRAT_DRUGOJ_GOROD"] = "Нет, выбрать другой город";
$MESS["RZ_DA__ETO_MOJ_GOROD"] = "Да, это мой город";
$MESS["RZ_VASH_GOROD"] = "Ваш город:";
$MESS["FURNITURE_CHOOSE_CITY"] = "Укажите город";
$MESS["FURNITURE_MODAL_CLOSE"] = "Закрыть";
$MESS["FURNITURE_SELECT_CITY"] = "Или выберите из списка";
$MESS["FURNITURE_POPUP_TITLE"] = "Введите свой город";
$MESS["FURNITURE_SELECTED_CITY"] = "Сейчас выбран";
$MESS["FURNITURE_GEOIP_OK"] = "Это мой город";
$MESS["FURNITURE_ENTER_LOCATION"] = "Или введите название";
$MESS["FURNITURE_FOR_HEADER"] = "Выбор города";
$MESS["FURNITURE_OR_SET_FROM_LIST"] = "Или выберите из списка:";
$MESS["FURNITURE_SHOOSE_YOUR_CITY"] = "Выберите свой город:";
$MESS["FURNITRE_GEOIP_OK"] = "Это мой город!";
$MESS["FURNITRE_CHOOSE_CITY"] = "Выбрать город";
