<?
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED!==true) die();
//HIDE params - not used params
	$arTemplateParameters['COLOR_SCHEME']['HIDDEN'] = 'Y';
	$arTemplateParameters['NEW_FONTS']['HIDDEN'] = 'Y';
	$arTemplateParameters['P1_LOCATION_ID']['HIDDEN'] = 'Y';
	$arTemplateParameters['P1_CITY_ID']['HIDDEN'] = 'Y';
	$arTemplateParameters['P2_LOCATION_ID']['HIDDEN'] = 'Y';
	$arTemplateParameters['P2_CITY_ID']['HIDDEN'] = 'Y';