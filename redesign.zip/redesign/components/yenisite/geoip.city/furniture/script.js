$(document).ready(function(){
	var modal_id = '#modal-city';

	var ysLocCookie = YS.GeoIP.Cookie;
	var town = ysLocCookie.getCookieTown('YS_GEO_IP_CITY');
	var ysLocAutoC	= YS.GeoIP.AutoComplete;

	// city text input handler

	var textchangeInterval;
	$(modal_id).on('keypress', '.form_city-select .ys-city-query',function(e) {
		// console.log('sd');
		if (e.which == 13) // press ENTER
		{
			$('.ys-loc-autocomplete div').eq(0).click();
			return false;
		}

	})
		.on('input', '.form_city-select .ys-city-query', function (e) {
			var txtField = $(this);
			if (txtField.val().length > 1)
			{
				if (textchangeInterval) {
					clearInterval(textchangeInterval);
				}
				textchangeInterval = setInterval(function(){
					ysLocAutoC.buildList( txtField.val(),function(){
							if (Geo.reload)
							{
								window.location.reload();
							}
						}
					);
					clearInterval(textchangeInterval);
				}, 500);

			} else if(txtField.val().length <= 1) {
				clearInterval(textchangeInterval);
				$('.ys-loc-autocomplete').css('display', 'none').empty();
			}
		});

	$(modal_id).on('click', '.modal-content', function(){
		$('.ys-loc-autocomplete').css('display', 'none').empty();
	});

	if(town == null)
	{
		$('.header-btn-wrap .header-btn.flaticon-location12 span.pseudo-link').click();
		ysLocCookie.setCookieFromTownClick($(modal_id + ' .header .sub span.selected').text());
	}

	// $(modal_id + ' .ys-loc-autocomplete').on('click','div',function () {
	// ysLocCookie.setCookieFromTownClick($(this).text());
	// });
	$(modal_id).on('click','.cities  .city-name-wrap',function () {
		// console.log('sd');
		if ($(this).hasClass('active')) return;

		ysLocCookie.setCookieFromTownClick($(this).text());
		$('#btn-save-city').click();
		if (Geo.reload)
		{
			window.location.reload();
		} else
		{
			var selectedText = $(this).text();
			$('.cities .city-name-wrap').show();
			$('.cities .city-name-wrap:contains('+selectedText+')').hide();
			if ($('.city-select span').length){
				$('.city-select  span').text(selectedText);
			} else{
				$('.city-select').text(selectedText);
			}
			$(modal_id).find('.modal-title').text(selectedText);
			if($('.cities .city-name-wrap.active').length > 0){
				$('.cities .city-name-wrap.active').text(selectedText);
			} else{
				$('.cities').find('.city-name-wrap').eq(0).before('<span class="city-name-wrap active">' + selectedText + '</div>')
			}

		}
	});

	if (!Geo.reload)
	{
		$(modal_id).on('click','.ys-loc-autocomplete div.ys-loc-autoc-selected',function (e) {
			var selectedText = $(this).text();
			$('.cities .city-name-wrap').show();
			selectedText = selectedText.substring(0,selectedText.indexOf(','));
			$('.cities .city-name-wrap:contains('+selectedText+')').hide();
			$('#btn-save-city').click();

			if ($('.city-select span').length){
				$('.city-select  span').text(selectedText);
			} else{
				$('.city-select').text(selectedText);
			}
			$(modal_id).find('.modal-title').text(selectedText);
			if($('.cities .city-name-wrap.active').length > 0){
				$('.cities .city-name-wrap.active').text(selectedText);
			} else{
				$('.cities').find('.city-name-wrap').eq(0).before('<span class="city-name-wrap active">' + selectedText + '</div>')
			}

			$('.cities .city-name-wrap.active').show();
			$('.form_city-select #city-search').val('');

		});

	}
});