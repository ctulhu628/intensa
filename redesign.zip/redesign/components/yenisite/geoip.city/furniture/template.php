<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
if (method_exists($this, 'setFrameMode')) $this->setFrameMode(true);
use \Yenisite\Furniture\Mobile;
use Yenisite\Furniture\Main;

if (!CModule::IncludeModule('statistic')) {
    return;
}
$id = 'bxdinamic_geoip_string';
?>
<? $this->SetViewTarget('modal_city_button'); ?>
<div class="city-select-box" id="<?= $id ?>" data-toggle="modal" data-target="#modal-city">
    <? $frame = $this->createFrame($id, false)->begin(\Yenisite\Furniture\Main::insertCompositLoader()); ?>
<!--         <button class="city-select action-link">
            <? if (!empty($arResult['CITY_INLINE'])) {
                ?>
                <?= $arResult['CITY_INLINE']; ?>
            <? } else { ?>
                <?= GetMessage('FURNITRE_CHOOSE_CITY'); ?><?
            }
            ?>
        </button> -->
        <a class="city-select header-address" href="#"><span>
            <? if (!empty($arResult['CITY_INLINE'])) {
                ?>
                <?= $arResult['CITY_INLINE']; ?>
            <? } else { ?>
                <?= GetMessage('FURNITRE_CHOOSE_CITY'); ?><?
            }
            ?>
        </span></a>
    <? $frame->end(); ?>
</div>
<? $this->EndViewTarget(); ?>
<?$id = 'bxdinamic_geoip_string_mobile';?>
<? $this->SetViewTarget('modal_city_button_mobile'); ?>
    <div class="city-select-box" id="<?= $id ?>" data-toggle="modal" data-target="#modal-city">
        <? $frame = $this->createFrame($id, false)->begin(\Yenisite\Furniture\Main::insertCompositLoader()); ?>
        <a href="#modal-city" class="city-select">
                 <span class="text">
                        <? if (!empty($arResult['CITY_INLINE'])) {
                            ?>
                            <?= $arResult['CITY_INLINE']; ?>
                        <? } else { ?>
                            <?= GetMessage('FURNITRE_CHOOSE_CITY'); ?><?
                        }
                        ?>
                   </span>
            </span></a>
        <? $frame->end(); ?>
    </div>
<? $this->EndViewTarget(); ?>

<? $this->SetViewTarget('modal_city_select'); ?>
<!-- Modal -->
<? $modalId = 'settings-modal-content' ?>
<div class="modal fade" id="modal-city" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-city">
        <div class="modal-content" id="<?= $modalId ?>">
            <? $frame = $this->createFrame($modalId, false)->begin(\Yenisite\Furniture\Main::insertCompositLoader()); ?>
            <? Main::includeDebug($this); ?>
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                        class="svg-wrap close"><svg>
		<use xlink:href="#close"></use>
	</svg></span></button>
                <h4 class="modal-title flaticon-point"><? if (!empty($arResult['CITY_INLINE']) || !empty($arResult['CITY_IP'])): ?><?= !empty($arResult['CITY_INLINE']) ? $arResult['CITY_INLINE'] : $arResult['CITY_IP']; ?><? else: ?><?= GetMessage('FURNITURE_FOR_HEADER') ?><? endif ?></h4>
            </div>

            <div class="modal-body">
                <span class="label-text"><?= GetMessage('FURNITURE_SHOOSE_YOUR_CITY') ?></span>

                <div class="search-wrap form_city-select">
                    <input id="city-search" type="text" class="ys-city-query form-control text-input"><!-- form-group -->
                    <ul class="search-popup ys-loc-autocomplete"></ul>
                </div>

                <h3><?= GetMessage('FURNITURE_OR_SET_FROM_LIST') ?></h3>

                <div class="cities"><?
                    $selected_city = !empty($arResult['CITY_INLINE']) ? $arResult['CITY_INLINE'] : $arResult['CITY_IP'];
					if($arResult['CITY'])
                    foreach ($arResult['CITY'] as $k => $city):?>
                        <? if (strcasecmp($selected_city, $city) == 0): ?>
                            <span class="city-name-wrap active"><?= $city ?></span>
                        <? elseif($city != $selected_city): ?>
                            <span class="city-name-wrap"><a href="#" class="city-name"><?= $city ?></a></span>
                        <? endif; ?>
                    <? endforeach; ?>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" data-dismiss="modal" id="btn-save-city"
                        class="btn-main btn-primary"><?= GetMessage('FURNITRE_GEOIP_OK') ?></button>
            </div>
            <? $frame->end(); ?>
        </div>
        <!-- .modal-content -->
    </div>
    <!-- /modal-dialog -->
</div><!-- #modal_city-select-panel.modal.fade -->
<? $this->EndViewTarget(); ?>

