<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
?>
<script>
	var Geo = Geo || {};
	Geo.reload = false;

	<?if($arParams['RELOAD_PAGE'] == 'Y'):?>
	Geo.reload = true;
	<?endif;?>
</script>
