<?
/**
 * @var CBitrixComponentTemplate $this
 */
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
use \Yenisite\Core\Ajax;
use \Yenisite\Core\Tools;

global $rz_options;
$this->setFrameMode(true);

if ($arParams['EMPTY']) {
	echo '<div>', GetMessage('FURNITURE_MAINSPEC_TITLE'), '</div>';
	return;
}

if (empty($arParams['FILTER_NAME'])) {
	$arParams['FILTER_NAME'] = 'arrFilter';
}

global ${$arParams['FILTER_NAME']};
$arFilter = &${$arParams['FILTER_NAME']};
if (!is_array($arFilter)) {
	$arFilter = array();
}

$isAjax = Ajax::isAjax();

$arTitles = array(
	'BESTSELLER' => array('NAME' => GetMessage('RZ_TAB_TITLE_BESTSELLER'), 'CLASS' => 'recommend'),
	'SALE' => array('NAME' => GetMessage('RZ_TAB_TITLE_SALE'), 'CLASS' => 'discounts'),
	'HIT' => array('NAME' => GetMessage('RZ_TAB_TITLE_HIT'), 'CLASS' => 'hits'),
	'NEW' => array('NAME' => GetMessage('RZ_TAB_TITLE_NEW'), 'CLASS' => 'hits'),
);
if (is_array($arParams['IBLOCK_TYPE'])) {
	$arParams['IBLOCK_TYPE'] = reset($arParams['IBLOCK_TYPE']);
}
$rnd = $this->randString();
$arParams['PROPERTY_CODE'] = array(0 => 'MORE_PHOTO');
$arParams['SHOW_ONE_CLICK'] = $rz_options['main_one_click'] != 'N';

if($_REQUEST['GET_CONTENT'] == 'Y') {
	$idSpec = 'special_tabs';
	Ajax::saveParams($this, $arParams, $idSpec);
}
if (count($arResult['TABS']) > 1):?>
	<?if($_REQUEST['GET_CONTENT'] == 'Y'):?>
		<div class="special-offers-global-wrap" <?Ajax::printAjaxDataAttr($this,$idSpec)?> data-specials="<?if($arParams['SPECIALS_TABS']):?>tabs<?else:?>expanded<?endif?>" id="specials-global-wrap">
	<?endif?>
	<div class="row">
		<div class="col-md-12 special-offers-pills-col">
			<ul class="nav nav-pills special-offers-pills">
				<? $f = 1;
				foreach ($arResult['TABS'] as $tabCode => $arTab): ?>
					<? if ($arTab['COUNT'] <= 0) continue ?>
					<?if (!empty($_REQUEST['TAB_ID'])){
						if ($tabCode . '_' . $rnd == $_REQUEST['TAB_ID']){
							$f = 1;
						} else {
							$f = 0;
						}
					}?>
					<li role="presentation"<?= $f ? ' class="active"' : '' ?>>
						<a href="#<?= $tabCode, '_', $rnd ?>" data-toggle="pill"
						   class="<?= $arTitles[$tabCode]['CLASS'] ?> simple-button">
							<?= $arTitles[$tabCode]['NAME'] ?>
						</a>
					</li>
					<? $f = 0;
				endforeach ?>
			</ul><!-- special-offers-pills -->

			<div class="special-offers-content tab-content">
				<? $f = 1;
				foreach ($arResult['TABS'] as $tabCode => $arTab): ?>
					<? if ($arTab['COUNT'] <= 0) continue ?>
					<?
					$arParams['TAB_TITLE'] = $arTitles[$tabCode]['NAME'];
					$arParams['TAB_ID'] = $tabCode . '_' . $rnd;
					if ($arParams['TAB_ID'] != $_REQUEST['TAB_ID'] && empty($_REQUEST['GET_CONTENT']) && $arParams['SPECIALS_TABS']) continue;
					$arParams['TAB_FIRST'] = $f;
					$arFilter = $arResult['TABS'][$tabCode]['FILTER'];
					?>
					<? $APPLICATION->IncludeComponent(
						"bitrix:catalog.section",
						"block-slider",
						$arParams,
						$this->__component
					); ?>
					<? $f = 0;
					if(empty($_REQUEST['TAB_ID']) && !empty($_REQUEST['GET_CONTENT']) && $arParams['SPECIALS_TABS']) break;
				endforeach ?>
			</div>
		</div>
	</div>
	<?if($_REQUEST['GET_CONTENT'] == 'Y'):?>
		</div>
	<?endif?>
<? else: ?>
	<? foreach ($arResult['TABS'] as $tabCode => $arTab): ?>
		<?
		$arParams['TAB_TITLE'] = $arTitles[$tabCode]['NAME'];
		$arParams['TAB_ID'] = $tabCode . '_' . $rnd;
		$arParams['TAB_FIRST'] = 1;
		$arParams['TAB_ONLY'] = 1;
		$arFilter = $arResult['TABS'][$tabCode]['FILTER'];
		?>
		<? $APPLICATION->IncludeComponent(
			"bitrix:catalog.section",
			"block-slider",
			$arParams,
			$this->__component
		); ?>
	<? endforeach ?>
<? endif ?>