<? if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();
\Bitrix\Main\Localization\Loc::loadLanguageFile(__FILE__);

//$arTemplateParameters['COMPONENT_LIST']['HIDDEN'] = 'Y';
$arTemplateParameters['ACTION_VARIABLE']['HIDDEN'] = 'Y';
$arTemplateParameters['ADD_PROPERTIES_TO_BASKET']['HIDDEN'] = 'Y';
$arTemplateParameters['ACTION_VARIABLE']['HIDDEN'] = 'Y';
$arTemplateParameters['ADD_PROPERTIES_TO_BASKET']['HIDDEN'] = 'Y';
$arTemplateParameters['ADD_SECTIONS_CHAIN']['HIDDEN'] = 'Y';
$arTemplateParameters['AJAX_MODE']['HIDDEN'] = 'Y';
$arTemplateParameters['AJAX_OPTION_ADDITIONAL']['HIDDEN'] = 'Y';
$arTemplateParameters['AJAX_OPTION_HISTORY']['HIDDEN'] = 'Y';
$arTemplateParameters['AJAX_OPTION_JUMP']['HIDDEN'] = 'Y';
$arTemplateParameters['AJAX_OPTION_STYLE']['HIDDEN'] = 'Y';
$arTemplateParameters['BACKGROUND_IMAGE']['HIDDEN'] = 'Y';
$arTemplateParameters['BASKET_URL']['HIDDEN'] = 'Y';
$arTemplateParameters['BROWSER_TITLE']['HIDDEN'] = 'Y';
$arTemplateParameters['DISABLE_INIT_JS_IN_COMPONENT']['HIDDEN'] = 'Y';
$arTemplateParameters['DISPLAY_BOTTOM_PAGER']['HIDDEN'] = 'Y';
$arTemplateParameters['DISPLAY_TOP_PAGER']['HIDDEN'] = 'Y';
$arTemplateParameters['MESSAGE_404']['HIDDEN'] = 'Y';
$arTemplateParameters['META_DESCRIPTION']['HIDDEN'] = 'Y';
$arTemplateParameters['META_KEYWORDS']['HIDDEN'] = 'Y';
$arTemplateParameters['OFFERS_LIMIT']['HIDDEN'] = 'Y';
$arTemplateParameters['PAGER_BASE_LINK_ENABLE']['HIDDEN'] = 'Y';
$arTemplateParameters['PAGER_DESC_NUMBERING']['HIDDEN'] = 'Y';
$arTemplateParameters['PAGER_DESC_NUMBERING_CACHE_TIME']['HIDDEN'] = 'Y';
$arTemplateParameters['PAGER_SHOW_ALL']['HIDDEN'] = 'Y';
$arTemplateParameters['PAGER_SHOW_ALWAYS']['HIDDEN'] = 'Y';
$arTemplateParameters['PAGER_TEMPLATE']['HIDDEN'] = 'Y';
$arTemplateParameters['PAGER_TITLE']['HIDDEN'] = 'Y';
$arTemplateParameters['LINE_ELEMENT_COUNT']['HIDDEN'] = 'Y';
$arTemplateParameters['PARTIAL_PRODUCT_PROPERTIES']['HIDDEN'] = 'Y';
$arTemplateParameters['PRICE_VAT_INCLUDE']['HIDDEN'] = 'Y';
$arTemplateParameters['PRODUCT_ID_VARIABLE']['HIDDEN'] = 'Y';
$arTemplateParameters['PRODUCT_PROPERTIES']['HIDDEN'] = 'Y';
$arTemplateParameters['PRODUCT_PROPS_VARIABLE']['HIDDEN'] = 'Y';
$arTemplateParameters['PRODUCT_QUANTITY_VARIABLE']['HIDDEN'] = 'Y';
$arTemplateParameters['SECTION_CODE']['HIDDEN'] = 'Y';
$arTemplateParameters['SECTION_ID']['HIDDEN'] = 'Y';
$arTemplateParameters['SECTION_ID_VARIABLE']['HIDDEN'] = 'Y';
$arTemplateParameters['SECTION_USER_FIELDS']['HIDDEN'] = 'Y';
$arTemplateParameters['USE_PRODUCT_QUANTITY']['HIDDEN'] = 'Y';
$arTemplateParameters['USE_PRICE_COUNT']['HIDDEN'] = 'Y';
$arTemplateParameters['USE_MAIN_ELEMENT_SECTION']['HIDDEN'] = 'Y';
$arTemplateParameters['SHOW_PRICE_COUNT']['HIDDEN'] = 'Y';
$arTemplateParameters['SHOW_404']['HIDDEN'] = 'Y';
$arTemplateParameters['SET_TITLE']['HIDDEN'] = 'Y';
$arTemplateParameters['SET_STATUS_404']['HIDDEN'] = 'Y';
$arTemplateParameters['SET_BROWSER_TITLE']['HIDDEN'] = 'Y';
$arTemplateParameters['SET_LAST_MODIFIED']['HIDDEN'] = 'Y';
$arTemplateParameters['SET_META_DESCRIPTION']['HIDDEN'] = 'Y';
$arTemplateParameters['SET_META_KEYWORDS']['HIDDEN'] = 'Y';
$arTemplateParameters['INCLUDE_SUBSECTIONS']['HIDDEN'] = 'Y';
$arTemplateParameters['HIDE_NOT_AVAILABLE']['HIDDEN'] = 'Y';
$arTemplateParameters['PROPERTY_CODE']['HIDDEN'] = 'Y';

$arTemplateParameters['COMPONENT_LIST']['HIDDEN'] = 'Y';
$arTemplateParameters['REMOVE_POSTFIX_IN_NAMES']['HIDDEN'] = 'Y';

$arTemplateParameters['RZ_TITLE'] = array(
	'PARENT' => 'BASE',
	'NAME' => GetMessage('RZ_TITLE_NAME'),
	'TYPE' => 'STRING',
	'DEFAULT' => '',
);

$arTemplateParameters['USE_ONECLICK'] = array(
	'PARENT' => 'BASE',
	'NAME' => GetMessage('RZ_USE_ONECLICK'),
	'TYPE' => 'CHECKBOX',
	'DEFAULT' => 'Y'
);

if (\Bitrix\Main\Loader::includeModule('yenisite.core')) {
	\Yenisite\Core\Resize::AddResizerParams(array('IMAGE', 'THUMB'), $arTemplateParameters);
}
