<?
$MESS ['RZ_TAB_TITLE_BESTSELLER'] = "рекомендуем";
$MESS ['RZ_TAB_TITLE_SALE'] = "акции и скидки";
$MESS ['RZ_TAB_TITLE_HIT'] = "хиты продаж";
$MESS ['RZ_TAB_TITLE_NEW'] = "новинки";
$MESS ['FURNITURE_MAINSPEC_TITLE'] = "Спецблок под категориями";