<?
$MESS["SLIDER_HEADER_TEXT"] = "Заголовок слайдера товаров";
$MESS["SLIDER_HEADER_TEXT_DEFAULT"] = "Товары этого бренда";
$MESS["CATALOG_PATH"] = "Путь до компонента каталога";
