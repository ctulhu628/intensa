<?php
$MESS['HLBLOCK_ROW_VIEW_NAME_COLUMN'] = 'Поле';
$MESS['HLBLOCK_ROW_VIEW_VALUE_COLUMN'] = 'Значение';
$MESS['HLBLOCK_ROW_VIEW_BACK_TO_LIST'] = 'Вернуться к списку';
$MESS['SLIDER_HEADER_TEXT'] = 'Товары #BRAND_NAME# в нашем магазине <a href="#LINK#" class="link-bd link-std">(все товары)</a>';
$MESS['SLIDER_ALL_ITEMS_TEXT'] = 'Посмотреть товары компании';
$MESS['IN_OUR_COMPANY'] = 'в нашем магазине';
