<?
$MESS["CATALOG_PATH"] = "Путь до компонента каталога";
$MESS['RESIZER_SET'] = 'Набор ресайзера';
