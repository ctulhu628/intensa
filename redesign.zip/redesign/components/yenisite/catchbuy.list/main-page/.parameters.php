<?
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED!==true) die();

use Bitrix\Main\Loader;
use Bitrix\Main\ModuleManager;

if (!Loader::includeModule('iblock'))
	return;

$arTemplateParameters["CATCHBUY_TITLE"] = array(
	"PARENT" => "VISUAL",
	"NAME" => GetMessage("CATCHBUY_TITLE"),
	"TYPE" => "STRING",
	"DEFAULT" => GetMessage('DEF_CATCHBUY_TITLE'),
);

if(Loader::includeModule('yenisite.oneclick')){
	$arTemplateParameters['USE_ONECLICK'] = array(
		'PARENT' => 'BASE',
		'NAME' => GetMessage('RZ_USE_ONECLICK'),
		'TYPE' => 'CHECKBOX',
		'DEFAULT' => 'Y'
	);
}

if (\Bitrix\Main\Loader::includeModule('yenisite.core')) {
	\Yenisite\Core\Resize::AddResizerParams(array('IMAGE', 'THUMB'), $arTemplateParameters);
}

$arTemplateParameters["DISPLAY_TOP_PAGER"]['HIDDEN'] = 'Y';
$arTemplateParameters["DISPLAY_BOTTOM_PAGER"]['HIDDEN'] = 'Y';

