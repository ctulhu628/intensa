<?
$MESS["CATCHBUY_TITLE"] = "Успей купить";