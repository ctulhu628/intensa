<?
// Resizer
$MESS["RESIZER_IMAGE"] = "Картинка для товара";
$MESS["RESIZER_THUMB"] = "Маленькая картинка для товара";
$MESS["DISPLAY_FAVORITE"] = "Отображать кнопки добавления в избранное";
$MESS["RZ_USE_ONECLICK"] = "Отображать кнопку купить в 1 клик";
$MESS["CATCHBUY_TITLE"] = "Заголовок для блок ауспей купить";
$MESS["DEF_CATCHBUY_TITLE"] = "Успей купить";