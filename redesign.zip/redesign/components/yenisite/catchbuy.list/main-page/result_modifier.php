<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
$arParams['USE_ONECLICK'] = $arParams['USE_ONECLICK'] != 'N' ? true : false;
$arParams['RESIZER_IMAGE'] = $arParams['RESIZER_IMAGE'] ? : 4;
$arParams['RESIZER_THUMB'] = $arParams['RESIZER_THUMB'] ? : 6;
$arParams['CATCHBUY_TITLE'] = $arParams['CATCHBUY_TITLE'] ? : GetMessage('CATCHBUY_TITLE');