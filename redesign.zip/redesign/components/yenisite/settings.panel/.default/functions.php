<?
if (!function_exists('showSettingsItem')) {
	function showSettingsItem($arItem, $curValue) {
		if ($arItem["CODE"] == 'theme') {
			$type = "COLOR_THEME";
		} elseif (isset($arItem["type"])) {
			$type = $arItem["type"];
		}
		// echo "<pre style='text-align:left;'>";print_r($curValue);echo "</pre>";
		// echo "<pre style='text-align:left;'>";print_r($arItem);echo "</pre>";
		switch ($type) {
			case 'HIDDEN':
				?>
				<input type="hidden" name="SETTINGS[<?= $arItem["CODE"] ?>]" value="<?= $curValue ?>" data-name="<?= $arItem["CODE"] ?>" data-default="<?= $arItem['default'] ?>">
			<? break;

			case "COLOR_THEME":
				?>
				<?$i = 0;?>
					<div class="settings-option mb-15">
						<?if(!empty($arItem['title'])):?>
							<div class="settings-title"><?= $arItem['title']?>:</div>
						<?elseif(is_null($arItem['title'])):?>
							<div class="settings-title"><?=$arItem['name'] ?>:</div>
						<?endif?>
					</div>
					<? foreach ($arItem['values'] as $theme): ?>
						<? ++$i ?>
						<label class="color-scheme-label" title="<?= $theme?>">
							<input type="radio" name="SETTINGS[theme]" class="color-scheme-radio" value="<?= $theme ?>"<? if ($theme == $curValue): ?> checked<? endif ?>>
										<span class="color-scheme-image-wrap">
											<img src="<?= SITE_TEMPLATE_PATH ?>/img/color-scheme/<?= $theme ?>.jpg" alt="" class="color-scheme-image">
										</span>
						</label>
					<? endforeach ?>
				<? unset($arItem) ?>
				<?break;

			case 'CHECKBOX':?>
				<div class="settings-option">
					<?if(!empty($arItem['title'])):?>
						<div class="settings-title"><?= $arItem['title']?>:</div>
					<?elseif(is_null($arItem['title'])):?>
						<div class="settings-title"><?=$arItem['name'] ?>:</div>
					<?endif?>
					<label class="checkbox">
						<input type="hidden" name="SETTINGS[<?= $arItem["CODE"] ?>]" value="<?= $arItem['values'][1]?>">
						<input type="checkbox" class="checkbox-input state" name="SETTINGS[<?= $arItem["CODE"] ?>]" value="<?= $arItem['values'][0]?>" <?= ($curValue == $arItem['values'][0]) ? ' checked ' : '' ?>>
						<span class="checkbox-content">
							<span class="check flaticon-checked21"></span><?= $arItem['name'] ?>
						</span>
					</label>
				</div>
			<? break;

			case 'RADIO':
				?>
				<div class="settings-option">
					<?if(!empty($arItem['title'])):?>
						<div class="settings-title"><?= $arItem['title']?>:</div>
					<?elseif(is_null($arItem['title'])):?>
						<div class="settings-title"><?=$arItem['name'] ?>:</div>
					<?endif?>
					<ul class="radio-options">
						<? foreach ($arItem['values'] as $theme): ?>
							<li>
								<label class="radio">
									<input <?if(!empty($arItem['data-menu'])):?>data-menu="<?=$arItem['data-menu']?>"<?endif?> data-select="<?=$arItem['data-attr']?>" data-select-value="<?=$arItem['data-'.$theme]?>" name="SETTINGS[<?= $arItem["CODE"] ?>]" type="radio" class="radio-input state radio-settings" value="<?= $theme ?>" <? if ($theme == $curValue): ?> checked<? endif ?>>
									<span class="radio-content"><?=$arItem['name_'.$theme] ?></span>
								</label>
							</li>
						<?endforeach?>
					</ul><!-- radio-options -->
				</div>
				<? break;

			case 'INFINITY_THEME':
				?>
				<?if (!empty($arItem['begin_big_div'])):?>
					<div class="settings-option custom-theme-demos-wrap row">
				<?endif?>
					<?if(empty($arItem['close_col'])):?>
						<div class="col-xs-6">
					<?endif?>
					<?if($arItem['default'][0] === '#'):?>
						<div class="settings-title"><?=$arItem['title']?>:</div>
						<p>
							<span><?=$arItem['name']?>:</span>
							<input type="text" class="minicolors-custom" data-name="<?= $arItem["CODE"] ?>" name="SETTINGS[<?= $arItem["CODE"] ?>]" value="<?=$curValue ? : $arItem['default']?>" data-default="<?=$curValue ? : $arItem['default']?>">
							<input type="hidden" data-name="<?= $arItem["CODE"] ?>" class="custom-color" name="SETTINGS[<?= $arItem["CODE"] ?>]" value="<?=$curValue ? : $arItem['default']?>" data-default="<?=$curValue ? : $arItem['default']?>">
						</p>
					<?else:?>
						<p><?=$arItem['title-small']?></p>
						<ul class="radio-options">
							<?foreach ($arItem['values'] as $value):?>
								<li>
									<label class="radio">
										<input data-select="<?=$arItem['data-attr']?>" data-select-value="<?=$arItem['data-'.$value]?>"  type="radio" class="radio-input state radio-settings" name="SETTINGS[<?= $arItem["CODE"] ?>]" value="<?= $value ?>" <? if ($value == $curValue): ?> checked<? endif ?>>
										<span class="radio-content"><?=$arItem['names'][$value] ?></span>
									</label>
								</li>
							<?endforeach?>
						</ul><!-- radio-options -->
					<?endif?>
					<?if(!empty($arItem['close_col'])):?>
						</div>
					<?endif?>

					<?if (!empty($arItem['end_big_div'])):?>
						<div class="col-xs-12">
							<p id="custom-theme-apply">
								<button type="button" class="btn-main btn-primary" id="btn-custom-theme"><?=GetMessage('RZ_MODAL_SETTINGS_APPLAY_CUSTOM_COLOR')?></button>
							</p>
							<p><?=GetMessage('RZ_MODAL_SETTINGS_NOT_FORGET')?></p>
						</div>
				</div>
				<?endif?>
				<?break;

			/*case 'SELECT': ?>
				<div class="setting-desc">
					<?= $arItem['name'] ?>:
					<? if ($arItem['preview']):?>
						<i class="has-preview flaticon-43123" title="<?= GetMessage('BITRONIC2_SETTING_HAS_PREVIEW') ?>" data-tooltip></i>
					<? endif ?>
				</div><!-- .setting-desc -->
				<div class="setting-content">
					<select name="SETTINGS[<?= $arItem["CODE"] ?>]" id="settings_<?= $arItem["CODE"] ?>" title="<?= $arItem['name'] ?>" data-name="<?= $arItem["CODE"] ?>"
							data-autowidth="true">
						<?foreach ($arItem["values"] as $value):?>
							<option value="<?= $value ?>"<?= ($curValue == $value) ? ' selected' : '' ?>
								<?if($arItem['default'] == $value):?> data-default<?endif?>
								>
								<?if(!empty($arItem['names'][$value])):?>
									<?= $arItem['names'][$value] ?>
								<?else:?>
									<?= GetMessage('BITRONIC2_' . strtoupper($arItem["CODE"]) . '_' . strtoupper($value)) ?>
								<?endif?>
							</option>
						<?endforeach?>
					</select>
				</div><!-- .setting-content -->
			<? break;*/

			/*case 'CHECKBOX_MOBILE': ?>
			<div class="setting-desc">
				<? if ($arItem['preview']):?>
					<i class="has-preview flaticon-43123" title="<?= GetMessage('BITRONIC2_SETTING_HAS_PREVIEW') ?>" data-tooltip></i>
				<? endif ?>
			</div><!-- .setting-desc -->
			<div class="setting-content">
				<div class="pull-left">
					<?
					$isDisabled = $arItem['states']['mobile']['state'] == 'disabled';

					if($isDisabled) {
						$checked = true;
						if($arItem['states']['mobile']['status'] == 'unchecked') {
							$checked = false;
						}
					}
					?>
					<input type="hidden" name="SETTINGS[<?= $arItem["CODE"] ?>_MOBILE]" id="settings_<?= $arItem["CODE"] ?>_MOBILE_hidden" value="<?= $arItem['values'][1]?>">
					<label class="checkbox-styled" for="settings_<?= $arItem["CODE"] ?>_MOBILE">
						<input name="SETTINGS[<?= $arItem["CODE"] ?>_MOBILE]" type="checkbox" id="settings_<?= $arItem["CODE"] ?>_MOBILE" value="<?= $arItem['values'][0]?>"
							   data-name="<?= $arItem["CODE"] ?>_mobile" <?if($isDisabled):?> disabled<?endif?>
							<?if(isset($checked)):?>
								<?= ($checked) ? ' checked ' : '' ?>
							<? else :?>
								<?= ($curValue['mobile'] == $arItem['values'][0]) ? ' checked ' : '' ?>
							<? endif ?>
							<?if($arItem['default_MOBILE'] == $arItem['values'][0]):?> data-default="1"<?else:?> data-default="0"<?endif?>
							/>
						<span class="checkbox-content"><i class="flaticon-check14"></i>&nbsp;<span class="icon flaticon-phone12" title="<?=GetMessage('BITRONIC2_TITLE_FOR_MOBILE')?>" data-tooltip></span></span></label>
					<br>
					<input type="hidden" name="SETTINGS[<?= $arItem["CODE"] ?>]" id="settings_<?= $arItem["CODE"] ?>_hidden" value="<?= $arItem['values'][1]?>">
					<label class="checkbox-styled" for="settings_<?= $arItem["CODE"] ?>">
						<input name="SETTINGS[<?= $arItem["CODE"] ?>]" type="checkbox" id="settings_<?= $arItem["CODE"] ?>" value="<?= $arItem['values'][0]?>"
							   data-name="<?= $arItem["CODE"] ?>"
							<?= ($curValue['orig'] == $arItem['values'][0]) ? ' checked ' : '' ?>
							<?if($arItem['default'] == $arItem['values'][0]):?> data-default="1"<?else:?> data-default="0"<?endif?>
							/>
						<span class="checkbox-content"><i class="flaticon-check14"></i>&nbsp;<span class="icon flaticon-widescreen" title="<?=GetMessage('BITRONIC2_TITLE_FOR_PC')?>" data-tooltip></span></span></label>
				</div>
				<div class="pull-left combined_name">
					<div class="wrapper">
						<span><?= $arItem['name'] ?></span>
					</div>
				</div>
				<div class="clearfix"></div>
			</div><!-- .setting-content -->
			<? break;

			case 'SLIDER': ?>
				<div class="setting-desc">
					<?= $arItem['name'] ?>:
					<? if ($arItem['preview']):?>
						<i class="has-preview flaticon-43123" title="<?= GetMessage('BITRONIC2_SETTING_HAS_PREVIEW') ?>" data-tooltip></i>
					<? endif ?>
				</div><!-- .setting-desc -->
				<div class="setting-content">
					<input type="text" name="SETTINGS[<?= $arItem["CODE"] ?>]" id="settings_<?= $arItem["CODE"] ?>"
						   class="textinput <?= $arItem["CODE"] ?>-input" value="<?= (!empty($curValue)) ? $curValue : $arItem['default'] ?>"
						   data-name="<?= $arItem["CODE"] ?>" data-default="<?= $arItem['default'] ?>">
					<div class="simple-slider <?= $arItem["CODE"] ?>-slider" id="<?= $arItem["CODE"] ?>-slider"
						 data-name="<?= $arItem["CODE"] ?>" data-start="<?= (!empty($curValue)) ? $curValue : $arItem['default'] ?>"
						 data-min="<?= $arItem["min"] ?>" data-max="<?= $arItem["max"] ?>" data-step="<?= $arItem["step"] ?>"
						 <?if ($arItem["preview"]): ?>data-set<? endif ?>
						 <?if(!empty($arItem['postfix'])):?> data-postfix="<?=$arItem['postfix']?>"<? endif ?>
						></div>
				</div><!-- .setting-content -->
				<? break;*/

			case 'COLOR': ?>
				<div class="settings-option">
					<?if(!empty($arItem['title'])):?>
						<div class="settings-title"><?= $arItem['title']?>:</div>
					<?elseif(is_null($arItem['title'])):?>
						<div class="settings-title"><?=$arItem['name'] ?>:</div>
					<?endif?>
					<?
					$curValue = (!empty($curValue)) ? $curValue : $arItem['default'];
					//$dataType = ($curValue{0} == '#') ? 'color' : 'pattern';
					?>
					<?/*if (isset($arItem['choose'])): ?>
						<select class="type-choose" name="<?= $arItem["CODE"] ?>_type" id="<?= $arItem["CODE"] ?>_type" title="">
							<? foreach ($arItem['choose'] as $val => $name): ?>
								<option value="<?= $val ?>"<?= ($dataType == $val) ? ' selected' : '' ?>><?= $name ?></option>
							<? endforeach ?>
						</select>
						<? if (isset($arItem['choose']['pattern'])): */?>
							<div class="settings-bg-wrap active" <?// ($dataType != 'pattern') ? 'style="display:none;"' : '' ?>>
								<?
								$arFiles = glob($_SERVER['DOCUMENT_ROOT'] . BX_ROOT . '/images/' . \Yenisite\Furniture\Settings::getModuleId() . '/patterns/*.{jpg,png,gif,jpeg}',GLOB_BRACE);
								?>
								<div class="patterns">
										<?
										natsort($arFiles);
										$filterType = ($arItem['filter']{0} == '!') ? 'not' : '';
										$filterVal = ($filterType == 'not') ? substr($arItem['filter'], 1) : $arItem['filter'];
										foreach ($arFiles as $file): ?>
											<label class="pattern-label" data-name="SETTINGS[<?= $arItem["CODE"] ?>]">
												<?
												$baseName = basename($file);
												$curValue = str_replace(')','',$curValue);
												$bgValue = 'url(' . str_replace($_SERVER['DOCUMENT_ROOT'], '', $file). ')';
												$bgSrc =  str_replace($_SERVER['DOCUMENT_ROOT'], '', $file);
												?>
												<input type="radio" class="pattern-radio" name="SETTINGS[<?= $arItem["CODE"] ?>]" value="<?= $bgValue ?>" <?= (basename($curValue) == $baseName) ? ' checked' : '' ?>>
												<span class="pattern-image-wrap"><img src="<?= $bgSrc ?>" alt="" class="pattern-image"></span>
											</label>
										<? endforeach ?>
								</div>
							</div>
						<?/* endif ?>
					<? endif */?>
				</div><!-- .setting-otion -->
				<? break;
		}
	}
}

