$(function () {
	var $body = $(document.body),
		$themeLink = $('#theme-css-link'),
		$themeMeta = $('#theme-color-mobile');

	$body.on('change', '#settings-form .color-scheme-radio', function () {
		var theme = $(this).val();
		var href = $themeLink.attr('href').replace(/theme_(.*)\.css$/, 'theme_' + theme + '.css');
		$themeLink.attr('href', href);

		if ($themeMeta.length) {
			var color;
			switch (theme) {
				case 'yellow-blue':
					color = '#fec006';
					break;
				case 'green-violet':
					color = '#22ff80';
					break;
				case 'red-blue':
					color = '#c03030';
					break;
				case 'green-yellow':
					color = '#12c000';
					break;
				case 'orange-lime':
					color = '#ff7200';
					break;
				default:
					color = '#fff';
			}
			$themeMeta.attr('content', color);
		}
	});

	$body.on('change', '#settings-form .radio-input.state.radio-settings', function () {
		var $this = $(this),
			$closestInputs = $this.closest('.radio').parent().siblings().find('.radio-input.state.radio-settings'),
			value = $this.attr('data-select-value'),
			select = $this.attr('data-select'),
			$el = '';
			if (!select.length) return;
			$closestInputs.each(function(){
				var currentValue = $(this).attr('data-select-value');
				$el = $(document).find("["+select + "='" + currentValue + "']");
				if($el.length) return false;
			});
		$el.attr(select,value);
		set['mainmenu']();

	});

	$body.on('change', '#settings-form .settings-option .pattern-radio', function () {
		var $this = $(this),
			value = $this.attr('value'),
			$body = $('body');
		$body.css('background',value);
	});
});