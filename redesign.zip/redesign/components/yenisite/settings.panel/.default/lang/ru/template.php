<?
$MESS['RZ_MODAL_SETTINGS_HEADER'] = 'Настройки';
$MESS['RZ_MODAL_SETTINGS_SAVE'] = 'Сохранить';
$MESS['RZ_MODAL_SETTINGS_SET_DEFAULT'] = 'Сохранить настройки для всех';
$MESS['RZ_MODAL_SETTINGS_APPLAY_CUSTOM_COLOR'] = 'Сгенерировать свою цветовую схему';
$MESS['RZ_MODAL_SETTINGS_NOT_FORGET'] = 'Не забудьте сохранить сгенерированную цветовую схему!';