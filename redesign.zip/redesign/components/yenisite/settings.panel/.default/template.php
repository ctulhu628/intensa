<? use Yenisite\Furniture\Form;
use Yenisite\Furniture\Main;
use Yenisite\Furniture\Settings;

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
/**
 * @var CBitrixComponentTemplate $this
 * @var array $arResult
 */
include "functions.php";
global $rz_options;
?>
<? if (count($arParams["EDIT_SETTINGS"])): ?>
	<button class="btn-settings flaticon-gear37" data-toggle="modal" data-target="#modal-settings"></button>
<? endif ?>
<div class="modal fade" id="modal-settings" tabindex="-1" role="dialog">
	<?
	$frame = $this->createFrame('modal-settings', false)->begin(Main::insertCompositLoader());
	if (count($arParams["EDIT_SETTINGS"]) == 0) {
		$frame->end();
		echo "</div>";
		return;
	}
	?>
	<div class="modal-dialog modal-settings" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span class="svg-wrap close"><svg>
		<use xlink:href="#close"></use>
	</svg></span></button>
				<h4 class="modal-title flaticon-mixer1"><?= GetMessage('RZ_MODAL_SETTINGS_HEADER') ?></h4>
			</div>
			<form data-using-theme="<?=$rz_options['custom-theme'] == 'Y' ? 'use-custom' : ''?>" id="settings-form" action="<?= $APPLICATION->GetCurPage() ?>" method="post">
				<div class="modal-body">
					<?foreach($arResult['GROUPS'] as $groupID => $arItem):?>
						<?
						foreach ($arItem['SETTINGS'] as $key => $val) {
							if (!in_array($val, $arParams["EDIT_SETTINGS"])) {
								unset($arItem['SETTINGS'][$key]);
							};
						}?>
						<?foreach ($arItem['SETTINGS'] as $key => $val):?>
							<?if(Settings::checkClearance($arResult['SETTINGS'][$val]['clearance'])){?>
								<?showSettingsItem($arResult['SETTINGS'][$val], $arResult['CURRENT_SETTINGS'][$val]); ?>
							<?}?>
						<?endforeach?>
					<?endforeach?>
					<? /* todo: settings - other settings
					<? foreach ($arResult['SETTINGS'] as $name => $arSett): ?>
						<div class="settings-option">
							<div class="settings-title"><?= $t['title'] ?></div>
							<ul class="radio-options">
								<li></li>
							</ul>
						</div>
					<? endforeach ?>
					*/ ?>
					<? if ($USER->IsAdmin()): ?>
						<div class="clearfix clear-settings-applay"></div>
						<div class="text-center">
							<div class="settings-option">
								<? Form::printElement(array(
										'NAME' => 'SETTINGS[SET_DEFAULT]',
										'TEXT' => GetMessage('RZ_MODAL_SETTINGS_SET_DEFAULT'),
								), Form::TYPE_CHECKBOX)
								?>
							</div>
						</div>
					<? endif ?>
				</div>
				<div class="modal-footer">
					<div class="btn-wrap">
						<button type="submit" class="btn btn-lg btn-primary" name="settings_apply" value="Y">
							<?= GetMessage('RZ_MODAL_SETTINGS_SAVE') ?>
						</button>
					</div>
					<? /* todo: settings - reset
					<div class="action-link has-icon flaticon-update6">
                    	<span class="link-text">reset to defaults</span>
                	</div>
					*/ ?>
				</div>
				<textarea name="SETTINGS[theme-custom]" id="theme-custom" style="display: none" class="hidden">
						<?= $arResult['CURRENT_SETTINGS']['theme-custom']?>
				</textarea>
			</form>
		</div>
	</div>
	<?
	$frame->end();
	?>
</div>
<script type="text/javascript">
	window.SAAS_globalWorkerUrl = "<?= SITE_TEMPLATE_PATH ?>/js/libs/sass.js_0.9.11/sass.worker.js";
</script>
