<?
use Yenisite\Core\Ajax;
use Yenisite\Furniture\Form;
use Yenisite\Furniture\Main;

/**
 * @var CBitrixComponentTemplate $this
 */

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
$isAjax = Ajax::isAjax();
if (!$isAjax || !empty($_REQUEST['TAB_DETAIL'])) {
    Ajax::saveParams($this, $arParams, 'catalog_add');
    $this->setFrameMode(true);
}
\Bitrix\Main\Localization\Loc::loadMessages($_SERVER['DOCUMENT_ROOT'] . SITE_TEMPLATE_PATH . '/lang/' . LANGUAGE_ID . '/header.php');
$pathToRules = COption::GetOptionString(\Yenisite\Furniture\Settings::getModuleId(), 'path_tu_rules_privacy', SITE_DIR . 'personal/rules/personal_data.php');
?>
<? if (!$isAjax || !empty($_REQUEST['TAB_DETAIL'])): ?>
    <div class="feedback-add-wrap">
    <button type="button" data-toggle="collapse" data-target="#feedback-add-form"
            class="action-link has-icon link-add-question flaticon-add20 form-group">
        <span class="link-text"><?= GetMessage('RZ_ADD_FEEDBACK') ?></span>
    </button>
    <form action="#" method="post" class="feedback-add-form form-horizontal ajax-form collapse" id="feedback-add-form" <? Ajax::printAjaxDataAttr($this, 'catalog_add') ?>>
<? endif ?>
    <input type="hidden" name="privacy_policy" value="N"/>
<? if ($arResult['SUCCESS']): ?>
    <div class="form-message shown">
        <? Main::ShowMessage($arResult['SUCCESS_TEXT'], Main::MSG_TYPE_SUCCESS, false) ?>
    </div>
<? else: ?>
    <div class="col-sm-12 required-info form-group">
        <span class="label-text"><?= GetMessage('RZ_REQUIRED_FIELDS_TEXT') ?></span>
    </div>
    <? if ($arResult['ERROR']): ?>
        <div class="form-message shown">
            <? Main::ShowMessage($arResult['ERROR']) ?>
        </div>
    <? endif ?>
    <? foreach ($arResult['FIELDS'] as $arItem): ?>
        <?
        if ($arItem['PROPERTY_TYPE'] == 'E') {
            echo $arItem['HTML'];
            continue;
        }
        $colClass = 'col-sm-6';
        if ($arItem['PROPERTY_TYPE'] == 'S' && $arItem['USER_TYPE'] == 'HTML') {
            $colClass = 'col-sm-12';
        }
        ?>
        <label class="<?= $colClass ?> mar-b-15 form-group <?= $arItem['CODE'] == 'EMAIL' ? 'half-group' : '' ?>">
            <span class="label-text"><?= $arItem['NAME'] ?><? if ($arItem['IS_REQUIRED'] == 'Y' || $arItem['CODE'] == 'NAME'): ?>
                    <span class="asterisk-required">*</span><? endif ?>:</span>
            <? if ($arItem['CODE']): ?>
                <?= $arItem['HTML'] ?>
            <? endif ?>
        </label>
    <? endforeach ?>
    <? /*  if ($arParams['TEXT_SHOW'] == 'Y'): ?>
				<label class="col-sm-12 mar-b-15 form-group">
					<span class="label-text"><?=GetMessage("RZ_TEXT_FIELD")?><span class="asterisk-required">*</span>:</span>
					<? Form::printElement(array('NAME' => $arResult['CODE'] . '[text]'), Form::TYPE_TEXTAREA) ?>
				</label>
			<? endif  */ ?>
    <? if (!empty($arResult["CAPTCHA_CODE"])): ?>
        <label class="form-group col-sm-12 captcha-group">
            <span class="label-text"><?= GetMessage("RZ_VVEDITE_SLOVO_NA_KARTINKE") ?><span
                        class="asterisk-required">*</span>:</span>
            <input type="hidden" name="captcha_sid" value="<?= $arResult["CAPTCHA_CODE"] ?>"/>
            <input type="hidden" name="captcha_code" value="<?= $arResult["CAPTCHA_CODE"] ?>"/>
        </label>
        <label class="form-group col-sm-12 captcha-group">
					<span class="captcha"><img
                                src="/bitrix/tools/captcha.php?captcha_sid=<?= $arResult["CAPTCHA_CODE"] ?>"
                                alt="<?= GetMessage("RZ_KAPCHA") ?>" class="captcha-img"></span>
        </label>
        <label class="form-group col-sm-12 captcha-group">
            <input type="text" name="captcha_word" class="form-control" required>
        </label>
    <? endif; ?>
    <br/>
    <div class="col-sm-12 mar-b-15 form-group">
        <?
        $text = GetMessage('RZ_RULES_YA') . ' ';
        $text .= GetMessage('RZ_ACCEPT') . " <a href='" . $pathToRules . "' target='_blank' class='classic-link'>" . GetMessage('RZ_CONCLUSION') . "</a>";
        Form::printElement(
            array(
                'NAME' => 'PRIVACY_POLICY',
                'CHECKED' => $_POST['PRIVACY_POLICY'] == 'Y',
                'TEXT' => $text,
                'REQ' => true,
                'INDEX' => ++$tabIndex,
                'CLASS' => 'col-sm-12 mar-b-15 form-group'
            ), Form::TYPE_CHECKBOX
        );
        ?>
    </div>
    <button type="submit" class="btn-main btn-primary btn-add-question"><?= GetMessage('RZ_SUBMIT_FEEDBACK') ?></button>
<? endif ?>
<? if (!$isAjax || !empty($_REQUEST['TAB_DETAIL'])): ?>
    </form>
    </div>
<? endif ?>