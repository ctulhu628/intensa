<?
$MESS['RZ_REQUIRED_FIELDS_TEXT'] = "Поля, помеченные <span class='asterisk-required'>*</span> &mdash; обязательны для заполнения";
$MESS['RZ_SUBMIT_FEEDBACK'] = 'Отправить отзыв';
$MESS['RZ_ADD_FEEDBACK'] = 'Добавить отзыв';
$MESS['RZ_TEXT_FIELD'] = 'Отзыв';