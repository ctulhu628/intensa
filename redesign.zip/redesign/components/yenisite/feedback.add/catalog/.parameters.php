<?
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED!==true) die();

use Bitrix\Main\Loader;
use Bitrix\Main\ModuleManager;

if (!Loader::includeModule('iblock'))
	return;

//HIDE params - not used params
	$arTemplateParameters['COLOR_SCHEME']['HIDDEN'] = 'Y';