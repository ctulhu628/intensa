<? use Yenisite\Furniture\Form;

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
if ($arParams['EMPTY']) return;

/**
 * @var CBitrixComponentTemplate $this
 */
$RND = $this->randString();

foreach ($arResult['FIELDS'] as &$arItem) {
	$NAME = $arResult['CODE'] . '[' . $arItem['CODE'] . ']';
	$VALUE = $arResult['DATA'][$arItem['CODE']] ?: '';
	$REQ = $arItem['IS_REQUIRED'] == 'Y';
	$TYPE = 0;
	$arItem['HTML_ID'] = $arItem['CODE'] . '_' . $RND;

	if (($arItem['PROPERTY_TYPE'] == 'S' || $arItem['PROPERTY_TYPE'] == 'N') && $arItem['USER_TYPE'] == null) {
		if (strcasecmp($arItem['CODE'], "email") == 0 && empty($arResult['DATA'][$arItem['CODE']])) {
			$VALUE = $arResult['EMAIL'] ?: '';
		}
		$TYPE = Form::TYPE_TEXT;
		if (strpos($arItem['CODE'], 'PHONE') !== false) {
			$TYPE = Form::TYPE_PHONE;
		}
	} elseif ($arItem['PROPERTY_TYPE'] == 'S' && $arItem['USER_TYPE'] == 'HTML') {
		$TYPE = Form::TYPE_TEXTAREA;
	} elseif ($arItem['PROPERTY_TYPE'] == 'S' && $arItem['USER_TYPE'] == 'DateTime') {
		$TYPE = Form::TYPE_DATE;
	} elseif ($arItem['PROPERTY_TYPE'] == 'E' && $arItem['USER_TYPE'] == null) {
		$TYPE = Form::TYPE_HIDDEN;
		$VALUE = $arParams['ELEMENT_ID'];
	} elseif ($arItem['PROPERTY_TYPE'] == 'F' && $arItem['USER_TYPE'] == null) {
		$TYPE = Form::TYPE_FILE;
	} elseif ($arItem['PROPERTY_TYPE'] == 'E' && $arItem['USER_TYPE'] == null && (int)$arParams['ELEMENT_ID'] > 0) {
		$TYPE = Form::TYPE_HIDDEN;
		$VALUE = $arParams['ELEMENT_ID'];
	}
	ob_start();
	Form::printElement(array(
		'NAME' => $NAME,
		'VALUE' => $VALUE,
		'REQ' => $REQ,
		'ATTR' => 'id="' . $arItem['HTML_ID'] . '"',
	), $TYPE);
	$arItem['HTML'] = ob_get_clean();
}
unset($arItem);