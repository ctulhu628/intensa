<?
use Yenisite\Core\Ajax;
use Yenisite\Furniture\Form;
use Yenisite\Furniture\Main;

/**
 * @var CBitrixComponentTemplate $this
 */

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
$isAjax = Ajax::isAjax();
if (!$isAjax) {
	Ajax::saveParams($this, $arParams, $arParams['FORM']);
	if ($arParams['SEND_TO_FOOTER'] == 'Y') {
		$this->SetViewTarget('modals');
	}
	$this->setFrameMode(true);
}
?>
<? if (!$isAjax): ?>
<div class="modal fade" id="<?= $arParams['FORM'] ?>" tabindex="-1" role="dialog">
	<div class="modal-dialog <?= $arParams['FORM'] ?>" role="document">
		<form method="post" action="#" class="modal-content ajax-form" data-validate="true" <? Ajax::printAjaxDataAttr($this,
				$arParams['FORM']) ?>>
<? endif ?>
		<? if ($arResult['SUCCESS']): ?>
			<div class="form-message shown">
				<? Main::ShowMessage($arResult['SUCCESS_TEXT'], Main::MSG_TYPE_SUCCESS, false) ?>
			</div>
		<? else: ?>
			<div class="modal-header">
				<button type="button" class="close flaticon-multiplication" data-dismiss="modal" aria-label="Close"></button>
				<h4 class="modal-title <?= $arParams['TITLE_CLASS'] ?>"><?= $arParams['TITLE'] ?></h4>
			</div>

			<div class="modal-body">
				<div class="form-reg-required-info">
					<?= GetMessage('RZ_REQUIRED_FIELDS_TEXT') ?>
				</div>
				<? if ($arResult['ERROR']): ?>
					<div class="form-message shown">
						<? Main::ShowMessage($arResult['ERROR']) ?>
					</div>
				<? endif ?>
				<div class="row">
					<? foreach ($arResult['FIELDS'] as $arItem): ?>
						<?
						if ($arItem['PROPERTY_TYPE'] == 'E') {
							echo $arItem['HTML'];
							continue;
						}
						$colClass = 'col-sm-6';
						if($arItem['PROPERTY_TYPE'] == 'S' && $arItem['USER_TYPE'] == 'HTML') {
							$colClass = 'col-sm-12';
						}
						?>
						<div class="<?= $colClass ?>">
							<label for="<?= $arItem['HTML_ID'] ?>">
								<?= $arItem['NAME'] ?><? if ($arItem['IS_REQUIRED'] == 'Y'): ?><span class="required-star">*</span><? endif ?>:
							</label>
							<span class="form-group has-feedback">
								<?= $arItem['HTML'] ?>
								<i class="form-control-feedback"></i>
								<span class="help-block with-errors"></span>
							</span>
						</div>
					<? endforeach ?>
				</div>
				<? if (!empty($arResult["CAPTCHA_CODE"])): ?>
					<? $captchaID = 'captcha_' . $this->randString() ?>
					<? $frame = $this->createFrame($captchaID, false)->begin('') ?>
						<div class="row" id="<?= $captchaID ?>">
							<div class="col-sm-12">
								<? Form::printCaptcha($arResult["CAPTCHA_CODE"]) ?>
							</div>
						</div>
					<? $frame->end() ?>
				<? endif ?>
			</div>
			<div class="modal-footer text-center">
				<button type="submit" class="btn btn-lg btn-primary"><?=GetMessage('RZ_MODAL_PO_SUBMIT')?></button>
			</div>
		<? endif ?>
<? if (!$isAjax): ?>
		</form>
	</div>
</div>
<? endif;
if (!$isAjax && $arParams['SEND_TO_FOOTER'] == 'Y') {
	$this->EndViewTarget();
}