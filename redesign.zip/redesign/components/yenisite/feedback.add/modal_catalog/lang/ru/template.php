<?
$MESS['RZ_REQUIRED_FIELDS_TEXT'] = "Поля, помеченные <span class='required-star'>*</span> &mdash; обязательны для заполнения";
$MESS ['RZ_MODAL_PO_SUBMIT'] = 'Отправить';