<?if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();
use Yenisite\Furniture\Main;
CModule::IncludeModule("iblock");

if (is_array($arResult['ITEMS'])){
$emptyPicture = \Yenisite\Furniture\Main::GetResizedImg("" ,array('WIDTH' => 50, 'HEIGHT' => 59, 'SET_ID' => $arParams['CART_RESIZER_SET']), "");

foreach($arResult["ITEMS"] as $key=>&$item){
	$item["CAN_BUY"] = "Y";
	$item["DELAY"] = "N";
	$item["QUANTITY"] = $item['COUNT'];
	$item['PRICE'] = $item["MIN_PRICE"];
	$item['PRICE_FORMATED'] = $item["MIN_PRICE"];
	$item['PRODUCT_ID'] = $item['ID'];
	
	if(is_array($item['FIELDS'])){
		$arResult["ITEMS"][$key]["NAME"] = $item['FIELDS']['NAME'];
		$arResult["ITEMS"][$key]["DETAIL_PAGE_URL"] = $item['FIELDS']['DETAIL_PAGE_URL'];
		$arResult["ITEMS"][$key]["PRICE"] = $item["QUANTITY"] * $item['PRICE'];
		$arResult["ITEMS"][$key]['PRICE_FORMATED'] = Main::getElementPriceFormat(false, $arResult["ITEMS"][$key]["PRICE"]);

		$arProduct = CMarketCatalogProduct::GetByID($item['FIELDS']['ID'], $item['FIELDS']['IBLOCK_ID']);
		if($arProduct['QUANTITY_TRACE'] == 'Y' && $arProduct['CAN_BUY_ZERO'] != 'Y' && $arProduct['QUANTITY'] <= 0) {
			$item['CAN_BUY'] = 'N';
		}
	}	
	
	$arResult["ITEMS"][$key]['PICTURE'] = \Yenisite\Furniture\Main::GetResizedImg($arResult["ITEMS"][$key]['FIELDS']['DETAIL_PICTURE'] ,array('WIDTH' => 50, 'HEIGHT' => 59, 'SET_ID' => $arParams['CART_RESIZER_SET']));
	if($arResult["ITEMS"][$key]['PICTURE'] == $emptyPicture) $arResult["ITEMS"][$key]['PICTURE'] = \Yenisite\Furniture\Main::GetResizedImg($arResult["ITEMS"][$key] ,array('WIDTH' => 50, 'HEIGHT' => 59, 'SET_ID' => $arParams['CART_RESIZER_SET']));
}
}
$arResult["TOTAL_SUM"] = $arResult['COMMON_PRICE'];
$arResult["TOTAL_SUM_FORMATTED"] = Main::getElementPriceFormat(false, $arResult['COMMON_PRICE']);
$arResult["TOTAL_COUNT"] = $arResult['COMMON_COUNT'];

?>