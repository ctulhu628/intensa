<?
use Yenisite\Core\Resize;

$arTemplateParameters['USE_ONECLICK'] = array(
	'PARENT' => 'VISUAL',
	'NAME' => GetMessage('USE_ONECLICK'),
	'TYPE' => 'CHECKBOX',
	'DEFAULT' => 'Y',
);

if (\Bitrix\Main\Loader::includeModule('yenisite.core')) {
	Resize::AddResizerParams(array('BASKET_ICON'), $arTemplateParameters);
}