<?
$MESS['USE_ONECLICK'] = 'Страница с информацией о доставке';
$MESS['RESIZER_BASKET_ICON'] = 'Картирнка для иконок товаров';