<?
$arTemplateParameters['USE_ONECLICK'] = array(
    'PARENT' => 'VISUAL',
    'NAME' => GetMessage('USE_ONECLICK'),
    'TYPE' => 'CHECKBOX',
    'DEFAULT' => 'Y'
);