<?
global $rz_options;
$arParams['SHOW_ONE_CLICK'] = $rz_options['personal_one_click'] != 'N';
$arParams['SHOW_ARTICLE'] = $rz_options['show_article'] != 'N';
$APPLICATION->IncludeComponent('bitrix:catalog.section', $arParams['CATALOG_TEMPLATE'], $arParams, $component);