<?
$arParams['USE_ONECLICK'] = $arParams['USE_ONECLICK'] ? : 'Y';
