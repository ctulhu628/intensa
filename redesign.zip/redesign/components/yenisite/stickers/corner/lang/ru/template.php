<?
$MESS["STICKER_NEW"] = "новинка";
$MESS["STICKER_DISCOUNT"] = "скидка";
$MESS["STICKER_HIT"] = "продаж";
$MESS["STICKER_BESTSELLER"] = "лучшее";