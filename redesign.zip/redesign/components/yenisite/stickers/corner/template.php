<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die(); ?>
<? if (method_exists($this, 'setFrameMode')) $this->setFrameMode(true); ?>
<? if (empty($arResult)) return; ?>
<? if ($arResult["NEW"]): ?>
	<img src="<?= $templateFolder ?>/img/new.png" alt="" class="sticker-corner">
	<? return ?>
<? endif ?>
<? if ($arResult["HIT"]): ?>
	<img src="<?= $templateFolder ?>/img/hit.png" alt="" class="sticker-corner">
	<? return ?>
<? endif ?>
<? if ($arResult["SALE"]): ?>
	<img src="<?= $templateFolder ?>/img/sale.png" alt="" class="sticker-corner">
	<? return ?>
<? endif; ?>
<? if ($arResult["BESTSELLER"]): ?>
	<img src="<?= $templateFolder ?>/img/price.png" alt="" class="sticker-corner">
	<? return ?>
<? endif ?>
<?if($arResult["CATCHBUY"] && ($arParams['SHOW_CATCH_BUY'] || !isset($arParams['SHOW_CATCH_BUY'] ))):?>
	<img src="<?= $templateFolder ?>/img/hit.png" alt="" class="sticker-corner">
	<? return ?>
<?endif?>
