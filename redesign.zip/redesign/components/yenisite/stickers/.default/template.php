<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die(); ?>
<? if (method_exists($this, 'setFrameMode')) $this->setFrameMode(true); ?>
<? if (empty($arResult)) return; ?>
<div class="catalog-item-stickers">
	<? if ($arResult["NEW"]): ?>
		<div class="sticker new">
			<div class="content">
				<strong>NEW</strong>
				<small><?= GetMessage('STICKER_NEW') ?></small>
			</div>
		</div>
	<? endif ?>
	<? if ($arResult["HIT"]): ?>
		<div class="sticker hit">
			<div class="content">
				<strong>HIT</strong>
				<small><?= GetMessage('STICKER_HIT') ?></small>
			</div>
		</div>
	<? endif ?>
	<? if ($arResult["SALE"]): ?>
		<div class="sticker discount">
			<div class="content">
				<strong>
					<? if ($arResult["SALE_DISC"] > 0) {
						echo round($arResult["SALE_DISC"]);
					}
					?>%
				</strong>
				<small><?= GetMessage('STICKER_DISCOUNT') ?></small>
			</div>
		</div>
	<? endif; ?>
	<? if ($arResult["BESTSELLER"]): ?>
		<div class="sticker gift">
			<div class="content">
				<strong>BEST</strong>
				<small><?= GetMessage('STICKER_BESTSELLER') ?></small>
			</div>
		</div>
	<? endif ?>
</div>