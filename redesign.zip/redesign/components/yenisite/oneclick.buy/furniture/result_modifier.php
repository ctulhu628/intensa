<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

$arParams['HEADER_OF_ONE_CLICK'] = $arParams['HEADER_OF_ONE_CLICK'] ? : GetMessage('FURNITURE_ONECLICK_TITLE');
if(!empty($_REQUEST['quantity'])) $arResult['QUANTITY'] = $_REQUEST['quantity'];

