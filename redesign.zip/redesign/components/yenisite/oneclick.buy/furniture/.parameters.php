<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();

use Bitrix\Main\Loader;

$arTemplateParameters = array(
    "HEADER_OF_ONE_CLICK" => array(
        "PARENT" => "VISAUL",
        "NAME" => GetMessage("HEADER_OF_ONE_CLICK"),
        "TYPE" => "STRING",
        "DEFAULT" => GetMessage('DEF_HEADER_OF_ONE_CLICK'),
    ),
);
