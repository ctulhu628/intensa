<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
use \Yenisite\Core\Ajax;
use \Yenisite\Furniture\Form;
$isAjax = Ajax::isAjax();
//Not cacheable
$this->setFrameMode(true);
\Bitrix\Main\Localization\Loc::loadMessages($_SERVER['DOCUMENT_ROOT'].SITE_TEMPLATE_PATH . '/lang/'.LANGUAGE_ID.'/header.php');
$pathToRules = COption::GetOptionString(\Yenisite\Furniture\Settings::getModuleId(),'path_tu_rules_privacy',SITE_DIR.'personal/rules/personal_data.php');
if ($arParams['EMPTY']) {
    echo '<div>', GetMessage('FURNITURE_ONECLICK_TITLE'), '</div>';
    return;
} ?>
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span class="svg-wrap close"><svg>
		<use xlink:href="#close"></use>
	</svg></span></button>
                    <h4 class="modal-title flaticon-shopping220"><?= $arParams['HEADER_OF_ONE_CLICK'] ?></h4>
            </div>
                <? if (!isset($arResult['SUCCESS'])):?>
                <div class="hint">
                                <?= GetMessage("FURNITURE_ONECLICK_REQ_FIELD") ?><span class="asterisk-required">*</span> &mdash; <?= GetMessage("FURNITURE_ONECLICK_REQ_FIELD_PART_2") ?></div><!-- hint -->
                <?endif?>
                <form  data-validate="true" novalidate method="post" action="<?= $APPLICATION->GetCurPage(true) ?>" class="form_registration modal-form">
                    <div class="modal-body">
                        <? if (isset($arResult['SUCCESS'])) {
                        \Yenisite\Furniture\Main::ShowMessage(array($arResult['SUCCESS']), \Yenisite\Furniture\Main::MSG_TYPE_SUCCESS, false);?>
                    </div>
                    <?return;
                    }
                    if (empty($arResult['FIELDS'])) {
                        \Yenisite\Furniture\Main::ShowMessage(array(GetMessage('STORY_ONECLICK_EMPTY_FILEDS')), \Yenisite\Furniture\Main::MSG_TYPE_ERROR, true, false);
                    }
                    if (!empty($arResult['ERROR'])) {
                        $err = '';
                        foreach ($arResult['ERROR'] as $arError) {
                            if (is_array($arError))
                                $err .= $arError['TEXT'] . '<br>';
                            else  $err .= $arError . '<br>';
                        }
                        \Yenisite\Furniture\Main::ShowMessage(array($err), \Yenisite\Furniture\Main::MSG_TYPE_ERROR, true, false);
                    } ?>
                    <?if(!empty($_REQUEST['ITEM_NAME'])):?>
                        <h4 class="modal-title title-of-quick"><?=GetMessage('FURNITURE_ONECLICK_ITEM_NAME')?>: <?=htmlspecialcharsbx($_REQUEST['ITEM_NAME'])?></h4>
                    <?endif?>
                    <?if(!empty($_REQUEST['ITEM_NAME'])):?>
                        <input type="hidden" name="ITEM_NAME" value="<?= htmlspecialcharsbx($_REQUEST['ITEM_NAME']) ?>"/>
                    <?endif?>
                    <input type="hidden" name="MESSAGE_OK" value="<?= htmlspecialcharsbx($arParams['MESSAGE_OK']) ?>"/>
                    <input type="hidden" name="FORM_ID" value="<?= $arParams['FORM_ID'] ?>"/>
                    <input type="hidden" name="BUY_SUBMIT" value="Y"/>
                    <input type="hidden" name="FORM_WITHOUT_ACCEPT" value="Y"/>
                    <input type="hidden" name="privacy_policy" value="N"/>
                    <?= bitrix_sessid_post() ?>
                    <? foreach ($arResult['HIDDEN_FIELDS'] as $arField) {
                        echo $arField['HTML'], "\n";
                    } ?>
                    <input type="hidden" name="id" value="<?= $arParams['IBLOCK_ELEMENT_ID'] ?>" title=""/>
                    <input type="hidden" name="RZ_BASKET" value="<?= htmlspecialcharsbx($_REQUEST['RZ_BASKET']) ?>"/>

                    <? if ($arParams['FIELD_QUANTITY'] == 'Y' && $_REQUEST['RZ_BASKET'] !== 'Y'): ?>
                        <label class="form-group">
                            <span class="label-text"> <?= GetMessage("FURNITURE_ONECLICK_QUANTITY") ?>:</span>
                            <input placeholder="<?= GetMessage("STORY_ONECLICK_QUANTITY") ?>" type="text"
                                   class="form-control"
                                   name="QUANTITY" value="<?= $arResult['QUANTITY'] ?>" title=""/>
                        </label><!-- form-group -->
                    <? endif ?>
                    <? foreach ($arResult['FIELDS'] as $arItem):
                        if($arItem['NAME'] == GetMessage('FURNITURE_ONECLICK_TELEPHONE')):
                            $arItem['HTML'] = str_replace('textinput', 'form-control label-for-phone', $arItem['HTML']);
                         else:
                            $arItem['HTML'] = str_replace('textinput', 'form-control', $arItem['HTML']);
                    endif;
                        $arItem['HTML'] = ($arItem['REQ']) ? str_replace('/>', ' required />', $arItem['HTML']) : $arItem['HTML'] ?>

                        <label class="form-group">
                            <span class="label-text"><?= $arItem['NAME'] ?><? if ($arItem['REQ']):?><span
                                class="asterisk-required">*</span><? endif ?>:</span>
                            <?= $arItem['HTML'] ?>
                        </label><!-- form-group -->
                    <? endforeach ?>

                    <? if ('Y' == $arResult['USE_CAPTCHA'] && strlen($arResult["CAPTCHA_CODE"]) > 0): ?>
                        <label class="form-group">
                                <input type="hidden" name="captcha_sid" value="<?= $arResult["CAPTCHA_CODE"] ?>">
                            <span class="text"><?=GetMessage('FURNITURE_ONECLICK_CAPTCHA_REGF_TITLE')?></span>
                            <span class="captcha">
                                         <img class="captcha-img" src="/bitrix/tools/captcha.php?captcha_sid=<?= $arResult["CAPTCHA_CODE"] ?>" alt="CAPTCHA">
                            </span>
                            <span class="label-text"><?= GetMessage('FURNITURE_ONECLICK_CAPTCHA_REGF_PROMT') ?><span
                                class="asterisk-required">*</span>:</span>
                            <input type="text" name="captcha_word"
                                   id="captcha_word"
                                   class="form-control" required
                                   value="" title=""
                                   placeholder="<?= GetMessage('STORY_ONECLICK_CAPTCHA_REGF_PROMT') ?>">
                        </label>
                    <? endif ?>
                        <?
                        $text = GetMessage('RZ_RULES_YA') . ' ';
                        $text .=  GetMessage('RZ_ACCEPT') . " <a href='" . $pathToRules . "' target='_blank' class='classic-link'>" . GetMessage('RZ_CONCLUSION') . "</a>";
                        Form::printElement(
                            array(
                                'NAME' => 'PRIVACY_POLICY',
                                'CHECKED' => $_POST['PRIVACY_POLICY'] == 'Y',
                                'TEXT' => $text,
                                'REQ' => true,
                                'INDEX' => ++$tabIndex,
                            ), Form::TYPE_CHECKBOX
                        );
                        ?>
                    <input type="hidden" name="PROPS"
                           value="<?= \Yenisite\Core\Tools::GetEncodedArParams($arParams['OFFER_PROPS']) ?>"/>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn-main btn-primary" name="submit">
                            <?= GetMessage('FURNITURE_ONECLICK_SUBMIT_BUTTON') ?>
                        </button>
                    </div>
                </form>