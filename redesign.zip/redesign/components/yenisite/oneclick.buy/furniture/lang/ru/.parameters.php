<?
$MESS['HEADER_OF_ONE_CLICK'] = 'Заголовок формы купить в 1 клик';
$MESS['DEF_HEADER_OF_ONE_CLICK'] = 'Быстрый заказ';
$MESS['FURNITURE_ONECLICK_ITEM_NAME'] = 'Товар';
