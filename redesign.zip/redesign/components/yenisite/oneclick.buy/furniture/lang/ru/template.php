<?
$MESS["FURNITURE_ONECLICK_REQ_FIELD"] = "Поля, помеченные ";
$MESS["FURNITURE_ONECLICK_REQ_FIELD_PART_2"] = "обязательны для заполнения";
$MESS["FURNITURE_ONECLICK_TITLE"] = "БЫСТРАЯ ПОКУПКА В 1 КЛИК";
$MESS["FURNITURE_ONECLICK_SUBMIT_BUTTON"] = "Жду звонка";
$MESS["FURNITURE_ONECLICK_QUANTITY"] = "Количество";
$MESS["FURNITURE_ONECLICK_TELEPHONE"] = "Телефон";
$MESS["FURNITURE_ONECLICK_ITEM_NAME"] = "Товар";
$MESS["FURNITURE_ONECLICK_CAPTCHA_REGF_TITLE"] = "Защита от автоматических сообщений";
$MESS["FURNITURE_ONECLICK_CAPTCHA_REGF_PROMT"] = "Введите слово с картинки";
$MESS["FURNITURE_ONECLICK_SUBMIT_BUTTON"] = "Отправить заказ";
$MESS["FURNITURE_ONECLICK_EMPTY_FILEDS"] = "В параметрах компонента не указаны поля для вывода";
