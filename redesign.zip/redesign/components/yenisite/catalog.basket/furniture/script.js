'use strict';
$(function () {
	var $mainBasket = $('#main_basket'),
		timer, ajaxStarted;
	var doAjax = function (addData) {
		if (ajaxStarted) return false; // fix strange bug on chrome 51.0
		var data;
		if (typeof addData == 'object') {
			data = addData;
		} else {
			data = $mainBasket.serializeArray();
		}
		data.push({'name': 'ajax', 'value': $mainBasket.data('ajax')}
		);
		$mainBasket.startAjax();
		ajaxStarted = 1;
		$.ajax({
			'url': AJAX_DIR + 'cart.php',
			'type': 'post',
			'data': data,
			'success': function (msg) {
				$mainBasket.html(msg);
				$mainBasket.refreshForm();
				$mainBasket.stopAjax();
				ajaxStarted = 0;
				deliveryCheck();
			}
		});
	};

	$mainBasket.on('submit', function (e) {
		if ($mainBasket.data('submit')) {
			if($('#agreement').attr('checked') == true){
				$mainBasket.find(':input[name="calculate"]').remove();
				$mainBasket.find(':input[name="BasketRefresh"]').remove();
			}
			return true;
		} else {
			e.preventDefault();
			doAjax();
			return false;
		}
	});

	$mainBasket.on('change', '.quantity-input', function (e) {
		if (timer) {
			clearTimeout(timer);
		}
		var $this = $(this);
		if($this.attr('value') == null){
		timer = setTimeout(
			function () {
				$mainBasket.submit();
			}, 300);
		}else{
			var data;
			$mainBasket.find(':input[name="order"]').remove();
			data = $mainBasket.serializeArray();
			data.push({'name': 'id', 'value': $this.attr('data-id')},
					{'name': 'q', 'value': $this.attr('value')}
					);
			doAjax(data);
		}
	});

	$mainBasket.on('click', '.basket-action-btn', function (e) {
		e.preventDefault();
		var $this = $(this);
		var data;
		$mainBasket.find(':input[name="order"]').remove();
		data = $mainBasket.serializeArray();
		data.push({'name': 'action', 'value': 'delete'},
				{'name': 'id', 'value': $this.attr('data-id')}
				);
		doAjax(data);
		return false;
	});

	$mainBasket.on('click', '[name="BasketOrder"]', function (e) {
		$mainBasket.data('submit', true);
	});
	
	$mainBasket.on('change', 'div.ys-delivery input', function (e) {
		var $this = $(this);
		$('#delivery').val($this.attr('data-value'));
		$mainBasket.find(':input[name="order"]').remove();
		doAjax();
		return false;
	});
	
	if (!$("tr.ys-delivery td.ys-delivery").html()){
		$('tr.ys-delivery').css('display', 'none');
	}
	
	function deliveryCheck(){
		if (!$("tr.ys-delivery td.ys-delivery").html()){
			$('tr.ys-delivery').css('display', 'none');
		}
		$('#delivery').val($('div.ys-delivery input:checked').attr('data-value'));
	}

	deliveryCheck();
	


});

function YS_Validate() {
	var $agreement = $('#agreement');
	if (!$agreement.is(':checked')) {
		rz_showMessage($agreement.attr('data-title'), "info");
		return false;
	} else {
		$('#calculate').attr('name', 'no_calculate');
		$('#order').attr('name', 'order');
	}
}