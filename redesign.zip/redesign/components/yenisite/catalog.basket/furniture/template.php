<? use Bitrix\Sale\DiscountCouponsManager;
use Yenisite\Core\Ajax;
use Yenisite\Furniture\Main;

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */
/** @var CBitrixBasketComponent $component */
use Yenisite\Furniture\Form;
$stepInt = 0;
$isAjax = Ajax::isAjax();
\Bitrix\Main\Localization\Loc::loadMessages($_SERVER['DOCUMENT_ROOT'].SITE_TEMPLATE_PATH . '/lang/'.LANGUAGE_ID.'/header.php');
$pathToRules = COption::GetOptionString(\Yenisite\Furniture\Settings::getModuleId(),'path_tu_rules_privacy',SITE_DIR.'personal/rules/personal_data.php');
?>

<? if(!isset($arResult["ITEMS"])): ?>
	<div class="ordering-option clearfix"><? Main::ShowMessage(GetMessage('RZ_NO_ITEMS'), Main::MSG_TYPE_WARNING, false) ?></div>
	<? return ?>
<? endif ?>

<? if(!empty($arResult["ERROR"])){ 
	foreach($arResult["ERROR"] as $errorMessege){ ?>
		<div class="ordering-option clearfix"><? Main::ShowMessage(GetMessage('ERROR') . $errorMessege, Main::MSG_TYPE_ERROR, true) ?></div>
<? 	}
} ?>

<?
if (!$isAjax):
Ajax::saveParams($this, $arParams, 'main_basket');
?>
<section class="ordering2-content">
	<form method="POST" action="#" name="main_basket" id="main_basket" onsubmit="return YS_Validate()" <? Ajax::printAjaxDataAttr($this,
		'main_basket') ?>>
<? endif ?>
		<input type="hidden" name="calculate" id="calculate"  value="calculate" />
		<input type="hidden" name="order" id="order" value="<?=GetMessage("ORDER");?>" />

		<input type="hidden" name="BasketRefresh" value="BasketRefresh"/>

		<? $delivAndPaym = '';?>
		
			<div class="ordering-option clearfix">
				<h3 class="ordering-option__header">
					<span class="option-cloud"><?= ++$stepInt ?></span>
					<?= GetMessage('SOA_TEMPL_BUYER_INFO'); ?>
				</h3>
				<div class="ordering-option__content clearfix personal">
					<div id='sale_order_props'>
					<?
					$reqFlag = false;
					foreach($arResult["DISPLAY_PROPERTIES"] as $code => $arProp):
					
						if ($code == 'PAYMENT_E' || $code == 'DELIVERY_E'){
							if(substr_count($arProp["INPUT"], "radio") > 0){
								$arr = explode("<br/>", $arProp["INPUT"]);
								foreach($arr as $k=>&$ar){
									if(empty($ar)) continue;
									$idInput = $code == 'DELIVERY_E'?'delivery':'payment';
									$deliveryCheck = $code == 'DELIVERY_E'?'ys-delivery':'';
									$idInput .= $k;
									$ar = '<label class="radio" for="' . $idInput . '">' . str_replace(
										array('<input', '/>' , 'placeholder'),
										array('<input class="radio-input state" id="' . $idInput . '"', '/><span class="radio-content">', 'data-value'),
										$ar) . '</span></label>';
								}
								
								$arProp["INPUT"] = '<div class="ordering-option col-md-6 ' . $deliveryCheck . '">
														<h3 class="ordering-option__header">
															<span class="option-cloud">' . ++$stepInt . '</span>' . 
															GetMessage("SOA_TEMPL_" . $code) .  
														'</h3>
														<div class="ordering-option__content">' .
															implode(" ", $arr) .
														'</div>
													</div>';
							}
							
							$delivAndPaym .= $arProp["INPUT"];
							continue;
						}
						?>
					
						<label class="form-group">
							<span class="label-text">
								<?=$arProp["NAME"]?><?if($arProp['IS_REQUIRED'] == "Y"):$reqFlag=true;?><span class="asterisk-required">*</span><?endif?>:
							</span>
							<?
							$arSearch = array('<input type="text"', '<textarea');
							$classReplace = $code == 'PHONE' ? 'form-control input-phone' : 'form-control';
							$arReplace = array('<input type="text" class="' . $classReplace . '" size="30" placeholder="'.$arProp['NAME'].'"', '<textarea class="form-control"');
							?>
							<?=str_replace($arSearch, $arReplace, $arProp["INPUT"])?>					
						</label>
					<?endforeach?>
					<?if($reqFlag):?>
						<label class="form-group">
							<span class="asterisk-required">*</span> <?=GetMessage('YS_BASKET_REQUIRED');?>
						</label>
					<?endif?>
					</div>
				</div>
			</div>

			<div class="row">
			<?= $delivAndPaym; ?>
			</div>
			
			<div class="ordering-option clearfix">
				<h3 class="ordering-option__header">
					<span class="option-cloud"><?= ++$stepInt ?></span>
					<?=GetMessage('SALE_NAME');?>:
				</h3>		
				<div class="ordering-option__content">
					<div class="cart-header">
						<span class="text">
							<?= GetMessage('RZ_BASKET-ITEMS-INSIDE') ?>
							<b><?= $arResult['COMMON_COUNT'] ?></b>
						</span>
						<span class="text">
							<?= GetMessage('RZ_BASKET-TOTAL-PRICE') ?>
							<b><?= $arResult['BUSKET_SUM_PRICE'] ?></b>
						</span>
					</div>
					<?
					$arItems = &$arResult['ITEMS'];
					$bHasItemsForOrder = !empty($arItems);
					include 'items.php';
					?>
					<? if ($bHasItemsForOrder): ?>
						<div class="table-footer clearfix cart-wrap">
							<div class="big-cart-total">
								<table class="total">
									<tbody>
										<tr>
											<th colspan='2'>
												<?= GetMessage('RZ_TOTAL') ?>
											</th>
										</tr>
										<tr>
											<td><?= GetMessage('RZ_BASKET-ITEMS-INSIDE') ?></td>
											<td><?= $arResult['COMMON_COUNT'] ?></td>
										</tr>
										<tr class='ys-delivery'>
											<td><?= GetMessage('DELIVERY') ?></td>
											<td class='ys-delivery'><?= $arResult['DELIVERY']?:'' ?></td>
										</tr>
										<tr>
											<td><?= GetMessage('RZ_TOTAL-PRICE') ?></td>
											<td><?= $arResult['TOTAL_SUM_FORMATTED'] ?></td>
										</tr>
									<tbody>
								</table>
							</div>
						</div>
						<input type="hidden" name="delivery" id="delivery" value="">
					<? endif ?>					
				</div>
			</div>



		<div class="big-cart-buttons">
			<div class="quick-order-wrap">
				<label class="checkbox" title="<?=GetMessage('AGREEMENT3')?>" for="agreement">
					<input type="checkbox" class="checkbox-input state" id="agreement" name="agreement" data-title="<?=GetMessage('AGREEMENT3')?>" <?= ($_REQUEST['agreement'] == 'on' || $_REQUEST['agreement'] == true) ? 'checked' : '' ?> >
					<span class="checkbox-content">
						<span class="check flaticon-checked21"></span>
						<?=GetMessage('AGREEMENT1')?>
						<a title="<?=GetMessage('AGREEMENT2')?>" target="_blank" href="<?=SITE_DIR?>about/payment_and_delivery/usloviya-dostavki-i-vozvrata-tovarov/"><?=GetMessage('AGREEMENT2')?></a>
					</span>
				</label>
                <?
                $text = GetMessage('RZ_RULES_YA') . ' ';
                $text .=  GetMessage('RZ_ACCEPT') . " <a href='" . $pathToRules . "' target='_blank' class='classic-link'>" . GetMessage('RZ_CONCLUSION') . "</a>";
                Form::printElement(
                    array(
                        'NAME' => 'PRIVACY_POLICY',
                        'CHECKED' => $_POST['PRIVACY_POLICY'] == 'Y',
                        'TEXT' => $text,
                        'REQ' => true,
                        'INDEX' => ++$tabIndex,
                    ), Form::TYPE_CHECKBOX
                );
                ?>
			</div>
			<div class="quick-order-wrap">
				<button type="submit" name="BasketOrder" value="BasketOrder"
						class="btn-main btn-primary btn-checkout" <? if (!$bHasItemsForOrder): ?> disabled<? endif ?>
						id="big-basket-submit-btn"><?= GetMessage('RZ_BIG-BASKET-SUBMIT-ORDER') ?></button>
			</div>
		</div>
<? if (!$isAjax): ?>
	</form>
</section>
<? endif ?>