<?
/**
 * @var array $arItems
 * @var array $arResult
 * @var array $arParams
 */
use Yenisite\Furniture\Form;
use Yenisite\Furniture\Main;

$resizeItem = array('WIDTH' => 80, 'HEIGHT' => 80, 'SET_ID' => $arParams['RESIZER_BASKET_PHOTO']);
$langPrefix = 'RZ_BASKET-HEADER-';
if (empty($arItems)) {
	Main::ShowMessage(GetMessage('RZ_NO_ITEMS'), Main::MSG_TYPE_WARNING, false);
	return;
}
?>
<table class='cart-table'>
	<thead>
		<tr>
			<td colspan="2"><?=GetMessage('RZ_BASKET-HEADER-NAME')?></td>
			<td class="hidden-xs"><?=GetMessage('RZ_BASKET-HEADER-PRICE')?></td>
			<td class="for-amount"><?=GetMessage('RZ_BASKET-HEADER-QUANTITY')?></td>
			<td class="hidden-xs"><?=GetMessage('RZ_BASKET-HEADER-SUM')?></td>
			<td class="hidden-xs"></td>
		</tr>
	</thead>
	<tbody>
	<? foreach ($arItems as &$arItem):
		$PIC = $arItem['FIELDS']['DETAIL_PICTURE'];
		if (!$PIC) {
			$PIC = $arItem['FIELDS']['PREVIEW_PICTURE'];
		}
		if (!$PIC) {
			$PIC = $arItem;
		}
		$PIC = Main::GetResizedImg($PIC, $resizeItem);
		$bCanBuy = $arItem['CAN_BUY'] == 'Y';
		?>
		<tr class="cart-item <?= $bCanBuy ? 'in-stock' : 'out-of-stock' ?>">

			<td class="img-wrap">
				<a href="<?= $arItem['FIELDS']['DETAIL_PAGE_URL'] ?>">
					<img src="<?= $PIC ?>" alt="<?= $arItem['FIELDS']['NAME'] ?>">
				</a>
			</td>
			
			<td class="name-wrap">
					<a href="<?= $arItem['FIELDS']['DETAIL_PAGE_URL'] ?>" class="link link-std"><?= $arItem['FIELDS']['NAME'] ?></a>
			</td>

			<td class="price-wrap">
				<div class="price"><?= $arItem['PRICE']['PRICE_BASE'] ?></div>
			</td>		

			<td class="availability" data-when-out-of-stock="<?= GetMessage('RZ_BASKET-OUT-OF-STOCK') ?>">
				<? if ($bCanBuy){ ?>
					<? Form::printElement(array('STEP' => $arResult['PROPERTIES'][$arItem['ID']]['MEASURE_NAME']['VALUE'], 'VALUE' => $arItem['COUNT'], 'NAME' => 'QUANTITY_' . $arItem['ID'], 'ATTR' => 'data-id='.$arItem['ID']),
							Form::TYPE_QUANTITY) ?>
					<span class="price-unit"><?= $arItem['MEASURE_TEXT'] ?></span>
				<? } ?>
			</td>

			<td class="sum">
				<?= $arItem['TOTAL_SUM_FORMATTED'] ?>
			</td>

			<td class="text-right actions">
				<button type="submit" name="<?= $arParams['ACTION_VARIABLE']? $arParams['ACTION_VARIABLE']:'del'.$arItem['ID'] ?>" value="delete_<?= $arItem['ID'] ?>" data-id="<?= $arItem['ID'] ?>"
				class="basket-action-btn delete flaticon-delete96 tooltip-simple" title="<?= GetMessage('RZ_BASKET-DELETE') ?>" 
				data-toggle="tooltip" data-placement="top" data-trigger="hover"></button>
			</td>
		</tr>
	<? endforeach;
	unset($arItem); ?>
	</tbody>
</table>
