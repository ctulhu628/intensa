<?
$MESS["SALE_PROPERTIES_RECALCULATE_BASKET"] = "Свойства, влияющие на пересчет корзины";
$MESS['BITRONIC2_DELIVERY_URL'] = 'Страница с информацией о доставке';
$MESS['USE_ONECLICK'] = 'Страница с информацией о доставке';
$MESS['DEF_TIP_BUY_IN_ONE_CLICK'] = 'Вам нужно будет указать только имя и номер телефона';
$MESS['TIP_BUY_IN_ONE_CLICK'] = 'Текст подсказки под кнопкой купить в 1 клик';
?>