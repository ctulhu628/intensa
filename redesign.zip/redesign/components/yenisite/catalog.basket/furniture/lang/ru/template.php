<?
/**
 * @var array $MESS
 */

$MESS['RZ_BASKET'] = 'Корзина';
$MESS['RZ_WAITLIST'] = 'Отложенные';
$MESS['RZ_NO_ITEMS'] = 'В вашей корзине ещё нет товаров.';
$MESS['RZ_TOTAL'] = 'Итого:';

$MESS['RZ_BASKET-CLEAR'] = 'Удалить всё из корзины';

$MESS['RZ_BASKET-ITEMS-INSIDE'] = 'Товаров в корзине:';
$MESS['RZ_BASKET-TOTAL-PRICE'] = 'На сумму:';
$MESS['RZ_TOTAL-PRICE'] = 'Итоговая сумма:';
$MESS['RZ_BASKET-TOTAL-DISCOUNT'] = 'Скидка:';
$MESS['RZ_BASKET-OUT-OF-STOCK'] = 'Товар отсутствует';
$MESS['RZ_WAITLIST-ITEMS'] = 'Отложенные товары';
$MESS['RZ_WAITLIST-ITEMS-SHORT'] = 'Отложено';
$MESS['RZ_WAITLIST-ITEMS-INSIDE'] = 'Отложенных товаров:';
$MESS['RZ_BACK-TO-BASKET'] = 'Товары в корзине';
$MESS['RZ_BACK-TO-BASKET-SHORT'] = 'В корзине';
$MESS['RZ_INFORM-ME'] = 'Сообщить о наличии';

$MESS['RZ_BIG-BASKET-HEADER'] = 'Корзина заказа';
$MESS['RZ_BIG-BASKET-PRINT'] = 'Распечатать корзину';
$MESS['RZ_BIG-BASKET-ADD-BY-CODE'] = 'Добавить товары по артикулу:';
$MESS['RZ_BIG-BASKET-ENTER-VENDORCODE'] = 'Введите артикул товара';

$MESS['RZ_BIG-BASKET-SUBMIT-ORDER'] = 'Оформить заказ';
$MESS['RZ_BIG-BASKET-TOTAL-WEIGHT'] = 'Общий вес:';
$MESS['RZ_BIG-BASKET-ASK-FOR-PROMOCODE'] = 'Знаете промо-код на скидку?';
$MESS['RZ_BIG-BASKET-ENTER-PROMOCODE'] = 'Введите код в это поле...';
$MESS['RZ_BIG-BASKET-ENTER-PROMOCODE2'] = 'Добавить еще промокод...';

$MESS['RZ_ADD'] = 'Добавить';
$MESS['RZ_QUICK-BUY'] = 'Быстрый заказ';
$MESS['RZ_VENDOR-CODE'] = 'Артикул';


$MESS['RZ_BASKET-HEADER-NAME'] = 'Товар';
$MESS['RZ_BASKET-HEADER-QUANTITY'] = 'Количество';
$MESS['RZ_BASKET-HEADER-WEIGHT'] = 'Вес, ед.';
$MESS['RZ_BASKET-HEADER-TOTAL_WEIGHT'] = 'Общий вес';
$MESS['RZ_BASKET-HEADER-PRICE'] = 'Цена, ед.';
$MESS['RZ_BASKET-HEADER-TYPE'] = 'Тип цены';
$MESS['RZ_BASKET-HEADER-DISCOUNT'] = 'Скидка';
$MESS['RZ_BASKET-HEADER-SUM'] = 'Сумма';
$MESS['RZ_BASKET-HEADER-PROPS'] = 'Свойства';
$MESS['RZ_BASKET-HEADER-PROPS'] = 'Свойства';
$MESS['RZ_BASKET-HEADER-VAT'] = 'НДС';
$MESS['RZ_BASKET-HEADER-DELETE'] = 'Удалить';
$MESS['RZ_BASKET-HEADER-DELAY'] = 'Отложить';

$MESS['RZ_BASKET-HELP-FOR-QUICK'] = 'Вам нужно будет указать только имя и номер телефона';
$MESS['RZ_BASKET-QUICK-ORDER'] = 'Быстрый заказ';


$MESS['NAME']="Ваше имя";
$MESS['EMAIL']="E-mail";
$MESS['PHONE']="Телефон";
$MESS['SALE_REFRESH']="Обновить";
$MESS['SALE_ORDER']="Отправить заказ";
$MESS['YENISITE_BASKET_NAME'] = "Наименование";
$MESS['YENISITE_BASKET_ARTICUL'] = "Артикул";
$MESS['YENISITE_BASKET_PRICE'] = "Цена";
$MESS['YENISITE_BASKET_QUANTITY'] = "Количество";
$MESS['YENISITE_BASKET_DELETE'] = "Удалить";
$MESS['YENISITE_BASKET_BASKET'] = "товаров в корзине на сумму ";
$MESS['YENISITE_BASKET_BASKET2'] = "Итого, ";
$MESS['YENISITE_BASKET_UE'] = "Р";
$MESS['YENISITE_BASKET_EMPTY'] = "Ваша корзина пуста.";
$MESS['PHOTO'] = "Фотография";
$MESS['NAME'] = "Наименование";
$MESS['COUNT'] = "Количество";
$MESS['PRICE'] = "Цена";
$MESS['DELETE'] = "Удалить";
$MESS['CALCULATE'] = "Пересчитать";
$MESS['ORDER'] = "Оформить заказ";
$MESS['UE'] = "рублей";
$MESS['ITOG'] = "Итого";
$MESS['DELIVERY'] = "Доставка:";
$MESS['ERROR'] = "Не заполнено обязательное поле ";
$MESS['YS_BASKET_REQUIRED'] = '&mdash; поля обязательные для заполнения';


$MESS['SOA_TITLE'] = "Ваш заказ";
$MESS['SOA_NO_JS'] = "Для оформления заказа необходимо включить JavaScript. По-видимому, JavaScript либо не поддерживается браузером, либо отключен. Измените настройки браузера и затем <a href=\"\">повторите попытку</a>.";
$MESS['SALE_PRODUCTS_SUMMARY'] = "Вы выбрали";
$MESS["PRICE_SYMBOL"] = "Р";
$MESS["REMOVE"] = "Удалить";
$MESS["SOA_TEMPL_BUYER_INFO"] = "Информация о покупателе";
$MESS["GOOD_CHOICE_TEXT"] = "Давайте, уточним некоторые детали вашего заказа";
$MESS["AGREEMENT1"] = "Я прочитал и принимаю";
$MESS["AGREEMENT2"] = "условия доставки";
$MESS["AGREEMENT3"] = "Необходимо принять условия доставки";


$MESS["SALE_ORDER"] = "Оформить заказ";
$MESS["SALE_OR"] = "или";
$MESS["SALE_NAME"] = "Товары";
$MESS["SALE_PROPS"] = "Свойства";
$MESS["SALE_PRICE"] = "Цена";
$MESS["SALE_TYPE"] = "Тип цены";
$MESS["SALE_QUANTITY"] = "Количество";
$MESS["SALE_SUM"] = "Сумма";
$MESS["SALE_DELETE"] = "Удалить";
$MESS["SALE_DELAY"] = "Отложить";
$MESS["SALE_ADD_TO_BASKET"] = "Добавить к заказу";
$MESS["SALE_WEIGHT"] = "Вес";
$MESS["SALE_TOTAL_WEIGHT"] = "Общий вес:";
$MESS["SALE_WEIGHT_G"] = "г";
$MESS["SALE_DELAYED_TITLE"] = "Отложено";
$MESS["SALE_UNAVAIL_TITLE"] = "Отсутствуют в продаже";
$MESS["STB_ORDER_PROMT"] = "Для того чтобы начать оформление заказа, нажмите кнопку \"Оформить заказ\".";
$MESS["STB_COUPON_PROMT"] = "Введите код купона для скидки:";
$MESS["SALE_VAT"] = "НДС:";
$MESS["SALE_VAT_EXCLUDED"] = "Товаров на:";
$MESS["SALE_VAT_INCLUDED"] = "В том числе НДС:";
$MESS["SALE_TOTAL"] = "Итого:";
$MESS["SALE_CONTENT_DISCOUNT"] = "Скидка:";
$MESS["SALE_DISCOUNT"] = "Скидка";
$MESS["SALE_NOTIFY_TITLE"] = "Ожидаемые товары";
$MESS["SALE_REFRESH_NOTIFY_DESCR"] = "Нажмите эту кнопку, чтобы удалить товары.";
$MESS["SALE_ITEMS"] = "Товары в корзине:";
$MESS["SALE_BASKET_ITEMS"] = "Готовые к заказу";
$MESS["SALE_BASKET_ITEMS_DELAYED"] = "Отложенные";
$MESS["SALE_BASKET_ITEMS_SUBSCRIBED"] = "Ожидаемые";
$MESS["SALE_BASKET_ITEMS_NOT_AVAILABLE"] = "Отсутствуют";
$MESS["SALE_NO_ITEMS"] = "В вашей корзине ещё нет товаров.";
$MESS["SALE_REFRESH"] = "Пересчитать";
$MESS["SALE_YOUR_ORDER"] = "Ваш заказ:";


$MESS["BITRONIC2_SALE_NAME"] = "Товар";
$MESS["BITRONIC2_SALE_PROPS"] = "Свойства";
$MESS["BITRONIC2_SALE_PRICE"] = "Цена за ед.";
$MESS["BITRONIC2_SALE_TYPE"] = "Тип цены";
$MESS["BITRONIC2_SALE_QUANTITY"] = "Количество";
$MESS["BITRONIC2_SALE_SUM"] = "Сумма";
$MESS["BITRONIC2_SALE_CLEAR"] = "Очистить корзину";


$MESS["SOA_TEMPL_BUYER_INFO"] = "Личная информация";
$MESS["SOA_TEMPL_DELIVERY_E"] = "Служба доставки";
$MESS["SOA_TEMPL_PAYMENT_E"] = "Платежная система";



