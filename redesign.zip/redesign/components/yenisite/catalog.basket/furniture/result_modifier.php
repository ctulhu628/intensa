<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
use Yenisite\Furniture\Main;

$arResult['BUSKET_SUM_PRICE'] = $arResult['COMMON_PRICE'];

if(!empty($_REQUEST['delivery']) && $_REQUEST['delivery'] != 0){
	$arResult['DELIVERY'] = $_REQUEST['delivery'];
	$arResult['BUSKET_SUM_PRICE'] -= !empty($_REQUEST['no_calculate']) ? $_REQUEST['delivery'] : 0;
	$arResult['DELIVERY'] = Main::getElementPriceFormat(false, $arResult['DELIVERY']);
}

if($arResult['ITEMS'])
foreach ($arResult['ITEMS'] as &$arItem){
	$arItem["CAN_BUY"] = "Y";
	$arItem['TOTAL_SUM_FORMATTED'] = Main::getElementPriceFormat(false, $arItem['COUNT']*$arItem['PRICE']['PRICE_BASE']);
	$arItem['PRICE']['PRICE_BASE'] = Main::getElementPriceFormat(false, $arItem['PRICE']['PRICE_BASE']);
	if($arItem['PRODUCT']['QUANTITY_TRACE'] == 'Y' && $arItem['PRODUCT']['CAN_BUY_ZERO'] != 'Y' && $arItem['PRODUCT']['QUANTITY'] <= 0) {
		$item['CAN_BUY'] = 'N';
	}
}
$arResult['COMMON_PRICE'] += $_REQUEST['calculate'] ? $_REQUEST['delivery'] : 0;
$arResult["TOTAL_SUM_FORMATTED"] = Main::getElementPriceFormat(false, $arResult['COMMON_PRICE']);
	
$arResult["BUSKET_SUM_PRICE"] = Main::getElementPriceFormat(false, $arResult['BUSKET_SUM_PRICE']);
	
$arParams['USE_ONECLICK'] = $arParams['USE_ONECLICK'] ? : 'Y';
$arParams['TIP_BUY_IN_ONE_CLICK'] = $arParams['TIP_BUY_IN_ONE_CLICK'] ? : GetMessage('RZ_BASKET-HELP-FOR-QUICK');