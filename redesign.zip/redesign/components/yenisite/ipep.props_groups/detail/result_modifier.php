<?if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED!==true) die();
$arParamsOfItem = array();
if (!empty($arParams['CATALOG_WIDTH'])){
    $arParamsOfItem['PROPS']['CATALOG_MESURE'] = 'CATALOG_MESURE';
    $arResult['DISPLAY_PROPERTIES']['CATALOG_MESURE']['CATALOG_WIDTH'] = $arParams['CATALOG_WIDTH'];
}
if(!empty($arParams['CATALOG_HEIGHT'])){
    $arParamsOfItem['PROPS']['CATALOG_MESURE'] = 'CATALOG_MESURE';
    $arResult['DISPLAY_PROPERTIES']['CATALOG_MESURE']['CATALOG_HEIGHT'] = $arParams['CATALOG_HEIGHT'];
}
if (!empty($arParams['CATALOG_LENGTH'])){
    $arParamsOfItem['PROPS']['CATALOG_MESURE'] = 'CATALOG_MESURE';
    $arResult['DISPLAY_PROPERTIES']['CATALOG_MESURE']['CATALOG_LENGTH'] = $arParams['CATALOG_LENGTH'];
}
if(!empty($arParams['CATALOG_WEIGHT'])){
    $arParamsOfItem['PROPS']['CATALOG_WEIGHT'] = 'CATALOG_WEIGHT';
    $arResult['DISPLAY_PROPERTIES']['CATALOG_WEIGHT'] = $arParams['CATALOG_WEIGHT'];
}
if (!empty($arParamsOfItem) && !empty($arResult['GROUPS'][0])){
    $arResult['GROUPS'][0]['PROPS'] = array_merge($arParamsOfItem['PROPS'],$arResult['GROUPS'][0]['PROPS']);
} elseif(!empty($arParamsOfItem)){
    $arParamsOfItem['NAME'] = GetMessage('WITHOUT_GROUP');
    array_unshift($arResult['GROUPS'],$arParamsOfItem);
}