<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) {
    die();
} ?>
<? if (method_exists($this, 'setFrameMode')) $this->setFrameMode(true); ?>
<?
$glueTemplate = ' / ';
foreach ($arResult['GROUPS'] as $groupID => $arGroup): ?>
    <div class="product-description-part col-xs-12 col-sm-6 col-md-12">
        <? if ($groupID > 0): ?>
            <a href="#product-description-part-<?= $groupID ?>" class="product-description-part-title"
               data-toggle="collapse"
               aria-expanded="<?= $arParams['SHOW_FULL_PROPS'] != 'N' ? 'true' : 'false' ?>">
                <span><?= $arGroup['NAME'] ?></span>
            </a>
        <? else: ?>
            <a  href="#product-description-part-<?= $groupID ?>" class="product-description-part-title"
               data-toggle="collapse"
               aria-expanded="<?= $arParams['SHOW_FULL_PROPS'] != 'N' ? 'true' : 'false' ?>">
                <span><?= $arParams['TITLE_EMPTY_CHAR_GROUP'] ?></span>
            </a>
        <? endif ?>
        <div
            class="product-description-part-text collapse <?= $arParams['SHOW_FULL_PROPS'] != 'N' ? 'in' : '' ?>"
            id="product-description-part-<?= $groupID ?>">
            <? foreach ($arGroup['PROPS'] as $pid):
                $arProperty = $arResult['DISPLAY_PROPERTIES'][$pid];
                ?>

                <? if ($pid == 'CATALOG_WEIGHT'): ?>
                    <p class="has-icon flaticon-two328">
                        <?= GetMessage('WEIGHT') ?>:
                        <b><?= $arProperty['CATALOG_WEIGHT'] ?> <?= GetMessage('WEIGHT_MESURE') ?></b>
                    </p>
                    <?continue;?>
                <? endif ?>

                <? if ($pid == 'CATALOG_MESURE'):?>
                    <p class="has-icon flaticon-ruler12">
                        <?= GetMessage('SIZE') ?>:
                        <b><?= !empty($arProperty['CATALOG_WIDTH']) ? $arProperty['CATALOG_WIDTH'] . ' �' : '' ?> <?= !empty($arProperty['CATALOG_HEIGHT']) ? $arProperty['CATALOG_HEIGHT'] . ' �' : '' ?> <?= !empty($arProperty['CATALOG_LENGTH']) ? $arProperty['CATALOG_LENGTH'] : '' ?>
                            (<?= GetMessage('SANTIMETR') ?>)</b>
                    </p>
                     <?continue;?>
                 <? endif ?>

                <p><? if (!empty($arProperty['HINT'])):?><span class="property-name"><?endif?><?= $arProperty["NAME"]?>:<? if (!empty($arProperty['HINT'])):?><i class="help-icon" data-tooltip="" data-placement="right" title="" data-original-title="<?= $arProperty['HINT'] ?>"></i><? endif ?><? if (!empty($arProperty['HINT'])):?></span><?endif?>
                <?
                if ($arProperty['PROPERTY_TYPE'] == 'L'):
                    if (is_array($arProperty['DISPLAY_VALUE'])):
                        echo implode($glueTemplate, $arProperty['DISPLAY_VALUE']);
                    else:
                        echo $arProperty['DISPLAY_VALUE'];
                    endif;
                else:
                    if (is_array($arProperty["DISPLAY_VALUE"]) && $arProperty['PROPERTY_TYPE'] != 'F'):
                        if ($arProperty['PROPERTY_TYPE'] == 'E' || $arProperty['PROPERTY_TYPE'] == 'G') {
                            foreach ($arProperty["DISPLAY_VALUE"] as &$p) {
                                if (substr_count($p, "a href") > 0) {
                                    $p = strip_tags($p);
                                }
                            }
                        }
                        echo implode($glueTemplate, $arProperty["DISPLAY_VALUE"]);
                    elseif ($arProperty['PROPERTY_TYPE'] == 'F'):
                        if ($arProperty['MULTIPLE'] == 'Y'):
                            if (is_array($arProperty['DISPLAY_VALUE'])):
                                foreach ($arProperty['DISPLAY_VALUE'] as $n => $value):
                                    echo $n > 0 ? ', ' : '';
                                    echo str_replace('</a>', ' ' . $arProperty['DESCRIPTION'][$n] . '</a>', $value);
                                endforeach;
                            else:
                                echo str_replace('</a>', ' ' . $arProperty['DESCRIPTION'][0] . '</a>', $arProperty['DISPLAY_VALUE']);
                            endif;
                        else:
                            echo str_replace('</a>', ' ' . $arProperty['DESCRIPTION'] . '</a>', $arProperty['DISPLAY_VALUE']);
                        endif;
                    else:
                        //if (substr_count($arProperty["DISPLAY_VALUE"], "a href") > 0) {
                        if ($arProperty['PROPERTY_TYPE'] == 'E' || $arProperty['PROPERTY_TYPE'] == 'G') {
                            $arProperty["DISPLAY_VALUE"] = strip_tags($arProperty["DISPLAY_VALUE"]);
                        }

                        echo $arProperty["DISPLAY_VALUE"];

                        // TODO DESCRIPTION
                        if (false && $arParams['SHOW_PROPERTY_VALUE_DESCRIPTION'] != 'N') {
                            echo ' ', $arProperty['DESCRIPTION'];
                        }
                    endif;
                endif;
                ?>
                </p>
            <? endforeach ?>
        </div>
    </div><!-- .tech-info-block -->
<? endforeach ?>

<?
// echo "<pre style='text-align:left;'>";print_r($arResult);echo "</pre>";
