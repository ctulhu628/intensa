<?
$MESS["FURNITURE_NO_GROUPS_NAME"] = "Основные характеристики товара";
$MESS["WEIGHT"] = " Вес";
$MESS["WEIGHT_MESURE"] = "кг";
$MESS["SIZE"] = "Размер";
$MESS["SANTIMETR"] = "см.";
$MESS["WITHOUT_GROUP"] = "Без группы";
?>