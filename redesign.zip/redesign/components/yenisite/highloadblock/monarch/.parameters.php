<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();

if (!CModule::IncludeModule("highloadblock"))
	return;

use Bitrix\Main\Loader;
 use Bitrix\Highloadblock as HL;

$arProperties = array('-' => GetMessage('CP_BC_TPL_PROP_EMPTY'));

if(!empty($arCurrentValues['BLOCK_ID'])){
	$dbBlock = HL\HighloadBlockTable::getById($arCurrentValues['BLOCK_ID'])->fetch();
	$hlentity = HL\HighloadBlockTable::compileEntity($dbBlock);
	$strEntityDataClass = $hlentity->getDataClass();

	$rsData = $strEntityDataClass::getList(array(
		'select' => array('*'),
		'order' => array('ID' => 'ASC'),
	));
	$arItem = $rsData->Fetch();
	foreach ($arItem as $key => $value){
		$arProperties[$key] = '['.$key.']';
	}
}
$arTemplateParameters = array(
	"PATH_TO_CATALOG" => array(
		"NAME" => GetMessage("RZ_HLB_PATH_TO_CATALOG"),
		"TYPE" => "STRING",
		"MULTIPLE" => "N",
		"DEFAULT" => "/catalog/",
		"COLS" => 25,
		"PARENT" => "URL_TEMPLATES",
	),
	"PROPERTY_FOR_DETAIL" => array(
		"NAME" => GetMessage("PROPERTY_FOR_DETAIL"),
		"TYPE" => "LIST",
		"MULTIPLE" => "Y",
		"VALUES" => $arProperties,
		"DEFAULT" => array('UF_DEF','UF_SORT','UF_LINK'),
	),
	"PROPERTY_FOR_DETAIL_LINK" => array(
		"NAME" => GetMessage("PROPERTY_FOR_DETAIL_LINK"),
		"TYPE" => "LIST",
		"MULTIPLE" => "N",
		"VALUES" => $arProperties,
		"DEFAULT" => 'UF_LINK',
	)
);

if (Loader::includeModule('yenisite.resizer2')) {
	$arResizerSets = array();
	$arSets = CResizer2Set::GetList();
	while ($arr = $arSets->Fetch()) {
		$arResizerSets[$arr["id"]] = "[".$arr["id"]."] ".$arr["NAME"];
	}
	$arTemplateParameters += array(
		"LIST_RESIZER_SET" => array(
			"PARENT" => "RESIZER",
			"NAME" => GetMessage('RZ_HLB_LIST_RESIZER_SET'),
			"TYPE" => "LIST",
			"VALUES" => $arResizerSets,
			"DEFAULT" => 4
		),
		"VIEW_RESIZER_SET" => array(
			"PARENT" => "RESIZER",
			"NAME" => GetMessage('RZ_HLB_VIEW_RESIZER_SET'),
			"TYPE" => "LIST",
			"VALUES" => $arResizerSets,
			"DEFAULT" => 2
		)
	);
}

