<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();

use Bitrix\Main\Localization\Loc;

if (empty($_REQUEST['sort_id'])) {
	$_REQUEST['sort_id'] = $_GET['sort_id'] = 'UF_SORT';
}

if (empty($_REQUEST['sort_type'])) {
	$_REQUEST['sort_type'] = $_GET['sort_type'] = 'ASC';
}
?>

<div class="brand-list-page">
<div class="brand-list-content">
	<div class="row brand-list__filter">
		<div class="col-md-6 col-xs-12">
			<form name="filter_brands" action="" method="GET">
				<div class="input-group brand-search">
					<div class="input-group-addon"><?=GetMessage('ME_NEED')?></div>
						<input name="q" type="text" class="form-control" value="<?=htmlspecialcharsbx($_GET['q'])?>" placeholder="<?=GetMessage('SOME_BRAND')?>">
						<div class="input-group-btn">
							<input value="<?=GetMessage('FILTER')?>" type="submit" class="btn btn-primary"/>
						</div>
				</div>
			</form>
		</div>
	</div>
<?
$APPLICATION->IncludeComponent("bitrix:highloadblock.list", "monarch", Array(
		"BLOCK_ID" => $arParams['BLOCK_ID'],
		"DETAIL_URL" => $arResult['PATH_TO_VIEW'],
		"NAV_TEMPLATE" => $arParams['NAV_TEMPLATE'],
		"RESIZER_SET" => $arParams['LIST_RESIZER_SET'],
	),
	$component
);
?>

</div>
