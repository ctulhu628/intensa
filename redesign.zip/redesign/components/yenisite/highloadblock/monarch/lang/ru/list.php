<?$MESS['ME_NEED'] = 'Мне нужен';
$MESS['SOME_BRAND'] = 'какой-то бренд';
$MESS['FILTER'] = 'Фильтр';