<?
$MESS['RZ_HLB_LIST_RESIZER_SET'] = 'Фото в списке';
$MESS['RZ_HLB_VIEW_RESIZER_SET'] = 'Фото на детальной странице';

$MESS["RZ_HLB_PATH_TO_CATALOG"] = "Путь к каталогу";
$MESS["PROPERTY_FOR_DETAIL"] = "Выберите свойства, которые выводить на детальной странице";
$MESS["PROPERTY_FOR_DETAIL_LINK"] = "Выберите свойство, в котором содержится ссылка на сайт бренда";
$MESS["CP_BC_TPL_PROP_EMPTY"] = "Не выбрано";
