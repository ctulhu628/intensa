<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();
use Bitronic2\Mobile;
use Bitrix\Main\Loader;
use Yenisite\Core\Tools;


// ##### FOR AJAX
// @var $moduleCode
// @var $moduleId
global $arModule;
include $_SERVER['DOCUMENT_ROOT'] . SITE_TEMPLATE_PATH . '/include/module.php';
$arParams['LIST_RESIZER_SET'] = $arParams['LIST_RESIZER_SET'] ? : 3;
$arParams['VIEW_RESIZER_SET'] = $arParams['VIEW_RESIZER_SET'] ? : 2;
$arParams['PROPERTY_FOR_DETAIL'] = $arParams['PROPERTY_FOR_DETAIL'] ? : array('UF_LINK');
$arParams['PROPERTY_FOR_DETAIL_LINK'] = $arParams['PROPERTY_FOR_DETAIL_LINK'] ? : 'UF_LINK';

\Yenisite\Furniture\Main::removeElementsFromArr($arParams['PROPERTY_FOR_DETAIL'], array($arParams['PROPERTY_FOR_DETAIL_LINK'], 'UF_FILE', 'UF_FULL_DESCRIPTION','ID','UF_NAME','UF_FILE','UF_DESCRIPTION'));

if ($bCore = Loader::IncludeModule('yenisite.core')) {
	\Yenisite\Core\Ajax::saveParams($this,
		array_merge($arParams, array('PATH_TO_VIEW' => $arResult['PATH_TO_VIEW'])),
		$addId = ($arParams['CUSTOM_CACHE_KEY'] ?: '')
	);

	$brandsFolder = $arParams['SEF_MODE'] == 'Y' ? $arParams['SEF_FOLDER'] : dirname($_SERVER['SCRIPT_NAME']) . '/';
	$curValue = COption::GetOptionString($arModule['ID'], 'brands_folder', false, SITE_ID);

	if($curValue != $brandsFolder) {
		COption::SetOptionString($arModule['ID'], 'brands_folder', $brandsFolder, false, SITE_ID);
	}
}

if (strtolower($_REQUEST['rz_update_brands_parameters_cache']) === 'y') {
	$APPLICATION->RestartBuffer();
	die('update');
}