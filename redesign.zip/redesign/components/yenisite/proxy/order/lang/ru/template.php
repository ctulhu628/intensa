<?
$MESS['MESSAGE_GET_ORDER'] = 'Укажите номер заказа';
$MESS['MESSAGE_GET_EMAIL'] = 'Укажите ваш email';
$MESS['MESSAGE_BUTTON_CHECK'] = 'Проверить';