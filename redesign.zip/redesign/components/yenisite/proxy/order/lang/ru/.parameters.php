<?
$MESS['IBLOCK_TYPE_ORDERS'] = 'Тип инфоблока заказов (лайт)';
$MESS['IBLOCK_ID_ORDERS'] = 'Инфоблок заказов (лайт)';
$MESS['DATA_LITE_ORDERS'] = 'Настройки лайт';