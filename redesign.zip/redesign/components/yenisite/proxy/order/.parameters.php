<?
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED!==true) die();

use Bitrix\Main\Loader;
use Bitrix\Main\ModuleManager;

if (!Loader::includeModule('iblock'))
	return;
$boolCatalog = Loader::includeModule('catalog');
$arIBlockType = CIBlockParameters::GetIBlockTypes();

$arIBlock=array();
$rsIBlock = CIBlock::GetList(array("sort" => "asc"), array("TYPE" => $arCurrentValues["IBLOCK_TYPE_ORDERS"], "ACTIVE"=>"Y"));
while($arr=$rsIBlock->Fetch())
{
	$arIBlock[$arr["ID"]] = "[".$arr["ID"]."] ".$arr["NAME"];
}

global $arComponentParameters;

$arComponentParameters["GROUPS"]["DATA_LITE_ORDERS"]= array(
	"NAME" => GetMessage("DATA_LITE_ORDERS"),
	"SORT" => 1
);

$arTemplateParameters = array(
	"IBLOCK_TYPE_ORDERS" => array(
		"PARENT" => "DATA_LITE_ORDERS",
		"NAME" => GetMessage("IBLOCK_TYPE_ORDERS"),
		"TYPE" => "LIST",
		"VALUES" => $arIBlockType,
		"DEFAULT" => "yenisite_market",
		"REFRESH" => "Y",
	),
	"IBLOCK_ID_ORDERS" => array(
		"PARENT" => "DATA_LITE_ORDERS",
		"NAME" => GetMessage("IBLOCK_ID_ORDERS"),
		"TYPE" => "LIST",
		"VALUES" => $arIBlock,
	),
);
