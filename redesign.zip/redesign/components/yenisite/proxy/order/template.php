<?
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();
/**
 * @var CMain $APPLICATION
 * @var CUser $USER
 * @var array $arResult
 * @var array $arParams
 * @var CBitrixComponent $component
 */
use Yenisite\Furniture\Main;

if(!empty($arResult['ERROR']['error'])){
?>
	<form action="<?=SITE_DIR?>personal/orders/" method="post" class="footer-subscribe-form">
		<div class="col-sm-8">
		<?	foreach($arResult['ERROR']['messege'] as $messege){ ?>
				<label for="footer-subscribe-input"><?= $messege ?></label>
		<? 	} ?>
		<?	if(isset($_REQUEST['ID']) || isset($_REQUEST['email']))
		foreach($arResult['ERROR']['error'] as $errorMessege){ ?>
				<? Main::ShowMessage($errorMessege, Main::MSG_TYPE_ERROR, false) ?>
		<? 	} ?>
		</div>
		<div class="col-sm-8">
			<label class="form-group">
				<span class="label-text">
					<?= GetMessage('MESSAGE_GET_ORDER' )?>
				</span>
				<input type="text" class="form-control" name="ID" placeholder="<?= GetMessage('MESSAGE_GET_ORDER' )?>" value="<?= $_REQUEST['ID']?$_REQUEST['ID']:"" ?>">					
			</label>
			<label class="form-group">
				<span class="label-text">
					<?= GetMessage('MESSAGE_GET_EMAIL' )?>
				</span>
				<input type="text" class="form-control" id="footer-subscribe-input" name="email" placeholder="<?= GetMessage('MESSAGE_GET_EMAIL' )?>" value="<?= $_REQUEST['email']?$_REQUEST['email']:"" ?>">
			</label>
			<label class="form-group">
				<span class="label-text">
				</span>
				<button class="btn-main btn-primary btn-checkout"><?= GetMessage('MESSAGE_BUTTON_CHECK' )?></button>
			</label>
		</div>
	</form>
<?	
}else{
	$APPLICATION->IncludeComponent(
		"bitrix:news.detail", 
		"order", 
		array(
			"IBLOCK_TYPE" => $arParams['IBLOCK_TYPE_ORDERS'],
			"IBLOCK_ID" => $arParams['IBLOCK_ID_ORDERS'],
			"ELEMENT_ID" => $_REQUEST['ID'],
			"ELEMENT_CODE" => "",
			"CHECK_DATES" => "Y",
			"FIELD_CODE" => array(
				0 => "DATE_CREATE",
				1 => "CREATED_BY",
				2 => "",
			),
			"PROPERTY_CODE" => array(
				0 => "FIO",
				1 => "EMAIL",
				2 => "PHONE",
				3 => "ABOUT",
				4 => "PAYMENT_E",
				5 => "DELIVERY_E",
				6 => "",
			),
			"IBLOCK_URL" => SITE_DIR."personal/",
			"AJAX_MODE" => "N",
			"AJAX_OPTION_JUMP" => "N",
			"AJAX_OPTION_STYLE" => "Y",
			"AJAX_OPTION_HISTORY" => "N",
			"CACHE_TYPE" => "N",
			"CACHE_TIME" => "36000000",
			"CACHE_GROUPS" => "Y",
			"SET_TITLE" => "N",
			"SET_BROWSER_TITLE" => "Y",
			"BROWSER_TITLE" => "-",
			"SET_META_KEYWORDS" => "Y",
			"META_KEYWORDS" => "-",
			"SET_META_DESCRIPTION" => "Y",
			"META_DESCRIPTION" => "-",
			"SET_STATUS_404" => "N",
			"INCLUDE_IBLOCK_INTO_CHAIN" => "Y",
			"ADD_SECTIONS_CHAIN" => "Y",
			"ADD_ELEMENT_CHAIN" => "N",
			"ACTIVE_DATE_FORMAT" => "d.m.Y",
			"USE_PERMISSIONS" => "N",
			"PAGER_TEMPLATE" => ".default",
			"DISPLAY_TOP_PAGER" => "N",
			"DISPLAY_BOTTOM_PAGER" => "Y",
			"PAGER_TITLE" => "вЂ?С‚СЂР°РЅРёС†Р°",
			"PAGER_SHOW_ALL" => "Y",
			"DISPLAY_DATE" => "Y",
			"DISPLAY_NAME" => "Y",
			"DISPLAY_PICTURE" => "Y",
			"DISPLAY_PREVIEW_TEXT" => "Y",
			"USE_SHARE" => "N",
			"AJAX_OPTION_ADDITIONAL" => "",
			"RESIZER_BASKET_PHOTO" => "11",
			"COMPONENT_TEMPLATE" => "order",
			"DETAIL_URL" => "",
			"SET_CANONICAL_URL" => "N",
			"SET_LAST_MODIFIED" => "N",
			"PAGER_BASE_LINK_ENABLE" => "N",
			"SHOW_404" => "N",
			"MESSAGE_404" => ""
		),
		false
	);
}