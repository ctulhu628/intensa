<?if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();
use \Yenisite\Core\Ajax;
use \Yenisite\Core\Tools;

$arSectionParams = Ajax::getParams('bitrix:catalog','bitrix_catalog','',SITE_ID);
if (!empty($arResult['CHEAP_ELEMENTS']['IDS'] )) {
    $arSectionParams = \Yenisite\Stroymag\Main::setFilterOnSection($arSectionParams,'ID',$arResult['CHEAP_ELEMENTS']['IDS']);
}
$arSectionParams['SUBSC_ELEMENTS'] = $arResult['CHEAP_ELEMENTS']['ELEMENTS'];
$arSectionParams['SHOW_PARAMS'] = $arParams['FOUND_CHEAP_PROPRS'];
$arSectionParams['SHOW_PARAMS_IN_CONTACTS'] = $arParams['FOUND_CHEAP_PROPRS_FOR_CONTACTS'];
$arSectionParams['SUBSC_PRICE'] = $arParams['FOUND_CHEAP_PRICE_PROPR'];
$arSectionParams['SUBSC_ADDRES'] = $arParams['FOUND_CHEAP_ADDRESS_PROPR'];
$arSectionParams['RESIZER_IMAGE'] = $arParams['RESIZER_IMAGE_PERSONAL'] ? : $arSectionParams['RESIZER_IMAGE'];
$arSectionParams['DATA_SECTION'] = 'CHEAP_SECTION';
?>

<div class="section">
    <h2 class="collapsed" data-toggle="collapse" data-target="#found-cheap">
        <?=$arParams['FOUND_CHEAP_HEADER']?>   <span class="caret"></span>
    </h2>
    <div class="collapse" id="found-cheap">
        <div class="account-section-content">
            <div class="account-section-description">
             <?Tools::IncludeArea('personal','cheap-description',array(),false)?>
            </div>
            <?if(!empty($arSectionParams['SUBSC_ELEMENTS'])):?>
                <? $APPLICATION->IncludeComponent(
                    'bitrix:catalog.section',
                    'table_view',
                    $arSectionParams,
                    $component,
                    array("HIDE_ICONS" => 'Y')
                ); ?>
            <?else:?>
                <div class="h3"><?=$arParams['EMPTY_SUBSCRIPTION_MESS'] ? :GetMessage('RZ_EMPTY_ITEMS')?></div>
            <?endif?>
        </div>
    </div>
</div>
<?
if (!empty($arResult['LOWER_ELEMENTS'] )){
    $arSectionParams = \Yenisite\Stroymag\Main::setFilterOnSection($arSectionParams,'ID',$arResult['LOWER_ELEMENTS']['IDS']);
}
$arSectionParams['DATA_SECTION'] = 'LOWER_PRICE_SECTION';
$arSectionParams['SUBSC_ELEMENTS'] = $arResult['LOWER_ELEMENTS']['ELEMENTS'];
$arSectionParams['SHOW_PARAMS'] = $arParams['LOWER_PRICE_PROPS'];
$arSectionParams['SHOW_PARAMS_IN_CONTACTS'] = $arParams['LOWER_PRICE_PROPRS_FOR_CONTACTS'];
$arSectionParams['SUBSC_PRICE'] = $arParams['LOWER_PRICE_PRICE_PROPR'];
$arSectionParams['SUBSC_ADDRES'] = '';
?>
<div class="section">
    <h2 class="open-personal-collaps collapsed" data-toggle="collapse" data-target="#low-price">
        <?=$arParams['LOWER_PRICE_HEADER']?> <span class="caret"></span>
    </h2>
    <div class="collapse" id="low-price">
        <div class="account-section-content">
            <div class="account-section-description">
                <?Tools::IncludeArea('personal','lower-price',array(),false)?>
            </div>
            <?if(!empty($arSectionParams['SUBSC_ELEMENTS'])):?>
                <? $APPLICATION->IncludeComponent(
                    'bitrix:catalog.section',
                    'table_view',
                    $arSectionParams,
                    $component,
                    array("HIDE_ICONS" => 'Y')
                ); ?>
            <?else:?>
                <div class="h3"><?=$arParams['EMPTY_SUBSCRIPTION_MESS'] ? :GetMessage('RZ_EMPTY_ITEMS')?></div>
            <?endif?>
        </div>
    </div>
</div>