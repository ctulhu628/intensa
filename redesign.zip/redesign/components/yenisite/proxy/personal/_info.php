<?if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();
 $APPLICATION->IncludeComponent(
    "bitrix:main.profile",
    "personal",
    array(
        "AJAX_MODE" => "N",
        "AJAX_OPTION_JUMP" => "N",
        "AJAX_OPTION_STYLE" => "N",
        "AJAX_OPTION_HISTORY" => "N",
        "SET_TITLE" => "N",
        "USER_PROPERTY" => array(),
        "SEND_INFO" => "N",
        "CHECK_RIGHTS" => "N",
        "AJAX_OPTION_ADDITIONAL" => "",
        "AJAX_ID" => "personal",
        "PARAMS" => array(
            0 => "NAME",
            1 => "LAST_NAME",
            2 => "PERSONAL_PHONE",
            3 => "PERSONAL_PHOTO",
        ),
    ),
    false) ?>