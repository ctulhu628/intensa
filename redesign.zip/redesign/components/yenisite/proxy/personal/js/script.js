$(function($){

    var $body = $(document.body);
    $body.off('click', '.sale-acountpay-fixedpay-item').on('click', '.sale-acountpay-fixedpay-item', function(){
        var $block = $(this).closest('.sale-acountpay-fixedpay-list');
        if ( $block.find('.sale-acountpay-fixedpay-item.active').length === 0 ) {
            $(this).addClass('active');
        } else {
            if ( !$(this).hasClass('active') ) {
                $block.find('.sale-acountpay-fixedpay-item.active').removeClass('active');
                $(this).addClass('active');
            }
        }
    });

    $body.on('update_favorite', function (e) {
        var $favSlider = $('#favorite_slider'),
            data = {ajax: $favSlider.data('ajax')};
        if (!$favSlider.length) return;
        $favSlider.startAjax();
        $.ajax({
            url: AJAX_DIR + 'main.php',
            data: data,
            success: function (msg) {
                $favSlider.html(msg);
                $favSlider.refreshForm();
                $favSlider.updateFavCompare();
                initHSly($favSlider.find('.item-frame'));
                var $alert = $favSlider.find('.alert');
                if ($alert.length) {
                    $alert.css('width', '100%');
                }
                initLazy();
                $favSlider.stopAjax();
            }
        })
    });

});