<?if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();
if (!$USER->IsAuthorized()) {
    $APPLICATION->IncludeComponent('bitrix:system.auth.form', '');
}else{
    $APPLICATION->IncludeComponent(
        "bitrix:main.profile",
        "personal",
        array(
            "AJAX_MODE" => "N",
            "AJAX_OPTION_JUMP" => "N",
            "AJAX_OPTION_STYLE" => "N",
            "AJAX_OPTION_HISTORY" => "N",
            "SET_TITLE" => "N",
            "USER_PROPERTY" => array(),
            "SEND_INFO" => "N",
            "CHECK_RIGHTS" => "N",
            "AJAX_OPTION_ADDITIONAL" => "",
            "AJAX_ID" => "reg_info",
            "PARAMS" => array(
                0 => "EMAIL",
                1 => "NEW_PASSWORD",
                2 => "NEW_PASSWORD_CONFIRM",
                3 => "",
            ),
        ),
        false);
}