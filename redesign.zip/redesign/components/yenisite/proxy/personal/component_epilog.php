<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
$Asset = \Bitrix\Main\Page\Asset::getInstance();
$Asset->addJs(SITE_TEMPLATE_PATH . '/js/vendor/sly.min.js');
$Asset->addJs(SITE_TEMPLATE_PATH . '/js/inits/initSly.js');
$Asset->addJs($templateFolder . '/js/script.js');
$Asset->addJs($templateFolder . '/js/scriptWelvelt.min.js');
$Asset->addCss($templateFolder . '/css/styleWilvet.css');
$Asset->addCss($templateFolder . '/css/styleBudget.css');
