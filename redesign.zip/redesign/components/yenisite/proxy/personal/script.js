/*(function(){
	var $hash = window.location.hash,
		$account = $('#account-page-row'),
		$wrap = $('.account-main-wrap'),
		$tabs = $('.account-menu-wrap').find('.account-menu-link');

	function loadTabs() {
		if ($hash !== '') {
			if ( $account.find('div.tab-pane' + $hash).length ) { // hash indicates a tab
				changeTab($hash);
			} else { // hash indicates a div or header in tab
				if ( $account.find('div' + $hash).length || $account.find('h2' + $hash).length ) {
					var hashTab, showCollapse;

					if ( $account.find('div' + $hash).length ) {
						hashTab = $account.find('div' + $hash).closest('.tab-pane').attr('id');
						showCollapse = $hash;
					} else if ( $account.find('h2' + $hash).length ) {
						hashTab = $account.find('h2' + $hash).closest('.tab-pane').attr('id');
						showCollapse = $('#' + hashTab).find('h2' + $hash).attr('data-target');
					}

					changeTab('#' + hashTab);

					$('#' + hashTab).find('.section > .collapse').each(function() {
						if ( ('#' + $(this).attr('id')) !== showCollapse )
							$(this).collapse('hide');
						else
							$(this).collapse('show');
					});
				}
			}
		}
	}

	function changeTab(tab) {
		$tabs.each(function() {
			if ( $(this).attr('href') === tab ) {
				$(this).tab('show');
				return;
			}
		});
	}

	$(window).load(loadTabs);

	$('#account__lowering').on('shown.bs.collapse', function(){
		$(this).find('.catalog-item-thumbs-wrap').initCatalogThumbs();
		$(this).find('.carousel-frame').sly('reload');
	});
})();*/