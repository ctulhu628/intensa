<?if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();
if (empty($arParams['YENISITE_FAVORITE_LIST'])) {
    $arParams['YENISITE_FAVORITE_LIST'] = array();
}
$arParams['YENISITE_FAVORITE_LIST']['CACHE_TIME'] = 0;
$arParams['YENISITE_FAVORITE_LIST']['CACHE_TYPE'] = 'N';
$arPars = $arParams['YENISITE_FAVORITE_LIST'] + array('CATALOG_TEMPLATE' => 'favorite-slider') + array('SHOW_CATCH_BUY' => $rz_options['section_catch_buy'] != 'N');
$arPars['SHOW_THUMB'] = $rz_options['show_thumb_on_favorite'] !== 'N';
$arPars['SHOW_ARTICLE'] = $rz_options['show_article'] !== 'N';
?>
<? $APPLICATION->IncludeComponent("yenisite:favorite.list", ".default", $arPars,
    $component,
    array('HIDE_ICONS' => true)
); ?>