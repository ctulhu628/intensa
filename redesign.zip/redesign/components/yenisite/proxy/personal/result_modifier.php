<? use Yenisite\Furniture\Paidadd;

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
global $USER;
$arNewParams = array();
foreach ($arParams as $key => $param) {
	if (strpos($key, '___') !== false) {
		$ar = explode('___', $key);

		$arNewParams[$ar[0]][$ar[1]] = $param;
	} else {
		$arNewParams[$key] = $param;
	}
}
$arParams = $arNewParams;
$arParams['RESIZER_ICONS'] = $arParams['RESIZER_ICONS'] ? : 6;
$arParams['ON_AJAX'] = $arParams['ON_AJAX'] != 'N' ? true : false;
$arParams['USE_COMBINE_MOD'] = $arParams['USE_COMBINE_MOD'] != 'N' ? true : false;
$arParams['USE_SELF_LINK'] = $arParams['USE_SELF_LINK'] != 'N' ? true : false;

$arParams['ACTION_OF_HREF'] = $arParams['ACTION_OF_HREF'] ? : 'TAB_ID';
$arResult['ITEMS'] = array();
$arResult['ITEMS'] = array(
		'personal_section' => array(
			'NAME' => $arParams['NAME_PERSONAL_SECTION'] ? :GetMessage('RZ_TITLE_PERSONAL'),
			'HREF' => $arParams['HREF_PERSONAL_SECTION'] ? : '?'.$arParams['ACTION_OF_HREF'].'=personal_section',
			'DATA_HREF' => $arParams['USE_SELF_LINK'] && $arParams['HREF_PERSONAL_SECTION'] ? $arParams['HREF_PERSONAL_SECTION']  :'personal_section#',
			'IMG' => $arParams['IMG_PERSONAL_SECTION'],
			'SVG' => $arParams['SVG_PERSONAL_SECTION'] ? :'#home',
			'DESCRIPTION' => $arParams['DESCRIPTION_PERSONAL_SECTION'] ? : GetMessage('DEF_DESCRIPTION'),
			'CLASS' => 'account-personal-panel',
		),
		'current_orders' => array(
			'NAME' => $arParams['NAME_CURRENT_ORDERS'] ? :GetMessage('RZ_TITLE_CURRENT_ORDERS'),
			'HREF' => $arParams['HREF_CURRENT_ORDERS'] ? :'?'.$arParams['ACTION_OF_HREF'].'=current_orders',
			'DATA_HREF' => $arParams['USE_SELF_LINK'] && $arParams['HREF_CURRENT_ORDERS'] ? $arParams['HREF_CURRENT_ORDERS'] :'current_orders#',
			'IMG' => $arParams['IMG_CURRENT_ORDERS'],
			'SVG' => $arParams['SVG_CURRENT_ORDERS'] ? :'#interface',
			'DESCRIPTION' => $arParams['DESCRIPTION_CURRENT_ORDERS'] ? : GetMessage('DEF_DESCRIPTION'),
			'CLASS' => 'account-personal-order-list',
		),
		'personal_count' => array(
			'NAME' => $arParams['NAME_PERSONAL_COUNT'] ? :GetMessage('RZ_TITLE_PERSONAL_COUNT'),
			'HREF' => $arParams['HREF_PERSONAL_COUNT'] ? :'?'.$arParams['ACTION_OF_HREF'].'=personal_count',
			'DATA_HREF' => $arParams['USE_SELF_LINK'] && $arParams['HREF_PERSONAL_COUNT'] ? $arParams['HREF_PERSONAL_COUNT'] :'personal_count#',
			'IMG' => $arParams['IMG_PERSONAL_COUNT'],
			'SVG' => $arParams['SVG_PERSONAL_COUNT'] ? :'#tool',
			'DESCRIPTION' => $arParams['DESCRIPTION_PERSONAL_COUNT'] ? : GetMessage('DEF_DESCRIPTION'),
			'CLASS' => 'account-personal-money',
		),
		'info' => array(
			'NAME' => $arParams['NAME_INFO'] ? :GetMessage('RZ_TITLE_INFO'),
			'HREF' => $arParams['HREF_INFO'] ? :'?'.$arParams['ACTION_OF_HREF'].'=info',
			'DATA_HREF' => $arParams['USE_SELF_LINK'] && $arParams['HREF_INFO'] ? $arParams['HREF_INFO'] :'info#',
			'IMG' => $arParams['IMG_INFO'],
			'SVG' => $arParams['SVG_INFO'] ? :'#user-card',
			'DESCRIPTION' => $arParams['DESCRIPTION_INFO'] ? : GetMessage('DEF_DESCRIPTION')
		),
		'reg' => array(
			'NAME' => $arParams['NAME_REG'] ? :GetMessage('RZ_TITLE_REG'),
			'HREF' => $arParams['HREF_REG'] ? :'?'.$arParams['ACTION_OF_HREF'].'=reg',
			'DATA_HREF' => $arParams['USE_SELF_LINK'] && $arParams['HREF_REG'] ? $arParams['HREF_REG'] :'reg#',
			'IMG' => $arParams['IMG_REG'],
			'SVG' => $arParams['SVG_REG'] ? :'#user-card',
			'DESCRIPTION' => $arParams['DESCRIPTION_REG'] ? : GetMessage('DEF_DESCRIPTION')
		),
		'history' =>  array(
			'NAME' => $arParams['NAME_HISTORY'] ? :GetMessage('RZ_TITLE_HISTORY'),
			'HREF' => $arParams['HREF_HISTORY'] ? :'?'.$arParams['ACTION_OF_HREF'].'=history',
			'DATA_HREF' => $arParams['USE_SELF_LINK'] && $arParams['HREF_HISTORY'] ? $arParams['HREF_HISTORY'] :'history#',
			'IMG' => $arParams['IMG_HISTORY'],
			'SVG' => $arParams['SVG_HISTORY'] ? :'#list-on-window',
			'DESCRIPTION' => $arParams['DESCRIPTION_HISTORY'] ? : GetMessage('DEF_DESCRIPTION'),
			'CLASS' => 'account-personal-order-list',
		),
		/*'subscription' => array(
			'NAME' => $arParams['NAME_SUBSCRIPTION'] ? :GetMessage('RZ_TITLE_SUBSCRIPTION'),
			'HREF' => $arParams['HREF_SUBSCRIPTION'] ? :'?'.$arParams['ACTION_OF_HREF'].'=subscription',
			'DATA_HREF' => $arParams['USE_SELF_LINK'] && $arParams['HREF_SUBSCRIPTION'] ?  $arParams['HREF_SUBSCRIPTION'] :'subscription#',
			'IMG' => $arParams['IMG_SUBSCRIPTION'],
			'SVG' => $arParams['SVG_SUBSCRIPTION'] ? :'#megaphone',
			'DESCRIPTION' => $arParams['DESCRIPTION_SUBSCRIPTION'] ? : GetMessage('DEF_DESCRIPTION')
		),
		'delivery' => array(
			'NAME' => $arParams['NAME_DELIVERY'] ? :GetMessage('RZ_TITLE_PERSONAL_DELIVERY'),
			'HREF' => $arParams['HREF_DELIVERY'] ? : SITE_DIR.'personal/subscribe/',
			'DATA_HREF' => $arParams['USE_SELF_LINK'] && $arParams['HREF_DELIVERY'] ? $arParams['HREF_DELIVERY'] : SITE_DIR.'personal/subscribe/',
			'IMG' => $arParams['IMG_DELIVERY'],
			'SVG' => $arParams['SVG_DELIVERY'] ? :'#messege',
			'DESCRIPTION' => $arParams['DESCRIPTION_DELIVERY'] ? : GetMessage('DEF_DESCRIPTION')
		),*/
		'favorite' => array(
			'NAME' => $arParams['NAME_FAVORITE'] ? :GetMessage('RZ_TITLE_FAVORITE'),
			'HREF' => $arParams['HREF_FAVORITE'] ? :'?'.$arParams['ACTION_OF_HREF'].'=favorite',
			'DATA_HREF' => $arParams['USE_SELF_LINK'] && $arParams['HREF_FAVORITE'] ? $arParams['HREF_FAVORITE'] :'favorite#',
			'IMG' => $arParams['IMG_FAVORITE'],
			'SVG' => $arParams['SVG_FAVORITE'] ? :'#heart',
			'DESCRIPTION' => $arParams['DESCRIPTION_FAVORITE'] ? : GetMessage('DEF_DESCRIPTION')
		),
		'basket' => array(
			'NAME' => $arParams['NAME_BASKET'] ? :GetMessage('RZ_TITLE_PERSONAL_CART'),
			'HREF' => $arParams['HREF_BASKET'] ? : SITE_DIR.'personal/cart/',
			'DATA_HREF' => $arParams['USE_SELF_LINK'] && $arParams['HREF_BASKET'] ? $arParams['HREF_BASKET'] : SITE_DIR.'personal/cart/',
			'IMG' => $arParams['IMG_BASKET'],
			'SVG' => $arParams['SVG_BASKET'] ? :'#cart-add',
			'DESCRIPTION' => $arParams['DESCRIPTION_BASKET'] ? : GetMessage('DEF_DESCRIPTION')
		),
		'compare' => array(
			'NAME' => $arParams['NAME_COMPARE'] ? :GetMessage('RZ_TITLE_PERSONAL_COMPARE'),
			'HREF' => $arParams['HREF_COMPARE'] ? : SITE_DIR.'catalog/compare/',
			'DATA_HREF' => $arParams['USE_SELF_LINK'] && $arParams['HREF_COMPARE'] ? $arParams['HREF_COMPARE'] : SITE_DIR.'catalog/compare/',
			'IMG' => $arParams['IMG_COMPARE'],
			'SVG' => $arParams['SVG_COMPARE'] ? :'#compare',
			'DESCRIPTION' => $arParams['DESCRIPTION_COMPARE'] ? : GetMessage('DEF_DESCRIPTION')
		),
		'contacts' => array(
			'NAME' => $arParams['NAME_CONTACTS'] ? :GetMessage('RZ_TITLE_PERSONAL_CONTACTS'),
			'HREF' => $arParams['HREF_CONTACTS'] ? : SITE_DIR.'about/contacts/',
			'DATA_HREF' => $arParams['USE_SELF_LINK'] && $arParams['HREF_CONTACTS'] ? $arParams['HREF_CONTACTS'] : SITE_DIR.'about/contacts/',
			'IMG' => $arParams['IMG_CONTACTS'],
			'SVG' => $arParams['SVG_CONTACTS'] ? :'#contacts-shop',
			'DESCRIPTION' => $arParams['DESCRIPTION_CONTACTS'] ? : GetMessage('DEF_DESCRIPTION')
		),
		'logout' => array(
			'NAME' => $arParams['NAME_LOGOUT'] ? :GetMessage('RZ_TITLE_PERSONAL_LOGOUT'),
			'HREF' => $arParams['HREF_LOGOUT'] ? : '?logout=yes',
			'DATA_HREF' => $arParams['USE_SELF_LINK'] && $arParams['HREF_LOGOUT'] ? $arParams['HREF_LOGOUT'] : SITE_DIR,
			'IMG' => $arParams['IMG_LOGOUT'],
			'SVG' => $arParams['SVG_LOGOUT'] ? :'#exit',
		),
	);

$arParams['ON_AJAX'] = $arParams['ON_AJAX'] ? 'Y' : 'N';
$arParams['USE_COMBINE_MOD'] = $arParams['USE_COMBINE_MOD'] ? 'Y' : 'N';
$arParams['USE_SELF_LINK'] = $arParams['USE_SELF_LINK'] ? 'Y' : 'N';

$arParams['SHOW_ITEMS_OF_MENU'] = $arParams['SHOW_ITEMS_OF_MENU'] ? : array('PERSONAL_SECTION','CURRENT_ORDERS','PERSONAL_COUNT','INFO','REG','HISTORY'/*'SUBSCRIPTION','DELIVERY'*/,'FAVORITE','BASKET','COMPARE','CONTACTS','LOGOUT');

$arShowMenu = array();
foreach($arParams['SHOW_ITEMS_OF_MENU'] as $itemMenu){
	$smallItemMenu = strtolower($itemMenu);
	$arShowMenu[$smallItemMenu] = $arResult['ITEMS'][$smallItemMenu];
}
$arResult['ITEMS'] = $arShowMenu;
if (!$USER->isAuthorized()){
	unset($arResult['ITEMS']['current_orders']);
	unset($arResult['ITEMS']['personal_count']);
	unset($arResult['ITEMS']['info']);
	unset($arResult['ITEMS']['history']);
	unset($arResult['ITEMS']['subscription']);
	unset($arResult['ITEMS']['delivery']);
	unset($arResult['ITEMS']['logout']);
}
if(\Bitrix\Main\Loader::includeModule('yenisite.furniturelite')){
	unset($arResult['ITEMS']['current_orders']);
	unset($arResult['ITEMS']['personal_count']);
	unset($arResult['ITEMS']['subscription']);
}

/*
$arParams['FOUND_CHEAP_PROPRS'] = $arParams['FOUND_CHEAP_PROPRS'] ? : array("PRODUCT", "URL","PRICE");
$arParams['FOUND_CHEAP_PROPRS'] = $arParams['FOUND_CHEAP_PROPRS'] == '-' ? array("PRODUCT", "URL","PRICE") : $arParams['FOUND_CHEAP_PROPRS'];
$arParams['FOUND_CHEAP_PROPRS_FOR_CONTACTS'] = $arParams['FOUND_CHEAP_PROPRS_FOR_CONTACTS'] ? : array("EMAIL", "PHONE","FIO");
$arParams['FOUND_CHEAP_PROPRS_FOR_CONTACTS'] = $arParams['FOUND_CHEAP_PROPRS_FOR_CONTACTS'] == '-' ? array("EMAIL", "PHONE","FIO") : $arParams['FOUND_CHEAP_PROPRS_FOR_CONTACTS'];
$arParams['FOUND_CHEAP_RELATIVE_PROPR'] = $arParams['FOUND_CHEAP_RELATIVE_PROPR'] ? : "PRODUCT";
$arParams['FOUND_CHEAP_RELATIVE_PROPR'] = $arParams['FOUND_CHEAP_RELATIVE_PROPR'] == '-' ? "PRODUCT" : $arParams['FOUND_CHEAP_RELATIVE_PROPR'];
$arParams['LOWER_PRICE_RELATIVE_PROPR'] = $arParams['LOWER_PRICE_RELATIVE_PROPR']  ? : "PRODUCT";
$arParams['LOWER_PRICE_RELATIVE_PROPR'] = $arParams['LOWER_PRICE_RELATIVE_PROPR'] == '-' ? "PRODUCT" :  $arParams['LOWER_PRICE_RELATIVE_PROPR'];
$arParams['FOUND_CHEAP_PRICE_PROPR'] = $arParams['FOUND_CHEAP_PRICE_PROPR'] ? : "PRICE_OTHER";
$arParams['FOUND_CHEAP_PRICE_PROPR'] = $arParams['FOUND_CHEAP_PRICE_PROPR'] == '-' ? "PRICE_OTHER" : $arParams['FOUND_CHEAP_PRICE_PROPR'];
$arParams['FOUND_CHEAP_ADDRESS_PROPR'] = $arParams['FOUND_CHEAP_ADDRESS_PROPR'] ? : "URL";
$arParams['FOUND_CHEAP_ADDRESS_PROPR'] = $arParams['FOUND_CHEAP_ADDRESS_PROPR'] = '-' ? "URL" : $arParams['FOUND_CHEAP_ADDRESS_PROPR'];
*/

$arResult['CURRENCY_BALANCE'] = Paidadd::getInfoBalance();
$arParams['DEF_PAYMENTS'] = $arParams['DEF_PAYMENTS'] ? :'100,200,500,1000,5000';
$arParams['BITRIX_SALE_ACCOUNT_PAY']['PATH_TO_BASKET'] = $arParams['BITRIX_SALE_ACCOUNT_PAY']['PATH_TO_BASKET'] ? : SITE_DIR.'personal/cart/';
$arParams['BITRIX_SALE_ACCOUNT_PAY']['PATH_TO_PAYMENT'] = $arParams['BITRIX_SALE_ACCOUNT_PAY']['PATH_TO_BASKET'] ? : SITE_DIR.'personal/payment/';

/*
$delEl = array_search($arParams['FOUND_CHEAP_RELATIVE_PROPR'],$arParams['FOUND_CHEAP_PROPRS']);
if(!empty($delEl)) unset($arParams['FOUND_CHEAP_PROPRS'][$delEl]);

$delEl = array_search($arParams['FOUND_CHEAP_PRICE_PROPR'],$arParams['FOUND_CHEAP_PROPRS']);
if(!empty($delEl)) unset($arParams['FOUND_CHEAP_PROPRS'][$delEl]);

$delEl = array_search($arParams['FOUND_CHEAP_ADDRESS_PROPR'],$arParams['FOUND_CHEAP_PROPRS']);
if(!empty($delEl)) unset($arParams['FOUND_CHEAP_PROPRS'][$delEl]);

$delEl = array_search($arParams['LOWER_PRICE_RELATIVE_PROPR'],$arParams['LOWER_PRICE_PROPS']);
if(!empty($delEl)) unset($arParams['LOWER_PRICE_PROPS'][$delEl]);

$delEl = array_search($arParams['LOWER_PRICE_PRICE_PROPR'],$arParams['LOWER_PRICE_PROPS']);
if(!empty($delEl)) unset($arParams['LOWER_PRICE_PROPS'][$delEl]);

unset($arParams['LOWER_PRICE_PROPS'][array_search($arParams['LOWER_PRICE_PRICE_PROPR'],$arParams['LOWER_PRICE_PROPS'])]);

$arParams['FOUND_CHEAP_PROPRS'] = array_diff($arParams['FOUND_CHEAP_PROPRS'],$arParams['FOUND_CHEAP_PROPRS_FOR_CONTACTS']);
$arParams['LOWER_PRICE_PROPS'] = array_diff($arParams['LOWER_PRICE_PROPS'], $arParams['LOWER_PRICE_PROPRS_FOR_CONTACTS']);


$arResult['CHEAP_ELEMENTS'] = \Yenisite\Furniture\Main::getElementsForSubscribe($arParams['FOUND_CHEAP_RELATIVE_PROPR'], $arParams['IBLOCK_FOUND_CHEAP']);
$arResult['LOWER_ELEMENTS'] = \Yenisite\Furniture\Main::getElementsForSubscribe($arParams['LOWER_PRICE_RELATIVE_PROPR'], $arParams['IBLOCK_LOWER_PRICE']);


$arParams['LOWER_PRICE_HEADER'] = $arParams['LOWER_PRICE_HEADER'] ? : GetMessage('DEF_LOWER_PRICE_HEADER');
$arParams['FOUND_CHEAP_HEADER'] = $arParams['FOUND_CHEAP_HEADER'] ? : GetMessage('DEF_FOUND_CHEAP_HEADER');
*/