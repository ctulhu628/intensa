<?if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();
use Bitrix\Main\Loader;
$arParams['DEF_PAYMENTS'] = array('100','200','500','1000','5000');
if($arParams['SHOW_WALVELT'] != 'N'):?>
<div class="account-section-content personal-walvelt">
    <div class="bx-content">
    <?$APPLICATION->IncludeComponent("bitrix:sale.personal.account","",Array(
            "SET_TITLE" => "N"
        )
    );?>
    </div>
</div>
<?endif;
$APPLICATION->IncludeComponent("bitrix:sale.account.pay", "", array(
    "VAR" => "BuyMoney",
    "ELIMINATED_PAY_SYSTEMS" => $arParams['BITRIX_SALE_ACCOUNT_PAY']['ELIMINATED_PAY_SYSTEMS'] ? :array("0"),
    "PATH_TO_BASKET" => $arParams['BITRIX_SALE_ACCOUNT_PAY']['PATH_TO_BASKET'],
    "PATH_TO_PAYMENT" => $arParams['BITRIX_SALE_ACCOUNT_PAY']['PATH_TO_PAYMENT'],
    "PERSON_TYPE" => $arParams['BITRIX_SALE_ACCOUNT_PAY']['PERSON_TYPE'] ? : "1",
    "REFRESHED_COMPONENT_MODE" => $arParams['BITRIX_SALE_ACCOUNT_PAY']['REFRESHED_COMPONENT_MODE'] ? : "Y",
    "SELL_CURRENCY" => $arParams['BITRIX_SALE_ACCOUNT_PAY']['SELL_CURRENCY'] ? : $arResult['CURRENCY_BALANCE']['CURRENCY'],
    "SELL_SHOW_FIXED_VALUES" => $arParams['BITRIX_SALE_ACCOUNT_PAY']['SELL_SHOW_FIXED_VALUES'] ? : "Y",
    "SELL_TOTAL" => $arParams['BITRIX_SALE_ACCOUNT_PAY']['SELL_TOTAL'] ? : $arParams['DEF_PAYMENTS'],
    "SELL_USER_INPUT" => $arParams['BITRIX_SALE_ACCOUNT_PAY']['SELL_USER_INPUT'] ? : "Y",
    "SELL_VALUES_FROM_VAR" => $arParams['BITRIX_SALE_ACCOUNT_PAY']['SELL_VALUES_FROM_VAR'] ? : "N",
    "SET_TITLE" => $arParams['BITRIX_SALE_ACCOUNT_PAY']['SET_TITLE'] ? : "Y",
    "SELL_SHOW_RESULT_SUM" => $arParams['BITRIX_SALE_ACCOUNT_PAY']['SELL_SHOW_RESULT_SUM'] ? : "Y",
    "SHOW_ACCOUNT_COMPONENT" => $arParams['BITRIX_SALE_ACCOUNT_PAY']['SHOW_ACCOUNT_COMPONENT'] ? : "Y",
    "SHOW_ACCOUNT_PAY_COMPONENT" => $arParams['BITRIX_SALE_ACCOUNT_PAY']['SHOW_ACCOUNT_PAY_COMPONENT'] ? : "Y",
),
    $component,
    array("HIDE_ICONS"=>"Y")
);
