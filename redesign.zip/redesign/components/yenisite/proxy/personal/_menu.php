<?use Yenisite\Stroymag\Main;
global $USER;?>
<section id="profile-scrollspy" class="clearfix">
	<ul  class="profile-scrollspy nav nav-tabs" data-bottom="#account-page-row" id="account-menu-list">
		<? foreach ($arResult['ITEMS'] as $key => $arItem): ?>
			<li class="profile-scrollspy__item  <? if ($id == $key):?>active<? endif ?>">
				<a id="<?= $key ?>-href" data-href="<?=$arItem['DATA_HREF']?>" href="<?= $arItem['HREF'] ?>" class="profile-scrollspy__link" data-text="<?= $arItem['NAME'] ?>">
					<? if ( !empty($arItem['IMG']) ): ?>
						<span class="panel-icon">
                                <img src="<?=Main::GetResizedImg($arItem['IMG'], array('WIDTH' => 30, 'HEIGHT' => 30, 'SET_ID' => $arParams['RESIZER_ICONS']))?>">
                            </span>
					<?elseif ( !empty($arItem['SVG'])):?>
							<span class="panel-icon">
								<svg>
									<use xlink:href="<?=$arItem['SVG']; ?>"></use>
								</svg>
							 </span>
					<? endif; ?>
				</a>
			</li>
		<? endforeach ?>
	</ul>
</section>