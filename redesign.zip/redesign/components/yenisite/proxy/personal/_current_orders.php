<?if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();
use \Yenisite\Core\Tools;
if (\CModule::IncludeModule("sale")){?>
    <ul class="nav nav-pills profile-page-pills">
            <li class="active" role="presentation">
                <a href="#wait-payment" data-toggle="pill" class="simple-button" aria-controls="#wait-payment"><?=GetMessage('RZ_ACCEPT_WAIT_PAYMENT')?></a>
            </li>
            <li role="presentation">
                <a href="#payed-formating" data-toggle="pill" class="simple-button" aria-controls="#payed-formating"> <?=GetMessage('RZ_PAYED_AND_FORMATING')?></a>
            </li>
    </ul>
    <div class="profile-page-content tab-content">
        <div class="tab-pane active" id="wait-payment">
            <div class="account-section-description">
                <?Tools::IncludeArea('personal','accept-and-waiting',array(),false)?>
            </div>
            <div class="profile-section-content">
                <?
                $arParams['BITRIX_SALE_PERSONAL_ORDER_LIST']['PATH_TO_CANCEL'] = $arParams['BITRIX_SALE_PERSONAL_ORDER_LIST']['PATH_TO_CANCEL'] ? : SITE_DIR.'personal/orders/cancel.php?ID=#ID#';
                $_REQUEST['filter_history'] = 'N';
                $arParams['BITRIX_SALE_PERSONAL_ORDER_LIST']['HISTORIC_STATUSES'] = array('P','F','O');
                $APPLICATION->IncludeComponent(
                    "bitrix:sale.personal.order.list",
                    "historic",
                    $arParams['BITRIX_SALE_PERSONAL_ORDER_LIST'],
                    $component,
                    array('HIDE_ICONS' => true)
                );
                ?>
            </div>
        </div>
        <div class="tab-pane" id="payed-formating">
            <div class="account-section-description">
                <?Tools::IncludeArea('personal','payed-and-formating',array(),false)?>
            </div>
            <div class="profile-section-content">
                <?
                $_REQUEST['filter_history'] = 'Y';
                $arParams['BITRIX_SALE_PERSONAL_ORDER_LIST']['HISTORIC_STATUSES'] = array('P');
                $APPLICATION->IncludeComponent(
                    "bitrix:sale.personal.order.list",
                    "historic",
                    $arParams['BITRIX_SALE_PERSONAL_ORDER_LIST'],
                    $component,
                    array('HIDE_ICONS' => true)
                );?>
            </div>
        </div>
    </div>
<?}