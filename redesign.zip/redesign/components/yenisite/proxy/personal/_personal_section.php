<?use \Yenisite\Stroymag\Main;?>
<ul class="panel">
    <? foreach ($arResult['ITEMS'] as $key => $arItem): ?>
        <?if($key == $id) continue?>
            <li class="panel-item panel-tab">
                <a data-href="<?=$arItem['DATA_HREF']?>" href="<?=$arItem['HREF']; ?>">
                    <? if ( !empty($arItem['IMG']) ): ?>
                            <span class="panel-icon">
                                <img src="<?=Main::GetResizedImg($arItem['IMG'], array('WIDTH' => 30, 'HEIGHT' => 30, 'SET_ID' => $arParams['RESIZER_ICONS']))?>">
                            </span>
                    <?elseif ( !empty($arItem['SVG'])):?>
                        <span class="panel-icon">
                            <svg>
                                 <use xlink:href="<?=$arItem['SVG']; ?>"></use>
                            </svg>
                         </span>
                    <? endif; ?>
                    <span class="panel-name"><?=$arItem['NAME']; ?></span>
                </a>
            </li>
    <? endforeach; ?>
</ul>
