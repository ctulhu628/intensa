<?
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED!==true) die();

use Bitrix\Main\Loader;
use Bitrix\Main\ModuleManager;

if (!Loader::includeModule('iblock'))
	return;
$boolCatalog = Loader::includeModule('catalog');
$arIBlockType = CIBlockParameters::GetIBlockTypes();
$arIblockTypeService = CIBlockParameters::GetIBlockTypes();

$arIBlock=array();
$rsIBlock = CIBlock::GetList(array("sort" => "asc"), array("TYPE" => $arCurrentValues["IBLOCK_TYPE_ORDERS"], "ACTIVE"=>"Y"));
while($arr=$rsIBlock->Fetch())
{
	$arIBlock[$arr["ID"]] = "[".$arr["ID"]."] ".$arr["NAME"];
}

$arIBlockService=array();
$rsIBlockService = CIBlock::GetList(array("sort" => "asc"), array("TYPE" => $arCurrentValues["IBLOCK_TYPE_CHEAP_LOWER_PRICE"], "ACTIVE"=>"Y"));
while($arr=$rsIBlockService->Fetch())
{
	$arIBlockService[$arr["ID"]] = "[".$arr["ID"]."] ".$arr["NAME"];
}

//PROPERTIES:
$arPropertiesFoundSheap_ALL = array('-' => GetMessage('CP_BC_TPL_PROP_EMPTY'));
if ((int)$arCurrentValues["IBLOCK_FOUND_CHEAP"]) {
	$dbProperties = CIBlockProperty::GetList(Array("sort" => "asc", "name" => "asc"),
		Array('ACTIVE' => 'Y', 'IBLOCK_ID' => (int)$arCurrentValues["IBLOCK_FOUND_CHEAP"]));
	while ($arProp = $dbProperties->GetNext()) {
		$strPropName = '[' . $arProp['ID'] . ']' . ('' != $arProp['CODE'] ? '[' . $arProp['CODE'] . ']' : '') . ' ' . $arProp['NAME'];
		$arPropertiesFoundSheap_ALL[$arProp["CODE"]] = "[{$arProp['CODE']}] {$arProp['NAME']}";
	}
}

$arPropertiesLowerPrice_ALL = array('-' => GetMessage('CP_BC_TPL_PROP_EMPTY'));
if ((int)$arCurrentValues["IBLOCK_LOWER_PRICE"]) {
	$dbProperties = CIBlockProperty::GetList(Array("sort" => "asc", "name" => "asc"),
		Array('ACTIVE' => 'Y', 'IBLOCK_ID' => (int)$arCurrentValues["IBLOCK_LOWER_PRICE"]));
	while ($arProp = $dbProperties->GetNext()) {
		$strPropName = '[' . $arProp['ID'] . ']' . ('' != $arProp['CODE'] ? '[' . $arProp['CODE'] . ']' : '') . ' ' . $arProp['NAME'];
		$arPropertiesLowerPrice_ALL[$arProp["CODE"]] = "[{$arProp['CODE']}] {$arProp['NAME']}";
	}
}

global $arComponentParameters;

// RESIZER:
$arComponentParameters["GROUPS"]["DATA_LITE_ORDERS"]= array(
	"NAME" => GetMessage("DATA_LITE_ORDERS"),
	"SORT" => 1
);
$defCheapIblock = 'found_cheap_'.$_GET['src_site'];
$defPriceLowerIblock = 'price_lower_'.$_GET['src_site'];
$arTemplateParameters = array(
	"ACTION_OF_HREF" => array(
		"PARENT" => "BASE",
		"NAME" => GetMessage("ACTION_OF_HREF"),
		"TYPE" => "STRING",
		"DEFAULT" => GetMessage('DEF_ACTION_OF_HREF')
	),
	"ON_AJAX" => array(
		"PARENT" => "BASE",
		"NAME" => GetMessage("ON_AJAX"),
		"TYPE" => "CHECKBOX",
		"DEFAULT" => 'Y'
	),
	"USE_COMBINE_MOD" => array(
		"PARENT" => "BASE",
		"NAME" => GetMessage("USE_COMBINE_MOD"),
		"TYPE" => "CHECKBOX",
		"DEFAULT" => 'Y'
	),
	"USE_SELF_LINK" => array(
		"PARENT" => "BASE",
		"NAME" => GetMessage("USE_SELF_LINK"),
		"TYPE" => "CHECKBOX",
		"DEFAULT" => 'Y'
	),
	"IBLOCK_TYPE_ORDERS" => array(
		"PARENT" => "DATA_LITE_ORDERS",
		"NAME" => GetMessage("IBLOCK_TYPE_ORDERS"),
		"TYPE" => "LIST",
		"VALUES" => $arIBlockType,
		"DEFAULT" => "yenisite_market",
		"REFRESH" => "Y",
	),
	"IBLOCK_ID_ORDERS" => array(
		"PARENT" => "DATA_LITE_ORDERS",
		"NAME" => GetMessage("IBLOCK_ID_ORDERS"),
		"TYPE" => "LIST",
		"VALUES" => $arIBlock,
	),
	"SHOW_WALVELT" => array(
		"PARENT" => "BASE",
		"NAME" => GetMessage("SHOW_WALVELT"),
		"TYPE" => "CHECKBOX",
		"DEFAULT" => 'Y',
	),
	/*
	"IBLOCK_TYPE_CHEAP_LOWER_PRICE" => array(
		"PARENT" => "BASE",
		"NAME" => GetMessage("IBLOCK_TYPE_CHEAP_LOWER_PRICE"),
		"TYPE" => "LIST",
		"VALUES" => $arIblockTypeService,
		"DEFAULT" => "stroymag_service",
		"REFRESH" => "Y",
	),
	"IBLOCK_FOUND_CHEAP" => array(
		"PARENT" => "BASE",
		"NAME" => GetMessage("IBLOCK_FOUND_CHEAP"),
		"TYPE" => "LIST",
		"REFRESH" => 'Y',
		"VALUES" => $arIBlockService,
		"DEFAULT" => $defCheapIblock
	),
	"IBLOCK_LOWER_PRICE" => array(
		"PARENT" => "BASE",
		"NAME" => GetMessage("IBLOCK_LOWER_PRICE"),
		"TYPE" => "LIST",
		"REFRESH" => 'Y',
		"VALUES" => $arIBlockService,
		"DEFAULT" => $defPriceLowerIblock
	),
	"LOWER_PRICE_HEADER" => array(
		"PARENT" => "BASE",
		"NAME" => GetMessage("LOWER_PRICE_HEADER"),
		"TYPE" => "STRING",
		"DEFAULT" => GetMessage('DEF_LOWER_PRICE_HEADER')
	),
	"FOUND_CHEAP_HEADER" => array(
		"PARENT" => "BASE",
		"NAME" => GetMessage("FOUND_CHEAP_HEADER"),
		"TYPE" => "LSTRINGIST",
		"DEFAULT" => GetMessage('DEF_FOUND_CHEAP_HEADER')
	),
	"FOUND_CHEAP_PROPRS" => array(
		"PARENT" => "BASE",
		"NAME" => GetMessage("FOUND_CHEAP_PROPRS"),
		"TYPE" => "LIST",
		"MULTIPLE" => 'Y',
		"VALUES" => $arPropertiesFoundSheap_ALL,
		"DEFAULT" => array("PRODUCT", "URL","PRICE")
	),
	"FOUND_CHEAP_PROPRS_FOR_CONTACTS" => array(
		"PARENT" => "BASE",
		"NAME" => GetMessage("FOUND_CHEAP_PROPRS_FOR_CONTACTS"),
		"TYPE" => "LIST",
		"MULTIPLE" => 'Y',
		"VALUES" => $arPropertiesFoundSheap_ALL,
		"DEFAULT" => array("EMAIL", "PHONE","FIO")
	),
	"FOUND_CHEAP_RELATIVE_PROPR" => array(
		"PARENT" => "BASE",
		"NAME" => GetMessage("FOUND_CHEAP_RELATIVE_PROPR"),
		"TYPE" => "LIST",
		"VALUES" => $arPropertiesFoundSheap_ALL,
		"DEFAULT" => array("PRODUCT")
	),
	"FOUND_CHEAP_PRICE_PROPR" => array(
		"PARENT" => "BASE",
		"NAME" => GetMessage("FOUND_CHEAP_PRICE_PROPR"),
		"TYPE" => "LIST",
		"VALUES" => $arPropertiesFoundSheap_ALL,
		"DEFAULT" => array("PRICE")
	),
	"FOUND_CHEAP_ADDRESS_PROPR" => array(
		"PARENT" => "BASE",
		"NAME" => GetMessage("FOUND_CHEAP_ADDRESS_PROPR"),
		"TYPE" => "LIST",
		"VALUES" => $arPropertiesFoundSheap_ALL,
		"DEFAULT" => array("URL")
	),
	"LOWER_PRICE_PROPS" => array(
		"PARENT" => "BASE",
		"NAME" => GetMessage("LOWER_PRICE_PROPS"),
		"TYPE" => "LIST",
		"MULTIPLE" => 'Y',
		"VALUES" => $arPropertiesLowerPrice_ALL,
		"DEFAULT" => array("PRODUCT")
	),
	"LOWER_PRICE_RELATIVE_PROPR" => array(
		"PARENT" => "BASE",
		"NAME" => GetMessage("LOWER_PRICE_RELATIVE_PROPR"),
		"TYPE" => "LIST",
		"VALUES" => $arPropertiesLowerPrice_ALL,
		"DEFAULT" => array("PRODUCT")
	),
	"LOWER_PRICE_PRICE_PROPR" => array(
		"PARENT" => "BASE",
		"NAME" => GetMessage("LOWER_PRICE_PRICE_PROPR"),
		"TYPE" => "LIST",
		"VALUES" => $arPropertiesLowerPrice_ALL,
		"DEFAULT" => array("PRICE")
	),
	"LOWER_PRICE_PROPRS_FOR_CONTACTS" => array(
		"PARENT" => "BASE",
		"NAME" => GetMessage("LOWER_PRICE_PROPRS_FOR_CONTACTS"),
		"TYPE" => "LIST",
		"MULTIPLE" => 'Y',
		"VALUES" => $arPropertiesLowerPrice_ALL,
		"DEFAULT" => array("EMAIL", "PHONE","FIO")
	),*/
);
$ext = 'jpg,jpeg,gif,png';
$arrNamesOfTabs = array('PERSONAL_SECTION','CURRENT_ORDERS','PERSONAL_COUNT','INFO','REG','HISTORY',/*'SUBSCRIPTION','DELIVERY',*/'FAVORITE','BASKET','COMPARE','CONTACTS','LOGOUT');

if(!empty($arCurrentValues['SHOW_ITEMS_OF_MENU'])){
	$arrNamesOfTabs = array();
	foreach($arCurrentValues['SHOW_ITEMS_OF_MENU'] as $itemOfMenu){
		$arrNamesOfTabs [] = $itemOfMenu;
	}
}
$arValuesForParShowMenu =array(
	'PERSONAL_SECTION' => GetMessage('ITEM_MENU_PERSONAL_SECTION'),
	'CURRENT_ORDERS' => GetMessage('ITEM_MENU_CURRENT_ORDERS'),
	'PERSONAL_COUNT' => GetMessage('ITEM_MENU_PERSONAL_COUNT'),
	'INFO' => GetMessage('ITEM_MENU_INFO'),
	'REG' => GetMessage('ITEM_MENU_REG'),
	'HISTORY' => GetMessage('ITEM_MENU_HISTORY'),
	//'SUBSCRIPTION' => GetMessage('ITEM_MENU_SUBSCRIPTION'),
	//'DELIVERY' => GetMessage('ITEM_MENU_DELIVERY'),
	'FAVORITE' => GetMessage('ITEM_MENU_FAVORITE'),
	'BASKET' => GetMessage('ITEM_MENU_BASKET'),
	'COMPARE' => GetMessage('ITEM_MENU_COMPARE'),
	'CONTACTS' => GetMessage('ITEM_MENU_CONTACTS'),
	'LOGOUT' => GetMessage('ITEM_MENU_LOGOUT'),
);

$arTemplateParameters['SHOW_ITEMS_OF_MENU'] = array(
	"PARENT" => "BASE",
	"NAME" => GetMessage("SHOW_ITEMS_OF_MENU"),
	"TYPE" => "LIST",
	"VALUES" => $arValuesForParShowMenu,
	"REFRESH" => 'Y',
	"MULTIPLE" => 'Y',
	"DEFAULT" => array('PERSONAL_SECTION','CURRENT_ORDERS','PERSONAL_COUNT','INFO','REG','HISTORY','SUBSCRIPTION','DELIVERY','FAVORITE','BASKET','COMPARE','CONTACTS','LOGOUT'),
);

foreach($arrNamesOfTabs as $tab){
	$defHref =  strpos(GetMessage('DEF_HREF_'.$tab), '?') === false ? '={SITE_DIR."'.GetMessage('DEF_HREF_'.$tab).'"}' : GetMessage('DEF_HREF_'.$tab);
	$arTemplateParametersDSeven = array(
		'NAME_'.$tab => array(
			"PARENT" => "BASE",
			"NAME" => GetMessage('NAME_'.$tab),
			"TYPE" => "STRING",
			"DEFAULT" => GetMessage('DEF_NAME_'.$tab)
		),
		'HREF_'.$tab => array(
			"PARENT" => "BASE",
			"NAME" => GetMessage('HREF_'.$tab),
			"TYPE" => "STRING",
			"DEFAULT" => $defHref
		),
		'SVG_'.$tab => array(
			"PARENT" => "BASE",
			"NAME" => GetMessage('SVG_'.$tab),
			"TYPE" => "STRING",
			"DEFAULT" => GetMessage('DEF_SVG_'.$tab)
		),
		'DESCRIPTION_'.$tab => array(
			"PARENT" => "BASE",
			"NAME" => GetMessage('DESCRIPTION_'.$tab),
			"TYPE" => "STRING",
			"DEFAULT" => GetMessage('DEF_DESCRIPTION_'.$tab)
		),
		'IMG_'.$tab => array(
			"PARENT" => "BASE",
			"NAME" => GetMessage('IMG_'.$tab),
			"TYPE" => "FILE",
			"FD_TARGET" => "F",
			"FD_EXT" => $ext,
			"FD_UPLOAD" => true,
			"FD_USE_MEDIALIB" => true,
			"FD_MEDIALIB_TYPES" => Array('image')
		)
	);
	$arTemplateParameters = array_merge($arTemplateParameters,$arTemplateParametersDSeven);
}
$arTemplateParameters['EMPTY_SUBSCRIPTION_MESS'] = array(
	"PARENT" => "BASE",
	"NAME" => GetMessage('EMPTY_SUBSCRIPTION_MESS'),
	"TYPE" => "STRING",
	"DEFAULT" => GetMessage('DEF_EMPTY_SUBSCRIPTION_MESS')
);

$arTemplateParameters['BITRIX_SALE_PERSONAL_ORDER_LIST___HISTORIC_STATUSES']['HIDDEN'] = 'Y';
$arTemplateParameters['BITRIX_CATALOG_SECTION_LIST___SECTION_CODE']['HIDDEN'] = 'Y';
$arTemplateParameters['YENISITE_FAVORITE_LIST___SECTION_USER_FIELDS']['HIDDEN'] = 'Y';
$arTemplateParameters['YENISITE_FAVORITE_LIST___SHOW_ALL_WO_SECTION']['HIDDEN'] = 'Y';
$arTemplateParameters['BITRIX_CATALOG_SECTION_LIST___COUNT_ELEMENTS']['HIDDEN'] = 'Y';
$arTemplateParameters['BITRIX_CATALOG_SECTION_LIST___TOP_DEPTH']['HIDDEN'] = 'Y';
$arTemplateParameters['BITRIX_CATALOG_SECTION_LIST___SECTION_FIELDS']['HIDDEN'] = 'Y';
$arTemplateParameters['BITRIX_CATALOG_SECTION_LIST___SECTION_USER_FIELDS']['HIDDEN'] = 'Y';
$arTemplateParameters['YENISITE_FAVORITE_LIST___THEME']['HIDDEN'] = 'Y';
$arTemplateParameters['BITRIX_MAIN_PROFILE___SET_TITLE']['HIDDEN'] = 'Y';
$arTemplateParameters['BITRIX_MAIN_PROFILE___AJAX_MODE']['HIDDEN'] = 'Y';
$arTemplateParameters['BITRIX_MAIN_PROFILE___USER_PROPERTY']['HIDDEN'] = 'Y';
$arTemplateParameters['BITRIX_MAIN_PROFILE___SEND_INFO']['HIDDEN'] = 'Y';
$arTemplateParameters['BITRIX_MAIN_PROFILE___CHECK_RIGHTS']['HIDDEN'] = 'Y';
$arTemplateParameters['BITRIX_SALE_PERSONAL_ORDER_LIST___SET_TITLE']['HIDDEN'] = 'Y';
$arTemplateParameters['BITRIX_SALE_PERSONAL_ORDER_LIST___SAVE_IN_SESSION']['HIDDEN'] = 'Y';
$arTemplateParameters['YENISITE_FAVORITE_LIST___AJAX_MODE']['HIDDEN'] = 'Y';
$arTemplateParameters['YENISITE_FAVORITE_LIST___CACHE_FILTER']['HIDDEN'] = 'Y';
$arTemplateParameters['BITRIX_SALE_PERSONAL_ORDER_LIST___SAVE_IN_SESSION']['HIDDEN'] = 'Y';
$arTemplateParameters['YENISITE_FAVORITE_LIST___CACHE_GROUPS']['HIDDEN'] = 'Y';
$arTemplateParameters['BITRIX_SALE_ACCOUNT_PAY___SELL_VALUES_FROM_VAR']['HIDDEN'] = 'Y';
$arTemplateParameters['BITRIX_SALE_ACCOUNT_PAY___SET_TITLE']['HIDDEN'] = 'Y';
$arTemplateParameters['BITRIX_CATALOG_SECTION_LIST___CACHE_GROUPS']['HIDDEN'] = 'Y';
$arTemplateParameters['BITRIX_CATALOG_SECTION_LIST___CACHE_GROUPS']['HIDDEN'] = 'Y';
$arTemplateParameters['BITRIX_CATALOG_SECTION_LIST___CACHE_GROUPS']['HIDDEN'] = 'Y';
$arTemplateParameters['BITRIX_CATALOG_SECTION_LIST___CACHE_GROUPS']['HIDDEN'] = 'Y';
$arTemplateParameters['BITRIX_CATALOG_SECTION_LIST___CACHE_GROUPS']['HIDDEN'] = 'Y';

if (\Bitrix\Main\Loader::includeModule('yenisite.core')) {
	\Yenisite\Core\Resize::AddResizerParams(array('ICON','IMAGE_PERSONAL'), $arTemplateParameters);
}