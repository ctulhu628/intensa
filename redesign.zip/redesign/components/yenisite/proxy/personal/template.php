<?
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();
/**
 * @var CMain $APPLICATION
 * @var CUser $USER
 * @var array $arResult
 * @var array $arParams
 * @var CBitrixComponent $component
 */
global $rz_options;
use \Yenisite\Core\Ajax;

$isAjax = Ajax::isAjax();
$id = 'personal_section';
if (!empty($_GET[$arParams['ACTION_OF_HREF']])){
	$id = htmlspecialchars($_GET[$arParams['ACTION_OF_HREF']]);
}elseif (!empty($_REQUEST[$arParams['ACTION_OF_HREF']])){
	$id = htmlspecialchars($_REQUEST[$arParams['ACTION_OF_HREF']]);
}
if ((!empty($_REQUEST['COPY_ORDER']) && $_REQUEST['COPY_ORDER'] == 'Y') || (!empty($_REQUEST['CANCEL']) && $_REQUEST['CANCEL'] == 'Y')){
	$id = 'history';
}
if (empty($arResult['ITEMS'][$id])){
	foreach($arResult['ITEMS'] as $key =>  $arItem){
		$id = $key;
		break;
	}
}
?>
<?if (!$isAjax):?>
	<?
	\CJSCore::Init(array('fileinput'));
	$idPersonal = 'personal_cab';
	Ajax::saveParams($this,$arParams,$idPersonal,SITE_ID);
	?>

<section class="clarification">
	<?\Yenisite\Core\Tools::IncludeArea('personal','describe_personal')?>
</section>
	<div class="row" id="account-page-row" <?Ajax::printAjaxDataAttr($this,$idPersonal)?>>
		<div class="navigation-col col-sm-4 col-md-3 col-lg-3 col-xl-2">
			<?include "_menu.php"?>
		</div>
		<div class="profile-content col-sm-8 col-md-9 col-lg-9 col-xl-10">
			<div class="tab-content">
<?endif?>
				<div class="tab-pane in active" id="tab_<?= $id ?>">
					<div class="h1" id="<?= $id ?>-header"><?=$arResult['ITEMS'][$id]['NAME']?></div>
					<div class="profile-tab-description">
						<?=$arResult['ITEMS'][$id]['DESCRIPTION']?>
					</div>
					<div class="profile-section-content <?=$arResult['ITEMS'][$id]['CLASS']?>" id="<?= $id ?>">
						<?include "_".$id.".php"; ?>
					</div>
				</div>
<?if(!$isAjax):?>
			</div>
		</div>
		</div>
	<script>
		var tabVar  = <?=CUtil::PhpToJSObject($arParams['ACTION_OF_HREF'])?>;
		var useAjaxPersonal  = <?=CUtil::PhpToJSObject($arParams['ON_AJAX'] != 'N')?>;
		var useSelfLink  = <?=CUtil::PhpToJSObject($arParams['USE_SELF_LINK'] != 'N')?>;
		var useCombineMod  = <?=CUtil::PhpToJSObject($arParams['USE_COMBINE_MOD'] != 'N')?>;
	</script>
<?endif?>

