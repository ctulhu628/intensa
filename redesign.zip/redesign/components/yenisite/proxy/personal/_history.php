<?if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();
use \Yenisite\Core\Tools;
if (\CModule::IncludeModule("sale")){?>
<ul class="nav nav-pills profile-page-pills">
    <li class="active" role="presentation">
        <a href="#finish-order" data-toggle="pill" class="simple-button" aria-controls="#finish-order"><?=GetMessage('RZ_FINISH_ORDER')?></a>
    </li>
    <li role="presentation">
        <a href="#canceled-order" data-toggle="pill" class="simple-button" aria-controls="#canceled-order"> <?=GetMessage('RZ_CANCELED_ORDER')?></a>
    </li>
</ul>
    <div class="profile-page-content tab-content">
        <div class="tab-pane active" id="finish-order">
            <div class="account-section-description">
                <?Tools::IncludeArea('personal','finish_orders',array(),false)?>
            </div>
                <?
                $arParams['BITRIX_SALE_PERSONAL_ORDER_LIST']['PATH_TO_CANCEL'] = $arParams['BITRIX_SALE_PERSONAL_ORDER_LIST']['PATH_TO_CANCEL'] ? : SITE_DIR.'personal/orders/cancel.php?ID=#ID#';
                $_REQUEST['filter_history'] = 'Y';
                $arParams['BITRIX_SALE_PERSONAL_ORDER_LIST']['HISTORIC_STATUSES'] = array('F');
                $APPLICATION->IncludeComponent(
                    "bitrix:sale.personal.order.list",
                    "historic",
                    $arParams['BITRIX_SALE_PERSONAL_ORDER_LIST'],
                    $component,
                    array('HIDE_ICONS' => true)
                );
            ?>
        </div>
         <div class="tab-pane" id="canceled-order">
                <div class="account-section-description">
                    <?Tools::IncludeArea('personal','canceled_orders',array(),false)?>
                </div>
                    <?
                    $arParams['BITRIX_SALE_PERSONAL_ORDER_LIST']['HISTORIC_STATUSES'] = array('O');
                    $_REQUEST['show_canceled'] = 'Y';
                    $arParams['BITRIX_SALE_PERSONAL_ORDER_LIST']['NOT_SHOW_CANCEL'] = true;
                    $APPLICATION->IncludeComponent(
                        "bitrix:sale.personal.order.list",
                        "historic",
                        $arParams['BITRIX_SALE_PERSONAL_ORDER_LIST'],
                        $component,
                        array('HIDE_ICONS' => true)
                    );?>
        </div>
</div>
<?}else{
    global $USER;
    if($USER->GetID()){
        global $arrFilter;
        $arrFilter = array();
        $arrFilter['CREATED_BY'] = $USER->GetID();
        $arrFilter['PROPERTY_SITE_ID'] = SITE_ID;
        $APPLICATION->IncludeComponent("bitrix:news.list", "orders", Array(
            "IBLOCK_TYPE" => $arParams['IBLOCK_TYPE_ORDERS'],
            "IBLOCK_ID" => $arParams['IBLOCK_ID_ORDERS'],
            "NEWS_COUNT" => "20",
            "SORT_BY1" => "ACTIVE_FROM",
            "SORT_ORDER1" => "DESC",
            "SORT_BY2" => "SORT",
            "SORT_ORDER2" => "ASC",
            "FILTER_NAME" => "arrFilter",
            "FIELD_CODE" => array(
                0 => "ID",
                1 => "DATE_CREATE",
                2 => "",
            ),
            "PROPERTY_CODE" => array(
                0 => "ITEMS",
                1 => "STATUS",
                2 => "AMOUNT",
                3 => "SITE_ID"
            ),
            "CHECK_DATES" => "Y",
            "DETAIL_URL" => SITE_DIR."personal/orders/?ID=#ID#",
            "AJAX_MODE" => "N",
            "AJAX_OPTION_JUMP" => "N",
            "AJAX_OPTION_STYLE" => "Y",
            "AJAX_OPTION_HISTORY" => "N",
            "CACHE_TYPE" => "A",
            "CACHE_TIME" => "36000000",
            "CACHE_FILTER" => "N",
            "CACHE_GROUPS" => "Y",
            "PREVIEW_TRUNCATE_LEN" => "",
            "ACTIVE_DATE_FORMAT" => "d.m.Y",
            "SET_TITLE" => "N",
            "SET_STATUS_404" => "N",
            "INCLUDE_IBLOCK_INTO_CHAIN" => "N",
            "ADD_SECTIONS_CHAIN" => "Y",
            "HIDE_LINK_WHEN_NO_DETAIL" => "Y",
            "PARENT_SECTION" => "",
            "PARENT_SECTION_CODE" => "",
            "INCLUDE_SUBSECTIONS" => "Y",
            "DISPLAY_TOP_PAGER" => "N",
            "DISPLAY_BOTTOM_PAGER" => "Y",
            "PAGER_TITLE" => "",
            "PAGER_SHOW_ALWAYS" => "N",
            "PAGER_TEMPLATE" => "",
            "PAGER_DESC_NUMBERING" => "N",
            "PAGER_DESC_NUMBERING_CACHE_TIME" => "36000",
            "PAGER_SHOW_ALL" => "N",
            "DISPLAY_DATE" => "Y",
            "DISPLAY_NAME" => "Y",
            "DISPLAY_PICTURE" => "Y",
            "DISPLAY_PREVIEW_TEXT" => "Y",
            "AJAX_OPTION_ADDITIONAL" => "",
        ),
            false,
            array("HIDE_ICONS" => "Y")
        );
    }else{
        $APPLICATION->IncludeComponent(
            "yenisite:proxy",
            "order",
            array(
                "COMPONENT_LIST" => array(
                ),
                "COMPONENT_TEMPLATE" => "order",
                "REMOVE_POSTFIX_IN_NAMES" => "N",
                "IBLOCK_TYPE_ORDERS" => $arParams['IBLOCK_TYPE_ORDERS'],
                "IBLOCK_ID_ORDERS" => $arParams['IBLOCK_ID_ORDERS'],
            ),
            false
        );
    }
}
?>