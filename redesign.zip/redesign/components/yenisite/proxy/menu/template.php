<?
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();
$this->setFrameMode(true);
use Yenisite\Core\Tools;
global $rz_options;

if (($APPLICATION->GetProperty("prop_menu_catalog") != "menu_catalog") && ($APPLICATION->GetProperty("prop_menu_slider") != "menu_slider")){
	$this->SetViewTarget('menu_header');
	Tools::IncludeArea('header', 'menu_catalog');
	$this->EndViewTarget();
}
if ((($APPLICATION->GetProperty("prop_menu_catalog") != "menu_catalog") && ($APPLICATION->GetProperty("prop_menu_slider") != "menu_slider") && ($rz_options['main_menu_position'] != 'at-top')) || ($APPLICATION->GetProperty("prop_menu_slider") == "menu_slider")){
	$this->SetViewTarget('search_form_header');
	echo "search-panel dropdown w-categories-select";
	$this->EndViewTarget();
}else{
	$this->SetViewTarget('search_form_header');
	echo "search-panel dropdown w-categories-select search-panel-full";
	$this->EndViewTarget();
}
