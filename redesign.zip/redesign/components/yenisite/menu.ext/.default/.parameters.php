<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$arTemplateParameters["ELEMENT_CNT"] = array(
	"PARENT" => "BASE",
	"NAME" => GetMessage("ELEMENT_CNT"),
	"TYPE" => "CHECKBOX",
	"DEFAULT" => "N",
	"HIDDEN" => "Y"
);
?>