<?
$MESS ['ASD_VK_TITLE'] = "Расшарить ВКонтакт";
$MESS ['ASD_VK'] = "ВКонтакт";
$MESS ['ASD_FB_TITLE'] = "Расшарить в Facebook";
$MESS ['ASD_FB'] = "Facebook";
$MESS ['ASD_BUZZ_TITLE'] = "Расшарить в Buzz";
$MESS ['ASD_BUZZZ'] = "Buzz";
$MESS ['ASD_TW_TITLE'] = "Расшарить в Twitter";
$MESS ['ASD_TW'] = "Twitter";
$MESS ['ASD_MAILRU_TITLE'] = "Расшарить в Mail.Ru";
$MESS ['ASD_MAILRU'] = "Mail.Ru";
$MESS ['ASD_YANDEX_TITLE'] = "Расшарить в Яндекс";
$MESS ['ASD_YANDEX'] = "Яндекс";
$MESS ['ASD_OD_TITLE'] = "Расшарить в Одноклассники";
$MESS ['ASD_OD'] = "Одноклассники";
$MESS ['ASD_LJ_TITLE'] = "Расшарить в Livejournal";
$MESS ['ASD_LJ'] = "Livejournal";
$MESS ['ASD_LI_TITLE'] = "Расшарить в Liveinternet";
$MESS ['ASD_LI'] = "Liveinternet";
$MESS ['ASD_GP_TITLE'] = "Расшарить в Google Plus";
$MESS ['ASD_GP'] = "Google Plus";
?>