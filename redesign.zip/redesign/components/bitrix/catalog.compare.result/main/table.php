<?
/**
 * @var array $arResult
 * @var array $arParams
 * @var CBitrixComponentTemplate $this
 * @global CMain $APPLICATION
 */
use Yenisite\Furniture\Form;
use Yenisite\Furniture\Main;

$rnd = $this->randString();
?>
<table class="compare-table">
	<thead class="compare-thead">
	<tr>
		<td class="bb-d">
			<div class="compare-comment">
				<img class="compare-comment__img center-block" src="<?= $templateFolder ?>/img/compare.png" height="111" width="133" alt="">
				<div class="compare-comment__text"><?= GetMessage('RZ_COMPARISON_DESC') ?></div>
			</div>
			<div class="compare-title"><?= GetMessage('RZ_COMPARISON_PARAMETERS') ?>:</div>
		</td>

		<? foreach ($arResult['ITEMS'] as $arItem): ?>
			<? $bHasSKU = $arItem['bOffers'] ?>
			<td>
				<div class="preview-item">
					<div class="preview-item__image-wrap">
						<form action="<?= $arItem['~DELETE_URL'] ?>" method="post">
							<a href="<?= $arItem['DETAIL_PAGE_URL'] ?>" class="preview-item__image-link">
								<img src="<?= $arItem['PHOTO'] ?>" alt="<?= $arItem['NAME'] ?>" class="preview-item__image">
							</a>
							<button type="submit" class="remove-from-compare flaticon-cross93"></button>
						</form>
						<? if ($arItem['ARTICLE']): ?>
							<span class="art"><?= $arItem['ARTICLE_NAME'] ?>: <span class="value-art"><?= $arItem['ARTICLE'] ?></span></span>
						<? endif ?>
						<? if ($arParams['USE_FAVORITE']): ?>
							<div class="add-buttons no-text no-border">
								<button class="add to-favorites addable flaticon-heart296 action-btn favorite-<?= $arItem['ID'] ?>"
										data-id="<?= $arItem['ID'] ?>">
									<span class="add-text"><?= GetMessage('RZ_FAVORITE_ADD') ?></span>
									<span class="added-text"><?= GetMessage('RZ_FAVORITE_DELETE') ?></span>
									<span class="cbutton cbutton--effect-nikola"></span>
								</button><!-- add.to-favorites -->
							</div>
						<? endif ?>
					</div>
					<div class="item-name">
						<div class="name-inner-wrap">
							<a href="<?= $arItem['DETAIL_PAGE_URL'] ?>" class="classic-link"><?= $arItem['NAME'] ?></a>
						</div>
					</div>
						<div class="preview-item__caption">
						<div class="caption-hidden">
							<?
							Form::printElement(array(
								'STEP' => $arItem['CATALOG_MEASURE_RATIO'],
								'DISABLED' => !$arItem['CAN_BUY'],
								'CLASS' => 'small',
								'ATTR' => 'id="' . $rnd . '-q_' . $arItem['ID'] . '"',
							),
								Form::TYPE_QUANTITY);
							$disabled = $arItem['CAN_BUY'] ? '' : ' disabled';
							?>
							<?if($arItem['CAN_BUY'] && Main::isOneClick() && $arParams['SHOW_ONE_CLICK']):?>
								<span  data-toggle="modal" data-target="#modal-quick-order">
									<a href="#" data-name="<?=$arItem['NAME']?>" data-toggle="tooltip" data-placement="top" title="" data-original-title="<?=GetMessage('RZ_BUY_IN_ONE_CLICK')?>" data-props="<?= \Yenisite\Core\Tools::GetEncodedArParams($arParams['OFFER_TREE_PROPS']) ?>" data-id="<?= $arItem['ID'] ?>"  class="buy-one-click three-color-i tooltip-simple">
										<svg xmlns="http://www.w3.org/2000/svg">
											<use xlink:href="#buy-one-click"></use>
										</svg>
									</a>
								</span>
							<?endif?>
							<? if ($bHasSKU): ?>
								<a href="<?= $arItem['DETAIL_PAGE_URL'] ?>"
								   class="sku add-to-cart-small three-color-p<?= $disabled ?>"<?= $disabled ?>><?= GetMessage('RZ_CHOOSE_ITEM') ?></a>
							<? else: ?>
								<a href="<?= $arParams['BASKET_URL'] ?>" data-q="#<?= $rnd . '-q_' . $arItem['ID'] ?>"
								   data-props='<?=$arItem['CART_PROP']?>' data-id="<?= $arItem['ID'] ?>" data-toggle="tooltip" data-placement="top" title="" data-original-title="<?=GetMessage('RZ_IN_BASKET')?>"
								   class="add-to-cart-small three-color-p incart-<?= $arItem['ID'] ?><?= $disabled ?>"<?= $disabled ?>><svg xmlns="http://www.w3.org/2000/svg">
										<use xlink:href="#cart-add"></use>
									</svg></a>
							<? endif ?>
						</div>
						<div class="price"><?= $arItem['MIN_PRICE']['PRINT_DISCOUNT_VALUE'] ?></div>
						<? $frame = $this->createFrame()->begin(Main::insertCompositLoader()) ?>
						<? $APPLICATION->IncludeComponent("bitrix:iblock.vote", "section", array(
								"IBLOCK_TYPE" => $arParams['IBLOCK_TYPE'],
								"IBLOCK_ID" => $arParams['IBLOCK_ID'],
								"ELEMENT_ID" => $arItem['ID'],
								"CACHE_TYPE" => $arParams["CACHE_TYPE"],
								"CACHE_TIME" => $arParams["CACHE_TIME"],
								"MAX_VOTE" => "5",
								"VOTE_NAMES" => array("1", "2", "3", "4", "5"),
								"SET_STATUS_404" => "N",
						),
								$component, array("HIDE_ICONS" => "Y")
						); ?>
						<? $frame->end(); ?>
					</div><!-- .info-wrap -->
				</div>
			</td>
		<? endforeach ?>
	</tr>
	<tr class="spacer">
		<? foreach ($arResult['ITEMS'] as $arItem): ?>
			<td></td>
		<? endforeach ?>
	</tr>
	</thead>
	<? if (count($arResult['SHOW_PROPERTIES']) > 0): ?>
			<?$GroupWithOutHeader = true; ?>
			<? foreach ($arResult['SHOW_PROPERTIES'] as $ID => $arProp): ?>
				<?if ($arResult['HAS_GROUPS'] === true && !empty($arProp['GROUP_NAME'])) {?>
				</tbody>
				<tbody class="compare-body ">
					<tr class= "section-header">
						<td>
							<button class="section-toggle shown" type="button">
								<span class="text"><?=$arProp['GROUP_NAME']?></span>
							</button>
						</td>
						<?=str_repeat('<td></td>', count($arResult["ITEMS"]))?>
					</tr>
				<?
				continue;
			} elseif($GroupWithOutHeader && empty($arProp['GROUP_NAME'])){?>
					<tbody  class="compare-body">
						<tr class="section-header">
							<td>
								<button type="button"  class="section-toggle shown">
									<span class="text"><?=GetMessage('RZ_COMMON_PROPERTIES')?></span>
								</button>
							</td>
							<?=str_repeat('<td></td>', count($arResult["ITEMS"]))?>
						</tr>
					<?$GroupWithOutHeader = false; ?>
				<?}?>
					<tr>
						<td>
							<?= $arProp['NAME'] ?>
						</td>
						<? foreach ($arResult['ITEMS'] as $arItem): ?>
							<td><?= $arItem['DISPLAY_PROPERTIES'][$ID]['DISPLAY_VALUE'] ?></td>
						<? endforeach ?>
					</tr>
			<? endforeach ?>
	<? endif ?>
</table>