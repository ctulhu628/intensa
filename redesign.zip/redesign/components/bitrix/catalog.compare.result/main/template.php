<? use Bitrix\Main\Localization\Loc;

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */
/** @var CBitrixComponent $component */

Loc::loadLanguageFile($_SERVER['DOCUMENT_ROOT'] . SITE_TEMPLATE_PATH . '/catalog.php');
?>
<div class="compare-page">
	<h1><? $APPLICATION->ShowTitle(false) ?></h1>
	<div class="compare-buttons">
		<form action="<?= $APPLICATION->GetCurPage(false) ?>" method="get">
			<button type="submit" name="DIFFERENT" value="N" class="compare-button<?= $arResult['DIFFERENT'] ? '' : ' active' ?>">
				<?= GetMessage('RZ_COMPARISON_SHOW_ALL_PARAMETERS') ?>
			</button>
			<button type="submit" name="DIFFERENT" value="Y" class="compare-button<?= $arResult['DIFFERENT'] ? ' active' : '' ?>">
				<?= GetMessage('RZ_COMPARISON_ONLY_DIFFERENT') ?>
			</button>
		</form>
	</div>
	<div class="no-item-frame compare-table-wrap" id="compare-table-wrap">
		<div class="slidee">
			<? include 'table.php'; ?>
		</div>
		<div class="pages-wrap">
			<button class="prevPage three-color-p flaticon-left207">
				<span class="cbutton cbutton--effect-lazar cbutton--effect-lazar-inverted"></span>
			</button>
			<div class="nums"><span class="num-current"></span> / <span class="num-total"></span></div>
			<ul class="pages">
				<li></li>
			</ul>
			<button class="nextPage three-color-p flaticon-right218"><span class="cbutton cbutton--effect-lazar"></span></button>
		</div><!-- pages-wrap -->
	</div>
</div>
