<?
/**
 * @var CBitrixComponentTemplate $this
 * @var array $arResult
 * @var array $arParams
 */
use Bitrix\Main\Loader;
use Yenisite\Furniture\Main;

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
if (empty($arResult['ITEMS'])) return;

$baseCurrency = 'RUB';
if (CModule::IncludeModule('currency') || CModule::IncludeModule('sale')) {
	$baseCurrency = CCurrency::GetBaseCurrency();
}

$resizeThumb = array('WIDTH' => 38, 'HEIGHT' => 38, 'SET_ID' => $arParams['RESIZER_THUMB']);
$resizeItem = array('WIDTH' => 233, 'HEIGHT' => 218, 'SET_ID' => $arParams['RESIZER_IMAGE']);
$arResizer = array('THUMB' => $resizeThumb, 'SRC' => $resizeItem);
$arParams['OFFER_TREE_PROPS'] = $arParams['OFFERS_PROPERTY_CODE'];

if (CModule::IncludeModule("catalog"))
Main::prepareSku($arResult, $arParams, $arResizer);

$arParamsCatalog = \Yenisite\Core\Ajax::getParams('bitrix:catalog', 'bitrix_catalog', '',SITE_ID);
$arParams['PRODUCT_PROPERTIES'] = array_merge($arParams['PRODUCT_PROPERTIES'], $arParamsCatalog['PRODUCT_PROPERTIES']);
$arParams['OFFERS_CART_PROPERTIES'] = array_merge($arParams['OFFERS_CART_PROPERTIES'], $arParamsCatalog['OFFERS_CART_PROPERTIES']);

$arTmpProps = array();
$arResult['PROPS_WITHOUT_GROUPS'] = array();
if (CModule::IncludeModule('yenisite.furniturelite') && CModule::IncludeModule('yenisite.market'))
	$arResult['CHECK_QUANTITY'] = (CMarketCatalog::UsesQuantity($arParams['IBLOCK_ID']) == 1);

$arId = array();

foreach ($arResult['ITEMS'] as $key => &$arItem) {
	$arId[] = $arItem['ID'];
}

if (CModule::IncludeModule("catalog"))
$arOffersList = CCatalogSKU::getOffersList(
	$arId,
	$arItem['IBLOCK_ID']
);

foreach ($arResult['ITEMS'] as $key => &$arItem) {
	if (CModule::IncludeModule("catalog"))
	$arItem['bOffers'] = CCatalogSKU::IsExistOffers($arItem['ID'], $arItem['IBLOCK_ID']);

	if (CModule::IncludeModule('yenisite.furniturelite') && CModule::IncludeModule('yenisite.market')) {
	
		if(!empty($arItem['PROPERTIES']['MEASURE_NAME']['VALUE_ENUM'])) $arItem['CATALOG_MEASURE_NAME'] = $arItem['PROPERTIES']['MEASURE_NAME']['VALUE_ENUM'];
		
		$prices = CMarketPrice::GetItemPriceValues($arItem['ID'], $arItem['PRICES']);
		if (count($prices) > 0) {
			unset($arItem['PRICES']);
		}
		$minPrice = false;
		foreach ($prices as $k => $pr) {
			$pr = floatval($pr);
			$arItem['PRICES'][$k]['VALUE'] = $pr;
			$arItem['PRICES'][$k]['PRINT_VALUE'] = $pr;
			if ((empty($minPrice) || $minPrice > $pr) && $pr > 0) {
				$minPrice = $pr;
			}
		}
		if ($minPrice !== false) {
		
			$minPrice = Main::getElementPriceFormat($arItem['MIN_PRICE']['CURRENCY'], $minPrice, $arItem['MIN_PRICE']['PRINT_VALUE']);
		
			$arItem['MIN_PRICE']['VALUE'] = $minPrice;
			$arItem['MIN_PRICE']['PRINT_VALUE'] = $minPrice;
			$arItem['MIN_PRICE']['DISCOUNT_VALUE'] = $minPrice;
			$arItem['MIN_PRICE']['PRINT_DISCOUNT_VALUE'] = $minPrice;
			$arItem['CATALOG_MEASURE_RATIO'] = 1;
			$arItem['CAN_BUY'] = true;
		}
		$arItem['CHECK_QUANTITY'] = $arResult['CHECK_QUANTITY'];
		$arItem['CATALOG_QUANTITY'] = CMarketCatalogProduct::GetQuantity($arItem['ID'], $arItem['IBLOCK_ID']);
		
		if ($arItem['CHECK_QUANTITY'] && $arItem['CATALOG_QUANTITY'] <= 0) {
			$arItem['CAN_BUY'] = false;
		}
		$arItem['CATALOG_TYPE'] = 1; //simple product		
		
	}

	if ($arItem['bOffers'] && empty($arItem['MIN_PRICE']) && floatval($arItem['PROPERTIES']['MINIMUM_PRICE']['VALUE']) > 0) {

		$arPricesOffers = array();
		if($arOffersList)
 		foreach($arOffersList[$arItem['ID']] as $key => $ProdSku){
			$ar_res = CPrice::GetBasePrice(
				$ProdSku['ID']
			);
			$arPricesOffers[] = $ar_res['PRICE'];
		}
		
		if(!empty($arPricesOffers)) $arItem['PROPERTIES']['MINIMUM_PRICE']['VALUE'] = min($arPricesOffers);

		$arItem['MIN_PRICE'] = array(
			'CURRENCY' => $baseCurrency,
			'DISCOUNT_VALUE' => floatval($arItem['PROPERTIES']['MINIMUM_PRICE']['VALUE'])
		);
		if ($arParams['CONVERT_CURRENCY'] === 'Y' && $arParams['CURRENCY_ID'] != $baseCurrency && CModule::IncludeModule('currency')) {
			$arItem['MIN_PRICE']['ORIG_CURRENCY'] = $arItem['MIN_PRICE']['CURRENCY'];
			$arItem['MIN_PRICE']['ORIG_DISCOUNT_VALUE'] = $arItem['MIN_PRICE']['DISCOUNT_VALUE'];
			$arItem['MIN_PRICE']['CURRENCY'] = $arParams['CURRENCY_ID'];
			$arItem['MIN_PRICE']['DISCOUNT_VALUE'] = CCurrencyRates::ConvertCurrency($arItem['MIN_PRICE']['DISCOUNT_VALUE'], $arItem['MIN_PRICE']['ORIG_CURRENCY'], $arItem['MIN_PRICE']['CURRENCY']);
		}
		$arItem['MIN_PRICE']['PRINT_DISCOUNT_VALUE'] = \Yenisite\Furniture\Events::CurrencyFormat(SITE_ID,$arItem['MIN_PRICE']['DISCOUNT_VALUE'],$arItem['MIN_PRICE']['CURRENCY']);
		//echo '<pre>', var_export($arItem, 1), '</pre>';
	}
	$arItem['GALLERY'] = Main::getGallery($arItem, $arResizer);
	$arItem['PHOTO'] = $arItem['GALLERY'][0]['SRC'];
	Main::processCatalogItem($arItem, $arParams['OFFERS_PROPERTY_CODE']);
	Main::preparePropsForCart($arItem, $arParams);

	foreach ($arResult['SHOW_PROPERTIES'] as $propCode => $arProp) {
		if (is_array($arItem['DISPLAY_PROPERTIES'][$propCode]['DISPLAY_VALUE'])) {
			$arItem['DISPLAY_PROPERTIES'][$propCode]['DISPLAY_VALUE'] = implode(', ',
				$arItem['DISPLAY_PROPERTIES'][$propCode]['DISPLAY_VALUE']);
		}
		if ($arResult['DIFFERENT']) {
			$valHash = md5($arItem['DISPLAY_PROPERTIES'][$propCode]['DISPLAY_VALUE']);
			++$arTmpProps[$propCode][$valHash];
		}
		$arResult['PROPS_WITHOUT_GROUPS'][$arProp['ID']] = $propCode;
	}

	$arItem['ARTICLE'] = '';
	$arItem['ARTICLE_NAME'] = GetMessage('RZ_ARTICLE_NAME');
	$strProp = 'CML2_ARTICLE';
	if (!empty($arParams['ARTICUL_PROP']) && $arParams['ARTICUL_PROP'] != '-') {
		$strProp = $arParams['ARTICUL_PROP'];
	}
	$arProp = $arItem['PROPERTIES'][$strProp];
	if (!empty($arProp['VALUE'])) {
		$arItem['ARTICLE_NAME'] = $arProp['NAME'];
		if (is_array($arProp['VALUE'])) {
			$arItem['ARTICLE'] = reset($arProp['VALUE']);
		} else {
			$arItem['ARTICLE'] = $arProp['VALUE'];
		}
	}
}

if (CModule::IncludeModule("catalog") && !empty($arResult['OFFERS']))
foreach($arResult['OFFERS'] as $key => $arOffer){
	if (!empty($arResult['ITEMS'][$key])){
		$arResult['ITEMS'][$key]['MIN_PRICE']  = $arOffer['MIN_PRICE'];
	}
}

foreach ($arTmpProps as $propCode => $arValues) {
	if (count($arValues) <= 1) {
		unset($arResult['SHOW_PROPERTIES'][$propCode]);
	}
}
unset($arItem, $arTmpProps);

$arParams['USE_FAVORITE'] = Loader::includeModule('yenisite.favorite');

if (Loader::includeModule('yenisite.infoblockpropsplus')) {
	$ar = CYenisiteInfoblockpropsplus::GetInitArray(array('IBLOCK_ID' => $arParams['IBLOCK_ID'], 'SECTION_ID' => 0));
	foreach ($ar['PROPS_TO_GROUPS'] as $group) {
		$firstInGroup = true;
		foreach ($group as $link) {
			if (empty($link['PROPERTY_ID']) || !isset($arResult['PROPS_WITHOUT_GROUPS'][$link['PROPERTY_ID']])) continue;
			if ($firstInGroup) {
				$firstInGroup = false;
				$arResult['SHOW_PROPERTIES'][$link['GROUP_ID']] = array('GROUP_NAME' => $link['GROUP_NAME']);
			}
			$propCode = $arResult['PROPS_WITHOUT_GROUPS'][$link['PROPERTY_ID']];
			$arProp = $arResult['SHOW_PROPERTIES'][$propCode];
			unset($arResult['SHOW_PROPERTIES'][$propCode]);
			unset($arResult['PROPS_WITHOUT_GROUPS'][$link['PROPERTY_ID']]);
			$arResult['SHOW_PROPERTIES'][$propCode] = $arProp;
			$arResult['HAS_GROUPS'] = true;
		}
	}
}