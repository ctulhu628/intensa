<? use Yenisite\Furniture\Main;
use Yenisite\Core\Ajax;
use Yenisite\Core\Tools;
use Yenisite\Furniture\Form;

/**
 * @var CMain $APPLICATION
 * @var CUser $USER
 * @var array $arParams
 * @var array $arResult
 */
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

$isAjax = Tools::isAjax();
$ajaxID = $arParams['AJAX_ID'];
if (!$isAjax || !empty($_REQUEST['TAB_ID'])) {
    Ajax::saveParams($this, $arParams, $ajaxID);
}
$bPhoto = false;
$search = array_search('PERSONAL_PHOTO', $arParams['PARAMS']);
if ($search !== false) {
    $bPhoto = true;
    unset($arParams['PARAMS'][$search], $search);
}
\Bitrix\Main\Localization\Loc::loadMessages($_SERVER['DOCUMENT_ROOT'] . SITE_TEMPLATE_PATH . '/lang/' . LANGUAGE_ID . '/header.php');
$pathToRules = COption::GetOptionString(\Yenisite\Furniture\Settings::getModuleId(), 'path_tu_rules_privacy', SITE_DIR . 'personal/rules/personal_data.php');
?>
<? if (!$isAjax || !empty($_REQUEST['TAB_ID'])): ?>
<form action="<?= $arResult["FORM_TARGET"] ?>" name="form1" method="post"
      class="with-edit ajax-form" <? Ajax::printAjaxDataAttr($this, $ajaxID) ?>
      enctype="multipart/form-data">
    <? endif ?>
    <input type="hidden" name="privacy_policy" value="N"/>
    <?= $arResult["BX_SESSION_CHECK"] ?>
    <input type="hidden" name="lang" value="<?= LANG ?>"/>
    <input type="hidden" name="ID" value="<?= $arResult["ID"] ?>"/>
    <input type="hidden" name="save" value="Y"/>
    <input type="hidden" name="LOGIN" value="<?= $arResult["arUser"]['LOGIN'] ?>"/>
    <div class="row">
        <div class="col-md-5">
            <? if (!in_array('EMAIL', $arParams['PARAMS'])): ?>
                <input type="hidden" name="EMAIL" value="<?= $arResult["arUser"]['EMAIL'] ?>"/>
            <? endif ?>
            <? if (!empty($arResult["strProfileError"])) {
                Main::ShowMessage($arResult["strProfileError"], Main::MSG_TYPE_ERROR);
            } ?>
            <?
            if ($arResult['DATA_SAVED'] == 'Y') {
                Main::ShowMessage(GetMessage('PROFILE_DATA_SAVED'), Main::MSG_TYPE_SUCCESS);
            }
            ?>
            <? foreach ($arParams['PARAMS'] as $code): ?>
                <? if (strlen(trim($code)) <= 0) continue; ?>
                <label class="form-group">
                    <span class="profile__helper-text"><?= GetMessage("RZ_AUTH_" . $code) ?>:</span>
                    <? switch ($code):
                        case 'NEW_PASSWORD_CONFIRM':
                        case 'NEW_PASSWORD': ?>
                            <input type="password" name="<?= $code ?>" maxlength="50" value="" class="form-control"/>
                            <? break;
                        default:
                            ?>
                            <input type="text" name="<?= $code ?>" maxlength="50"
                                   value="<?= $arResult["arUser"][$code] ?>"
                                   class="form-control"/>
                        <? endswitch ?>
                </label>
            <? endforeach ?>
            <? /* todo: add city to fields
					<div class="account__city-select">
						<span class="account__helper-text"><?= GetMessage('RZ_CITY_TEXT') ?>:</span>
						<a href="#" class="account__city-select-btn" data-toggle="modal"
						   data-target="#modal-city"><?= GetMessage('RZ_CITY_NAME') ?></a>
						<button data-content="_/modals/modal_city.html" class="btn-edit flaticon-pen31" type="button"
								title="<?= GetMessage('RZ_CHANGE_CITY') ?>" data-toggle="modal" data-target="#modal-city"></button>
						<div>
							<button class="btn btn-primary" type="button"><?= GetMessage('RZ_SAVE_CHANGES') ?></button>
						</div>
					</div>
			*/ ?>
        </div>

        <? if ($bPhoto): ?>
            <div class="col-md-offset-1 col-md-5">
                <span class="profile__helper-text"><?= GetMessage('RZ_PROFILE_PHOTO') ?>:</span>
                <div>
                    <?
                    $noPhotoSRC = $_SERVER['DOCUMENT_ROOT'] . BX_ROOT . '/templates/romza_bbsauto/img/no_photo/no-avatar.png';
                    $userPhoto = Main::GetResizedImg($USER->GetParam("PERSONAL_PHOTO"),
                        array('WIDTH' => 180, 'HEIGHT' => 180, 'SET_ID' => $arParams['RESIZER_PERSONAL_BIG_AVATAR']), $noPhotoSRC);
                    ?>
                    <? /* todo: self photo uploader
			<div class="account__profile-photo-wrap">
				<div class="account__profile-photo">
					<input type="file" class="hidden" id="account-photo-input">
					<button class="account__action-btn action-delete flaticon-trash30" type="button"
							title="<?= GetMessage('RZ_DELETE_PHOTO') ?>" data-tooltip></button>
					<label for="account-photo-input" class="account__action-btn action-edit flaticon-pen31"
						   title="<?= GetMessage('RZ_EDIT_PHOTO') ?>" data-tooltip></label>
					<img src="<?= $userPhoto ?>" alt="<?= GetMessage('RZ_PROFILE_PHOTO') ?>">
				</div>
			</div>
			*/ ?>
                    <?= \Bitrix\Main\UI\FileInput::createInstance(array(
                        "name" => "PERSONAL_PHOTO",
                        "description" => false,
                        "upload" => true,
                        "allowUpload" => "I",
                        "medialib" => false,
                        "fileDialog" => true,
                        "cloud" => false,
                        "edit" => true,
                        "delete" => true,
                        "maxCount" => 1,
                    ))->show($USER->GetParam("PERSONAL_PHOTO"));
                    ?>
                </div>
            </div>
        <? endif ?>
    </div>
    <div class="row">
        <div class="col-md-12">
            <?
            $text = GetMessage('RZ_RULES_YA') . ' ';
            $text .= GetMessage('RZ_ACCEPT') . " <a href='" . $pathToRules . "' target='_blank' class='classic-link'>" . GetMessage('RZ_CONCLUSION') . "</a>";
            Form::printElement(
                array(
                    'NAME' => 'PRIVACY_POLICY',
                    'CHECKED' => $_POST['PRIVACY_POLICY'] == 'Y',
                    'TEXT' => $text,
                    'REQ' => true,
                    'INDEX' => ++$tabIndex,
                ), Form::TYPE_CHECKBOX
            );
            ?>
        </div>
        <div class="col-md-5">
            <button class="btn btn-lg btn-primary" type="submit" name="save"
                    value="Y"><?= GetMessage('RZ_SAVE_CHANGES') ?></button>
        </div>
    </div>
    <? if (!$isAjax || !empty($_REQUEST['TAB_ID'])): ?>
</form>
<? else: die();
endif ?>
