<?
$MESS['PROFILE_DATA_SAVED'] = 'Изменения сохранены';
$MESS['RZ_SAVE_CHANGES'] = 'Сохранить изменения';

$MESS['RZ_AUTH_LOGIN'] = 'Логин';
$MESS['RZ_AUTH_EMAIL'] = 'Ваш e-mail';
$MESS['RZ_AUTH_NEW_PASSWORD'] = 'Сменить пароль';
$MESS['RZ_AUTH_NEW_PASSWORD_CONFIRM'] = 'Повторите пароль';
$MESS['RZ_AUTH_NAME'] = 'Имя';
$MESS['RZ_AUTH_LAST_NAME'] = 'Фамилия';
$MESS['RZ_AUTH_PERSONAL_PHONE'] = 'Телефон';

$MESS['RZ_PROFILE_PHOTO'] = 'Фото профиля';
$MESS['RZ_DELETE_PHOTO'] = 'Удалить фото';
$MESS['RZ_EDIT_PHOTO'] = 'Изменить фото';