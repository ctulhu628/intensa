<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
$this->setFrameMode(true);
if (empty($arResult['ITEMS'])) return;
?>

<? foreach ($arResult['ITEMS'] as &$arItem): ?>
  <!-- slider-->
  <section class="block-padd">
    <div class="container">
      <div class="h4"><?= $arItem['NAME'] ?></div>
      <div class="pagewside-content mb-4">
        <div class="text-content">
          <p><?= $arItem['PREVIEW_TEXT'] ?></p>
        </div>
      </div>
      <div class="swiper-container nportfolio-sl">
        <div class="swiper-wrapper">
          <?php foreach ($arItem['DISPLAY_PROPERTIES']['gallery']['FILE_VALUE'] as $image): ?>
          <!-- el-->
          <div class="swiper-slide nportfolio-sl-el"><a class="nportfolio-sl-link" href="<?= $image['SRC'] ?>" data-fancybox="pf_<?= $arItem['ID'] ?>" style="background-image: url('<?= $image['SRC'] ?>');"></a></div>
          <!-- /el-->
          <?php endforeach ?>
        </div>
        <div class="swiper-button swiper-button-prev"></div>
        <div class="swiper-button swiper-button-next"></div>
      </div>
    </div>
  </section>
  <!-- /slider-->
<? endforeach;
unset($arItem) ?>