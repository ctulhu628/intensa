<?
/**
 * @var CBitrixComponentTemplate $this
 * @var array $arResult
 * @var array $arParams
 */
use Yenisite\Furniture\Main;

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
if (empty($arResult['ITEMS'])) return;


$resizeThumb = array('WIDTH' => 38, 'HEIGHT' => 38, 'SET_ID' => $arParams['RESIZER_THUMB']);
$resizeItem = array('WIDTH' => 233, 'HEIGHT' => 218, 'SET_ID' => $arParams['RESIZER_IMAGE']);
$arParams['OFFER_TREE_PROPS'] = $arParams['OFFERS_PROPERTY_CODE'];
if (CModule::IncludeModule("catalog"))
Main::prepareSku($arResult, $arParams);

$arParamsCatalog = \Yenisite\Core\Ajax::getParams('bitrix:catalog', 'bitrix_catalog', '',SITE_ID);
$arParams['PRODUCT_PROPERTIES'] = array_merge($arParams['PRODUCT_PROPERTIES'], $arParamsCatalog['PRODUCT_PROPERTIES']);
$arParams['OFFERS_CART_PROPERTIES'] = array_merge($arParams['OFFERS_CART_PROPERTIES'], $arParamsCatalog['OFFERS_CART_PROPERTIES']);

if ($arParams['SHOW_ARTICLE']) {
	$arParams['ARTICUL_PROP'] = $arParamsCatalog['ARTICUL_PROP'] ? : 'ARTICLE';
}

if (CModule::IncludeModule('yenisite.furniturelite') && CModule::IncludeModule('yenisite.market'))
	$arResult['CHECK_QUANTITY'] = (CMarketCatalog::UsesQuantity($arParams['IBLOCK_ID']) == 1);

foreach ($arResult['ITEMS'] as &$arItem) {
	
	if (CModule::IncludeModule('yenisite.furniturelite') && CModule::IncludeModule('yenisite.market')) {

		$valueMeasure = CMarketCatalogProperties::getPropertyValueElement($arItem['IBLOCK_ID'], $arItem['ID'], "MEASURE_NAME");
		if(!empty($valueMeasure['VALUE_ENUM'])) $arItem['CATALOG_MEASURE_NAME'] = $valueMeasure['VALUE_ENUM'];
	
		$prices = CMarketPrice::GetItemPriceValues($arItem['ID'], $arItem['PRICES']);
		if (count($prices) > 0) {
			unset($arItem['PRICES']);
		}
		$minPrice = false;
		foreach ($prices as $k => $pr) {
			$pr = floatval($pr);
			$arItem['PRICES'][$k]['VALUE'] = $pr;
			$arItem['PRICES'][$k]['PRINT_VALUE'] = $pr;
			if ((empty($minPrice) || $minPrice > $pr) && $pr > 0) {
				$minPrice = $pr;
			}
		}
		if ($minPrice !== false) {
		
			$minPrice = Main::getElementPriceFormat($arItem['MIN_PRICE']['CURRENCY'], $minPrice, $arItem['MIN_PRICE']['PRINT_VALUE']);
		
			$arItem['MIN_PRICE']['VALUE'] = $minPrice;
			$arItem['MIN_PRICE']['PRINT_VALUE'] = $minPrice;
			$arItem['MIN_PRICE']['DISCOUNT_VALUE'] = $minPrice;
			$arItem['MIN_PRICE']['PRINT_DISCOUNT_VALUE'] = $minPrice;
			$arItem['CATALOG_MEASURE_RATIO'] = 1;
			$arItem['CAN_BUY'] = true;
		}
		$arItem['CHECK_QUANTITY'] = $arResult['CHECK_QUANTITY'];
		$arItem['CATALOG_QUANTITY'] = CMarketCatalogProduct::GetQuantity($arItem['ID'], $arItem['IBLOCK_ID']);
		
		if ($arItem['CHECK_QUANTITY'] && $arItem['CATALOG_QUANTITY'] <= 0) {
			$arItem['CAN_BUY'] = false;
		}
		$arItem['CATALOG_TYPE'] = 1; //simple product		
		
	}

	if ($arParams['SHOW_ARTICLE']) {
		$arItem['ARTICLE'] = '';
		$arItem['ARTICLE_NAME'] = GetMessage('RZ_ARTICLE_NAME');
		$strProp = 'CML2_ARTICLE';
		if (!empty($arParams['ARTICUL_PROP']) && $arParams['ARTICUL_PROP'] != '-') {
			$strProp = $arParams['ARTICUL_PROP'];
		}
		$arProp = $arItem['PROPERTIES'][$strProp];
		if (!empty($arProp['VALUE'])) {
			$arItem['ARTICLE_NAME'] = $arProp['NAME'];
			if (is_array($arProp['VALUE'])) {
				$arItem['ARTICLE'] = reset($arProp['VALUE']);
			} else {
				$arItem['ARTICLE'] = $arProp['VALUE'];
			}
		}
	}
	
	$arItem['GALLERY'] = Main::getGallery($arItem, array('THUMB' => $resizeThumb, 'SRC' => $resizeItem));
	$arItem['PHOTO'] = $arItem['GALLERY'][0]['SRC'];
	Main::processCatalogItem($arItem, $arParams['OFFERS_PROPERTY_CODE']);
	Main::preparePropsForCart($arItem, $arParams);

}
unset($arItem);


if(Main::isCatchBuy()){
	$arParams['CATCHBUY'] = Main::getCatchBuyList();
}

$arParams['USE_FAVORITE'] = \Bitrix\Main\Loader::includeModule('yenisite.favorite');