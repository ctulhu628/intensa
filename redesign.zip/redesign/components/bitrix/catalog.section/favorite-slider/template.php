<?
/**
 * @var CBitrixComponentTemplate $this
 */
use Bitrix\Main\Localization\Loc;
use Yenisite\Core\Ajax;
use Yenisite\Furniture\Main;

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
$isAjax = Ajax::isAjax();
if(!$isAjax || !empty($_REQUEST['TAB_ID'])) {
	$Parent = $this->__component->__parent;
	$ID = 'favorite_slider';
	Ajax::saveParams($Parent, $Parent->arParams, $ID);
}

if (empty($arResult['ITEMS'])) {
	Main::ShowMessage(GetMessage('RZ_NO_FAVORITE_ITEMS'), Main::MSG_TYPE_WARNING);
	return;
}
Loc::loadLanguageFile($_SERVER['DOCUMENT_ROOT'] . SITE_TEMPLATE_PATH . '/catalog.php');
?>
<? if (!$isAjax || !empty($_REQUEST['TAB_ID'])): ?>
<div class="special-offers-content" id="<?= $ID ?>" <? Ajax::printAjaxDataAttr($Parent->__template, $ID) ?>>
<? endif ?>
	<div class="item-frame">
		<div class="items-gallery">
			<?
			foreach ($arResult['ITEMS'] as &$arItem) {
				include 'item.php';
			}
			unset($arItem);
			?>
		</div>
	</div>
	<div class="pages-wrap">
		<button class="prevPage three-color-p flaticon-left207">
			<span class="cbutton cbutton--effect-lazar cbutton--effect-lazar-inverted"></span>
		</button>
		<div class="nums"><span class="num-current"></span> / <span class="num-total"></span></div>
		<ul class="pages">
			<li></li>
		</ul>
		<button class="nextPage three-color-p flaticon-right218"><span class="cbutton cbutton--effect-lazar"></span></button>
	</div><!-- pages-wrap -->
<? if (!$isAjax || !empty($_REQUEST['TAB_ID'])): ?>
</div>
<? endif ?>