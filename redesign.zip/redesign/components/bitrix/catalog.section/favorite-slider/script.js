/*$(function ($) {
	var $body = $(document.body),
		$favSlider = $('#favorite_slider');
	if ($favSlider.length) {
		$body.on('update_favorite', function (e) {
			var data = {ajax: $favSlider.data('ajax')};
			$favSlider.startAjax();
			$.ajax({
				url: AJAX_DIR + 'main.php',
				data: data,
				success: function (msg) {
					$favSlider.html(msg);
					$favSlider.refreshForm();
					$favSlider.updateFavCompare();
					initHSly($favSlider.find('.item-frame'));
					var $alert = $favSlider.find('.alert');
					if ($alert.length) {
						$alert.css('width', '100%');
					}
					initLazy();
					$favSlider.stopAjax();
				}
			})
		});
	}
});
*/