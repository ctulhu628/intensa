<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
$this->setFrameMode(true);
if (empty($arResult['ITEMS'])) return;
?>

<!-- portfolio-->
<section class="block-padd">
  <div class="container">
    <div class="nportfolio">
    <? foreach ($arResult['ITEMS'] as &$arItem): ?>
    <?/* var_dump($arItem) */?>
      <!-- el-->
      <div class="nportfolio-item">
        <div class="nportfolio-head">
          <div class="nportfolio-head-img"><img src="<?= $arItem['PREVIEW_PICTURE']['SRC'] ?>" alt=""></div>
          <div class="nportfolio-head-content">
            <div class="nportfolio-head-name"><?= $arItem['NAME'] ?></div>
            <div class="nportfolio-head-text">
              <p><?= $arItem['PREVIEW_TEXT'] ?></p>
            </div>
          </div>
        </div>
        <div class="swiper-container nportfolio-sl">
          <div class="swiper-wrapper">
            <?php foreach ($arItem['DISPLAY_PROPERTIES']['gallery']['FILE_VALUE'] as $image): ?>
            <!-- el-->
            <div class="swiper-slide nportfolio-sl-el"><a class="nportfolio-sl-link" href="<?= $image['SRC'] ?>" data-fancybox="pf_<?= $arItem['ID'] ?>" style="background-image: url('<?= $image['SRC'] ?>');"></a></div>
            <!-- /el-->
            <?php endforeach ?>
          </div>
          <div class="swiper-button swiper-button-prev"></div>
          <div class="swiper-button swiper-button-next"></div>
        </div>
      </div>
      <!-- /el-->
    <? endforeach;
    unset($arItem) ?>
    </div>
    <?= $arResult['NAV_STRING'] ?>
  </div>
</section>
<!-- /portfolio-->
