<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
$this->setFrameMode(true);
if (empty($arResult['ITEMS'])) return;
?>

<? foreach ($arResult['ITEMS'] as &$arItem): ?>
<?/* var_dump($arItem) */?>
  <!-- el-->
  <div class="swiper-slide staff-sl-el">
    <div class="staff-sl-body">
      <div class="staff-sl-img" style="background-image: url('<?= $arItem['PREVIEW_PICTURE']['SRC'] ?>');"></div>
      <div class="staff-sl-name"><?= $arItem['NAME'] ?></div>
      <div class="staff-sl-post"><?= $arItem['PREVIEW_TEXT'] ?></div>
    </div>
  </div>
  <!-- /el-->
<? endforeach;
unset($arItem) ?>