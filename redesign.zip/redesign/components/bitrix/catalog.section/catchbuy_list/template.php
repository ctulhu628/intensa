<?
/**
 * @var CBitrixComponentTemplate $this
 */
use Bitrix\Main\Localization\Loc;

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
$this->setFrameMode(true);
if (empty($arResult['ITEMS'])) return;
Loc::loadLanguageFile($_SERVER['DOCUMENT_ROOT'] . SITE_TEMPLATE_PATH . '/catalog.php');
?>
<div class="special-offers-global-wrap hot-sale">
	<div class="pseudo-h2 text-center">
		<div class="svg-wrap">
			<svg xmlns="http://www.w3.org/2000/svg">
				<use xlink:href="#hot-sale"></use>
			</svg>
		</div>
		<? if (!empty($arParams['CATCHBUY_TITLE'])): ?>
			<?= $arParams['CATCHBUY_TITLE'] ?>
		<? endif ?>
	</div>
	<div class="special-offers-content">
		<div class="item-frame">
			<div class="items-gallery">
				<?
				foreach ($arResult['ITEMS'] as &$arItem) {
					include 'item.php';
				}
				unset($arItem);
				?>
			</div>
		</div>
		<div class="pages-wrap">
			<button class="prevPage three-color-p flaticon-left207">
				<span class="cbutton cbutton--effect-lazar cbutton--effect-lazar-inverted"></span>
			</button>
			<div class="nums"><span class="num-current"></span> / <span class="num-total"></span></div>
			<ul class="pages">
				<li></li>
			</ul>
			<button class="nextPage three-color-p flaticon-right218"><span class="cbutton cbutton--effect-lazar"></span></button>
		</div><!-- pages-wrap -->
	</div><!-- special-offers-content -->
</div><!-- special-offers-global-wrap -->
