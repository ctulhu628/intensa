<?
/**
 * @var CBitrixComponentTemplate $this
 * @var array $arResult
 * @var array $arParams
 */
use Yenisite\Furniture\Main;

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
if (empty($arResult['ITEMS'])) return;

$resizeItem = array('WIDTH' => 233, 'HEIGHT' => 218, 'SET_ID' => $arParams['RESIZER_IMAGE']);
$resizeThumb = array('WIDTH' => 38, 'HEIGHT' => 38, 'SET_ID' => $arParams['RESIZER_THUMB']);
$arParams['OFFER_TREE_PROPS'] = $arParams['OFFERS_PROPERTY_CODE'];
$arParamsCatalog = \Yenisite\Core\Ajax::getParams('bitrix:catalog', 'bitrix_catalog', '',SITE_ID);
$arParams['PRODUCT_PROPERTIES'] = array_merge($arParams['PRODUCT_PROPERTIES'], $arParamsCatalog['PRODUCT_PROPERTIES']);
$arParams['OFFERS_CART_PROPERTIES'] = array_merge($arParams['OFFERS_CART_PROPERTIES'], $arParamsCatalog['OFFERS_CART_PROPERTIES']);

if ($arParams['SHOW_ARTICLE']) {
	$arParams['ARTICUL_PROP'] = $arParamsCatalog['ARTICUL_PROP'] ? : 'ARTICLE';
}

if (CModule::IncludeModule("catalog"))
Main::prepareSku($arResult, $arParams);

foreach ($arResult['ITEMS'] as $key => &$arItem) {
	if (!$arItem['CAN_BUY']) {
		unset ($arResult['ITEMS'][$key]);
		continue;
	}

	if ($arParams['SHOW_ARTICLE']) {
			$arItem['ARTICLE'] = '';
			$arItem['ARTICLE_NAME'] = GetMessage('RZ_ARTICLE_NAME');
			$strProp = 'CML2_ARTICLE';
			if (!empty($arParams['ARTICUL_PROP']) && $arParams['ARTICUL_PROP'] != '-') {
				$strProp = $arParams['ARTICUL_PROP'];
			}
			$arProp = $arItem['PROPERTIES'][$strProp];
			if (!empty($arProp['VALUE'])) {
				$arItem['ARTICLE_NAME'] = $arProp['NAME'];
				if (is_array($arProp['VALUE'])) {
					$arItem['ARTICLE'] = reset($arProp['VALUE']);
				} else {
					$arItem['ARTICLE'] = $arProp['VALUE'];
				}
			}
	}
	$arItem['GALLERY'] = Main::getGallery($arItem, array('THUMB' => $resizeThumb, 'SRC' => $resizeItem));
	$arItem['PHOTO'] = $arItem['GALLERY'][0]['SRC'];
	Main::processCatalogItem($arItem, $arParams['OFFERS_PROPERTY_CODE']);
	Main::preparePropsForCart($arItem, $arParams);
}
unset($arItem);

$arParams['USE_FAVORITE'] = \Bitrix\Main\Loader::includeModule('yenisite.favorite');