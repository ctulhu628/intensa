<?
/**
 * @var array $arResult
 * @var array $arParams
 * @var array $arItem
 * @var CBitrixComponentTemplate $this
 */
use Yenisite\Furniture\Form;
use Yenisite\Furniture\Main;
use Yenisite\Core\Tools;

$bHasSKU = !empty($arItem['OFFERS']);
$rnd = $this->randString();
$arIDs = array(
		'ITEM_GALLERY' => 'preview-item-carousel' . $arItem['ID'] . '_' . $rnd,
		'Q' => 'q_' . $arItem['ID'] . '_' . $rnd,
		'ARTICUL' => 'art_' . $arItem['ID'] . '_' . $rnd,
);
$bMorePhoto = count($arItem['GALLERY']) > 1;

$arCatchBuy = $arParams['CATCHBUY'][$arItem['ID']];
$bTimer = !empty($arCatchBuy['ACTIVE_TO']);
$bProgressBar = $arCatchBuy['MAX_USES'] > 0;
$arCatchBuy['PERCENT'] = ($bProgressBar) ? $arCatchBuy['COUNT_USES']/$arCatchBuy['MAX_USES'] * 100 : 0;
?>
<div class="preview-item-wrap">
	<div class="preview-item complex<?= !$bMorePhoto ? ' no__photo-viewer' : '' ?>">
		<? if ($bMorePhoto): ?>
		<div class="preview-item__photo-viewer sku-active">
			<div class="carousel slide preview-item-carousel" id="<?= $arIDs['ITEM_GALLERY'] ?>" data-interval="false">
				<a href="<?= $arItem['DETAIL_PAGE_URL'] ?>" class="carousel-inner">
					<? foreach ($arItem['GALLERY'] as $key => $arPhoto): ?>
						<div class="item<?= ($key == 0) ? ' active' : '' ?>">
							<img src="<?=SITE_TEMPLATE_PATH.'/img/ring.gif'?>" data-original="<?= $arPhoto['SRC'] ?>" class="preview-item-carousel-image <?= ($key == 0) ? ' lazy' : ' lazy-carousel' ?>" alt="<?= $arItem['NAME'] ?>">
						</div>
					<? endforeach ?>
				</a>
				<? if ($arItem['ARTICLE']): ?>
					<span id="<?=$arIDs['ARTICUL']?>" class="art"><?= $arItem['ARTICLE_NAME'] ?>: <span class="value-art"><?= $arItem['ARTICLE'] ?></span></span>
				<? endif ?>
				<? $APPLICATION->IncludeComponent("yenisite:stickers", "corner", array(
					"ELEMENT" => $arItem,
					"STICKER_NEW" => $arParams['STICKER_NEW'],
					"STICKER_HIT" => $arParams['STICKER_HIT'],
					"TAB_PROPERTY_NEW" => $arParams['TAB_PROPERTY_NEW'],
					"TAB_PROPERTY_HIT" => $arParams['TAB_PROPERTY_HIT'],
					"TAB_PROPERTY_SALE" => $arParams['TAB_PROPERTY_SALE'],
					"TAB_PROPERTY_BESTSELLER" => $arParams['TAB_PROPERTY_BESTSELLER'],
					"MAIN_SP_ON_AUTO_NEW" => $arParams['MAIN_SP_ON_AUTO_NEW'],
					"SHOW_DISCOUNT_PERCENT" => $arParams['SHOW_DISCOUNT_PERCENT'],
				),
					$component, array("HIDE_ICONS" => "Y")
				); ?>
				<? //todo: include '_/html/buttons/btn-quick-view.php'; ?>
				<div class="add-buttons no-text no-border">
					<? if ($arParams['USE_FAVORITE']): ?>
						<button class="add to-favorites addable flaticon-heart296 action-btn favorite-<?= $arItem['ID'] ?>"
								data-id="<?= $arItem['ID'] ?>">
							<span class="add-text"><?= GetMessage('RZ_FAVORITE_ADD') ?></span>
							<span class="added-text"><?= GetMessage('RZ_FAVORITE_DELETE') ?></span>
							<span class="cbutton cbutton--effect-nikola"></span>
						</button><!-- add.to-favorites -->
					<? endif ?>
					<button class="add to-comparison addable flaticon-right130 action-btn compare-<?= $arItem['ID'] ?>"
							data-id="<?= $arItem['ID'] ?>">
						<span class="add-text"><?= GetMessage('RZ_COMPARE_ADD') ?></span>
						<span class="added-text"><?= GetMessage('RZ_COMPARE_DELETE') ?></span>
						<span class="cbutton cbutton--effect-nikola"></span>
					</button><!-- add.to-comparison -->
				</div><!-- add-buttons -->
			</div>
			<div class="thumbs">
				<div class="thumbs-wrap" data-breakpoint="0">
					<div>
						<? foreach ($arItem['GALLERY'] as $key => $arPhoto): ?>
							<div class="thumb<?= ($key == 0) ? ' active' : '' ?>"
								 data-target="#<?= $arIDs['ITEM_GALLERY'] ?>"
								 data-slide-to="<?= $key ?>">
								<img src="<?=SITE_TEMPLATE_PATH.'/img/ring.gif'?>" data-original="<?= $arPhoto['THUMB'] ?>" class="thumb-image lazy-thumb" alt="<?= $arItem['NAME'] ?>">
							</div>
						<? endforeach ?>
					</div>
				</div>
				<button class="thumbs-control up"><i class="flaticon-up151"></i></button>
				<button class="thumbs-control down"><i class="flaticon-down119"></i></button>
			</div>
		</div>
		<? else: ?>
		<div class="preview-item__photo-viewer">
			<div class="preview-item-carousel">
				<a href="<?= $arItem['DETAIL_PAGE_URL'] ?>" class="preview-item__image-link">
					<img src="<?=SITE_TEMPLATE_PATH.'/img/ring.gif'?>" data-original="<?= $arItem['GALLERY'][0]['SRC'] ?>" alt="" class="preview-item__image lazy">
				</a>
				<? if ($arItem['ARTICLE']): ?>
					<span id="<?=$arIDs['ARTICUL']?>" class="art"><?= $arItem['ARTICLE_NAME'] ?>: <span class="value-art"><?= $arItem['ARTICLE'] ?></span></span>
				<? endif ?>
				<? $APPLICATION->IncludeComponent("yenisite:stickers", "corner", array(
					"ELEMENT" => $arItem,
					"STICKER_NEW" => $arParams['STICKER_NEW'],
					"STICKER_HIT" => $arParams['STICKER_HIT'],
					"TAB_PROPERTY_NEW" => $arParams['TAB_PROPERTY_NEW'],
					"TAB_PROPERTY_HIT" => $arParams['TAB_PROPERTY_HIT'],
					"TAB_PROPERTY_SALE" => $arParams['TAB_PROPERTY_SALE'],
					"TAB_PROPERTY_BESTSELLER" => $arParams['TAB_PROPERTY_BESTSELLER'],
					"MAIN_SP_ON_AUTO_NEW" => $arParams['MAIN_SP_ON_AUTO_NEW'],
					"SHOW_DISCOUNT_PERCENT" => $arParams['SHOW_DISCOUNT_PERCENT'],
				),
					$component, array("HIDE_ICONS" => "Y")
				); ?>
				<div class="add-buttons no-text no-border">
					<? if ($arParams['USE_FAVORITE']): ?>
						<button class="add to-favorites addable flaticon-heart296 action-btn favorite-<?= $arItem['ID'] ?>"
								data-id="<?= $arItem['ID'] ?>">
							<span class="add-text"><?= GetMessage('RZ_FAVORITE_ADD') ?></span>
							<span class="added-text"><?= GetMessage('RZ_FAVORITE_DELETE') ?></span>
							<span class="cbutton cbutton--effect-nikola"></span>
						</button><!-- add.to-favorites -->
					<? endif ?>
					<button class="add to-comparison addable flaticon-right130 action-btn compare-<?= $arItem['ID'] ?>"
							data-id="<?= $arItem['ID'] ?>">
						<span class="add-text"><?= GetMessage('RZ_COMPARE_ADD') ?></span>
						<span class="added-text"><?= GetMessage('RZ_COMPARE_DELETE') ?></span>
						<span class="cbutton cbutton--effect-nikola"></span>
					</button><!-- add.to-comparison -->
				</div><!-- add-buttons -->
				</div>
			</div>
		<?endif?>
		<div class="item-name">
			<div class="name-inner-wrap">
				<a href="<?= $arItem['DETAIL_PAGE_URL'] ?>" class="classic-link"><?= $arItem['NAME'] ?></a>
			</div>
		</div>
		<div class="preview-item__caption">
			<div class="caption-hidden">
				<?
				Form::printElement(array(
					'STEP' => $arItem['CATALOG_MEASURE_RATIO'],
					'DISABLED' => !$arItem['CAN_BUY'],
					'CLASS' => 'small',
					'ATTR' => 'id="' . $arIDs['Q'] . '"',
				), Form::TYPE_QUANTITY);
				$disabled = $arItem['CAN_BUY'] ? '' : ' disabled';
				?>
				<? if ($bHasSKU): ?>
					<a href="<?= $arItem['DETAIL_PAGE_URL'] ?>"
					   class="sku-section add-to-cart-small three-color-p<?= $disabled ?>"<?= $disabled ?>><?= GetMessage('RZ_CHOOSE_ITEM') ?></a>
				<? else: ?>
					<?if($arItem['CAN_BUY'] && Main::isOneClick()  && $arParams['SHOW_ONE_CLICK']):?>
						<span  data-toggle="modal" data-target="#modal-quick-order">
							<a href="#" data-name="<?=$arItem['NAME']?>" data-toggle="tooltip" data-placement="top" title="" data-original-title="<?=GetMessage('RZ_BUY_IN_ONE_CLICK')?>" data-props="<?= \Yenisite\Core\Tools::GetEncodedArParams($arParams['OFFER_TREE_PROPS']) ?>" data-id="<?= $arItem['ID'] ?>"  class="buy-one-click three-color-i tooltip-simple">
								<svg xmlns="http://www.w3.org/2000/svg">
									<use xlink:href="#buy-one-click"></use>
								</svg>
							</a>
						</span>
					<?endif?>
					<a href="<?= $arParams['BASKET_URL'] ?>" data-q="#<?= $arIDs['Q'] ?>"
					   data-props='<?=$arItem['CART_PROP']?>' data-id="<?= $arItem['ID'] ?>" data-toggle="tooltip" data-placement="top" title="" data-original-title="<?=GetMessage('RZ_IN_BASKET')?>"
					   class="add-to-cart-small three-color-p incart-<?= $arItem['ID'] ?><?= $disabled ?>"<?= $disabled ?>><svg xmlns="http://www.w3.org/2000/svg">
							<use xlink:href="#cart-add"></use>
						</svg></a>
				<? endif ?>
			</div><!-- caption-hidden -->
			<div class="price"><?= $arItem['MIN_PRICE']['PRINT_DISCOUNT_VALUE'] ?></div>
			<? if ($arItem['MIN_PRICE']['DISCOUNT_VALUE'] != $arItem['MIN_PRICE']['VALUE']): ?>
				<div class="old-price"><?= $arItem['MIN_PRICE']['PRINT_VALUE'] ?></div>
			<? endif ?>
			<? $frame = $this->createFrame()->begin(Main::insertCompositLoader()) ?>
			<? $APPLICATION->IncludeComponent("bitrix:iblock.vote", "section", array(
					"IBLOCK_TYPE" => $arParams['IBLOCK_TYPE'],
					"IBLOCK_ID" => $arParams['IBLOCK_ID'],
					"ELEMENT_ID" => $arItem['ID'],
					"CACHE_TYPE" => $arParams["CACHE_TYPE"],
					"CACHE_TIME" => $arParams["CACHE_TIME"],
					"MAX_VOTE" => "5",
					"VOTE_NAMES" => array("1", "2", "3", "4", "5"),
					"SET_STATUS_404" => "N",
			),
					$component, array("HIDE_ICONS" => "Y")
			); ?>
			<? $frame->end(); ?>
			<?if($bTimer || $bProgressBar):?>
				<div class="countdown-block">
					<?if($bTimer):?>
						<div class="countdown">
							<div class="chronometer">
								<svg xmlns="http://www.w3.org/2000/svg">
									<use xlink:href="#chronometer"></use>
								</svg>
							</div>
							<div class="timer" data-until="<?=str_replace('XXX', 'T', ConvertDateTime($arCatchBuy['ACTIVE_TO'], 'YYYY-MM-DDXXXhh:mm:ss'))?>"></div>
						</div>
					<?endif?>
					<?if($bProgressBar):?>
						<div class="already-sold">
							<span><span class="text"><?=intVal($arCatchBuy['PERCENT'])?>% </span><?=GetMessage('RZ_SOLD')?></span>
							<div class="already-sold-track">
								<div class="bar" style="width: <?=intVal($arCatchBuy['PERCENT'])?>%"></div>
							</div>
						</div>
					<?endif?>
				</div>
			<?endif?>
			<? /*
			<div class="caption__parameters">
				<span class="color-select-title">�����:</span>
				<? include "_/html/color-select-form.html"; ?>
				<? include "_/html/select-default.html"; ?>
			</div>
			*/ ?>
		</div><!-- preview-item__caption -->
	</div>
</div>