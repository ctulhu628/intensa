<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
$this->setFrameMode(true);
if (empty($arResult['ITEMS'])) return;
?>

<!-- goods hits-->
<section class="block-padd">
  <div class="container">
    <div class="ptitle row justify-content-center">
      <div class="col-auto">
        <div class="h2">Популярные товары</div>
      </div>
    </div>
    <div class="swiper-container goods-sl goods-slhits">
      <div class="swiper-wrapper">
		<?
		foreach ($arResult['ITEMS'] as &$arItem): ?>
			<?/* var_dump($arItem) */?>
        <!-- el-->
        <div class="swiper-slide goods-sl-el">
          <div class="ccard">
            <div class="ccard-body">
              <div class="marker">
              <?php if ($arItem['PROPERTIES']['NEW']['VALUE']): ?>
                <span class="new">new</span>
              <?php endif ?>
              <?php if ($arItem['PROPERTIES']['SALE']['VALUE']): ?>
                <span class="sale">sale</span>
              <?php endif ?>
              <?php if ($arItem['PROPERTIES']['HIT']['VALUE']): ?>
                <span class="hit">hit</span>
              <?php endif ?>
              </div>
              <a class="ccard-name" href="<?= $arItem['DETAIL_PAGE_URL'] ?>"><span><?= $arItem['NAME'] ?></span></a>
              <a class="ccard-img" href="<?= $arItem['DETAIL_PAGE_URL'] ?>"><img src="<?= $arItem['GALLERY'][0]['SRC'] ?>" alt=""></a>
              <div class="ccard-des">
                <?php if (!empty($arItem['PROPERTIES']['RAZMERY_SHXDXV']['VALUE'])): ?>
                  Размеры (ШxГxВ): <?= $arItem['PROPERTIES']['RAZMERY_SHXDXV']['VALUE'] ?>
                <?php else: ?>
                  &nbsp;
                <?php endif; ?>
              </div>
              <div class="ccard-price">
              <? if ($arItem['MIN_PRICE']['DISCOUNT_VALUE'] != $arItem['MIN_PRICE']['VALUE']): ?>
                <div class="ccard-price-old"><?= $arItem['MIN_PRICE']['PRINT_VALUE'] ?></div>
              <? endif ?>
                <div class="ccard-price-new">
                <?php if ($arItem['MIN_PRICE']['PRINT_DISCOUNT_VALUE'] == 'по запросу'): ?>Цена:<?php endif ?>
                <?= $arItem['MIN_PRICE']['PRINT_DISCOUNT_VALUE'] ?>
                </div>
              </div>
            </div>
            <div class="ccard-popup"><a class="mbtn mbtn-primary addcart" href="<?= $arItem['DETAIL_PAGE_URL'] ?>"><span>В&nbsp;корзину</span></a></div>
          </div>
        </div>
        <!-- /el-->
		<? endforeach;
		unset($arItem) ?>
      </div>
    </div>
    <div class="text-center pt-4 d-md-none"><a class="mbtn mbtn-brddark warrow-right" href="#"><span>Показать еще</span></a></div>
  </div>
</section>
<!-- /goods hits-->
