<?
$MESS['RZ_OPEN_ALL'] = 'Смотреть все';
$MESS['RZ_SOLD'] = 'продано';
$MESS['RZ_BUY_IN_ONE_CLICK'] = 'Купить в 1 клик';
$MESS['RZ_IN_BASKET'] = 'В корзину';
$MESS['RZ_ARTICLE_NAME'] = 'Артикул';
