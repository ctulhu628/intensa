<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
$this->setFrameMode(true);
if (empty($arResult['ITEMS'])) return;
?>

<!-- awards-->
<section class="block-padd">
  <div class="container">
    <div class="awards row">
    <? foreach ($arResult['ITEMS'] as &$arItem): ?>
      <!-- el-->
      <div class="awards-el col-12 col-sm-6 col-md-4 col-lg-3">
        <div class="awards-body" style="background-image: url('<?= $arItem['PREVIEW_PICTURE']['SRC'] ?>');"><a class="awards-link" href="<?= $arItem['PREVIEW_PICTURE']['SRC'] ?>" data-fancybox="awards"></a>
          <div class="awards-popup">
            <div class="awards-name"><?= $arItem['NAME'] ?></div>
            <div class="awards-title"><?= $arItem['PREVIEW_TEXT'] ?></div>
          </div>
        </div>
      </div>
      <!-- /el-->
    <? endforeach;
    unset($arItem) ?>
    </div>
  </div>
</section>
<!-- /awards-->
