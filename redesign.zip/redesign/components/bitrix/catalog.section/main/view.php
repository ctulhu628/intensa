<?
$arView = array(
		array('TITLE' => GetMessage('RZ_VIEW_TYPE_BLOCK'), 'TYPE' => 'blocks', 'CLASS' => 'flaticon-square234'),
		array('TITLE' => GetMessage('RZ_VIEW_TYPE_LIST'), 'TYPE' => 'list', 'CLASS' => 'flaticon-list50'),
		array('TITLE' => GetMessage('RZ_VIEW_TYPE_TABLE'), 'TYPE' => 'table', 'CLASS' => 'flaticon-listing1'),
);
?>
<ul class="view-type-switcher vav nav-pills pull-right" role="tablist">
	<? foreach ($arView as $arVal): ?>
		<li role="presentation" class="view-type-switcher-li<?= $arParams['VIEW_MODE'] == $arVal['TYPE'] ? ' active' : '' ?>">
			<a href="javascript:;" class="view-type-switch-btn block <?= $arVal['CLASS'] ?>" data-view="<?= $arVal['TYPE'] ?>">
			</a>
		</li>
	<? endforeach ?>
</ul><!-- view-type-switcher -->