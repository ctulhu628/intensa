<?
/**
 * @var array $arResult
 * @var array $arParams
 * @var array $arItem
 * @var CBitrixComponentTemplate $this
 */
use Yenisite\Furniture\Form;
use Yenisite\Furniture\Main;

$rnd = $this->randString();
?>
<div class="catalog-list tab-pane fade active in" id="list">
	<? foreach ($arResult['ITEMS'] as &$arItem): ?>
		<?
		$bHasSKU = !empty($arItem['OFFERS']);
		$arIDs = array(
				'ITEM_GALLERY' => 'preview-item-carousel' . $arItem['ID'] . '_' . $rnd,
				'Q' => 'q_' . $arItem['ID'] . '_' . $rnd,
				'ARTICUL' => 'art_' . $arItem['ID'] . '_' . $rnd,

		);
		$bMorePhoto = count($arItem['GALLERY']) > 1;

		$arCatchBuy = $arParams['CATCHBUY'][$arItem['ID']];
		$bTimer = !empty($arCatchBuy['ACTIVE_TO']);
		$bProgressBar = $arCatchBuy['MAX_USES'] > 0;

		if(!$arParams['SHOW_CATCH_BUY']) {
			$bTimer = false;
			$bProgressBar = false;
		};
		$arCatchBuy['PERCENT'] = ($bProgressBar) ? $arCatchBuy['COUNT_USES']/$arCatchBuy['MAX_USES'] * 100 : 0;
		?>
		<div class="catalog-item-list">
			<div class="row">
				<div class="col-sm-4 col-md-4 col-lg-3 col-xl-3 catalog-item__photo">
					<div class="preview-item__photo-viewer sku-active">
						<div class="carousel slide preview-item-carousel" id="<?= $arIDs['ITEM_GALLERY'] ?>" data-interval="false">
							<a href="<?= $arItem['DETAIL_PAGE_URL'] ?>" class="carousel-inner">
								<? foreach ($arItem['GALLERY'] as $key => $arPhoto): ?>
									<div class="item<?= ($key == 0) ? ' active' : '' ?>">
										<img src="<?=SITE_TEMPLATE_PATH.'/img/ring.gif'?>" data-original="<?= $arPhoto['SRC'] ?>" class="preview-item-carousel-image <?= ($key == 0) ? ' lazy' : ' lazy-carousel' ?>"
											 alt="<?= $arItem['NAME'] ?>">
									</div>
								<? endforeach ?>
							</a>
							<? $APPLICATION->IncludeComponent("yenisite:stickers", "corner", array(
									"ELEMENT" => $arItem,
									"STICKER_NEW" => $arParams['STICKER_NEW'],
									"STICKER_HIT" => $arParams['STICKER_HIT'],
									"TAB_PROPERTY_NEW" => $arParams['TAB_PROPERTY_NEW'],
									"TAB_PROPERTY_HIT" => $arParams['TAB_PROPERTY_HIT'],
									"TAB_PROPERTY_SALE" => $arParams['TAB_PROPERTY_SALE'],
									"TAB_PROPERTY_BESTSELLER" => $arParams['TAB_PROPERTY_BESTSELLER'],
									"MAIN_SP_ON_AUTO_NEW" => $arParams['MAIN_SP_ON_AUTO_NEW'],
									"SHOW_DISCOUNT_PERCENT" => $arParams['SHOW_DISCOUNT_PERCENT'],
							),
									$component, array("HIDE_ICONS" => "Y")
							); ?>
						</div>
						<? if ($bMorePhoto): ?>
							<div class="thumbs">
								<div class="thumbs-wrap" data-breakpoint="0">
									<div>
										<? foreach ($arItem['GALLERY'] as $key => $arPhoto): ?>
											<div class="thumb<?= ($key == 0) ? ' active' : '' ?>"
												 data-target="#<?= $arIDs['ITEM_GALLERY'] ?>"
												 data-slide-to="<?= $key ?>">
												<img src="<?=SITE_TEMPLATE_PATH.'/img/ring.gif'?>"data-original="<?= $arPhoto['THUMB'] ?>" class="thumb-image lazy-thumb" alt="<?= $arItem['NAME'] ?>">
											</div>
										<? endforeach ?>
									</div>
								</div>
								<button class="thumbs-control up"><i class="flaticon-up151"></i></button>
								<button class="thumbs-control down"><i class="flaticon-down119"></i></button>
							</div>
						<? endif ?>
					</div>
				</div>
				<div class="col-sm-5 col-md-5 col-lg-6 col-xl-6 catalog-item__info">
					<div class="item-link-wrap">
						<a href="<?= $arItem['DETAIL_PAGE_URL'] ?>" class="classic-link"><?= $arItem['NAME'] ?></a>
					</div>
					<? $frame = $this->createFrame()->begin(Main::insertCompositLoader()) ?>
					<? $APPLICATION->IncludeComponent("bitrix:iblock.vote", "section", array(
							"IBLOCK_TYPE" => $arParams['IBLOCK_TYPE'],
							"IBLOCK_ID" => $arParams['IBLOCK_ID'],
							"ELEMENT_ID" => $arItem['ID'],
							"CACHE_TYPE" => $arParams["CACHE_TYPE"],
							"CACHE_TIME" => $arParams["CACHE_TIME"],
							"MAX_VOTE" => "5",
							"VOTE_NAMES" => array("1", "2", "3", "4", "5"),
							"SET_STATUS_404" => "N",
					),
							$component, array("HIDE_ICONS" => "Y")
					); ?>
					<? $frame->end() ?>

					<? if ($arItem['ARTICLE']): ?>
						<span id="<?=$arIDs['ARTICUL']?>" class="art"><?= $arItem['ARTICLE_NAME'] ?>: <span class="value-art"><?= $arItem['ARTICLE'] ?></span></span>
					<? endif ?>

					<? if (!empty($arItem['PREVIEW_TEXT'])): ?>
						<p class="catalog-item-description"><?= $arItem['PREVIEW_TEXT'] ?></p>
					<? endif ?>
					<? if ($arItem['CAN_BUY'] && $arParams['SHOW_AMOUNT'] && !$bHasSKU): ?>
						<? 
						if (\CModule::IncludeModule("catalog"))
						$APPLICATION->IncludeComponent(
							"bitrix:catalog.store.amount",
							"detail",
							array(
								"STORES" => $arParams['STORES'],
								"ELEMENT_ID" => $arItem["ID"],
								'PARENT_ID' => $rnd. '_' .$arItem['ID'],
								"ELEMENT_CODE" => $arItem["CODE"],
								"CACHE_TYPE" => $arParams['CACHE_TYPE'],
								"CACHE_TIME" => $arParams['CACHE_TIME'],
								"FIELDS" => array(
									0 => "TITLE",
								),
								"SHOW_EMPTY_STORE" => $arParams["SHOW_EMPTY_STORE"] ?: 'Y',
								"USE_MIN_AMOUNT" => "Y",
								"SHOW_GENERAL_STORE_INFORMATION" => "N",
								"MIN_AMOUNT" => $arParams["MIN_AMOUNT"] ?: '100',
								"SHOW_NUMBERS" => $arParams["STORES_SHOW_NUMBERS"] ?: 'N',
								'STORES_COUNT' => $arParams['STORES_COUNT'],
								'SECTION_PAGE' => true
							),
							$component
						); ?>
					<?else:?>
						<div class="availability section-avaibility">
							<div class="availability-title"><?= GetMessage("RZ_NALICHIE") ?>:&nbsp;<b
									style="color:<?= $arItem['CAN_BUY'] ? '#137e23' : '#bd2020' ?>"><?= $arItem['CAN_BUY'] ? GetMessage('RZ_YES') : GetMessage('RZ_NO') ?></b>
							</div>
						</div>
					<? endif ?>
					<? /* todo: list view sku
					<div class="item-list-info"> ... </div>
					*/ ?>
				</div>
				<div class="col-sm-3 col-md-3 col-xl-3 catalog-item-buttons">
					<?if($bTimer || $bProgressBar):?>
						<div class="countdown-block">
							<?if($bTimer):?>
								<div class="countdown">
									<div class="chronometer">
										<svg xmlns="http://www.w3.org/2000/svg">
											<use xlink:href="#chronometer"></use>
										</svg>
									</div>
									<span><?=GetMessage('RZ_UNTIL_END')?>:</span>
									<div class="timer" data-until="<?=str_replace('XXX', 'T', ConvertDateTime($arCatchBuy['ACTIVE_TO'], 'YYYY-MM-DDXXXhh:mm:ss'))?>"></div>
								</div>
							<?endif?>
							<?if($bProgressBar):?>
								<div class="already-sold">
									<span><span class="text"><?=intVal($arCatchBuy['PERCENT'])?>% </span><?=GetMessage('RZ_SOLD')?></span>
									<div class="already-sold-track">
										<div class="bar" style="width: <?=intVal($arCatchBuy['PERCENT'])?>%"></div>
									</div>
								</div>
							<?endif?>
						</div>
					<?endif?>
					<div class="prices">
						<div class="price"><?= $arItem['MIN_PRICE']['PRINT_DISCOUNT_VALUE'] ?></div>
						<? if ($arItem['MIN_PRICE']['DISCOUNT_VALUE'] != $arItem['MIN_PRICE']['VALUE']): ?>
							<div class="old-price"><?= $arItem['MIN_PRICE']['PRINT_VALUE'] ?></div>
						<? endif ?>
					</div>
					<div class="add-buttons">
						<? if ($arParams['USE_FAVORITE']): ?>
							<button class="add to-favorites addable flaticon-heart296 action-btn favorite-<?= $arItem['ID'] ?>"
									data-id="<?= $arItem['ID'] ?>">
								<span class="add-text"><?= GetMessage('RZ_FAVORITE_ADD') ?></span>
								<span class="added-text"><?= GetMessage('RZ_FAVORITE_DELETE') ?></span>
								<span class="cbutton cbutton--effect-nikola"></span>
							</button><!-- add.to-favorites -->
						<? endif ?>
						<button class="add to-comparison addable flaticon-right130 action-btn compare-<?= $arItem['ID'] ?>"
								data-id="<?= $arItem['ID'] ?>">
							<span class="add-text"><?= GetMessage('RZ_COMPARE_ADD') ?></span>
							<span class="added-text"><?= GetMessage('RZ_COMPARE_DELETE') ?></span>
							<span class="cbutton cbutton--effect-nikola"></span>
						</button><!-- add.to-comparison -->
					</div><!-- add-buttons -->
					<?
					Form::printElement(array(
							'STEP' => $arItem['CATALOG_MEASURE_RATIO'],
							'DISABLED' => !$arItem['CAN_BUY'],
							'ATTR' => 'id="' . $arIDs['Q'] . '"',
					), Form::TYPE_QUANTITY);
					$disabled = $arItem['CAN_BUY'] ? '' : ' disabled';
					?>
					<? if ($bHasSKU): ?>
						<a href="<?= $arItem['DETAIL_PAGE_URL'] ?>"
						   class="btn-main sku-section	add-to-cart btn-primary add-to-cart-small<?= $disabled ?>"<?= $disabled ?>><span class="svg-wrap">
									<svg xmlns="http://www.w3.org/2000/svg">
										<use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#cart-add"></use>
									</svg>
								</span><?= GetMessage('RZ_CHOOSE_ITEM') ?></a>
					<? else: ?>
						<?if($arItem['CAN_BUY'] && Main::isOneClick() && $arParams['SHOW_ONE_CLICK']):?>
							<button data-name="<?=$arItem['NAME']?>" data-target="#modal-quick-order" data-toggle="modal"  data-props="<?= \Yenisite\Core\Tools::GetEncodedArParams($arParams['OFFER_TREE_PROPS']) ?>" data-id="<?= $arItem['ID'] ?>" class="btn-main	buy-one-click btn-secondary">
								<span class="svg-wrap">
									<svg xmlns="http://www.w3.org/2000/svg">
										<use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#buy-one-click"></use>
									</svg>
								</span>
							</button>
						<?endif?>
						   <button data-props='<?=$arItem['CART_PROP']?>' data-href="<?= $arParams['BASKET_URL'] ?>" data-q="#<?= $arIDs['Q'] ?>" data-id="<?= $arItem['ID'] ?>" data-toggle-text="<?= GetMessage('RZ_ALLREADY-IN-BASKET') ?>" data-text="<?= GetMessage('RZ_ADD-TO-BASKET') ?>" class="btn-main	add-to-cart btn-primary incart-<?= $arItem['ID'] ?><?= $disabled ?>">
								<span class="svg-wrap">
									<svg xmlns="http://www.w3.org/2000/svg">
										<use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#cart-add"></use>
									</svg>
								</span>
								<!--span class="text"><?//= GetMessage('RZ_ADD-TO-BASKET') ?></span-->
							</button>
					<? endif ?>
				</div>
			</div>
		</div>
	<? endforeach;
	unset($arItem) ?>
</div>