$(function ($) {
	var $body = $(document.body);
	var bTimer = false;
	var $catalogWrap = $('#catalog_wrapper');
	if ($catalogWrap.length > 0) {
		var changeFix = 1;
		var updateCatalog = function () {
			REQUEST_URI = removeParams(REQUEST_URI);
			var data = {'REQUEST_URI': REQUEST_URI + window.location.search};
			if (typeof FilterParams != 'undefined') {
				var UrlParams = window.location.search.length ? window.location.search + '&' + FilterParams : '?' + FilterParams;
			} else{
				var UrlParams = window.location.search.length ? window.location.search : '';
			}
			$catalogWrap.startAjax();
			return $.ajax({
				url: AJAX_DIR + 'catalog.php' + UrlParams,
				type: 'GET',
				data: data,
				success: function (msg) {
					if($('.countdown').length > 0) bTimer = true;
					bTimer ? $('.timer').countdown('destroy') : '';
					$catalogWrap.html(msg);
					$catalogWrap.find('.top-items').remove();
					$catalogWrap.refreshForm();
					$catalogWrap.updateBasketItems(); // /bitrix/templates/romza_stroymag/components/bitrix/sale.basket.basket.line/top/js/script.js
					$catalogWrap.updateFavCompare();
					initToggles(document);
					initTimers();
					initLazy();
					if ('rzCurSeoParams' in window && window.rzCurSeoParams) {
						if ('RZ_SEO_TOP' in window.rzCurSeoParams.SEO_TEXT) {
							$('.rz_description_top').html(window.rzCurSeoParams.SEO_TEXT.RZ_SEO_TOP);
						}
						if ('RZ_SEO_BOT' in window.rzCurSeoParams.SEO_TEXT) {
							$('.rz_description_bot').html(window.rzCurSeoParams.SEO_TEXT.RZ_SEO_BOT);
						}
					}
					$('.catalog-description').heightControl();
					$catalogWrap.stopAjax();
					changeFix = 1;
				}
			});
		};

		$catalogWrap.on('change', '.quantity-input', function (e) {
			var curVal = 0;
			$catalogWrap.find('.quantity-input').each(function () {
				curVal += parseInt($(this).val());
			});
			$('#catalog_affix_button').find('.catalog-table-chosen-quantity').text(curVal);
		});

		$body.on('click', '#catalog_affix_button', function (e) {
			var $affixBtn = $(this);
			$affixBtn.startAjax();
			var requests = [];
			var errors = [];
			$catalogWrap.find('.quantity-input').each(function () {
				var $this = $(this);
				if ($this.val() > 0) {
					var id = $this.data('id');
					requests.push($.ajax({
						url: AJAX_DIR + 'actions.php',
						dataType: 'json',
						data: {ACTION: 'ADD_TO_CART', ID: id, Q: $this.val(), PROPS: $this.data('props')},
						success: function (msg) {
							if (!msg.success) {
								errors.push(msg.message);
							} else{
								$('.amount.small .minus').addClass('disabled');
							}
						}
					}));
				}
			});
			$.when.apply($, requests).done(function () {
				$affixBtn.stopAjax();
				if (errors.length > 0) {
					rz_showMessage(errors.join('<br>'));
				}
				$body.trigger('update_basket');
				$("#catalog_wrapper .amount .quantity-input").each(function(){
					if($(this).val() != 0) $(this).val(0);		
				});
				$("#catalog_affix_button .catalog-table-chosen-quantity").first().text(0);
			});
		});

		$body.on('click', '.pagination a', function (e) {
			e.preventDefault();
			var $this = $(this);
			if (!$this.hasClass('disabled')) {
				addParameter($this.data('param'), $this.data('value'));
				updateCatalog();
				$catalogWrap.scrollToObj();
			}
			return false;
		});

		$body.on('click', '.view-type-switcher a', function (e,params) {
			params = params ? params : '';
			if (params.length && params == 'FRONT') return;
			var $this = $(this),
				val = $this.data('view');
			addParameter('view_mode', val);
			setCookie('VIEW_MODE', val);
			updateCatalog();
		});

		$catalogWrap.on('change', '.sort-by select', function () {
			var $this = $(this),
				val = $this.val();
			if (changeFix) {
				changeFix = 0;
				addParameter('catalog_sort', val);
				setCookie('CATALOG_SORT', val);
				updateCatalog();
			}
		});

		$catalogWrap.on('click', '.show-by input', function (e) {
			var $this = $(e.target),
				val = $this.val();

			if (changeFix) {
				changeFix = 0;
				addParameter('list_count', val);
				setCookie('LIST_COUNT', val);
				updateCatalog();
			}
		});

		$body.on('update_catalog', function () {
			updateCatalog();
		});
	}

	window.skuGalleryChange = function (el) {
		if ('GALLERY' in this && $.isArray(this.GALLERY)) {
			var activeCache = {};

			var templateIt = function (NAME, OBJ, template) {
				var result = '',
					SRC = 'SRC',
					THUMB = 'THUMB';

				if (NAME in el && el[NAME].length && SRC in OBJ && OBJ[SRC].length) {
					template = template.replace('#ACTIVE#', (activeCache[NAME]) ? '' : ' active');
					activeCache[NAME] = true;
					template = template.replace('#SRC#', OBJ[SRC]);
					if (THUMB in OBJ && OBJ[THUMB].length) {
						template = template.replace('#THUMB#', OBJ[THUMB]);
					}
					result += template;
				}
				return result;
			};
			var galThumb = '',
				galSrc = false,
				total = 0;
			this.GALLERY.forEach(function (obj) {
				galThumb += templateIt('GALLERY_THUMB', obj, '<div class="catalog-item-thumb#ACTIVE#" data-big="#SRC#"><img src="#THUMB#" alt=""></div>');
				if (!galSrc) {
					el.GALLERY_SRC.attr('src', obj.SRC);
					galSrc = true;
				}
				total++;
			});
			if (galThumb.length) {
				el.GALLERY_THUMB.html(galThumb);
			}
			var $thumbWrap = el.ITEM.find('.catalog-item-thumbs-wrap');
			if (total <= 1) {
				$thumbWrap.addClass('hidden');
			} else {
				$thumbWrap.removeClass('hidden');
			}
		}
	};
});