<?
use Yenisite\Furniture\Form;

$count = $count ? $count + 1 : 1;
?>
<div class="pageinformer-sort">
    <div class="pageinformer-sort-label">Сортировка</div>
    <div class="pageinformer-sort-select">
		<?
		foreach ($arParams['ARSORT'] as $key => &$value) {
			if ($arParams['CURSORT']['CURRENT'] == $key) {
				$value['CHECKED'] = 1;
			}
		}
		unset($value);
		Form::printElement(array('CLASS' => 'select-styled', 'VALUES' => $arParams['ARSORT']), Form::TYPE_SELECT);
		?>
	</div>
</div>
