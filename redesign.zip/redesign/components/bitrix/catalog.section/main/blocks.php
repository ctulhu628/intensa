<?
/**
 * @var array $arResult
 * @var array $arParams
 * @var array $arItem
 * @var CBitrixComponentTemplate $this
 */
?>
<div class="pagewside-content ml-auto">
    <div class="listcatalog row">
    <? foreach ($arResult['ITEMS'] as &$arItem): ?>
		<!-- el-->
	    <div class="listcatalog-el col-6 col-sm-6 col-md-4">
	      	<div class="ccard">
	            <div class="ccard-body">
	              	<div class="marker">
	              	<?php if ($arItem['PROPERTIES']['NEW']['VALUE']): ?>
	                	<span class="new">new</span>
	              	<?php endif ?>
	              	<?php if ($arItem['PROPERTIES']['SALE']['VALUE']): ?>
	                	<span class="sale">sale</span>
	              	<?php endif ?>
	              	<?php if ($arItem['PROPERTIES']['HIT']['VALUE']): ?>
	                	<span class="hit">hit</span>
	              	<?php endif ?>
	              	</div>
	              	<a class="ccard-name" href="<?= $arItem['DETAIL_PAGE_URL'] ?>"><span><?= $arItem['NAME'] ?></span></a>
	              	<a class="ccard-img" href="<?= $arItem['DETAIL_PAGE_URL'] ?>"><img src="<?= $arItem['GALLERY'][0]['SRC'] ?>" alt=""></a>
	              	<div class="ccard-des">
	                <?php if (!empty($arItem['PROPERTIES']['RAZMERY_SHXDXV']['VALUE'])): ?>
	                  	Размеры (ШxГxВ): <?= $arItem['PROPERTIES']['RAZMERY_SHXDXV']['VALUE'] ?>
                	<?php else: ?>
	                  	&nbsp;
	                <?php endif; ?>
	              	</div>
	              	<div class="ccard-price">
	              	<? if ($arItem['MIN_PRICE']['DISCOUNT_VALUE'] != $arItem['MIN_PRICE']['VALUE']): ?>
	                	<div class="ccard-price-old"><?= $arItem['MIN_PRICE']['PRINT_VALUE'] ?></div>
	              	<? endif ?>
	                	<div class="ccard-price-new">
	                		<?php if ($arItem['MIN_PRICE']['PRINT_DISCOUNT_VALUE'] == 'по запросу'): ?>Цена:<?php endif ?>
	                		<?= $arItem['MIN_PRICE']['PRINT_DISCOUNT_VALUE'] ?>
	                	</div>
	              	</div>
	            </div>
	            <div class="ccard-popup"><a class="mbtn mbtn-primary addcart" href="<?= $arItem['DETAIL_PAGE_URL'] ?>"><span>В&nbsp;корзину</span></a></div>
	        </div>
      	</div>
      	<!-- /el-->
	<? endforeach;
	unset($arItem) ?>
    </div>
</div>