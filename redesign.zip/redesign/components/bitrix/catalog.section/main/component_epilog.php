<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
global $rz_options;

if($rz_options['main_menu_position'] == 'at-vertical' && $rz_options['filter_position'] == 'horizontal'){ 
	$viewTarget = 'menu_header';
}
if($rz_options['main_menu_position'] == 'at-vertical' && $rz_options['filter_position'] != 'horizontal'){ 
	$viewTarget = 'menu_catalog';
}

$APPLICATION->SetPageProperty("prop_menu_catalog", $viewTarget);