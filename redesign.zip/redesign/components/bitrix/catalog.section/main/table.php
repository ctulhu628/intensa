<?
/**
 * @var array $arResult
 * @var array $arParams
 * @var array $arItem
 * @var CBitrixComponentTemplate $this
 */
use Yenisite\Furniture\Form;
use Yenisite\Furniture\Main;

$rnd = $this->randString();
?>
<div class="catalog-table tab-pane fade active in" id="table">
	<div class="put-all-in-cart">
		<div class="text">
			<?= GetMessage('RZ_BUY_ALL_TEXT') ?>
		</div>
		<div class="for-button">
			<button type="button" class="btn-main btn-secondary btn-put-all-in-cart" id="catalog_affix_button">
				<?= GetMessage('RZ_BUY_ALL_BUTTON') ?>&nbsp;(<span class="catalog-table-chosen-quantity">0</span>)
			</button>
		</div>
	</div>
	<div class="catalog-table-wrap">
		<? foreach ($arResult['ITEMS'] as &$arItem): ?>
			<?
			$bHasSKU = !empty($arItem['OFFERS']);
			$arIDs = array(
					'ITEM_GALLERY' => 'preview-item-carousel' . $arItem['ID'] . '_' . $rnd,
					'Q' => 'q_' . $arItem['ID'] . '_' . $rnd,
					'ARTICUL' => 'art_' . $arItem['ID'] . '_' . $rnd,
			);
			$bMorePhoto = count($arItem['GALLERY']) > 1;
			?>
			<div class="catalog-item-table-wrap">
				<div class="catalog-item-table clearfix">
					<div class="table-item-main-container">
						<? if ($arItem['CAN_BUY'] && $arParams['SHOW_AMOUNT'] && !$bHasSKU): ?>
							<? 
							if (\CModule::IncludeModule("catalog"))
							$APPLICATION->IncludeComponent(
								"bitrix:catalog.store.amount",
								"detail",
								array(
									"STORES" => $arParams['STORES'],
									"ELEMENT_ID" => $arItem["ID"],
									'PARENT_ID' => $rnd. '_' .$arItem['ID'],
									"ELEMENT_CODE" => $arItem["CODE"],
									"CACHE_TYPE" => $arParams['CACHE_TYPE'],
									"CACHE_TIME" => $arParams['CACHE_TIME'],
									"FIELDS" => array(
										0 => "TITLE",
									),
									"SHOW_EMPTY_STORE" => $arParams["SHOW_EMPTY_STORE"] ?: 'Y',
									"USE_MIN_AMOUNT" => "Y",
									"SHOW_GENERAL_STORE_INFORMATION" => "N",
									"MIN_AMOUNT" => $arParams["MIN_AMOUNT"] ?: '100',
									"SHOW_NUMBERS" => $arParams["STORES_SHOW_NUMBERS"] ?: 'N',
									'STORES_COUNT' => $arParams['STORES_COUNT'],
									'SECTION_PAGE' => true,
									'TABLE_SECTION' => true,
								),
								$component
							); ?>
						<?else:?>
							<div class="availability">
								<div class="availability-title"><?= GetMessage("RZ_NALICHIE") ?>:&nbsp;<b
										style="color:<?= $arItem['CAN_BUY'] ? '#137e23' : '#bd2020' ?>"><?= $arItem['CAN_BUY'] ? GetMessage('RZ_YES') : GetMessage('RZ_NO') ?></b>
								</div>
							</div>
						<? endif ?>
						<div class="name-block">
							<div class="item-link-wrap">
								<a href="<?= $arItem['DETAIL_PAGE_URL'] ?>" class="classic-link"><?= $arItem['NAME'] ?></a>
							</div>
							<? $frame = $this->createFrame()->begin(Main::insertCompositLoader()) ?>
							<? $APPLICATION->IncludeComponent("bitrix:iblock.vote", "section", array(
								"IBLOCK_TYPE" => $arParams['IBLOCK_TYPE'],
								"IBLOCK_ID" => $arParams['IBLOCK_ID'],
								"ELEMENT_ID" => $arItem['ID'],
								"CACHE_TYPE" => $arParams["CACHE_TYPE"],
								"CACHE_TIME" => $arParams["CACHE_TIME"],
								"MAX_VOTE" => "5",
								"VOTE_NAMES" => array("1", "2", "3", "4", "5"),
								"SET_STATUS_404" => "N",
							),
								$component, array("HIDE_ICONS" => "Y")
							); ?>
							<? $frame->end() ?>
							<? if ($arItem['ARTICLE']): ?>
								<span id="<?=$arIDs['ARTICUL']?>" class="art"><?= $arItem['ARTICLE_NAME'] ?>: <span class="value-art"><?= $arItem['ARTICLE'] ?></span></span>
							<? endif ?>
							<div class="name-block-photo-link">
								<img src="<?=SITE_TEMPLATE_PATH.'/img/ring.gif'?>" data-original="<?= $arItem['GALLERY'][0]['SRC'] ?>" class="name-block-photo lazy" alt="<?= $arItem['NAME'] ?>">
							</div>
						</div><!-- name-block -->
					</div>
					<div class="table-item-fixed-container">
						<div class="add-buttons no-text">
							<? if ($arParams['USE_FAVORITE']): ?>
								<button class="add to-favorites addable flaticon-heart296 action-btn favorite-<?= $arItem['ID'] ?>"
										data-id="<?= $arItem['ID'] ?>">
									<span class="add-text"><?= GetMessage('RZ_FAVORITE_ADD') ?></span>
									<span class="added-text"><?= GetMessage('RZ_FAVORITE_DELETE') ?></span>
									<span class="cbutton cbutton--effect-nikola"></span>
								</button><!-- add.to-favorites -->
							<? endif ?>
							<button class="add to-comparison addable flaticon-right130 action-btn compare-<?= $arItem['ID'] ?>"
									data-id="<?= $arItem['ID'] ?>">
								<span class="add-text"><?= GetMessage('RZ_COMPARE_ADD') ?></span>
								<span class="added-text"><?= GetMessage('RZ_COMPARE_DELETE') ?></span>
								<span class="cbutton cbutton--effect-nikola"></span>
							</button><!-- add.to-comparison -->
						</div><!-- add-buttons -->
						<?
						if ($bHasSKU):?>
							<div class="amount small">
								<a href="<?= $arItem['DETAIL_PAGE_URL'] ?>" class="btn-main btn-primary"><?= GetMessage('RZ_CHOOSE_ITEM') ?></a>
							</div>
						<? else : ?>
							<? Form::printElement(array(
								'STEP' => $arItem['CATALOG_MEASURE_RATIO'],
								'DISABLED' => !$arItem['CAN_BUY'] || $bHasSKU,
								'CLASS' => 'small',
								'VALUE' => '0',
								'ATTR' => 'data-props=\''.$arItem['CART_PROP'].'\' id="' . $arIDs['Q'] . '" data-id="' . $arItem['ID'] . '"',
							), Form::TYPE_QUANTITY);
						endif ?>
						<div class="prices">
							<div class="price"><?= $arItem['MIN_PRICE']['PRINT_DISCOUNT_VALUE'] ?></div>
							<? if ($arItem['MIN_PRICE']['DISCOUNT_VALUE'] != $arItem['MIN_PRICE']['VALUE']): ?>
								<div class="old-price"><?= $arItem['MIN_PRICE']['PRINT_VALUE'] ?></div>
							<? endif ?>
						</div>
					</div>
						<? /* todo: table view SKU and availability
						<div class="catalog-item__color-select">
							<div class="color-select-title">�����:</div>
							<? include "_/html/color-select-form.html"; ?>
						</div>
						<div class="availability">
							<span class="availability-text">����� �� <span class="stock">��������, 49�</span></span>
							<div class="on-stock">
								<div class="on-stock-stripes lots"></div>
							</div>
							<div class="item-link-wrap">
								<a href="#" class="choose-another action-link action-popover">������� ������</a>
								<? include "_/html/modal/popover-another-store.php"; ?>
							</div>
						</div><!-- availability -->
						*/ ?>
						<? /* todo: table view SKU and availability
						<div class="catalog-item-selectors">
							<? include "_/html/select-default.html"; ?>
							<select class="select-default cs-select cs-skin-elastic">
								<option value="choose">�������� ������������</option>
								<option value="1">�������� 1</option>
								<option value="2">�������� 2</option>
								<option value="3">�������� 3</option>
								<option value="4">�������� 4</option>
								<option value="5">�������� 5</option>
								<option value="6">�������� 6</option>
								<option value="7">�������� 7</option>
							</select>
						</div><!-- catalog-item-selectors -->
						*/ ?>
				</div>
			</div>
		<? endforeach;
		unset($arItem) ?>
	</div>
</div>