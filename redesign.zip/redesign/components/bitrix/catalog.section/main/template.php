<?
/**
 * @var CBitrixComponentTemplate $this
 * @var array $arResult
 * @var array $arParams
 */

use Yenisite\Furniture\Main;
use Yenisite\Core\Tools;
use \Yenisite\Furniture\Mobile;

global $rz_options;

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
$this->setFrameMode(true);
include 'get_cur_section.php';
$isAjax = \Yenisite\Core\Ajax::isAjax();
\Bitrix\Main\Localization\Loc::loadLanguageFile($_SERVER['DOCUMENT_ROOT'] . SITE_TEMPLATE_PATH . '/catalog.php');
?>

    <div class="pageinformer">
        <div class="row align-items-center">
            <div class="col-12 col-lg-4 d-none d-lg-block">&nbsp;</div>
            <div class="col-6 col-sm d-lg-none"><a class="pageinformer-filterlink" href="#"><span>Фильтр</span></a>
            </div>
            <div class="col-6 col-lg">
                <? include 'options-form.php' ?>
            </div>
            <div class="col-auto d-none d-lg-block">
                <div class="pageinformer-numgoods">
                    <?
                    $Nav = $arResult['NAV_RESULT'];
                    $PAGE_SIZE = $Nav->NavPageSize;
                    $PAGEN = $Nav->NavPageNomer;
                    $NavFirstRecordShow = ($Nav->NavPageNomer - 1) * $Nav->NavPageSize + 1;
                    if ($Nav->NavPageNomer != $Nav->NavPageCount) {
                        $NavLastRecordShow = $Nav->NavPageNomer * $Nav->NavPageSize;
                    } else {
                        $NavLastRecordShow = $Nav->NavRecordCount;
                    }
                    ?>
                    <? if (!empty($arResult['ITEMS'])): ?>
                        <?= GetMessage("RZ_TOVARI") ?>
                        <?= $NavFirstRecordShow ?>-<?= $NavLastRecordShow ?>
                        <?= GetMessage("RZ_IZ") ?> <?= $Nav->NavRecordCount ?>
                    <? else: ?>
                        &nbsp;
                    <? endif ?>
                </div>
            </div>
        </div>
    </div>
    <div class="pagewside">
        <div class="row">
            <div class="col-12 col-lg-3 d-none d-lg-block">
                <?php $APPLICATION->ShowViewContent('catalog_filter'); ?>
            </div>
            <div class="col-12 col-lg-9">

                <? if (empty($arParams['HIDE_SEBSECTIONS_DESC']) && $arParams['HIDE_SEBSECTIONS_DESC'] != 'Y'): ?>
                    <? include "section_list.php" ?>
                <? endif ?>

                <!-- catalog -->
                <? if (empty($arResult['ITEMS'])):
                    $arFilter = &$GLOBALS[$arParams['FILTER_NAME']];
                    if (is_array($arFilter) && !empty($arFilter)) {
                        Main::ShowMessage(GetMessage('RZ_NO_ITEMS_FILTERED'), Main::MSG_TYPE_WARNING, false);
                    } else {
                        Main::ShowMessage(GetMessage('RZ_NO_ITEMS'), Main::MSG_TYPE_WARNING, false);
                    }
                else: ?>
                    <? include $arParams['VIEW_MODE'] . '.php' ?>
                <? endif ?>
                <!-- /catalog -->

                <?= $arResult['NAV_STRING'] ?>
            </div>
        </div>
    </div>

<?
if ($rz_options['main_menu_position'] == 'at-vertical' && $rz_options['filter_position'] == 'horizontal') {
    $viewTarget = 'menu_header';
}
if ($rz_options['main_menu_position'] == 'at-vertical' && $rz_options['filter_position'] != 'horizontal') {
    $viewTarget = 'menu_catalog';
}

if ($viewTarget == 'menu_catalog') {
    $this->SetViewTarget($viewTarget);
    Tools::IncludeArea('header', 'menu_catalog');
    $this->EndViewTarget();
}
?>