<?
/**
 * @var CBitrixComponentTemplate $this
 * @var array $arResult
 * @var array $arParams
 */
use Yenisite\Furniture\Main;

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
if (empty($arResult['ITEMS'])) return;

$resizeThumb = array('WIDTH' => 38, 'HEIGHT' => 38, 'SET_ID' => $arParams['RESIZER_THUMB']);
$resizeItem = array('WIDTH' => 233, 'HEIGHT' => 218, 'SET_ID' => $arParams['RESIZER_IMAGE']);
$arResizer = array('THUMB' => $resizeThumb, 'SRC' => $resizeItem);
$arParams['OFFER_TREE_PROPS'] = &$arParams['OFFERS_CART_PROPERTIES'];
if (CModule::IncludeModule("catalog"))
Main::prepareSku($arResult, $arParams, $arResizer);

foreach ($arResult['ITEMS'] as &$arItem) {
	$arItem['GALLERY'] = Main::getGallery($arItem, $arResizer);
	$arItem['PHOTO'] = $arItem['GALLERY'][0]['SRC'];
	Main::processCatalogItem($arItem, $arParams['OFFERS_PROPERTY_CODE']);
	Main::preparePropsForCart($arItem, $arParams);

	$arItem['ARTICLE'] = '';
	$arItem['ARTICLE_NAME'] = GetMessage('RZ_ARTICLE_NAME');
	$strProp = 'CML2_ARTICLE';
	if (!empty($arParams['ARTICUL_PROP']) && $arParams['ARTICUL_PROP'] != '-') {
		$strProp = $arParams['ARTICUL_PROP'];
	}
	$arProp = $arItem['PROPERTIES'][$strProp];
	if (!empty($arProp['VALUE'])) {
		$arItem['ARTICLE_NAME'] = $arProp['NAME'];
		if (is_array($arProp['VALUE'])) {
			$arItem['ARTICLE'] = reset($arProp['VALUE']);
		} else {
			$arItem['ARTICLE'] = $arProp['VALUE'];
		}
	}
}
unset($arItem);

$arParams['USE_FAVORITE'] = \Bitrix\Main\Loader::includeModule('yenisite.favorite');

if(Main::isCatchBuy()){
	$arParams['CATCHBUY'] = Main::getCatchBuyList();
}

//Prices for MARKET
if (CModule::IncludeModule('yenisite.furniturelite') && CModule::IncludeModule('yenisite.market')) {
	$arResult['CHECK_QUANTITY'] = (CMarketCatalog::UsesQuantity($arParams['IBLOCK_ID']) == 1);
	foreach ($arResult['ITEMS'] as $key => &$arItem)
	{
		if(!empty($arItem['PROPERTIES']['MEASURE_NAME']['VALUE_ENUM'])) $arItem['CATALOG_MEASURE_NAME'] = $arItem['PROPERTIES']['MEASURE_NAME']['VALUE_ENUM'];
		$prices = CMarketPrice::GetItemPriceValues($arItem['ID'], $arItem['PRICES']);
		if (count($prices) > 0) {
			unset($arItem['PRICES']);
		}
		$minPrice = false;
		foreach ($prices as $k => $pr) {
			$pr = floatval($pr);
			$arItem['PRICES'][$k]['VALUE'] = $pr;
			$arItem['PRICES'][$k]['PRINT_VALUE'] = $pr;
			if ((empty($minPrice) || $minPrice > $pr) && $pr > 0) {
				$minPrice = $pr;
			}
		}
		if ($minPrice !== false) {
		
			$minPrice = Main::getElementPriceFormat($arItem['MIN_PRICE']['CURRENCY'], $minPrice, $arItem['MIN_PRICE']['PRINT_VALUE']);
		
			$arItem['MIN_PRICE']['VALUE'] = $minPrice;
			$arItem['MIN_PRICE']['PRINT_VALUE'] = $minPrice;
			$arItem['MIN_PRICE']['DISCOUNT_VALUE'] = $minPrice;
			$arItem['MIN_PRICE']['PRINT_DISCOUNT_VALUE'] = $minPrice;
			$arItem['CATALOG_MEASURE_RATIO'] = 1;
			$arItem['CAN_BUY'] = true;
		}
		$arItem['CHECK_QUANTITY'] = $arResult['CHECK_QUANTITY'];
		$arItem['CATALOG_QUANTITY'] = CMarketCatalogProduct::GetQuantity($arItem['ID'], $arItem['IBLOCK_ID']);
		
		if ($arItem['CHECK_QUANTITY'] && $arItem['CATALOG_QUANTITY'] <= 0) {
			$arItem['CAN_BUY'] = false;
		}
		$arItem['CATALOG_TYPE'] = 1; //simple product
	}
}
//end Prices for MARKET