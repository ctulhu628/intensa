<?
$MESS["RZ_TOVARI"] = "Товары";
$MESS["RZ_NALICHIE"] = "Наличие";
$MESS['RZ_SOLD'] = 'продано';
$MESS["RZ_UNTIL_END"] = "До конца акции";
$MESS["RZ_YES"] = "Да";
$MESS["RZ_NO"] = "Нет";
$MESS['RZ_IN_BASKET'] = 'В корзину';
$MESS["RZ_IZ"] = "из";
$MESS['RZ_ARTICLE_NAME'] = 'Артикул';
$MESS["RZ_BUY_IN_ONE_CLICK"] = "Купить в 1 клик";
$MESS["RZ_QUICK_ORDER"] = "быстрый заказ";
$MESS["RZ_OPEN_ALL"] = "Смотреть все";
$MESS["RZ_NO_ITEMS_FILTERED"] = "Товаров, попадающих под фильтр, не найдено <br> Попробуйте изменить условия фильтрации";
$MESS["RZ_NO_ITEMS"] = "В данном разделе пока нет товаров";
$MESS["RZ_BUY_ALL_BUTTON"] = "Все в корзину";
$MESS["RZ_BUY_ALL_TEXT"] = "<p>Выберите, пожалуйста, товары, которые хотите купить, указав требуемое количество товара.</p><p>После выбора нажмите кнопку <b>\"" . $MESS["RZ_BUY_ALL_BUTTON"] . "\"</b>.</p>";