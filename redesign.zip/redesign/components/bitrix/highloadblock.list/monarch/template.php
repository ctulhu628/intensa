<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();

if (!empty($arResult['ERROR']))
{
	echo $arResult['ERROR'];
	return false;
}

$this->setFrameMode(true);
include $_SERVER["DOCUMENT_ROOT"].SITE_TEMPLATE_PATH.'/include/debug_info_dynamic.php';
?>

<div class="row">
<?if(empty($arResult['rows']) && !empty($_GET['q'])):?>
	<div class="col-md-12"><?=GetMessage('NOT_FOUND')?></div>
	</div>
	<?return;?>
<?elseif(empty($arResult['rows'])):?>
	<div class="col-md-12"><?=GetMessage('EMPTY_LIST')?></div>
	</div>
	<?return;?>
<?endif?>
<?if($arParams["DISPLAY_TOP_PAGER"]):?>
	<?=$arResult["NAV_STRING"]?>
<?endif;?>
<?foreach($arResult["rows"] as $arItem):
	if (!empty($arParams['DETAIL_URL']))
	{
		$url = str_replace(
			array('#ID#', '#XML_ID#', '#BLOCK_ID#'),
			array($arItem['ID'], $arItem['UF_XML_ID'], intval($arParams['BLOCK_ID'])),
			$arParams['DETAIL_URL']
		);
	}?>

		<a href="<?=htmlspecialcharsbx($url)?>" class="brands-grid-item col-xs-4 col-sm-2">
			<?if(!empty($arItem['UF_FILE'])):?>
				<?=$arItem['UF_FILE']?>
			<?endif?>
			<span class="brands-grid-text" data-text="<?echo $arItem["UF_NAME"]?>"></span>
		</a>
<?endforeach;?>
</div>
<div class="row">
	<?=$arResult["NAV_STRING"]?>
</div>
