<?
$MESS['RESIZER_SET'] = 'Набор ресайзера';
