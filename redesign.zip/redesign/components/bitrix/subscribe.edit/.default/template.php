<? use Yenisite\Furniture\Main;

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die() ?>
<div class="col-sm-12">
	<div class="row" id="subscribe-main">
		<? if (!empty($arResult["MESSAGE"])): ?>
			<? Main::ShowMessage(implode('<br/>', $arResult["MESSAGE"]), Main::MSG_TYPE_SUCCESS) ?>
		<? endif; ?>
		<? if (!empty($arResult["ERROR"])): ?>
			<? Main::ShowMessage(implode('<br/>', $arResult["ERROR"])) ?>
		<? endif; ?>
		<? //whether to show the forms
		if ($arResult["ID"] == 0 && empty($_REQUEST["action"]) || CSubscription::IsAuthorized($arResult["ID"])) {
			//show current authorization section
			if ($USER->IsAuthorized() && ($arResult["ID"] == 0 || $arResult["SUBSCRIPTION"]["USER_ID"] == 0)) {
				include("authorization.php");
			}
			//show authorization section for new subscription
			if (false && $arResult["ID"] == 0 && !$USER->IsAuthorized()) {
				if ($arResult["ALLOW_ANONYMOUS"] == "N" || ($arResult["ALLOW_ANONYMOUS"] == "Y" && $arResult["SHOW_AUTH_LINKS"] == "Y")) {
					include("authorization_new.php");
				}
			}
			//setting section
			include("setting.php");
			//status and unsubscription/activation section
			if ($arResult["ID"] > 0) {
				include("status.php");
			}
			//show confirmation form
			if ($arResult["ID"] > 0 && $arResult["SUBSCRIPTION"]["CONFIRMED"] <> "Y") {
				include("confirmation.php");
			}
			?>
			<div class="form-group">
				<p class="help-block">
					<?= GetMessage("subscr_req") ?>
				</p>
			</div>
			<?
		} else {
			//subscription authorization form
			include("authorization_full.php");
		}
		?>
	</div>
</div>