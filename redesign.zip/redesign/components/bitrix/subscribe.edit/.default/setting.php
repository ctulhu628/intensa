<? use Yenisite\Furniture\Form;

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die(); ?>
<?
//***********************************
//setting section
//***********************************
\Bitrix\Main\Localization\Loc::loadMessages($_SERVER['DOCUMENT_ROOT'].SITE_TEMPLATE_PATH . '/lang/'.LANGUAGE_ID.'/header.php');
$pathToRules = COption::GetOptionString(\Yenisite\Furniture\Settings::getModuleId(),'path_tu_rules_privacy',SITE_DIR.'personal/rules/personal_data.php');
?>
<div class="col-md-6">
	<form action="<?= $arResult["FORM_ACTION"] ?>" method="post">
        <input type="hidden" name="privacy_policy" value="N"/>
		<?= bitrix_sessid_post(); ?>
		<div class="form-group">
			<h2><?= GetMessage("subscr_title_settings") ?></h2>
		</div>
		<div class="form-group">
			<label for=""><?= GetMessage("subscr_email") ?><span class="required-star">*</span>:</label>
			<input type="text" name="EMAIL" class="form-control"
				   value="<?= ($arResult["SUBSCRIPTION"]["EMAIL"] != "") ?
						   $arResult["SUBSCRIPTION"]["EMAIL"] : $arResult["REQUEST"]["EMAIL"]; ?>"/>
		</div>
		<div class="form-group">
			<label for=""><?= GetMessage("subscr_rub") ?><span class="required-star">*</span>:</label>
		</div>
		<? foreach ($arResult["RUBRICS"] as $itemID => $itemValue): ?>
			<div class="form-group">
				<?
				Form::printElement(array(
						'NAME' => 'RUB_ID[]',
						'VALUE' => $itemValue["ID"],
						'CHECKED' => $itemValue["CHECKED"],
						'TEXT' => $itemValue["NAME"],
				), Form::TYPE_CHECKBOX)
				?>
			</div>
		<? endforeach; ?>
		<div class="form-group">
			<label for=""><?= GetMessage("subscr_fmt") ?>:</label>
			<? Form::printElement(array(
					'NAME' => 'FORMAT',
					'VALUE' => 'text',
					'CHECKED' => $arResult["SUBSCRIPTION"]["FORMAT"] == "text",
					'TEXT' => GetMessage("subscr_text"),
			), Form::TYPE_RADIO) ?>
			<?
			Form::printElement(array(
					'NAME' => 'FORMAT',
					'VALUE' => 'html',
					'CHECKED' => $arResult["SUBSCRIPTION"]["FORMAT"] == "html",
					'TEXT' => 'HTML',
			), Form::TYPE_RADIO)
			?>
		</div>
		<div class="form-group">
			<p class="help-block"><?= GetMessage("subscr_settings_note1") ?></p>

			<p class="help-block"><?= GetMessage("subscr_settings_note2") ?></p>
		</div>
        <div class="form-group">
            <?
            $text = GetMessage('RZ_RULES_YA') . ' ';
            $text .=  GetMessage('RZ_ACCEPT') . " <a href='" . $pathToRules . "' target='_blank' class='classic-link'>" . GetMessage('RZ_CONCLUSION') . "</a>";
            Form::printElement(
                array(
                    'NAME' => 'PRIVACY_POLICY',
                    'CHECKED' => $_POST['PRIVACY_POLICY'] == 'Y',
                    'TEXT' => $text,
                    'REQ' => true,
                    'INDEX' => ++$tabIndex,
                ), Form::TYPE_CHECKBOX
            );
            ?>
        </div>
		<div class="form-group">
			<input type="submit" name="Save" class="btn btn-primary"
				   value="<?= ($arResult["ID"] > 0 ? GetMessage("subscr_upd") : GetMessage("subscr_add")) ?>"/>
			<input type="reset" value="<?= GetMessage("subscr_reset") ?>" name="reset" class="btn btn-link"/>
		</div>
		<input type="hidden" name="PostAction" value="<?= ($arResult["ID"] > 0 ? "Update" : "Add") ?>"/>
		<input type="hidden" name="ID" value="<?= $arResult["SUBSCRIPTION"]["ID"]; ?>"/>
		<? if ($_REQUEST["register"] == "YES"): ?>
			<input type="hidden" name="register" value="YES"/>
		<? endif; ?>
		<? if ($_REQUEST["authorize"] == "YES"): ?>
			<input type="hidden" name="authorize" value="YES"/>
		<? endif; ?>
	</form>
</div>
