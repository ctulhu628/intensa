<?
$MESS["F_THEME_BLACK"] = "ciemny";
$MESS["F_THEME_BLUE"] = "Niebieski";
$MESS["F_THEME_GREEN"] = "Zielony";
$MESS["F_THEME_RED"] = "Czerwony";
$MESS["F_THEME_SITE"] = "Użyj motywu strony (dla bitrix.eshop)";
$MESS["F_THEME_WOOD"] = "Skóra";
$MESS["F_THEME_YELLOW"] = "żółty";
$MESS["MENU_THEME"] = "Motyw menu";
?>