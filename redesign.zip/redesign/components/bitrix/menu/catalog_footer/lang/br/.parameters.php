<?
$MESS["F_THEME_BLUE"] = "Azul ";
$MESS["F_THEME_GREEN"] = "Verde";
$MESS["F_THEME_RED"] = "Vermelho";
$MESS["F_THEME_SITE"] = "Usar tema do site (para bitrix.eshop)";
$MESS["F_THEME_WOOD"] = "Bark";
$MESS["F_THEME_YELLOW"] = "Amarelo";
$MESS["MENU_THEME"] = "Tema do menu";
?>