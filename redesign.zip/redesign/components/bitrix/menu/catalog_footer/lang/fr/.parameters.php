<?
$MESS["F_THEME_BLACK"] = "Espace des thèmes";
$MESS["F_THEME_BLUE"] = "Bleu";
$MESS["F_THEME_GREEN"] = "Vert";
$MESS["F_THEME_RED"] = "Rouge";
$MESS["F_THEME_SITE"] = "Prendre le thème dans les paramètres du site (pour la solution bitrix.eshop)";
$MESS["F_THEME_WOOD"] = "arbre";
$MESS["F_THEME_YELLOW"] = "Jaune";
$MESS["MENU_THEME"] = "Thème du menu";
?>