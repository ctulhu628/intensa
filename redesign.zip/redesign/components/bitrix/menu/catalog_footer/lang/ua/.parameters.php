<?
$MESS["MENU_THEME"] = "Тема меню";
$MESS["F_THEME_SITE"] = "Брати тему з налаштувань сайту (для вирішення bitrix.eshop)";
$MESS["F_THEME_BLUE"] = "Синя";
$MESS["F_THEME_WOOD"] = "Дерево";
$MESS["F_THEME_YELLOW"] = "Жовта";
$MESS["F_THEME_GREEN"] = "Зелена";
$MESS["F_THEME_RED"] = "Червона";
$MESS["F_THEME_BLACK"] = "Темна";
?>