<?
$MESS["MENU_THEME"] = "Meniu tema";
$MESS["F_THEME_SITE"] = "Naudoti svetainės temą (bitrix.eshop)";
$MESS["F_THEME_BLUE"] = "Žydra";
$MESS["F_THEME_WOOD"] = "Ruda";
$MESS["F_THEME_YELLOW"] = "Geltona";
$MESS["F_THEME_GREEN"] = "Žalia";
$MESS["F_THEME_RED"] = "Raudona";
$MESS["F_THEME_BLACK"] = "Tamsi";
?>