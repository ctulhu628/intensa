<?
$MESS["F_THEME_BLACK"] = "Oscuro";
$MESS["F_THEME_BLUE"] = "Azul";
$MESS["F_THEME_GREEN"] = "Verde";
$MESS["F_THEME_RED"] = "Rojo";
$MESS["F_THEME_SITE"] = "Tema de uso del sitio (por bitrix.eshop)";
$MESS["F_THEME_WOOD"] = "Corteza";
$MESS["F_THEME_YELLOW"] = "Amarillo";
$MESS["MENU_THEME"] = "Tema de menú";
?>