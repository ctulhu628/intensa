<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
use Yenisite\Furniture\Main;

if (method_exists($this, 'setFrameMode')) $this->setFrameMode(false);
Main::includeDebug($this);
?>
<? if ($arParams['SECOND'] !== 'Y'): ?>
	<div class="sitemap-actions">
		<button type="button" class="action-link has-icon disabled" id="sitemap-minify">
			<i class="when-opened flaticon-folder21"></i>
			<span class="link-text"><?= GetMessage('RZ_CLOSE_ALL') ?></span>
		</button>
		<button type="button" class="action-link has-icon" id="sitemap-expand">
			<i class="when-closed flaticon-folder11"></i>
			<span class="link-text"><?= GetMessage('RZ_SHOW_ALL') ?></span>
		</button>
	</div><!-- sitemap-actions -->
<? endif ?>
<? if ($arParams['SECOND'] !== 'Y'): ?>
<ul class="sitemap-list">
<? endif ?>
	<?
	$previousLevel = -1;
	foreach ($arResult as $arItem): ?>
		<? $ID = 'sitemap-lvl' . $arItem["DEPTH_LEVEL"] . '-' . $arItem['ITEM_INDEX'] ?>
		<? if ($arItem["DEPTH_LEVEL"] < $previousLevel):?>
			<?= str_repeat("</ul></li>", ($previousLevel - $arItem["DEPTH_LEVEL"])); ?>
		<? endif ?>
		<? if ($arItem["IS_PARENT"]): ?>
		<li>
			<button type="button" class="sitemap-item" data-toggle="collapse" data-target="#<?= $ID ?>" aria-expanded="false"
					aria-controls="sitemap-lvl1-2">
				<i class="sitemap-icon when-closed flaticon-folder21"></i>
				<i class="sitemap-icon when-opened flaticon-folder11"></i>
				<span class="text"><?= $arItem["TEXT"] ?></span>
			</button>
			<a href="<?= $arItem['LINK'] ?>" class="link link-std"></a>
			<ul class="sitemap-list-lvl2 collapse" id="<?= $ID ?>">
		<? else:?>
			<li><a href="<?= $arItem['LINK'] ?>" class="sitemap-item"><i class="sitemap-icon flaticon-document58"></i><span
							class="text"><?= $arItem["TEXT"] ?></span></a></li>
		<? endif ?>
			<? $previousLevel = $arItem["DEPTH_LEVEL"]; ?>
	<? endforeach ?>
	<? if ($previousLevel > 1): //close last item tags?>
		<?= str_repeat("</ul></li>", ($previousLevel - 1)); ?>
	<? endif ?>
	<? if (false): ?>
			</ul>
		</li>
	<? endif ?>
<? if ($arParams['SECOND'] == 'Y'): ?>
</ul>
<? endif ?>