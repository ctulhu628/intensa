"use strict";
$(function () {
	$('.sitemap-item-toggle').on('click', function () {
		var $t = $(this);
		$t.toggleClass('collapsed');
		$t.siblings(".collapse").collapse("toggle");
	});
	var $sitemap = $('#sitemap'),
		$collapses = $sitemap.find('.collapse'),
		$minify = $('#sitemap-minify'),
		$expand = $('#sitemap-expand'),
		$collapseToggles = $sitemap.find('.sitemap-item-toggle'),
		checkTimeout;

	function delayCheck() {
		if ($sitemap.find('.collapsing').length) {
			clearTimeout(checkTimeout);
			checkTimeout = setTimeout(delayCheck, 100);
		} else check();
	}

	function check() {
		var checked = $collapses.filter('.in');
		if (checked.length === 0) $minify.addClass('disabled');
		else $minify.removeClass('disabled');

		var notChecked = $collapses.not('.in');
		if (notChecked.length === 0) $expand.addClass('disabled');
		else $expand.removeClass('disabled');
	}

	// EVENTS
	$minify.on('click', function () {
		$collapses.collapse('hide');
		$collapseToggles.addClass('collapsed');
	});
	$expand.on('click', function () {
		$collapses.collapse('show');
		$collapseToggles.removeClass('collapsed');
	});
	$sitemap.on('shown.bs.collapse hidden.bs.collapse', delayCheck);

	delayCheck();
});