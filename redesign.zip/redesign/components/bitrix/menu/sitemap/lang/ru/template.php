<?
$MESS['RZ_CLOSE_ALL'] = "Свернуть все";
$MESS['RZ_SHOW_ALL'] = "Развернуть все";
