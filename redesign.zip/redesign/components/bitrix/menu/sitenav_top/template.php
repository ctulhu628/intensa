<?
use Yenisite\Core\Tools;
use Yenisite\Furniture\Main;

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
$this->setFrameMode(true);
if (empty($arResult)) return;
?>
<ul class="header-menu">
<? foreach ($arResult as $arItem): ?>
	<? if ($arItem['DEPTH_LEVEL'] > 1) continue ?>
	<li>
	<? if ($arItem['SELECTED']): ?>
		<span><?= $arItem['TEXT'] ?></span>
	<? else: ?>
		<a href="<?= $arItem['LINK'] ?>"><?= $arItem['TEXT'] ?></a>
	<? endif ?>
	</li>
<? endforeach ?>
</ul>
