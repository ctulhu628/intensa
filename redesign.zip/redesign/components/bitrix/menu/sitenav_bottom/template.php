<?
use Yenisite\Core\Tools;
use Yenisite\Furniture\Main;

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
$this->setFrameMode(true);
if (empty($arResult)) return;
?>
<ul class="footer-menu">
<? foreach ($arResult as $arItem): ?>
	<? if ($arItem['DEPTH_LEVEL'] > 1) continue ?>
	<li>
		<a href="<?= $arItem['LINK'] ?>"><?= $arItem['TEXT'] ?></a>
	</li>
<? endforeach ?>
</ul>
