<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
use Bitrix\Main\Page\Asset;
use Bitrix\Main\Loader;
use Yenisite\Core\Tools;

/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */
/** @var CBitrixComponent $component */
$this->setFrameMode(true);

global $rz_current_sectionID;
global $rz_options;
/**
 * @var array $arCurSection
 */
include 'include/get_cur_section.php';
$rz_current_sectionID = $arCurSection['ID'];

$arPrepareParams = include 'include/prepare_params_element.php';
?>
<div class="detailed-page" itemscope itemtype="http://schema.org/Product">
	<?
	ob_start();
	$ElementID = $APPLICATION->IncludeComponent(
			"bitrix:catalog.element",
			'main',
			$arPrepareParams,
			$component
	);
	$content = ob_get_clean();
	$reviews = '';
	$banner1 = '';
	$banner2 = '';
	global $elementVoteString;
	$elementVoteString = '0';
	?>
	<? if (CIBlockFindTools::GetSectionID($section_id = 0, $section_code = "ITEM_REVIEW_" . $ElementID,
					$arFilter = array("GLOBAL_ACTIVE" => "Y", "IBLOCK_ID" => $arPrepareParams['FEEDBACK_IBLOCK_ID'])) > 0
	): ?>
		<? ob_start() ?>
		<? $APPLICATION->IncludeComponent('bitrix:news.list', 'comments', array(
				'DISPLAY_DATE' => 'N',
				'DISPLAY_NAME' => 'N',
				'DISPLAY_PICTURE' => 'N',
				'DISPLAY_PREVIEW_TEXT' => 'Y',
				'AJAX_MODE' => 'N',
				'IBLOCK_TYPE' => $arPrepareParams['FEEDBACK_IBLOCK_TYPE'],
				'IBLOCK_ID' => $arPrepareParams['FEEDBACK_IBLOCK_ID'],
				'NEWS_COUNT' => '0',
				'SORT_BY1' => 'ACTIVE_FROM',
				'SORT_ORDER1' => 'DESC',
				'SORT_BY2' => 'SORT',
				'SORT_ORDER2' => 'ASC',
				'FILTER_NAME' => '',
				'FIELD_CODE' => Array('ID', 'DATE_CREATE', 'CREATED_BY'),
				'PROPERTY_CODE' => Array('NAME', 'IP'),
				'CHECK_DATES' => 'Y',
				'DETAIL_URL' => '',
				'PREVIEW_TRUNCATE_LEN' => '',
				'ACTIVE_DATE_FORMAT' => 'd.m.Y',
				'SET_TITLE' => 'N',
				'SET_BROWSER_TITLE' => 'N',
				'SET_META_KEYWORDS' => 'N',
				'SET_META_DESCRIPTION' => 'N',
				'SET_STATUS_404' => 'N',
				'INCLUDE_IBLOCK_INTO_CHAIN' => 'N',
				'ADD_SECTIONS_CHAIN' => 'N',
				'HIDE_LINK_WHEN_NO_DETAIL' => 'N',
				'PARENT_SECTION' => '',
				'PARENT_SECTION_CODE' => 'ITEM_REVIEW_' . $ElementID,
				'INCLUDE_SUBSECTIONS' => 'N',
				'CACHE_TYPE' => $arPrepareParams['CACHE_TYPE'],
				'CACHE_TIME' => $arPrepareParams['CACHE_TIME'],
				'CACHE_FILTER' => 'N',
				'CACHE_GROUPS' => 'Y',
				'DISPLAY_TOP_PAGER' => 'N',
				'DISPLAY_BOTTOM_PAGER' => 'N',
				'PAGER_TITLE' => '',
				'PAGER_SHOW_ALWAYS' => 'N',
				'PAGER_TEMPLATE' => '',
				'PAGER_DESC_NUMBERING' => 'N',
				'PAGER_DESC_NUMBERING_CACHE_TIME' => '36000',
				'PAGER_SHOW_ALL' => 'Y',
				'AJAX_OPTION_JUMP' => 'N',
				'AJAX_OPTION_STYLE' => 'Y',
				'AJAX_OPTION_HISTORY' => 'N',
				'AJAX_OPTION_ADDITIONAL' => '',
		),
				$component,
				array(
						'HIDE_ICONS' => 'N',
				)
		); ?>
		<? $reviews = ob_get_clean() ?>
	<? endif ?>

	<?if( $rz_options["section_banners"]!="N" && !\Bitrix\Main\Loader::includeModule('yenisite.furniturelite')):?>
		<? ob_start() ?>
			<?Tools::IncludeArea('catalog/detail','banner1')?>
		<? $banner1 = ob_get_clean() ?>
		<? ob_start() ?>
			<?Tools::IncludeArea('catalog/detail','banner2')?>
		<? $banner2 = ob_get_clean() ?>
	<?endif?>
	<?= str_replace(array('#FEEDBACK_LIST#', '#VOTE_STRING#','#BANNER_1#','#BANNER_2#','#BANNER_3#'), array($reviews, $elementVoteString,$banner1,$banner2,$banner3), $content) ?>
</div>
