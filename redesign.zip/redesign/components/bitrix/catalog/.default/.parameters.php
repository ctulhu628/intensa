<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

use Bitrix\Main\Loader;
use Bitrix\Main\ModuleManager;


if (!Loader::includeModule('iblock')) {
	return;
}
$boolCatalog = Loader::includeModule('catalog');

// SKU:
$arSKU = false;
$boolSKU = false;
if ($boolCatalog && (isset($arCurrentValues['IBLOCK_ID']) && 0 < intval($arCurrentValues['IBLOCK_ID']))) {
	$arSKU = CCatalogSKU::GetInfoByProductIBlock($arCurrentValues['IBLOCK_ID']);
	$boolSKU = !empty($arSKU) && is_array($arSKU);
}

//PROPERTIES:
$arProperties_ALL = array('-' => GetMessage('CP_BC_TPL_PROP_EMPTY'));
$arProperties_LNS = array('-' => GetMessage('CP_BC_TPL_PROP_EMPTY')); // list, number, string
$arProperties_LNS_S = array('-' => GetMessage('CP_BC_TPL_PROP_EMPTY')); // same but not multiple
$arProperties_E = array('-' => GetMessage('CP_BC_TPL_PROP_EMPTY')); // link element
if ((int)$arCurrentValues["IBLOCK_ID"]) {
	$dbProperties = CIBlockProperty::GetList(Array("sort" => "asc", "name" => "asc"),
		Array('ACTIVE' => 'Y', 'IBLOCK_ID' => (int)$arCurrentValues["IBLOCK_ID"]));
	while ($arProp = $dbProperties->GetNext()) {
		$strPropName = '[' . $arProp['ID'] . ']' . ('' != $arProp['CODE'] ? '[' . $arProp['CODE'] . ']' : '') . ' ' . $arProp['NAME'];

		$arProperties_ALL[$arProp["CODE"]] = "[{$arProp['CODE']}] {$arProp['NAME']}";
		if (in_array($arProp["PROPERTY_TYPE"], array("L", "N", "S"))) {
			$arProperties_LNS[$arProp["CODE"]] = &$arProperties_ALL[$arProp["CODE"]];
			if ($arProp["MULTIPLE"] != "Y") {
				$arProperties_LNS_S[$arProp["CODE"]] = &$arProperties_ALL[$arProp["CODE"]];
			}
		}
		if ($arProp['PROPERTY_TYPE'] == 'E') {
			$arProperties_E[$arProp["CODE"]] = &$arProperties_ALL[$arProp["CODE"]];
		}
		if ('S' == $arProp['PROPERTY_TYPE'] && 'directory' == $arProp['USER_TYPE'] && CIBlockPriceTools::checkPropDirectory($arProp)) {
			$arHighloadPropList[$arProp['CODE']] = $strPropName;
		}
	}
}

$siteTemplate = $_REQUEST['siteTemplateId'];
if (empty($siteTemplate)) $siteTemplate = $_REQUEST['site_template'];
if (empty($siteTemplate)) $siteTemplate = $_REQUEST['template_id'];


$arDefPropsHide = array(
	'SERVICE',
	'MANUAL',
	'ID_3D_MODEL',
	'MAILRU_ID',
	'VIDEO',
	'ARTICLE',
	'HOLIDAY',
	'SHOW_MAIN',
	'HIT',
	'SALE',
	'PHOTO',
	'DESCRIPTION',
	'MORE_PHOTO',
	'NEW',
	'KEYWORDS',
	'TITLE',
	'FORUM_TOPIC_ID',
	'FORUM_MESSAGE_CNT',
	'PRICE_BASE',
	'H1',
	'YML',
	'FOR_ORDER',
	'WEEK_COUNTER',
	'WEEK',
	'BESTSELLER',
	'SALE_INT',
	'SALE_EXT',
	'COMPLETE_SETS',
	'vote_count',
	'vote_sum',
	'rating',
);


$arPrice = array();
if (Loader::includeModule("catalog")) {
	$rsPrice = CCatalogGroup::GetList($v1 = "sort", $v2 = "asc");
	while ($arr = $rsPrice->Fetch()) {
		$arPrice["CATALOG_PRICE_{$arr['ID']}"] = "[" . $arr["NAME"] . "] " . $arr["NAME_LANG"];
	}
	$defPrice = 'CATALOG_PRICE_1';
}

$arComponentParameters["GROUPS"]["STICKERS"] = array(
	"NAME" => GetMessage("STICKER_GROUP"),
	"SORT" => "4900",
);

// COMMON
$arTemplateParameters_common = array(
	// ARTICUL
	'ARTICUL_PROP' => array(
		'PARENT' => 'VISUAL',
		'NAME' => GetMessage('ARTICUL_PROP'),
		'TYPE' => 'LIST',
		'MULTIPLE' => 'N',
		'DEFAULT' => 'ARTICUL',
		'VALUES' => $arProperties_ALL,
	),
);
if (Loader::includeModule('yenisite.favorite')) {
	$arTemplateParameters_common['DISPLAY_FAVORITE'] = array(
		'PARENT' => 'VISUAL',
		'NAME' => GetMessage('DISPLAY_FAVORITE'),
		'TYPE' => 'CHECKBOX',
		'DEFAULT' => 'Y',
	);
}


// DETAIL
$arTemplateParameters_detail['SETTINGS_HIDE'] = array(
	"PARENT" => "DETAIL_SETTINGS",
	"NAME" => GetMessage("SETTINGS_HIDE"),
	"TYPE" => "LIST",
	"MULTIPLE" => "Y",
	"VALUES" => $arProperties_ALL,
	"SIZE" => "8",
	"DEFAULT" => $arDefPropsHide,
);

//OPTIONS BLOCK

$arIBlock = array('-' => GetMessage('CP_BC_TPL_PROP_EMPTY'));
$iblockFilter = (
!empty($arCurrentValues['IBLOCK_TYPE'])
	? array('TYPE' => $arCurrentValues['IBLOCK_TYPE'], 'ACTIVE' => 'Y')
	: array('TYPE' => 'furniture_catalog', 'ACTIVE' => 'Y')
);
$rsIBlock = CIBlock::GetList(array('SORT' => 'ASC'), $iblockFilter);
while ($arr = $rsIBlock->Fetch()) {
	$arIBlock[$arr['ID']] = '[' . $arr['ID'] . '] ' . $arr['NAME'];
}
unset($arr, $rsIBlock, $iblockFilter);

$arTemplateParameters_detail['IBLOCK_OPTIONS_ID'] = array(
	"PARENT" => "DETAIL_SETTINGS",
	"NAME" => GetMessage("IBLOCK_OPTIONS_ID"),
	"TYPE" => "LIST",
	"VALUES" => $arIBlock,
	"DEFAULT" => 'furniture_options',
);
$arTemplateParameters_detail['HEADER_PAID_OPTIONS'] = array(
	"PARENT" => "DETAIL_SETTINGS",
	"NAME" => GetMessage("HEADER_PAID_OPTIONS"),
	"TYPE" => "STRING",
	"DEFAULT" => GetMessage('DEF_HEADER_PAID_OPTIONS'),
);

$arTemplateParameters_detail['DETAIL_SIMILAR_PRICE_PERCENT'] = array(
	'PARENT' => 'DETAIL_SETTINGS',
	'NAME' => GetMessage('DETAIL_SIMILAR_PRICE_PERCENT'),
	'TYPE' => 'STRING',
	'DEFAULT' => '20',
);
$arTemplateParameters_detail['DETAIL_SIMILAR_PRICE_SMART_FILTER'] = array(
	'PARENT' => 'DETAIL_SETTINGS',
	'NAME' => GetMessage('DETAIL_SIMILAR_PRICE_SMART_FILTER'),
	'TYPE' => 'CHECKBOX',
	'DEFAULT' => 'N',
);
$arTemplateParameters_detail['SHOW_SOCIAL_BUTTONS'] = array(
	"PARENT" => "DETAIL_SETTINGS",
	"NAME" => GetMessage("SHOW_SOCIAL_BUTTONS"),
	"TYPE" => "CHECKBOX",
	"DEFAULT" => 'Y',
);
$arTemplateParameters_detail['SHARE_TEXT'] = array(
	"PARENT" => "DETAIL_SETTINGS",
	"NAME" => GetMessage("SHARE_TEXT"),
	"TYPE" => "STRING",
	"DEFAULT" => GetMessage('DEF_SHARE_TEXT'),
);
$arTemplateParameters_detail['RECOMMENDED_PAGE_ELEMENT_COUNT'] = array(
	'PARENT' => 'DETAIL_SETTINGS',
	'NAME' => GetMessage('RECOMMENDED_PAGE_ELEMENT_COUNT'),
	'TYPE' => 'STRING',
	'DEFAULT' => 999999
);
$arTemplateParameters_detail['TITLE_RECOMMEND'] = array(
	'PARENT' => 'DETAIL_SETTINGS',
	'NAME' => GetMessage('TITLE_RECOMMEND'),
	'TYPE' => 'STRING',
	'DEFAULT' => GetMessage('DEF_TITLE_RECOMMEND')
);
$arTemplateParameters_detail['DETAIL_SIMILAR_PRICE_WITH_EMPTY_PROPS'] = array(
	'PARENT' => 'DETAIL_SETTINGS',
	'NAME' => GetMessage('DETAIL_SIMILAR_PRICE_WITH_EMPTY_PROPS'),
	'TYPE' => 'CHECKBOX',
	'DEFAULT' => 'N',
);
$arTemplateParameters_detail['ADD_PARENT_PHOTO'] = array(
	'PARENT' => 'DETAIL_SETTINGS',
	'NAME' => GetMessage('ADD_PARENT_PHOTO'),
	'TYPE' => 'CHECKBOX',
	'DEFAULT' => 'Y',
);
$arTemplateParameters_detail['DETAIL_SIMILAR_PRICE_PROPERTIES'] = array(
	'PARENT' => 'DETAIL_SETTINGS',
	'NAME' => GetMessage('DETAIL_SIMILAR_PRICE_PROPERTIES'),
	'TYPE' => 'LIST',
	'MULTIPLE' => 'Y',
	'VALUES' => array_merge(
		array(
			'-'               => NULL, //fills from merge with $arProperties_LNS
			'---AVAILABLE---' => GetMessage('DETAIL_SIMILAR_PRICE_PROPERTIES_AVAILABLE'),
			'---SECTION---'   => GetMessage('DETAIL_SIMILAR_PRICE_PROPERTIES_SECTION'),
			'---PRICE---'     => GetMessage('DETAIL_SIMILAR_PRICE_PROPERTIES_PRICE'),
		),
		$arProperties_LNS
	),
	'DEFAULT' => array('---AVAILABLE---', '---SECTION---', '---PRICE---')
);
$arTemplateParameters_detail['DETAIL_SIMILAR_PRICE_PROPERTIES']['SIZE'] = min(count($arTemplateParameters_detail['DETAIL_SIMILAR_PRICE_PROPERTIES']['VALUES']), 10);

global $MESS;
if ($boolCatalog) {
	$MESS['DETAIL_SIMILAR_PRICE_SMART_FILTER_TIP'] = GetMessage(
		'DETAIL_SIMILAR_PRICE_SMART_FILTER_TIP_CATALOG',
		array('#IBLOCK_ID#' => $arCurrentValues['IBLOCK_ID'])
	);
} else {
	$MESS['DETAIL_SIMILAR_PRICE_SMART_FILTER_TIP'] = GetMessage(
		'DETAIL_SIMILAR_PRICE_SMART_FILTER_TIP_MARKET',
		array(
			'#IBLOCK_ID#'   => $arCurrentValues['IBLOCK_ID'],
			'#IBLOCK_TYPE#' => $arCurrentValues['IBLOCK_TYPE']
		)
	);
}


$arTemplateParameters_detail['DETAIL_SIMILAR_PRICE_WITH_EMPTY_PROPS'] = array(
	'PARENT' => 'DETAIL_SETTINGS',
	'NAME' => GetMessage('DETAIL_SIMILAR_PRICE_WITH_EMPTY_PROPS'),
	'TYPE' => 'CHECKBOX',
	'DEFAULT' => 'N',
);
$arTemplateParameters_detail['SIMILAR_TITLE'] = array(
	'PARENT' => 'DETAIL_SETTINGS',
	'NAME' => GetMessage('SIMILAR_TITLE'),
	'TYPE' => 'STRING',
	'DEFAULT' => GetMessage('DEF_SIMILAR_TITLE'),
);

/*if (Loader::includeModule('yenisite.feedback')) {
	//FOUND_CHEAP
	//PRICE_LOWER
	$arTemplateParameters_detail['DETAIL_FOUND_CHEAP'] = array(
		'PARENT' => 'DETAIL_SETTINGS',
		'NAME' => GetMessage('FURNITURE_FOUND_CHEAP_USE'),
		'TYPE' => 'CHECKBOX',
		'DEFAULT' => 'Y',
		'REFRESH' => 'Y',
	);

	$arTemplateParameters_detail['DETAIL_PRICE_LOWER'] = array(
		'PARENT' => 'DETAIL_SETTINGS',
		'NAME' => GetMessage('FURNITURE_PRICE_LOWER_USE'),
		'TYPE' => 'CHECKBOX',
		'DEFAULT' => 'Y',
		'REFRESH' => 'Y',
	);
}*/

if (ModuleManager::isModuleInstalled("highloadblock")) {
	$arTemplateParameters_section['LIST_BRAND_USE'] = array(
		'PARENT' => 'DETAIL_SETTINGS',
		'NAME' => GetMessage('CP_BC_TPL_LIST_BRAND_USE'),
		'TYPE' => 'CHECKBOX',
		'DEFAULT' => 'Y',
	);

	$arTemplateParameters_section['LIST_BRAND_PROP_CODE'] = array(
		'PARENT' => 'DETAIL_SETTINGS',
		"NAME" => GetMessage("CP_BC_TPL_LIST_PROP_CODE"),
		"TYPE" => "LIST",
		"VALUES" => $arHighloadPropList,
		"MULTIPLE" => "N",
		"ADDITIONAL_VALUES" => "Y",
		"DEFAULT" => "BRANDS_REF",
	);
	$arTemplateParameters_detail['BRAND_DETAIL'] = array(
		"PARENT" => "DETAIL_SETTINGS",
		"NAME" => GetMessage("CP_BC_TPL_BRAND_DETAIL"),
		"TYPE" => "STRING",
		"DEFAULT" => "={SITE_DIR.\"brands/#ID#/\"}",
	);
}

// DETAIL
$arTemplateParameters_detail['SHOW_FULL_PROPS'] = array(
	"PARENT" => "DETAIL_SETTINGS",
	"NAME" => GetMessage("SHOW_FULL_PROPS"),
	"TYPE" => "CHECKBOX",
	"DEFAULT" => 'Y',
);

$arTemplateParameters_detail['TITLE_EMPTY_CHAR_GROUP'] = array(
	"PARENT" => "DETAIL_SETTINGS",
	"NAME" => GetMessage("TITLE_EMPTY_CHAR_GROUP"),
	"TYPE" => "STRING",
	"DEFAULT" => GetMessage('DEF_TITLE_EMPTY_CHAR_GROUP'),
);

$arViewMods = array('TEXT' => GetMessage('VIEW_MODE_TEXT'), 'BOTH' => GetMessage('VIEW_MODE_BOTH'),'PICTURE' => GetMessage('VIEW_MODE_PICTURE'));
$arTemplateParameters_section['VIEW_MODE'] = array(
	'PARENT' => 'SECTIONS_SETTINGS',
	"NAME" => GetMessage("VIEW_MODE"),
	"TYPE" => "LIST",
	"DEFAULT" => "BOTH",
	"VALUES" => $arViewMods,
	"MULTIPLE" => "N",
);
$arTemplateParameters_section['FULL_DESCTRIPTION'] = array(
	'PARENT' => 'SECTIONS_SETTINGS',
	"NAME" => GetMessage("FULL_DESCTRIPTION"),
	"TYPE" => "CHECKBOX",
	"DEFAULT" => "N",
);

$arPosition = array('TOP' => GetMessage('SUBSECTION_POSITION_TOP'), 'BOTTOM' => GetMessage('SUBSECTION_POSITION_BOTTOM'),'ALL' => GetMessage('SUBSECTION_POSITION_ALL'), 'NONE' => GetMessage('SUBSECTION_POSITION_NONE'));
$arTemplateParameters_section['SUBSECTION_POSITION'] = array(
	'PARENT' => 'SECTIONS_SETTINGS',
	"NAME" => GetMessage("SUBSECTION_POSITION"),
	"TYPE" => "LIST",
	"DEFAULT" => "TOP",
	"VALUES" => $arPosition,
	"MULTIPLE" => "N",
);

//COMPARE
$arTemplateParameters_detail['SHOW_FULL_PROPS_ON_COMPARE'] = array(
	'PARENT' => 'COMPARE_SETTINGS',
	'NAME' => GetMessage('SHOW_FULL_PROPS_ON_COMPARE'),
	'TYPE' => 'CHECKBOX',
	'DEFAULT' => 'Y',
	'REFRESH' => 'Y',
);

//REVIEWS
$arTemplateParameters_detail['HEAD_REVIWES_BLOCK'] = array(
	'PARENT' => 'REVIEW_SETTINGS',
	'NAME' => GetMessage('HEAD_REVIWES_BLOCK'),
	'TYPE' => 'STRING',
	'DEFAULT' => GetMessage('DEF_HEAD_REVIWES_BLOCK'),
);

$arTemplateParameters_detail['SHOW_REVIEWS'] = array(
	'PARENT' => 'REVIEW_SETTINGS',
	'NAME' => GetMessage('SHOW_REVIEWS'),
	'TYPE' => 'CHECKBOX',
	'DEFAULT' => 'Y',
);

// BIG DATA
if ($boolCatalog) {
	\Bitrix\Main\Localization\Loc::loadLanguageFile($_SERVER['DOCUMENT_ROOT'] . BX_ROOT . '/components/bitrix/catalog.bigdata.products/.parameters.php');
	/*$arTemplateParameters_detail['BIGDATA_RCM_TYPE'] = array(
		'PARENT' => 'DETAIL_SETTINGS',
		'NAME' => GetMessage('BIGDATA_RCM_TYPE'),
		'TYPE' => 'LIST',
		"VALUES" => array(
			// general
			'bestsell' => GetMessage('CVP_RCM_BESTSELLERS'),
			// personal
			'personal' => GetMessage('CVP_RCM_PERSONAL'),
			// item2item
			'similar_sell' => GetMessage('CVP_RCM_SOLD_WITH'),
			'similar_view' => GetMessage('CVP_RCM_VIEWED_WITH'),
			'similar' => GetMessage('CVP_RCM_SIMILAR'),
			// randomly distributed
			'any_similar' => GetMessage('CVP_RCM_SIMILAR_ANY'),
			'any_personal' => GetMessage('CVP_RCM_PERSONAL_WBEST'),
			'any' => GetMessage('CVP_RCM_RAND')
		),
		'DEFAULT' => 'any',
	);

	$arTemplateParameters_detail['BIGDATA_TITLE'] = array(
		'PARENT' => 'DETAIL_SETTINGS',
		'NAME' => GetMessage('BIGDATA_TITLE'),
		'TYPE' => 'STRING',
	);*/
}

$arTemplateParameters = array_merge(
	$arTemplateParameters_common,
	$arTemplateParameters_detail,
	$arTemplateParameters_section
);


// #### EDIT exist params

// TODO
$arTemplateParameters["HIDE_NOT_AVAILABLE"]['HIDDEN'] = 'Y';
$arTemplateParameters["USE_ALSO_BUY"]['HIDDEN'] = 'Y';
$arTemplateParameters["DETAIL_BRAND_USE"]['HIDDEN'] = 'Y';

if ($boolSKU) {
	$arTemplateParameters["LIST_PRICE_SORT"]['HIDDEN'] = 'Y';
}

// HIDDEN	
$arTemplateParameters["DETAIL_PROPERTY_CODE"]['HIDDEN'] = 'Y';
$arTemplateParameters["AJAX_MODE"]['HIDDEN'] = 'Y';
$arTemplateParameters["ELEMENT_SORT_FIELD"]['HIDDEN'] = 'Y';
$arTemplateParameters["ELEMENT_SORT_ORDER"]['HIDDEN'] = 'Y';
$arTemplateParameters["ELEMENT_SORT_FIELD2"]['HIDDEN'] = 'Y';
$arTemplateParameters["ELEMENT_SORT_ORDER2"]['HIDDEN'] = 'Y';
$arTemplateParameters["FILTER_FIELD_CODE"]['HIDDEN'] = 'Y';
$arTemplateParameters["FILTER_PROPERTY_CODE"]['HIDDEN'] = 'Y';
$arTemplateParameters["FILTER_PRICE_CODE"]['HIDDEN'] = 'Y';
$arTemplateParameters["FILTER_OFFERS_FIELD_CODE"]['HIDDEN'] = 'Y';
$arTemplateParameters["FILTER_OFFERS_PROPERTY_CODE"]['HIDDEN'] = 'Y';
$arTemplateParameters["TOP_ELEMENT_COUNT"]['HIDDEN'] = 'Y';
$arTemplateParameters["TOP_LINE_ELEMENT_COUNT"]['HIDDEN'] = 'Y';
$arTemplateParameters["TOP_ELEMENT_SORT_FIELD"]['HIDDEN'] = 'Y';
$arTemplateParameters["TOP_ELEMENT_SORT_ORDER"]['HIDDEN'] = 'Y';
$arTemplateParameters["TOP_ELEMENT_SORT_FIELD2"]['HIDDEN'] = 'Y';
$arTemplateParameters["TOP_ELEMENT_SORT_ORDER2"]['HIDDEN'] = 'Y';
$arTemplateParameters["TOP_PROPERTY_CODE"]['HIDDEN'] = 'Y';
$arTemplateParameters["TOP_OFFERS_FIELD_CODE"]['HIDDEN'] = 'Y';
$arTemplateParameters["TOP_OFFERS_PROPERTY_CODE"]['HIDDEN'] = 'Y';
$arTemplateParameters["TOP_OFFERS_LIMIT"]['HIDDEN'] = 'Y';
$arTemplateParameters["TOP_VIEW_MODE"]['HIDDEN'] = 'Y';
$arTemplateParameters["SHOW_TOP_ELEMENTS"]['HIDDEN'] = 'Y';
$arTemplateParameters["PAGE_ELEMENT_COUNT"]['HIDDEN'] = 'Y';
$arTemplateParameters["LINE_ELEMENT_COUNT"]['HIDDEN'] = 'Y';

$arTemplateParameters["PATH_TO_SMILE"]['HIDDEN'] = 'Y';
$arTemplateParameters["REVIEW_AJAX_POST"]['HIDDEN'] = 'Y';
$arTemplateParameters["URL_TEMPLATES_READ"]['HIDDEN'] = 'Y';
$arTemplateParameters["SHOW_LINK_TO_FORUM"]['HIDDEN'] = 'Y';

$arTemplateParameters['GIFTS_SHOW_NAME']['HIDDEN'] = 'Y';
$arTemplateParameters['GIFTS_SHOW_IMAGE']['HIDDEN'] = 'Y';
$arTemplateParameters['GIFTS_MESS_BTN_BUY']['HIDDEN'] = 'Y';
$arTemplateParameters['USE_GIFTS_SECTION']['HIDDEN'] = 'Y';
$arTemplateParameters['MESSAGES_PER_PAGE']['HIDDEN'] = 'Y';
// $arTemplateParameters['USE_CAPTCHA']['HIDDEN'] = 'Y';
$arTemplateParameters['DISABLE_INIT_JS_IN_COMPONENT']['HIDDEN'] = 'Y';
$arTemplateParameters['USE_GIFTS_DETAIL']['HIDDEN'] = 'Y';
$arTemplateParameters['USE_GIFTS_MAIN_PR_SECTION_LIST']['HIDDEN'] = 'Y';
$arTemplateParameters['GIFTS_DETAIL_PAGE_ELEMENT_COUNT']['HIDDEN'] = 'Y';
$arTemplateParameters['GIFTS_DETAIL_HIDE_BLOCK_TITLE']['HIDDEN'] = 'Y';
$arTemplateParameters['GIFTS_DETAIL_BLOCK_TITLE']['HIDDEN'] = 'Y';
$arTemplateParameters['GIFTS_DETAIL_HIDE_BLOCK_TITLE']['HIDDEN'] = 'Y';
$arTemplateParameters['GIFTS_DETAIL_BLOCK_TITLE']['HIDDEN'] = 'Y';
$arTemplateParameters['GIFTS_DETAIL_TEXT_LABEL_GIFT']['HIDDEN'] = 'Y';
$arTemplateParameters['GIFTS_SHOW_DISCOUNT_PERCENT']['HIDDEN'] = 'Y';
$arTemplateParameters['GIFTS_SHOW_OLD_PRICE']['HIDDEN'] = 'Y';
$arTemplateParameters['GIFTS_MAIN_PRODUCT_DETAIL_PAGE_ELEMENT_COUNT']['HIDDEN'] = 'Y';
$arTemplateParameters['GIFTS_MAIN_PRODUCT_DETAIL_HIDE_BLOCK_TITLE']['HIDDEN'] = 'Y';
$arTemplateParameters['GIFTS_MAIN_PRODUCT_DETAIL_BLOCK_TITLE']['HIDDEN'] = 'Y';

if ($arCurrentValues['USE_STORE'] === 'Y') {
	$arTemplateParameters['USE_STORE']['HIDDEN'] = 'Y';
} else {
	$arTemplateParameters['USE_STORE'] = array(
		"PARENT" => "STORE_SETTINGS",
		'TYPE' => 'CHECKBOX',
		'NAME' => GetMessage('FURNITURE_USE_STORE'),
		'REFRESH' => 'Y',
	);
}


// SHOW_REVIEWS


$arReviewModeValues = array();
if ($bForum = ModuleManager::isModuleInstalled('forum')) $arReviewModeValues['forum'] = GetMessage('REVIEWS_FORUM');
if ($bFeedback = (CModule::IncludeModule('yenisite.feedback') && ModuleManager::isModuleInstalled('yenisite.furniturelite'))) {
	$arReviewModeValues['feedback'] = GetMessage('REVIEWS_FEEDBACK');
}
$arReviewDefault = current(array_keys($arReviewModeValues));
if (!isset($arReviewModeValues[$arCurrentValues['REVIEWS_MODE']])) {
	$arCurrentValues['REVIEWS_MODE'] = $arReviewDefault;
}

$arTemplateParameters['REVIEWS_MODE'] = array(
	"PARENT" => "REVIEW_SETTINGS",
	"NAME" => GetMessage("REVIEWS_MODE"),
	"TYPE" => "LIST",
	"MULTIPLE" => "N",
	'REFRESH' => 'Y',
	"VALUES" => $arReviewModeValues,
	"DEFAULT" => $arReviewDefault,
);

if (isset($arCurrentValues['REVIEWS_MODE']) && !($arCurrentValues['REVIEWS_MODE'] == 'forum' && $bForum))
{
	$arTemplateParameters_detail["USE_REVIEW"]['HIDDEN'] = 'Y';
	$arTemplateParameters_detail["USE_CAPTCHA"]['HIDDEN'] = 'Y';
}
if (isset($arCurrentValues['REVIEWS_MODE']) && $arCurrentValues['REVIEWS_MODE'] == 'feedback' && $bFeedback) {
	$arIBlockType = CIBlockParameters::GetIBlockTypes();
	$arTemplateParameters['FEEDBACK_IBLOCK_TYPE'] = array(
		'PARENT' => 'REVIEW_SETTINGS',
		'NAME' => GetMessage('CP_BCE_TPL_FEEDBACK_IBLOCK_TYPE'),
		'TYPE' => 'LIST',
		'VALUES' => $arIBlockType,
		'DEFAULT' => 'yenisite_feedback',
		'REFRESH' => 'Y',
	);
	$arIBlock = array();
	$iblockFilter = (
	!empty($arCurrentValues['FEEDBACK_IBLOCK_TYPE'])
		? array('TYPE' => $arCurrentValues['FEEDBACK_IBLOCK_TYPE'], 'ACTIVE' => 'Y')
		: array('TYPE' => 'yenisite_feedback', 'ACTIVE' => 'Y')
	);
	$rsIBlock = CIBlock::GetList(array('SORT' => 'ASC'), $iblockFilter);
	while ($arr = $rsIBlock->Fetch()) {
		$arIBlock[$arr['ID']] = '[' . $arr['ID'] . '] ' . $arr['NAME'];
	}
	unset($arr, $rsIBlock, $iblockFilter);

	$arTemplateParameters['FEEDBACK_IBLOCK_ID'] = array(
		'PARENT' => 'REVIEW_SETTINGS',
		'NAME' => GetMessage('CP_BCE_TPL_FEEDBACK_IBLOCK_ID'),
		'TYPE' => 'LIST',
		'VALUES' => $arIBlock,
		'DEFAULT' => '',
	);

	$arTemplateParameters['FEEDBACK_SUCCESS_TEXT'] = array(
		'PARENT' => 'REVIEW_SETTINGS',
		'NAME' => GetMessage('CP_BCE_TPL_FEEDBACK_SUCCESS_TEXT'),
		'TYPE' => 'STRING',
		'DEFAULT' => GetMessage('CP_BCE_TPL_FEEDBACK_SUCCESS_TEXT_DEFAULT'),
	);
}










// if ($arCurrentValues['USE_REVIEW'] === 'Y') {
	// $arTemplateParameters['USE_REVIEW']['HIDDEN'] = 'Y';
// } else {
	// $arTemplateParameters['USE_REVIEW'] = array(
		// 'PARENT' => 'REVIEW_SETTINGS',
		// 'TYPE' => 'CHECKBOX',
		// 'NAME' => GetMessage('FURNITURE_USE_REVIEW'),
		// 'REFRESH' => 'Y',
	// );
// }

$arComponentParameters = array();
/** @noinspection PhpDynamicAsStaticMethodCallInspection */
\CComponentUtil::__IncludeLang($componentPath, ".parameters.php");
include($_SERVER["DOCUMENT_ROOT"] . $componentPath . "/.parameters.php");

$arTemplateParameters['USE_PRICE_COUNT'] = $arComponentParameters['USE_PRICE_COUNT'];
$arTemplateParameters['USE_PRICE_COUNT']['HIDDEN'] = 'Y';
$arTemplateParameters['USE_PRICE_COUNT']['DEFAULT'] = 'N';

unset($arComponentParameters);

$arTemplateParameters['USE_ONECLICK'] = array(
	'PARENT' => 'VISUAL',
	'NAME' => GetMessage('USE_ONECLICK'),
	'TYPE' => 'CHECKBOX',
	'DEFAULT' => 'Y'
);

$arTemplateParameters['SHOW_BY_ALL'] = array(
	'PARENT' => 'VISUAL',
	'NAME' => GetMessage('SHOW_BY_ALL'),
	'TYPE' => 'CHECKBOX',
	'DEFAULT' => 'N'
);

// +++
$arTemplateParameters["SHOW_GENERAL_STORE_INFORMATION"]['HIDDEN'] = 'Y';
$arTemplateParameters["STORE_PATH"]['HIDDEN'] = 'Y';
$arTemplateParameters["MAIN_TITLE"]['HIDDEN'] = 'Y';
$arTemplateParameters["FIELDS"]['HIDDEN'] = 'Y';

$arTemplateParameters['STORES_SHOW_NUMBERS'] = array(
	'PARENT' => 'STORE_SETTINGS',
	'NAME' => GetMessage('RZ_STORES_SHOW_NUMBERS'),
	'TYPE' => 'CHECKBOX',
	'DEFAULT' => 'Y',
);

$arTemplateParameters['STORES_COUNT'] = array(
	'PARENT' => 'STORE_SETTINGS',
	'NAME' => GetMessage('STORES_COUNT'),
	'TYPE' => 'STRING',
	'DEFAULT' => '4',
);

if (\Bitrix\Main\Loader::includeModule('yenisite.core')) {
	\Yenisite\Core\Resize::AddResizerParams(array('IMAGE', 'THUMB', 'BIG_THUMB', 'BIG_IMAGE', 'MAX_IMAGE', 'BRAND_DETAIL', 'SIMILAR_IMAGE', 'SUBSECTION','DETAIL_COMMENTS', 'SECTION_IMG'), $arTemplateParameters);
}

//