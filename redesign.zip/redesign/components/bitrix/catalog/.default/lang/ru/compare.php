<?
$MESS['RZ_COMPARE_RESULTS'] = 'Сравнение';