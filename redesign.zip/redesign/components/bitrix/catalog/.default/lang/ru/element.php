<?
$MESS['SIMILAR_TITLE'] = 'Похожие товары';
$MESS['DEF_HEAD_REVIWES_BLOCK'] = 'Отзывы';
$MESS['DEF_TITLE_EMPTY_CHAR_GROUP'] = 'Основные характеристики товара';
$MESS['TITLE_RECOMMEND'] = 'Рекомендуемые товары';
$MESS ['DEF_SHARE_TEXT'] = "Поделиться с друзьями:";