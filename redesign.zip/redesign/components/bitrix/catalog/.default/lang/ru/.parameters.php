<?
$MESS["SORT_PROPERTIES"] = "Свойства для сортировки";

// COMMON
$MESS["ARTICUL_PROP"] = "Свойство-артикул";
$MESS["DISPLAY_FAVORITE"] = "Отображать кнопки добавления в избранное";
$MESS["DISPLAY_ONECLICK"] = "Отображать кнопки для покупки в 1 клик в списках";
$MESS["DISPLAY_ONECLICK_TIP"] = "Кнопки появятся в разделе каталога вида блоки, а также на детальной странице в списках рекомендуемых, похожих и просматриваемых товаров";

$MESS["CP_BC_TPL_SHOW_OLD_PRICE"] = "Показывать старую цену";

// Resizer
$MESS["RESIZER_SETS"] = "Настройка наборов Ресайзера";
$MESS["RESIZER_IMAGE"] = "Картинка для списка";
$MESS["RESIZER_THUMB"] = "Картинка миниатюры для списка";
$MESS["RESIZER_BIG_THUMB"] = "Миниатюра для детальной страницы";
$MESS["RESIZER_BIG_IMAGE"] = "Большая картинка для детальной страницы";
$MESS["RESIZER_MAX_IMAGE"] = "Большая картинка зума на детальной странице";
$MESS["RESIZER_BRAND_DETAIL"] = "Картинка для бренда на детальной";
$MESS["RESIZER_SECTION_LVL0"] = "Набор для списка категорий";
$MESS["RESIZER_SECTION"] = "Набор для списка товаров";
$MESS["RESIZER_SECTION_ICON"] = "Набор для миниатюр в списке товаров";
$MESS["RESIZER_SUBSECTION"] = "Набор для иконок подразделов";
$MESS['RESIZER_DETAIL_SMALL'] = 'Среднее изображение для детальной страницы ';
$MESS['RESIZER_DETAIL_BIG'] = 'Увеличенное изображение для детальной страницы ';
$MESS['RESIZER_QUICK_VIEW'] = 'Среднее изображение для быстрого просмотра';
$MESS['RESIZER_DETAIL_ICON'] = 'Изображения-иконки для детальной страницы';
$MESS['RESIZER_DETAIL_PROP'] = 'Картинки из справочников в списке характеристик на детальной странице';
$MESS['RESIZER_DETAIL_FLY_BLOCK'] = 'Изображения в летающем блоке справа для детальной страницы';
$MESS['RESIZER_COMMENT_AVATAR'] = 'Фото автора комментария для детальной страницы';
$MESS['RESIZER_SET_CONTRUCTOR'] = 'Для наборов на детальной странице';
$MESS['RESIZER_RECOMENDED'] = 'Рекомендуемые товары на детальной странице';
$MESS['RESIZER_FILTER'] = 'Для картинок в фильтре';
$MESS['RESIZER_SIMILAR_THUMB'] = 'Для миниатюр блока похожих товаров';
$MESS['RESIZER_SIMILAR_IMAGE'] = 'Для картинок блока похожих товаров';
$MESS['RESIZER_DETAIL_COMMENTS'] = 'Набор для картинок формы отзывов на детальной';
$MESS['RESIZER_SECTION_IMG'] = 'Набор для картинок разделов в блоке описания раздела';

//  Section
$MESS['FURNITURE_PRICE_SORT'] = 'Тип цены, по которому сортировать список товаров';
$MESS['FURNITURE_DEFAULT_ELEMENT_SORT_BY'] = 'Сортировка списка товаров по умолчанию' ;
$MESS['FURNITURE_DEFAULT_ELEMENT_SORT_ORDER'] = 'Порядок сортировки списка товаров по умолчанию' ;
$MESS['FURNITURE_ELEMENT_SORT_ASC']   = 'по возрастанию' ;
$MESS['FURNITURE_ELEMENT_SORT_DESC']  = 'по убыванию' ;
$MESS['FURNITURE_ELEMENT_SORT_HIT']   = 'по популярности (количество просмотров)';
$MESS['FURNITURE_ELEMENT_SORT_PRICE'] = 'по цене' ;
$MESS['FURNITURE_ELEMENT_SORT_NAME']  = 'по названию' ;
$MESS['FURNITURE_ELEMENT_SORT_SALE_INT'] = 'по автоматически подсчитанному количеству продаж [SALE_INT]';
$MESS['FURNITURE_ELEMENT_SORT_SALE_EXT'] = 'по выгруженному количеству продаж [SALE_EXT]';
$MESS['FURNITURE_ELEMENT_SORT_SORT'] = 'по сортировке';
$MESS['FURNITURE_ELEMENT_SORT_RATING'] = 'по рейтингу';
$MESS['FURNITURE_LIST_SORT_PROPS'] = 'Дополнительные характеристики товаров для сортировки';
$MESS['FURNITURE_HIDE_SHOW_ALL_BUTTON'] = 'Скрыть кнопку "Все" в блоке "Показывать по"';
$MESS['FURNITURE_HIDE_ICON_SLIDER'] = 'Скрыть слайдер с миниатюрными изображениями';
$MESS['FURNITURE_HIDE_STORE_LIST'] = 'Скрыть список складов в виде "Список"';
$MESS['SHOW_DESCRIPTION_TOP'] = 'Выводить описание раздела над списком товаров';
$MESS['SHOW_DESCRIPTION_BOTTOM'] = 'Выводить описание раздела после списка товаров';

$MESS['SECTION_SHOW_HITS'] = 'Показывать блок хитовых товаров';
$MESS['SECTION_HITS_RCM_TYPE'] = 'Тип рекомендаций для блока хитовых товаров';
$MESS['SECTION_HITS_RCM_TYPE_BESTSELL'] = 'Самые продаваемые';
$MESS['SECTION_HITS_RCM_TYPE_PERSONAL'] = 'Персональные рекомендации';
$MESS['SECTION_HITS_HIDE_NOT_AVAILABLE'] = 'Скрыть отсутствующие товары в блоке хитовых товаров';

//	Detail:
$MESS['SETTINGS_HIDE'] = 'Не выводить указанные свойства';
$MESS['HEAD_REVIWES_BLOCK'] = 'Заголовок для вкладки отзывов';
$MESS['DEF_HEAD_REVIWES_BLOCK'] = 'Отзывы';
$MESS['SHOW_REVIEWS'] = 'Отображать отзывы на детальной';
$MESS['SETTINGS_HIDE_TIP'] = 'Скрывает указанные свойства на детальной странице товаров и в таблице сравнения';

$MESS["CP_BCE_TPL_USE_COMMENTS"] = "Включить отзывы о товаре";
$MESS["CP_BCE_TPL_BLOG_USE"] = "Использовать комментарии";
$MESS["CP_BCE_TPL_BLOG_URL"] = "Название блога латинскими буквами";
$MESS["CP_BCE_TPL_BLOG_EMAIL_NOTIFY"] = "Уведомление по электронной почте";
$MESS["CP_BCE_TPL_FEEDBACK_USE"] = "Использовать гостевую книгу";
$MESS["CP_BCE_TPL_FEEDBACK_IBLOCK_TYPE"] = "Тип инфоблока гостевой книги";
$MESS["CP_BCE_TPL_FEEDBACK_IBLOCK_ID"] = "Инфоблок гостевой книги";
$MESS['CP_BCE_TPL_FEEDBACK_SUCCESS_TEXT'] = 'Сообщение об успешном добавлении отзыва';
$MESS['CP_BCE_TPL_FEEDBACK_SUCCESS_TEXT_DEFAULT'] = 'Спасибо! Ваше сообщение появится после одобрения модератором';

$MESS["CP_BCE_TPL_VK_USE"] = "Использовать Вконтакте";
$MESS["CP_BCE_TPL_VK_API_ID"] = "Идентификатор приложения Вконтакте (API_ID)";
$MESS["CP_BCE_TPL_FB_USE"] = "Использовать Facebook";
$MESS["CP_BCE_TPL_FB_APP_ID"] = "Идентификатор приложения (APP_ID)";

$MESS["CP_BC_TPL_PROP_EMPTY"] = "не выбрано";
$MESS["CP_BC_TPL_LIST_BRAND_USE"] = "Отображать \"Бренды\" отдельным блоком вне фильтра";
$MESS["CP_BC_TPL_LIST_PROP_CODE"] = "Таблица с брендами";
$MESS["CP_BC_TPL_BRAND_DETAIL"] = "Путь к детальной странице бренда";

$MESS["DETAIL_HIDE_ACCESSORIES"] = "Скрыть блок 'Не забудьте добавить к заказу'";
$MESS["DETAIL_HIDE_SIMILAR"] = "Скрыть блок 'Просматриваемые с этим товаром'";
$MESS["DETAIL_HIDE_SIMILAR_VIEW"] = "Скрыть блок 'Похожие товары'";

$MESS["DETAIL_ACCESSORIES_TITLE"] = 'Заголовок блока "Не забудьте добавить к заказу (BigData)"';
$MESS["DETAIL_SIMILAR_TITLE"] = 'Заголовок блока "Похожие товары (BigData)"';
$MESS["DETAIL_SIMILAR_VIEW_TITLE"] = 'Заголовок блока "Просматриваемые с этим товаром (BigData)"';
$MESS["DETAIL_SIMILAR_PRICE_TITLE"] = 'Заголовок блока "Похожие товары (по цене и характеристикам)"';
$MESS["DETAIL_RECOMMENDED_TITLE"] = 'Заголовок блока "Рекомендуемые вместе с этим товаром"';
$MESS["DETAIL_VIEWED_TITLE"] = 'Заголовок блока "Вы смотрели"';

$MESS["DETAIL_ACCESSORIES_TITLE_DEFAULT"] = "Не забудьте добавить к заказу";
$MESS["DETAIL_SIMILAR_TITLE_DEFAULT"] = "Похожие товары";
$MESS["DETAIL_SIMILAR_VIEW_TITLE_DEFAULT"] = "Просматриваемые с этим товаром";
$MESS["DETAIL_SIMILAR_PRICE_TITLE_DEFAULT"] = "Похожие товары";
$MESS["DETAIL_RECOMMENDED_TITLE_DEFAULT"] = "Рекомендуемые вместе с этим товаром";
$MESS["DETAIL_VIEWED_TITLE_DEFAULT"] = "Вы смотрели";

$MESS["DETAIL_SIMILAR_PRICE_PERCENT"] = "\"Похожие товары (по цене и характеристикам)\": максимально допустимая разница в цене, %";
$MESS["DETAIL_SIMILAR_PRICE_PERCENT_TIP"] = "Число от 1 до 100 без знака процента";
$MESS["DETAIL_SIMILAR_PRICE_SMART_FILTER"] = "\"Похожие товары (по цене и характеристикам)\": отбирать по 100% совпадению значений свойств, отображаемых в умном фильтре";
$MESS["DETAIL_SIMILAR_PRICE_SMART_FILTER_TIP_CATALOG"] = 'Управлять списком свойств инфоблока, отображаемых в умном фильтре, можно на странице <a href="/bitrix/admin/cat_catalog_edit.php?IBLOCK_ID=#IBLOCK_ID#&form_catalog_edit_#IBLOCK_ID#_active_tab=edit3">настроек каталога товаров</a>.';
$MESS["DETAIL_SIMILAR_PRICE_SMART_FILTER_TIP_MARKET"] = 'Управлять списком свойств инфоблока, отображаемых в умном фильтре, можно на странице <a href="/bitrix/admin/iblock_edit.php?type=#IBLOCK_TYPE#&tabControl_active_tab=edit2&ID=#IBLOCK_ID#&admin=Y">настроек свойств инфоблока</a>.';
$MESS["DETAIL_SIMILAR_PRICE_WITH_EMPTY_PROPS"] = "\"Похожие товары (по цене и характеристикам)\": также отбирать товары, у которых не заполнены проверяемые свойства";
$MESS["DETAIL_SIMILAR_PRICE_PROPERTIES"] = "\"Похожие товары (по цене и характеристикам)\": учитывать следующие критерии отбора";
$MESS["DETAIL_SIMILAR_PRICE_PROPERTIES_AVAILABLE"] = "Товары доступные для покупки";
$MESS["DETAIL_SIMILAR_PRICE_PROPERTIES_SECTION"] = "Из этого же раздела и подразделов";
$MESS["DETAIL_SIMILAR_PRICE_PROPERTIES_PRICE"] = "С похожей ценой в процентном соотношении";
$MESS["DETAIL_SIMILAR_PRICE_PROPERTIES_TIP"] = '<b>Товары доступные для покупки</b> - накладывает фильтр "CATALOG_AVAILABLE"=>"Y",
то есть использует встроенный в Битрикс механизм определения наличия товаров
(выключен количественный учет, или же доступное количество больше ноля, или же разрешена покупка при отсутствии товара).
В Битронике это будут товары со статусом "В наличии", "Под заказ" и часть товаров "По запросу" с соответствующими параметрами торгового каталога.
Статус товара может не соответствовать в редакции ПРО при учете наличия на отдельных складах (включен складской учет).<br>
<br>
<b>Из этого же раздела и подразделов</b> - будут отобраны только товары, лежащие в одном разделе с текущим товаром или его подразделах.
При отключении этой опции товары будут отбираться из всего инфоблока.<br>
<br>
<b>С похожей ценой в процентном соотношении</b> - будут отобраны лишь те товары, чья цена лежит в диапазоне (X - Y% ... X + Y%),
где X - цена текущего товара, а Y - значение параметра "максимально допустимая разница в цене, %".<br>
<br>
Все остальные критерии - это <b>свойства инфоблока</b>.<br>
Похожие товары будут отбираться только по 100% совпадению значений указанных свойств при условии, что эти свойства заполнены у текущего товара.
А если включена предыдущая опция, то будет учитываться заполненность свойств и у других проверяемых товаров.<br>
Каждое свойство сопоставляется по отдельности, и товар будет признан похожим, если совпали ВСЕ указанные свойства, имеющие значения.
Этот список дополняет свойства, отображаемые в умном фильтре, если включен предыдущий параметр.';

// EDOST:
$MESS["EDOST_SORT"] = "eDost: упорядочить тарифы по возрастанию";
$MESS["EDOST_SHOW_QTY"] = "eDost: ячейка для ввода количества товара";
$MESS["EDOST_SHOW_ADD_CART"] = 'eDost: галочка "Учитывать товары в корзине"';
$MESS["EDOST_MINIMIZE"] = "eDost: минимум информации";
$MESS["EDOST_MINIMIZE_TIP"] = "маленькие иконки + скрыть описание тарифа";
$MESS["EDOST_ECONOMIZE"] = "eDost: экономный расчет";
$MESS["EDOST_ECONOMIZE_TIP"] = "округление в большую сторону веса и стоимости товара и отключение учета габаритов - значительно снижает количество запросов на сервер расчетов. <b>Рекомендуется при использовании встроенного расчета.</b>";
$MESS["EDOST_ECONOMIZE_INLINE"] = "eDost 2.0: экономный расчет для встроенного блока";
$MESS["EDOST_ECONOMIZE_INLINE_TIP"] = "Данная опция включает экономный расчет при использовании встроенного блока с тарифами сразу на странице независимо от предыдущей опции. На мобильных устройствах не отображается подробное окно, там всегда выводится встроенный блок.";
$MESS["EDOST_MAX"] = "eDost 2.0: ограничение количества тарифов для встроенного блока";
$MESS["EDOST_PRICE_VALUE"] = "eDost 2.0: если у товара несколько цен, тогда брать";
$MESS["EDOST_PRICE_VALUE_MAX"] = "максимальную";
$MESS["EDOST_PRICE_VALUE_MIN"] = "минимальную";
$MESS["EDOST_PRICE_VALUE_FIRST"] = "первую";

//REVIEWS:
$MESS['USE_OWN_REVIEW'] = 'Использовать внутренние отзывы сайта';
$MESS['REVIEWS_MODE'] = 'Режим отзывов сайта';
$MESS['REVIEWS_FORUM'] = 'На модуле "Форум"';
$MESS['REVIEWS_BLOG'] = 'На модуле "Блог"';
$MESS['REVIEWS_FEEDBACK'] = 'На модуле "Гостевая книга"';
$MESS['DETAIL_YM_API_USE'] = 'Отзывы с Я.М. API';

//FILTER:
$MESS["FILTER_DISPLAY_ELEMENT_COUNT"] = "Выводить кол-во товаров рядом со значениями свойств";
$MESS["FILTER_VISIBLE_PROPS_COUNT"] = "Сколько свойств не скрывать в подробный фильтр";
$MESS["FILTER_HIDE_DISABLED_VALUES"] = "Скрывать отсутствующие свойства";
$MESS["FILTER_HIDE_DISABLED_VALUES_TIP"] = "По умолчанию значения свойств без товаров лишь затемняются";
$MESS["FILTER_SHOW_NAME_FIELD"] = "Использовать фильтрацию по названию товара";

//STICKERS:
$MESS['STICKER_GROUP'] = 'Настройка умных стикеров';
$MESS["STICKER_NEW"] = "Сколько дней считать товар новинкой";
$MESS["STICKER_HIT"] = "При каком количестве просмотров за неделю, считать товар хитом";
$MESS['STICKER_BESTSELLER'] = 'При каком количестве продаж считать товар лидером';
	$MESS["TAB_PROPERTY"] = "Служебное свойство для стикера ";
		$MESS["TAB_NEW"] = "Новинка";
		$MESS["TAB_HIT"] = "Хит продаж";
		$MESS["TAB_SALE"] = "Скидка";
		$MESS["TAB_BESTSELLER"] = "Рекомендуем";

//SKU:
$MESS["CP_BCS_TPL_PROP_EMPTY"] = "не выбрано";
$MESS["CP_BCS_TPL_OFFER_ADD_PICT_PROP"] = "Дополнительные картинки предложения";
$MESS["CP_BCS_TPL_OFFER_TREE_PROPS"] = "Свойства для отбора предложений";
$MESS["OFFER_VAR_NAME"] = "Название параметра для идентификации SKU на детальной";
$MESS["MANUAL_PROP_NAME"] = "Символьный код свойства для отображения документов";
$MESS["OFFER_VAR_NAME_TIP"] = "Название GET параметра, в котором передается номер торгового предложения для переключения торговых предложений(SKU) на детальной странице товара";
$MESS["ADD_PARENT_PHOTO"] = "Показывать фото родителького товара";
$MESS["ADD_PARENT_PHOTO_TIP"] = "При включенной опции в галлерее картинок товара помимо собственных фотографий товара будут отображаться фотографии родительского товара (в конце списка)";

//STORES:
$MESS["SHOW_AMOUNT_STORE"] = "Показывать наличие на складах";
$MESS["STORES_COUNT"] = "Количество выводимых складов (остальные будут отображены в модальном окне)";
$MESS["SHOW_AMOUNT_STORE_TIP"] = "Для товаров с торговыми предложениями блок с наличием на складах не отображается в списке товаров";

//META
$MESS ['FURNITURE_META_H1'] = "Шаблон для генерации заголовка страницы (H1)";
$MESS ['FURNITURE_META_H1_FORCE'] = "Установить заголовок страницы (H1) из свойства (если заполнено)";
$MESS ['FURNITURE_META_TITLE'] = "Шаблон для генерации заголовка браузера (title)";
$MESS ['FURNITURE_META_TITLE_FORCE'] = "Установить заголовок браузера (title) из свойства (если заполнено)";
$MESS ['FURNITURE_META_KEYWORDS'] = "Шаблон для генерации Keywords";
$MESS ['FURNITURE_META_KEYWORDS_FORCE'] = "Установить Keywords из свойства (если заполнено)";
$MESS ['FURNITURE_META_DESCRIPTION'] = "Шаблон для генерации Description";
$MESS ['FURNITURE_META_DESCRIPTION_FORCE'] = "Установить Description из свойства (если заполнено)";
$MESS ['FURNITURE_META_SPLITTER'] = "Разделитель для свойств имеющих множественное значение";
$MESS ['FURNITURE_META_TITLE_PROP_BUY'] = 'Купить ' ;
$MESS ['FURNITURE_META_COMPARE_SPLITTER'] = "Разделитель для перечисления товаров";
$MESS ['FURNITURE_META_COMPARE_COMPARE'] = "Сравнение #TEXT#";
$MESS ['FURNITURE_META_COMPARE_THAT_BETTER'] = "Что лучше: #TEXT# ?";
$MESS ['FURNITURE_META_COMPARE_THAT_BETTER_BUY'] = "Что лучше купить: #TEXT# ?";

$MESS["FURNITURE_FOUND_CHEAP_USE"] = "Использовать \"Нашли дешевле\"";
$MESS["FURNITURE_FOUND_CHEAP_TYPE"] = "Тип инфоблока \"Нашли дешевле\"";
$MESS["FURNITURE_FOUND_CHEAP_IBLOCK"] = "Инфоблок \"Нашли дешевле\"";

$MESS["FURNITURE_PRICE_LOWER_USE"] = "Использовать \"Сообщить о снижении цены\"";
$MESS["FURNITURE_PRICE_LOWER_TYPE"] = "Тип инфоблока \"Сообщить о снижении цены\"";
$MESS["FURNITURE_PRICE_LOWER_IBLOCK"] = "Инфоблок \"Сообщить о снижении цены\"";

$MESS["FURNITURE_ELEMENT_EXIST_USE"] = "Использовать \"Сообщить о поступлении\"";
$MESS["FURNITURE_ELEMENT_EXIST_TYPE"] = "Тип инфоблока \"Сообщить о поступлении\"";
$MESS["FURNITURE_ELEMENT_EXIST_IBLOCK"] = "Инфоблок \"Сообщить о поступлении\"";

$MESS['FURNITURE_USE_REVIEW'] = 'Показать поля для настройки отзывов (включить/отключить отзывы можно в панели настроек решения)';
$MESS['FURNITURE_USE_STORE'] = 'Показать настройки отображения информации по складам';
$MESS['FURNITURE_USE_MIN_AMOUNT'] = 'Показать настройки отображения информации в нечисловом виде';
$MESS['MIN_AMOUNT_TIP'] = 'Данный параметр используется для <b>текстового</b> представления информации о количестве товара на складах.<br>В <b>графическом</b> представлении значение параметра будет умножено на два, чтобы определить диапазон среднего количества и начало шкалы полного склада.<br><b>Тип представления</b> остатков задается в панели настройки решения.';
// ADV
$MESS["ADV_TYPE"] = "Тип баннера для страницы секции";
$MESS["ADV_SELECT_DEFAULT"] = "выберите тип баннера";

//+++
$MESS["RZ_STORES_MIN_AMOUNT"] = "Минимальное достаточное количество товара на складе";
$MESS["RZ_STORES_SHOW_NUMBERS"] = "Показывать точное количество вместо информации о достаточности";

$MESS['USE_ONECLICK'] = 'Страница с информацией о доставке';
$MESS['SHOW_BY_ALL'] = 'Разрешить показ всех элементов для списка';

$MESS['BIGDATA_RCM_TYPE'] = 'BigData - тип отображаемых рекомендаций';
$MESS['BIGDATA_TITLE'] = 'BigData - заголовок рекомендаций';


$MESS['SIMILAR_TITLE'] = 'Заголовок для блока похожих товаров';
$MESS['DEF_SIMILAR_TITLE'] = 'Похожие товары';

//SUBSECTION
$MESS['SHOW_SUBSECTIONS'] = 'Выводить подразделы в списке';
$MESS['SHOW_DESCRIPTION'] = 'Выводить описание раздела';
$MESS['VIEW_MODE'] = 'Способ вывода подразделов в разделе';
$MESS['VIEW_MODE_TEXT'] = 'только название подразделов';
$MESS['VIEW_MODE_PICTURE'] = 'только изображения подразделов';
$MESS['VIEW_MODE_BOTH'] = 'и изображения и названия подразделов';
$MESS['SUBSECTION_POSITION'] = 'Место вывода описания раздела';
$MESS['SUBSECTION_POSITION_TOP'] = 'Над списком товаров';
$MESS['SUBSECTION_POSITION_BOTTOM'] = 'Под списком товаров';
$MESS['SUBSECTION_POSITION_ALL'] = 'Над списком и под списком';
$MESS['SUBSECTION_POSITION_NONE'] = 'Не выводить описание раздела';
$MESS['FULL_DESCTRIPTION'] = 'Выводить описание раздела полностью (в развернутом виде)';

//PROPERTY
$MESS['SHOW_FULL_PROPS'] = 'Выводить развернутыми характеристики товара';
$MESS['SHOW_FULL_PROPS_ON_COMPARE'] = 'Выводить развернутыми группы характеристик';
$MESS['TITLE_EMPTY_CHAR_GROUP'] = 'Заголовк для группы, для свйоств без группы';
$MESS['DEF_TITLE_EMPTY_CHAR_GROUP'] = 'Основные характеристики товара';

//RECOMMEND
$MESS['DEF_TITLE_RECOMMEND'] = 'Рекомендуемые товары';
$MESS['TITLE_RECOMMEND'] = 'Заголовок блока "Рекомендуемые товары"';
$MESS['RECOMMENDED_PAGE_ELEMENT_COUNT'] = 'Количество товаров выводимых в блоке "С этим товаром покупают"';

//SOCIALS
$MESS ['SHOW_SOCIAL_BUTTONS'] = "Выводить блок 'поделиться в социальных сетях'";
$MESS ['DEF_SHARE_TEXT'] = "Поделиться с друзьями:";
$MESS ['SHARE_TEXT'] = "Заголовк для блока 'Поделиться в социальных сетях'";

$MESS['IBLOCK_OPTIONS_ID'] = 'Инфоблок платных опций';
$MESS['DEF_HEADER_PAID_OPTIONS'] = 'Дополнительные услуги';
$MESS['HEADER_PAID_OPTIONS'] = 'Заголовок для блока дополнительных услуг';
