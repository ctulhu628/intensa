<?
$MESS['RZ_SEARCH_RESULTS'] = 'Результаты поиска';
$MESS['RZ_NOT_FOUND'] = 'По вашему запросу результатов не найдено';