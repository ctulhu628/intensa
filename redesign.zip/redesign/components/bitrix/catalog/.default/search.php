<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
use Yenisite\Furniture\Main;

$APPLICATION->SetTitle(GetMessage("RZ_SEARCH_RESULTS"));
$APPLICATION->AddChainItem(GetMessage("RZ_SEARCH_RESULTS"));
$this->setFrameMode(true);
$isAjax = \Yenisite\Core\Ajax::isAjax();
\Bitrix\Main\Localization\Loc::loadLanguageFile($_SERVER['DOCUMENT_ROOT'] . '/' . SITE_TEMPLATE_PATH . '/catalog.php');
// hack search request
if (empty($_GET['where']) || empty($_REQUEST['where'])) {
	$_GET['where'] = $_REQUEST['where'] = 'iblock_' . $arParams['IBLOCK_TYPE'];
}

if ($_GET['where'] === 'ALL' || $_REQUEST['where'] === 'ALL') {
	$_GET['where'] = $_REQUEST['where'] = '';
}

$arSectionParams = include 'include/prepare_params_section.php';

$arSearchParams = array(
		"FILTER_NAME" => 'searchFilter',
		"SECTION_ID" => "",
		"SECTION_CODE" => "",
		"SECTION_USER_FIELDS" => array(),
		"INCLUDE_SUBSECTIONS" => "Y",
		"SHOW_ALL_WO_SECTION" => "Y",
		"META_KEYWORDS" => "",
		"META_DESCRIPTION" => "",
		"BROWSER_TITLE" => "",
		"ADD_SECTIONS_CHAIN" => "N",
		"SET_TITLE" => "N",
		"SET_STATUS_404" => "N",
		"CACHE_FILTER" => "N",
		"CACHE_GROUPS" => "N",
		"HIDE_NAV" => 'Y',
);

$arSearchParams = array_merge($arSectionParams, $arSearchParams);

$arElements = $APPLICATION->IncludeComponent(
		"bitrix:search.page",
		"search",
		Array(
				"RESTART" => "N",
				"NO_WORD_LOGIC" => "Y",
				"USE_LANGUAGE_GUESS" => "N",
				"CHECK_DATES" => "Y",
				"arrFILTER_iblock_" . $arParams["IBLOCK_TYPE"] => array($arParams["IBLOCK_ID"]),
				"USE_TITLE_RANK" => "N",
				"DEFAULT_SORT" => "rank",
				"FILTER_NAME" => '',
				"arrFILTER" => array(
						0 => "iblock_" . $arParams["IBLOCK_TYPE"],
						//1 => "iblock_" . $arParams["IBLOCK_TYPE_FILTER_FOR_NEWS"],
				),
				//"arrFILTER_" . $arParams["IBLOCK_TYPE_FILTER_FOR_NEWS"] => array(
				//		0 => $arParams["IBLOCK_FILTER_FOR_NEWS"],
				//),
				"SHOW_WHERE" => "Y",
				"arrWHERE" => array(
						0 => "iblock_" . $arParams["IBLOCK_TYPE"],
					//1 => "iblock_" . $arParams["IBLOCK_TYPE_FILTER_FOR_NEWS"],
				),
				"SHOW_WHEN" => "N",
				"PAGE_RESULT_COUNT" => 20,
				"DISPLAY_TOP_PAGER" => "N",
				"DISPLAY_BOTTOM_PAGER" => "Y",
				"PAGER_SHOW_ALWAYS" => "N",
				"PAGER_TEMPLATE" => "",

				"IBLOCK_TYPE" => $arParams['IBLOCK_TYPE'],
		),
		$component,
		array('HIDE_ICONS' => 'Y')
);

if ($_REQUEST['where'] !== 'iblock_' . $arParams['IBLOCK_TYPE']) return;

if (!empty($arElements) && is_array($arElements)) {
	global $searchFilter;
	$searchFilter = array(
			"=ID" => $arElements,
	);
	$arSearchParams['HIDE_SEBSECTIONS_DESC'] = 'Y';
	?>
	<? if ($isAjax) $APPLICATION->RestartBuffer() ?>
	<div class="ordering3" id="catalog_wrapper">
		<? $APPLICATION->IncludeComponent(
				"bitrix:catalog.section",
				"main",
				$arSearchParams,
				$component,
				array('HIDE_ICONS' => 'Y')
		); ?>
	</div>
	<? if ($isAjax) die() ?>
	<?
}
