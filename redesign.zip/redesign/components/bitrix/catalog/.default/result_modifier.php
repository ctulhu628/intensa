<?
global $rz_options;
\Yenisite\Core\Ajax::saveParams($this, $arParams);

$arParams['ARTICUL_PROP'] = $arParams['ARTICUL_PROP'] ? : 'ARTICLE';
$arParams['ARTICUL_PROP'] = $rz_options['show_article'] != 'N' ? $arParams['ARTICUL_PROP'] : '';
$arParams['USE_ONECLICK'] = $arParams['USE_ONECLICK'] ? : 'Y';
$arParams['SHOW_FULL_PROPS'] = $arParams['SHOW_FULL_PROPS'] ? : 'Y';
$arParams['SHOW_SUBSECTIONS'] = $arParams['SHOW_SUBSECTIONS'] ? : 'Y';
$arParams['BRAND_USE'] = $arParams['BRAND_USE'] ? : 'Y';
$arParams['BRAND_USE'] = $arParams['BRAND_USE'] ? : 'Y';
$arParams['BRAND_PROP_CODE'] = $arParams['LIST_BRAND_PROP_CODE'] ? : 'BRANDS_REF';
$arParams['SHOW_DESCRIPTION'] = $arParams['SHOW_DESCRIPTION'] ? : 'Y';
$arParams['SHOW_REVIEWS'] = $arParams['SHOW_REVIEWS'] ? : 'Y';
$arParams['SHOW_FULL_PROPS_ON_COMPARE'] = $arParams['SHOW_FULL_PROPS_ON_COMPARE'] ? : 'Y';
$arParams['USE_STORE'] = $arParams['USE_STORE'] ? : 'Y';
$arParams['DISPLAY_ONECLICK'] = $arParams['DISPLAY_ONECLICK'] ? : 'Y';
$arParams['MIN_AMOUNT'] = $arParams['MIN_AMOUNT'] ? : 25;
$arParams['FULL_DESCTRIPTION'] = $arParams['FULL_DESCTRIPTION'] ? : 'N';
$arParams['STORES_COUNT'] = $arParams['STORES_COUNT'] ? : 2;
$arParams['RESIZER_SECTION_IMG'] = $arParams['RESIZER_SECTION_IMG'] ? : 4;
$arParams['RESIZER_BRAND_DETAIL'] = $arParams['RESIZER_BRAND_DETAIL'] ? : 5;
$arParams['TITLE_RECOMMEND'] = $arParams['TITLE_RECOMMEND'] ? : GetMessage('TITLE_RECOMMEND');
$arParams['SHARE_TEXT'] = $arParams['SHARE_TEXT'] ? : GetMessage('DEF_SHARE_TEXT');
$arParams['VIEW_MODE'] = $arParams['VIEW_MODE'] ? : 'BOTH';
$arParams['SUBSECTION_POSITION'] = $arParams['SUBSECTION_POSITION'] ? : 'TOP';
$arParams['LIST_BRAND_PROP_CODE'] = $arParams['LIST_BRAND_PROP_CODE'] ? : 'BRANDS_REF';
$arParams['SIMILAR_TITLE'] = $arParams['SIMILAR_TITLE'] ? : GetMessage('SIMILAR_TITLE');
$arParams['HEAD_REVIWES_BLOCK'] = $arParams['HEAD_REVIWES_BLOCK'] ? : GetMessage('DEF_HEAD_REVIWES_BLOCK');
$arParams['TITLE_EMPTY_CHAR_GROUP'] = $arParams['TITLE_EMPTY_CHAR_GROUP'] ? : GetMessage('DEF_TITLE_EMPTY_CHAR_GROUP');
$arParams['SETTINGS_HIDE'] = array_merge($arParams['SETTINGS_HIDE'], $arParams['PRODUCT_PROPERTIES']);
$arParams["COMPARE_PROPERTY_CODE"] =
$arParams["DETAIL_PROPERTY_CODE"] = \Yenisite\Furniture\Main::getDetailPropShowList($arParams['IBLOCK_ID'], $arParams['SETTINGS_HIDE']);
\Yenisite\Core\Ajax::saveParams($this, $arParams, 'bitrix_catalog', SITE_ID);