<? use Yenisite\Core\Catalog;
use Yenisite\Furniture\Main;
use \Yenisite\Furniture\Mobile;

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */
/** @var CBitrixComponent $component */

$sortField = 'PROPERTYSORT_RZ_AVAILABLE';
global $rz_options;
global $rz_options;

$arSort = Main::getSortAvailable();
$arDefSort = array();
foreach ($arSort as $key => &$value) {
	$arDefSort[$key] = $value['PROP'];
}
unset($value);
$curSort = Catalog::getSort($arParams, false, false, $arDefSort);

unset($value);
$arShow = array('12', '24', '48');
if ($arParams['SHOW_BY_ALL'] == 'Y') {
	$arShow[] = 'ALL';
}

$showBy = Catalog::getCount(false, $arShow);

$viewMode = Catalog::getViewMode(false, array('blocks', 'list', 'table'));
if (Mobile::isMobile()) $viewMode = 'blocks';

return array(
	"SHOW_ALL_WO_SECTION" => "Y",
	"FILTER_NAME" => $arParams["FILTER_NAME"],
	"PAGE_ELEMENT_COUNT" => $showBy,
	"IBLOCK_TYPE" => $arParams["IBLOCK_TYPE"],
	"IBLOCK_ID" => $arParams["IBLOCK_ID"],
	"ELEMENT_SORT_FIELD" => $sortField,
	"ELEMENT_SORT_ORDER" => 'ASC',
	"ELEMENT_SORT_FIELD2" => $curSort['BY'],
	"ELEMENT_SORT_ORDER2" => $curSort['ORDER'],
	"META_KEYWORDS" => $arParams["LIST_META_KEYWORDS"],
	"META_DESCRIPTION" => $arParams["LIST_META_DESCRIPTION"],
	"BROWSER_TITLE" => $arParams["LIST_BROWSER_TITLE"],
	"SECTION_URL" => $arResult["FOLDER"] . $arResult["URL_TEMPLATES"]["section"],
	"DETAIL_URL" => $arResult["FOLDER"] . $arResult["URL_TEMPLATES"]["element"],
	"BASKET_URL" => $arParams["BASKET_URL"],
	"ACTION_VARIABLE" => $arParams["ACTION_VARIABLE"],
	"PRODUCT_ID_VARIABLE" => $arParams["PRODUCT_ID_VARIABLE"],
	"SECTION_ID_VARIABLE" => $arParams["SECTION_ID_VARIABLE"],
	"PRODUCT_QUANTITY_VARIABLE" => $arParams["PRODUCT_QUANTITY_VARIABLE"],
	"PRODUCT_PROPS_VARIABLE" => $arParams["PRODUCT_PROPS_VARIABLE"],
	"INCLUDE_SUBSECTIONS" => $arParams["INCLUDE_SUBSECTIONS"],
	"ADD_SECTIONS_CHAIN" => "Y",
	"PROPERTY_CODE" => $arParams["LIST_PROPERTY_CODE"],
	"PRICE_CODE" => $arParams["PRICE_CODE"],
	"USE_PRICE_COUNT" => "N",
	"SHOW_PRICE_COUNT" => $arParams["SHOW_PRICE_COUNT"],
	"PRICE_VAT_INCLUDE" => $arParams["PRICE_VAT_INCLUDE"],
	"PRICE_VAT_SHOW_VALUE" => $arParams["PRICE_VAT_SHOW_VALUE"],
	"USE_PRODUCT_QUANTITY" => $arParams["USE_PRODUCT_QUANTITY"],
	"ADD_PROPERTIES_TO_BASKET" => (isset($arParams["ADD_PROPERTIES_TO_BASKET"]) ? $arParams["ADD_PROPERTIES_TO_BASKET"] : ''),
	"PARTIAL_PRODUCT_PROPERTIES" => (isset($arParams["PARTIAL_PRODUCT_PROPERTIES"]) ? $arParams["PARTIAL_PRODUCT_PROPERTIES"] : ''),
	"PRODUCT_PROPERTIES" => $arParams["PRODUCT_PROPERTIES"],
	"CACHE_TYPE" => $arParams["CACHE_TYPE"],
	"CACHE_TIME" => $arParams["CACHE_TIME"],
	"CACHE_GROUPS" => $arParams["CACHE_GROUPS"],
	"CACHE_FILTER" => $arParams["CACHE_FILTER"],
	"SET_TITLE" => $arParams["SET_TITLE"],
	"SET_STATUS_404" => $arParams["SET_STATUS_404"],
	//sku:
	'OFFER_TREE_PROPS' => $arParams['OFFER_TREE_PROPS'],
	'OFFER_ADD_PICT_PROP' => $arParams['OFFER_ADD_PICT_PROP'],
	"OFFERS_CART_PROPERTIES" => $arParams["OFFERS_CART_PROPERTIES"],
	"OFFERS_FIELD_CODE" => $arParams["LIST_OFFERS_FIELD_CODE"],
	"OFFERS_PROPERTY_CODE" => array_merge($arParams["OFFERS_CART_PROPERTIES"], $arParams["LIST_OFFERS_PROPERTY_CODE"]),
	"OFFERS_SORT_FIELD" => $arParams["OFFERS_SORT_FIELD"],
	"OFFERS_SORT_ORDER" => $arParams["OFFERS_SORT_ORDER"],
	"OFFERS_SORT_FIELD2" => $arParams["OFFERS_SORT_FIELD2"],
	"OFFERS_SORT_ORDER2" => $arParams["OFFERS_SORT_ORDER2"],
	"OFFERS_LIMIT" => $arParams["LIST_OFFERS_LIMIT"],

	'PRODUCT_SUBSCRIPTION' => $arParams['PRODUCT_SUBSCRIPTION'],
	'SHOW_OLD_PRICE' => $arParams['SHOW_OLD_PRICE'],
	'MESS_BTN_BUY' => $arParams['MESS_BTN_BUY'],
	'MESS_BTN_ADD_TO_BASKET' => $arParams['MESS_BTN_ADD_TO_BASKET'],
	'MESS_BTN_SUBSCRIBE' => $arParams['MESS_BTN_SUBSCRIBE'],
	'MESS_BTN_DETAIL' => $arParams['MESS_BTN_DETAIL'],
	'MESS_NOT_AVAILABLE' => $arParams['MESS_NOT_AVAILABLE'],

	"SECTION_ID" => $arResult["VARIABLES"]["SECTION_ID"],
	"SECTION_CODE" => $arResult["VARIABLES"]["SECTION_CODE"],
	'CONVERT_CURRENCY' => $arParams['CONVERT_CURRENCY'],
	'CURRENCY_ID' => $arParams['CURRENCY_ID'],
	'HIDE_NOT_AVAILABLE' => $arParams['HIDE_NOT_AVAILABLE'],
	'LABEL_PROP' => $arParams['LABEL_PROP'],
	'ADD_PICT_PROP' => $arParams['ADD_PICT_PROP'],
	'PRODUCT_DISPLAY_MODE' => $arParams['PRODUCT_DISPLAY_MODE'],
	'HIDE_ICON_SLIDER' => $arParams['HIDE_ICON_SLIDER'],
	"ADD_PARENT_PHOTO" => $arParams["ADD_PARENT_PHOTO"],

	// paginator:
	'PAGER_SHOW_ALWAYS' => $arParams['PAGER_SHOW_ALWAYS'],
	'PAGER_DESC_NUMBERING' => $arParams['PAGER_DESC_NUMBERING'],
	'PAGER_DESC_NUMBERING_CACHE_TIME' => $arParams['PAGER_DESC_NUMBERING_CACHE_TIME'],
	'PAGER_SHOW_ALL' => $arParams['PAGER_SHOW_ALL'],
	'PAGER_TEMPLATE' => $arParams['PAGER_TEMPLATE'],
	'DISPLAY_TOP_PAGER' => $arParams['DISPLAY_TOP_PAGER'],
	'DISPLAY_BOTTOM_PAGER' => $arParams['DISPLAY_BOTTOM_PAGER'],
	'PAGER_TITLE' => $arParams['PAGER_TITLE'],

	//store:
	'USE_STORE' => $arParams['USE_STORE'],
	'USE_STORE_PHONE' => $arParams['USE_STORE_PHONE'],
	'USE_MIN_AMOUNT' => $arParams['USE_MIN_AMOUNT'],
	'MIN_AMOUNT' => $arParams['MIN_AMOUNT'],
	'STORES_COUNT' => $arParams['STORES_COUNT'],
	'STORES_SHOW_NUMBERS' => $arParams['STORES_SHOW_NUMBERS'],

	//AMOUNT
	'SHOW_AMOUNT' => $rz_options['section_amount'] != 'N',

	//resizer:
	"RESIZER_IMAGE" => $arParams["RESIZER_IMAGE"],
	"RESIZER_THUMB" => $arParams["RESIZER_THUMB"],
	"RESIZER_SUBSECTION" => $arParams["RESIZER_SUBSECTION"],
	"RESIZER_SECTION_IMG" => $arParams["RESIZER_SECTION_IMG"],
	//stickers :
	"STICKER_NEW" => $arParams['STICKER_NEW'],
	"STICKER_HIT" => $arParams['STICKER_HIT'],
	"STICKER_BESTSELLER" => $arParams['STICKER_BESTSELLER'],
	"TAB_PROPERTY_NEW" => $arParams['TAB_PROPERTY_NEW'],
	"TAB_PROPERTY_HIT" => $arParams['TAB_PROPERTY_HIT'],
	"TAB_PROPERTY_SALE" => $arParams['TAB_PROPERTY_SALE'],
	"TAB_PROPERTY_BESTSELLER" => $arParams['TAB_PROPERTY_BESTSELLER'],
	"MAIN_SP_ON_AUTO_NEW" => $arParams['MAIN_SP_ON_AUTO_NEW'],

	//articul:
	"ARTICUL_PROP" => $arParams['ARTICUL_PROP'],

	//reviews
	'USE_REVIEW' => $arParams['USE_REVIEW'],
	'USE_OWN_REVIEW' => $arParams['USE_OWN_REVIEW'],
	'REVIEWS_MODE' => $arParams['REVIEWS_MODE'],
	"FEEDBACK_IBLOCK_ID" => $arParams["FEEDBACK_IBLOCK_ID"],
	//
	'VIEW_MODE' => $viewMode,
	'USE_ONECLICK' => $arParams['USE_ONECLICK'],
	'ARSORT' => $arSort,
	'CURSORT' => $curSort,
	'ARSHOW' => $arShow,
	'CURSHOW' => $showBy,

	'SECTION_COUNT_ELEMENTS' => $arParams['SECTION_COUNT_ELEMENTS'],
	'VIEW_MODE_SECTION_LIST' => $arParams['VIEW_MODE'],
	'SUBSECTION_POSITION' => $arParams['SUBSECTION_POSITION'],
	'SECTION_TOP_DEPTH' => $arParams['SECTION_TOP_DEPTH'],
	'FULL_DESCTRIPTION' => $arParams['FULL_DESCTRIPTION'] == 'Y',

	'DISPLAY_ONECLICK' => $arParams['DISPLAY_ONECLICK'] == 'Y',
	'SHOW_CATCH_BUY' => $rz_options['section_catch_buy'] == 'Y',
	'SHOW_ONE_CLICK' => $rz_options['section_one_click'] != 'N',
	'SHOW_DESCRIPTION' => $rz_options['section_description'] != 'N',
	'SHOW_SUBSECTIONS' => $rz_options['show_subsections'] != 'N',
	"TYPE_MENU" => $rz_options['main_menu_position'],
	"TYPE_FILTER_POSITION" =>$rz_options['filter_position'],
	"SHOW_BANNERS" =>$rz_options["section_banners"]!="N",
);