<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();
	$arParamsOwnwer = array(
			"CACHE_TYPE" => 'A',
			"CACHE_TIME" => 1,
			"MESSAGES_PER_PAGE" => $arParams["MESSAGES_PER_PAGE"],
			"USE_CAPTCHA" => $arParams["USE_CAPTCHA"],
			"PATH_TO_SMILE" => $arParams["PATH_TO_SMILE"],
			"FORUM_ID" => $arParams["FORUM_ID"],
			"ELEMENT_ID" => $arResult['ID'],
			"IBLOCK_ID" => $arParams["IBLOCK_ID"],
			"AJAX_POST" => $arParams["REVIEW_AJAX_POST"],
			"RZ_AJAX" => $bAjax,
			"POST_FIRST_MESSAGE" => $arParams["POST_FIRST_MESSAGE"],
			"URL_TEMPLATES_DETAIL" => "",
			"HEAD_REVIWES_BLOCK" => $arParams['HEAD_REVIWES_BLOCK'],
			"AUTOSAVE" => false,
			"PREORDER" => (!empty($arParams["PREORDER"])) ? $arParams["PREORDER"] : "N",
			"PAGE_NAVIGATION_TEMPLATE" => ".default",
			'RESIZER_DETAIL_COMMENTS' => $arParams['RESIZER_DETAIL_COMMENTS']
		);?>
