<div class="row catalog-bottom-images">
	<?global $demoIBlock;?>
    <? if (\Bitrix\Main\Loader::includeModule("advertising")): ?>
		<?
			$typeBanner = "fu_catalog_bottom_left";
			if(!empty($demoIBlock['ID_BANNERS'])) $typeBanner .= "_" . $demoIBlock['ID_BANNERS'];
		?>
        <? $APPLICATION->IncludeComponent(
            "bitrix:advertising.banner",
            "catalog_bottom",
            Array(
                "TYPE" => $typeBanner,
                "NOINDEX" => "Y",
                "CACHE_TYPE" => "A",
                "CACHE_TIME" => "3600",
            )
        ); ?>
    <? endif ?>
    <? if (\Bitrix\Main\Loader::includeModule("advertising")): ?>
		<?
			$typeBanner = "fu_catalog_bottom_right";
			if(!empty($demoIBlock['ID_BANNERS'])) $typeBanner .= "_" . $demoIBlock['ID_BANNERS'];
		?>
        <? $APPLICATION->IncludeComponent(
            "bitrix:advertising.banner",
            "catalog_bottom",
            Array(
                "TYPE" => $typeBanner,
                "NOINDEX" => "Y",
                "CACHE_TYPE" => "A",
                "CACHE_TIME" => "3600",
            )
        ); ?>
    <? endif ?>
</div>