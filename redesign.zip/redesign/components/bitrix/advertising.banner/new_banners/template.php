<?
use Yenisite\Furniture\Main;
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();
$this->setFrameMode(true);
$id = 'bxdinamic_banner_'/*.$arResult['BANNER_PROPERTIES']['ID'].'_'*/.$arResult['BANNER_PROPERTIES']['CONTRACT_ID'].'_'.$arResult['BANNER_PROPERTIES']['TYPE_SID']; ?>
<? Main::includeDebug($this);?>
<div id="<?=$id?>"  class="<?if($arParams['BANNER_SMALL']):?>banner-1<?else:?>banner-2<?endif?>">
	<?$frame = $this->createFrame($id, false)->begin(\Yenisite\Furniture\Main::insertCompositLoader());?>
	<?if(!empty($arResult['BANNER_PROPERTIES']) && intval($arResult['BANNER_PROPERTIES']["IMAGE_ID"]) > 0):?>
		<a href="<?=CAdvBanner::GetRedirectURL($arResult['BANNER_PROPERTIES']['URL'], $arResult['BANNER_PROPERTIES'])?>" target="<?=$arResult['BANNER_PROPERTIES']['URL_TARGET']?>">

			<img  src="<?=SITE_TEMPLATE_PATH.'/img/ring.gif'?>" class="lazy" data-original="<?=CFile::GetPath($arResult['BANNER_PROPERTIES']["IMAGE_ID"])?>" alt="<?=$arResult['BANNER_PROPERTIES']["IMAGE_ALT"]?>">
			<!-- <span class="catalog-image-bottom-text left"><b></b></span> -->
		</a>
	<?endif;?>
	<?$frame->end()?>
</div>