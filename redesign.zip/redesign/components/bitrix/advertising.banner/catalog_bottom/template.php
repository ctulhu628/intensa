<?
use Yenisite\Furniture\Main;
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();
$this->setFrameMode(true);
$id = 'bxdinamic_banner_'/*.$arResult['BANNER_PROPERTIES']['ID'].'_'*/.$arResult['BANNER_PROPERTIES']['CONTRACT_ID'].'_'.$arResult['BANNER_PROPERTIES']['TYPE_SID']; ?>
<? Main::includeDebug($this);?>
<div id="<?=$id?>"  class="<?if(!empty($arParams['FULL'])):?>col-sm-12<?else:?>col-md-6 col-sm-6 col-xs-12<?endif?>">
	<?$frame = $this->createFrame($id, false)->begin(\Yenisite\Furniture\Main::insertCompositLoader());?>
		<?if(!empty($arResult['BANNER_PROPERTIES']) && intval($arResult['BANNER_PROPERTIES']["IMAGE_ID"]) > 0):?>
			<?if(!empty($arParams['RESPON'])):?>
					<div class="banner embed-responsive">
				<?endif?>
						<a class="<?=$arParams['RESPON'] ? 'banner-link' :''?> <?if(!empty($arResult['BANNER_PROPERTIES']['CODE'])):?> <?=$arParams['DARK'] ? 'cover-dark' : 'cover-light' ?> <?else:?>embed-responsive<?endif?>" href="<?=CAdvBanner::GetRedirectURL($arResult['BANNER_PROPERTIES']['URL'], $arResult['BANNER_PROPERTIES'])?>" target="<?=$arResult['BANNER_PROPERTIES']['URL_TARGET']?>">

						<img  src="<?=SITE_TEMPLATE_PATH.'/img/ring.gif'?>" class="lazy embed-responsive-item" data-original="<?=CFile::GetPath($arResult['BANNER_PROPERTIES']["IMAGE_ID"])?>" alt="<?=$arResult['BANNER_PROPERTIES']["IMAGE_ALT"]?>">
							<!-- <span class="catalog-image-bottom-text left"><b></b></span> -->
							<?if(!empty($arResult['BANNER_PROPERTIES']['CODE'])):?>
								<?=$arResult['BANNER_PROPERTIES']['CODE']?>
							<?endif?>
						</a>
				<?if(!empty($arParams['RESPON'])):?>
					</div>
				<?endif?>
		<?endif;?>
	<?$frame->end()?>
</div>