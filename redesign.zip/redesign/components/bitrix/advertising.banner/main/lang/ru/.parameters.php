<?$MESS['DARK_BAKGROUND'] = 'Темный фон для банера';
$MESS['BIG_BANNER'] = 'Сделать большим';
$MESS['TOP_BANNER'] = 'Добавить разрыв снизу между банерами';