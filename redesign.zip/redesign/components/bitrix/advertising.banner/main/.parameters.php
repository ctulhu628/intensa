<?
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

$arTemplateParameters = array(
	"DARK" => Array(
		"NAME" => GetMessage("DARK_BAKGROUND"),
		"TYPE" => "CHECKBOX",
		"DEFAULT" => "Y",
	),
	"BIG" => Array(
		"NAME" => GetMessage("BIG_BANNER"),
		"TYPE" => "CHECKBOX",
		"DEFAULT" => "Y",
	),
	"TOP" => Array(
		"NAME" => GetMessage("TOP_BANNER"),
		"TYPE" => "CHECKBOX",
		"DEFAULT" => "Y",
	),
);