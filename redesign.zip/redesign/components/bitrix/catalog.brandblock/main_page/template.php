<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

$this->setFrameMode(true);
// echo "<pre style='text-align:left;'>";print_r($arResult);echo "</pre>";
include $_SERVER["DOCUMENT_ROOT"].SITE_TEMPLATE_PATH.'/include/debug_info_dynamic.php';
?>
<? if (!empty($arResult['ITEMS'])): ?>
<div class="manufacturers">
	<div class="manufacturers-title pseudo-h2 text-center">
		<span><?= $arParams['HEADER'] ?></span>
		<a class="classic-link" href="<?=$arParams['PATH_FOLDER']?>"><?=GetMessage('ALL_MANUFACTURE')?></a>
	</div>
	<? if ($arResult['show_cloud']): ?>
		<?
		$minFont = 12;
		$maxFont = 20;
		$fontSteps = $maxFont - $minFont;
		$range = max(.01, $fontSteps) * 1.0001;
		?>
		<div class="brands-tagcloud" data-switch=".brand-tag">
			<? foreach ($arResult['ITEMS'] as $arItem): ?>
				<?
				$cnt = (int)$arResult['BRANDS_CNT'][$arItem['UF_XML_ID']];
				$fontSize = $minFont + 1 + floor($fontSteps * ($cnt - $arResult['BRANDS_CNT_MIN']) / $range);
				if($cnt > 0):?>
					<a class="brand-tag" href="<?= $arItem['LINK'] ?>" style="font-size: <?= $fontSize ?>px"><?= $arItem['NAME'] ?>
						<sup><?= $cnt ?></sup></a>
				<?endif;?>
			<? endforeach ?>
		</div><!-- /.brands-tagcloud -->
	<? else: ?>
		<? $id = 'bx_dynamic_' . $this->randString(20) ?>
		<div class="manufacturers-wrap row" id="mans" data-sly-to="767">
			<div class="slidee" id="<?= $id ?>">
				<?$frame = $this->createFrame($id, false)->begin();?>
				<?	if (!empty($arResult['ITEMS'])):?>
					<?foreach($arResult['ITEMS'] as $arItem):?>
						<div class="col-lg-3 col-md-4 col-sm-6 col-xs-12">
							<div class="d-table">
								<div class="manufacturer">
									<a href="<?= $arItem['LINK'] ?>" class="manufacturer-link" title="<?= $arItem['NAME'] ?>">
										<img data-original="<?=\Yenisite\Furniture\Main::GetResizedImg($arItem['PICT']['SRC'],array('WIDTH' => 145, 'HEIGHT' => 145, 'SET_ID' =>$arParams['RESIZER_BRAND_IMAGE']))?>"  src="<?=SITE_TEMPLATE_PATH.'/img/ring.gif'?>" alt="<?= $arItem['NAME'] ?>" class="manufacturer-logo lazy">
									</a>
								</div>
							</div>
						</div>
					<?endforeach?>
				<?endif?>
				<?$frame->end();?>
			</div>
			<div class="pages-wrap">
				<button class="prevPage three-color-p flaticon-left207">
					<span class="cbutton cbutton--effect-lazar cbutton--effect-lazar-inverted"></span>
				</button>
				<div class="nums">
					<span class="num-current"></span> /
					<span class="num-total"></span>
				</div>
				<ul class="pages">
					<li></li>
				</ul>
				<button class="nextPage three-color-p flaticon-right218">
					<span class="cbutton cbutton--effect-lazar"></span>
				</button>
			</div><!-- pages-wrap -->
		</div><!-- .manufacturers -->
	<? endif ?>
</div>

	<div class="row">
		<div class="col-lg-12 all-manufacturers-row">
			<a href="#mans" class="all-manufacturers flaticon-navigate2 collapsed" data-text="<?=GetMessage('ALL_MANUFACTURE')?>" data-text-when-opened="<?=GetMessage('HIDE')?>">
				<img src="<?=SITE_TEMPLATE_PATH.'/img/button.png'?>" alt="" class="bg">
			</a>
		</div>
	</div>
<? endif ?>