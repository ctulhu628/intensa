<?
$MESS['CP_BCSF_FILTER_NAME'] = "Имя входного массива фильтрации";
$MESS['PATH_FOLDER'] = "Путь до списка брендов";
$MESS["CP_BCSF_CATALOG_FILTER_NAME"] = "Имя массива для фильтрации в каталоге товаров";
$MESS["BRAND_DETAIL"] = "Путь к детальной странице бренда";

$MESS ['HL_NAME_FIELD'] = "Поле содержащее имя элемента";
$MESS ['HL_IMG_FIELD'] = "Поле содержащее картинку элемента";
$MESS ['HL_LINK_FIELD'] = "Поле содержащее ссылку элемента";

$MESS["IBLOCK_CB_PROP_CODE"] = "Таблица брендов";
$MESS["RESIZER_BRAND_IMAGE"] = "Картинка для брендов";
?>