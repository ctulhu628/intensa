<?
$MESS['ALL_MANUFACTURE'] = 'все производители';
$MESS['HIDE'] = 'свернуть';