<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
use Yenisite\Furniture\Main;
use \Yenisite\Core\Tools;
use \Yenisite\Core\Ajax;

$isAjax = Tools::isAjax();
if (!$isAjax) {
	Ajax::saveParams($this, $arParams, 'personal_orders');
}
?>
<? if (!empty($arResult['ERRORS']['FATAL'])): ?>
	<? Main::ShowMessage($arResult['ERRORS']['FATAL']); ?>
<? else: ?>
	<? if (!empty($arResult['ERRORS']['NONFATAL'])): ?>
		<? Main::ShowMessage($arResult['ERRORS']['NONFATAL'], Main::MSG_TYPE_WARNING); ?>
	<? endif ?>
	<? if (!$isAjax): ?>
		<div class="order-history tabs tabs-style-linebox" id="order-history">
	<? endif ?>
	<? if (!empty($arResult['ORDERS'])): ?>
		<? if (!$isAjax): ?>
			<form id="personal_orders_filter" class="order-history__search" <? Ajax::printAjaxDataAttr($this, 'personal_orders') ?>>
				<label class="form-group order-code">
					<span class="label-text"><?= GetMessage('RZ_KOD_ZAKAZA') ?>:</span>
					<input name="filter_id" type="text" class="form-control">
				</label>
				<div class="form-group date-inputs">
					<span class="label-text"><?= GetMessage('RZ_DATA_ZAKAZA') ?>:</span>
					<input name="filter_date_from" class="form-control date-masked" id="datemask-ot" placeholder="DD.MM.YYYY"/>
					<span class="mdash hidden-xs hidden-sm">&mdash;</span>
					<input name="filter_date_to" class="form-control date-masked hidden-xs hidden-sm" id="datemask-do"
						   placeholder="DD.MM.YYYY"/>
				</div>
				<button type="submit" class="three-color-p btn-show-result flaticon-pointing6"><?= GetMessage('RZ_POKAZAT') ?></button>
			</form>
			<div class="order-history__search-results">
				<ul class="nav nav-pills" role="tablist">
					<li role="presentation" class="active">
						<a href="#" data-status-id="show_all" aria-controls="all" role="tab" data-toggle="pill">
							<span class="text"><?= GetMessage('RZ_VSE') ?></span>
						</a>
					</li>
					<li role="presentation">
						<a href="#" data-status-id="P" aria-controls="all" role="tab" data-toggle="pill">
							<span class="text"><?= GetMessage('RZ_OPLACHENNIE') ?></span>
						</a>
					</li>
					<li role="presentation">
						<a href="#" data-status-id="canceled" aria-controls="all" role="tab" data-toggle="pill">
							<span class="text"><?= GetMessage('RZ_OTMENENNIE') ?></span>
						</a>
					</li>
					<li role="presentation">
						<a href="#" data-status-id="F" aria-controls="all" role="tab" data-toggle="pill">
							<span class="text"><?= GetMessage('RZ_DOSTAVLENNIE') ?></span>
						</a>
					</li>
				</ul>
			</div>
			<div id="personal_orders_content">
		<? endif ?>
		<table class="order-history-table">
			<thead>
			<tr>
				<th><?= GetMessage('RZ_NUM_ZAK') ?></th>
				<th><?= GetMessage('RZ_STOIM_ZAK') ?></th>
				<th><?= GetMessage('MARKETPLACE_SPOL_STATUS') ?></th>
				<th><?= GetMessage('MARKETPLACE_ITEMS') ?></th>
				<th><?= GetMessage('MARKETPLACE_PAYMENT_DELIVERY') ?></th>
				<th><?= GetMessage('MARKETPLACE_SPOL_ACTIONS') ?></th>
			</tr>
			</thead>
			<tbody>
			<? foreach ($arResult["ORDERS"] as $key => $order): ?>
				<tr>
					<td>
						<a href="<?= $order["ORDER"]["URL_TO_DETAIL"] ?>"
						   class="classic-link order-number"><?= $order["ORDER"]["ACCOUNT_NUMBER"] ?></a>
						<div class="order-number-text order-date"><?= GetMessage('MARKETPLACE_SPOL_FROM') ?> <?= $order["ORDER"]["DATE_INSERT_FORMATED"]; ?></div>
					</td>
					<td>
						<span class="order-price"><?= $order["ORDER"]["FORMATED_PRICE"] ?></span>
					</td>
					<td>
						<? if ($order['ORDER']['CANCELED'] == "Y"): ?>
							<span>
								<?= GetMessage('MARKETPLACE_SPOL_CANCELED') ?>
							</span>
						<? else: ?>
							<span class="order-status<?= ($order["ORDER"]['PAYED'] == 'Y') ? ' paid' : ' awaiting' ?>">
								<?= $arResult['INFO']['STATUS'][$order["ORDER"]["STATUS_ID"]]['NAME'] ?>
							</span>
						<? endif ?>
					</td>
					<td class="hidden-xs hidden-sm">
						<? foreach ($order['BASKET_ITEMS'] as $arItem):
							$hasLink = !empty($arItem["DETAIL_PAGE_URL"]); ?>
							<div class="order-item">
								<? if ($hasLink): ?>
									<a href="<?= $arItem['DETAIL_PAGE_URL'] ?>" class="classic-link"><span
												class="text"><?= $arItem['NAME'] ?></span></a>
								<? else: ?>
									<span class="text"><?= $arItem['NAME'] ?></span>
								<? endif ?>
								&ndash;
								<span class="text"><?= $arItem['QUANTITY'] ?> <?= ($arItem['MEASURE_TEXT']) ? $arItem['MEASURE_TEXT'] : $arItem['MEASURE_NAME'] ?></span>
							</div>
						<? endforeach ?>
					</td>
					<td class="hidden-xs hidden-sm">
						<div><?= $arResult['INFO']['PAY_SYSTEM'][$order["ORDER"]["PAY_SYSTEM_ID"]]['NAME'] ?></div>
						<? if (intval($order["ORDER"]["DELIVERY_ID"] > 0)): ?>
							<div> /<?= $arResult['INFO']['DELIVERY'][$order["ORDER"]["DELIVERY_ID"]]['NAME'] ?></div>
						<? endif ?>
					</td>
					<td>
						<div>
							<a href="<?= $order["ORDER"]["URL_TO_COPY"] ?>" class="repeat action-link has-icon flaticon-update24">
								<span class="link-text"><?= GetMessage('MARKETPLACE_SPOL_REPEAT_ORDER') ?></span>
							</a>
							<br>
							<a href="<?= $order["ORDER"]["URL_TO_CANCEL"] ?>" class="cancel action-link has-icon flaticon-forbidden15">
								<span class="link-text"><?= GetMessage('MARKETPLACE_SPOL_CANCEL_ORDER') ?></span>
							</a>
						</div>
					</td>
				</tr>
			<? endforeach ?>
			</tbody>
		</table>
		<? if (!$isAjax): ?>
			</div>
		<? endif ?>
	<? else: ?>
		<? Main::ShowMessage(GetMessage('MARKETPLACE_SPOL_NO_ORDERS'), Main::MSG_TYPE_WARNING) ?>
	<? endif ?>
	<? if (!$isAjax): ?>
		</div>
	<? endif ?>
<? endif ?>