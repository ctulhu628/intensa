<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
use \Yenisite\Core\Tools;
use \Yenisite\Core\Ajax;

$isAjax = Tools::isAjax();
if (!$isAjax || !empty($_REQUEST['TAB_ID'])) {
	Ajax::saveParams($this, $arParams, 'personal_orders');
}
?>
<?foreach($arResult['ORDERS'] as $arOrder):?>
	<div class="account-order__list-container">
		<div class="account-order__list-title-container">
			<div class="col-sm-12">
				<h2 class="account-order__list-title"><?=GetMessage('NUMBER_OF_ZAKAZ').$arOrder['ORDER']['ID']?> <?=GetMessage('MARKETPLACE_SPOL_FROM')?> <?=$arOrder["ORDER"]["DATE_INSERT_FORMATED"]?>, <?=count($arOrder["BASKET_ITEMS"])?> <?=\Yenisite\Furniture\Main::BITGetDeclNum(count($arOrder["BASKET_ITEMS"]),array(GetMessage('MARKETPLACE_SPOL_GOOD'),GetMessage('MARKETPLACE_SPOL_GOODS'),GetMessage('MARKETPLACE_SPOL_GOODSS')))?> <?=GetMessage('ON_SUMM')?> <?=$arOrder['ORDER']['FORMATED_PRICE']?></h2>
			</div>
		</div>
		<div class="account-order__list-inner-container">
		<?if (!empty($arOrder['PAYMENT'])):?>
			<span class="account-order__list-inner-title-line">
				<span class="line-item"><?=GetMessage('MARKETPLACE_SPOL_PAYSYSTEM')?></span>
				<span class="line-border"></span>
			</span>
			<?foreach($arOrder['PAYMENT'] as $payment):?>
				<div class="row account-order__list-inner-row">
					<div class="col-md-9 col-sm-8 col-xs-12 account-order__list-payment">
						<div class="payment-title">
							<?=GetMessage('ACCOUNT_NUMBER')?><?=$payment['ACCOUNT_NUMBER']?> <?=GetMessage('MARKETPLACE_SPOL_FROM')?> <?=$arOrder["ORDER"]["DATE_INSERT_FORMATED"]?>, <span class="payment-title-element"><?=$payment['PAY_SYSTEM_NAME']?></span>
							<?if($payment['PAID'] != 'N'):?>
								<span class="account-order__list-status-success">
													<?=GetMessage('MARKETPLACE_PAYED')?>										</span>
							<?else:?>
								<span class="account-order__list-status-alert">
													<?=GetMessage('MARKETPLACE_NOT_PAYED')?>										</span>
							<?endif?>
						</div>
						<div class="payment-price">
							<span><?=GetMessage('SUM_BY_BILL')?>:</span>
							<span><?=$payment['FORMATED_SUM']?></span>
						</div>
					</div>
				</div>
			<?endforeach?>
		<?endif?>
		<?if (!empty($arOrder['SHIPMENT'])):?>
			<div class="account-order__list-inner-title-line">
				<span class="line-item"><?=GetMessage('MARKETPLACE_SPOL_DELIVERY')?></span>
				<span class="line-border"></span>
			</div>
			<?foreach($arOrder['SHIPMENT'] as $shipment):?>
				<div class="row account-order__list-inner-row">
					<div class="col-md-9 col-sm-8 col-xs-12 account-order__list-shipment">
						<div class="shipment-title">
							<span><?=GetMessage('ACCOUNT_NUMBER_SHIPMENT')?><?=$shipment['ACCOUNT_NUMBER']?>, <?=GetMessage('SHIPMENT_SUMM')?> <?=$shipment['FORMATED_DELIVERY_PRICE'] ? : \Yenisite\Stroymag\Events::CurrencyFormat(SITE_ID,0,$arOrder['ORDER']['CURRENCY'])?></span>
							<?if($shipment['STATUS_ID'] == 'F' || $shipment['STATUS_ID'] == 'DF' ):?>
								<span class="account-order__list-status-success">
													<?=GetMessage('SHIPMENT_DONE')?>										</span>
							<?else:?>
								<span class="account-order__list-status-alert">
													<?=GetMessage('SHIPMENT_NOT_DONE')?>										</span>
							<?endif?>
						</div>
						<div class="shipment-status">
							<span class="shipment-status-item"><?=GetMessage('STATUS_SHIPMENT')?>:</span>
							<span class="shipment-status-block"><?=$shipment['DELIVERY_STATUS_NAME']?></span>
						</div>
						<div class="shipment-item"><?=GetMessage('STATUS_DELIVERY')?>: <?=$shipment['DELIVERY_NAME']?></div>
					</div>
				</div>
			<?endforeach?>
		<?endif?>
		<div class="row account-order__list-inner-row">
			<div class="col-xs-12 account-order__list-link-container">
				<div class="account-order__list-top-border"></div>
				<div class="link-item">
					<a class="link link-std link-about" href="<?=htmlspecialchars($arOrder['ORDER']['URL_TO_DETAIL'])?>"><?=GetMessage('MARKETPLACE_SPOL_ORDER_DETAIL')?></a>
				</div>
				<div class="link-item">
					<a class="link link-std link-repeat" href="<?=htmlspecialchars($arOrder['ORDER']['URL_TO_COPY'])?>"><?=GetMessage('REPEAT_ORDER')?></a>
				</div>
				<?if(empty($arParams['NOT_SHOW_CANCEL']) && !$arParams['NOT_SHOW_CANCEL']):?>
					<div class="link-item">
						<a class="link link-std link-cancel" href="<?=htmlspecialchars($arOrder['ORDER']['URL_TO_CANCEL'])?>"><?=GetMessage('CANCEL_ORDER')?></a>
					</div>
				<?endif?>
			</div>
		</div>
	</div>
	</div>
<?endforeach?>


