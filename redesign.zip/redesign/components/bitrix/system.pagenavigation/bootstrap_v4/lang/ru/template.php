<?
$MESS["MAIN_UI_PAGINATION__PAGES"] = "Страницы:";
$MESS["MAIN_UI_PAGINATION__PREV"] = "Предыдущая";
$MESS["MAIN_UI_PAGINATION__NEXT"] = "Следующая";
$MESS["MAIN_UI_PAGINATION__PAGED"] = "По страницам";
$MESS["MAIN_UI_PAGINATION__ALL"] = "Все";
?>