<?
$MESS["MAIN_UI_PAGINATION__PAGES"] = "Сторінки";
$MESS["MAIN_UI_PAGINATION__PREV"] = "Попередня";
$MESS["MAIN_UI_PAGINATION__NEXT"] = "Наступна";
$MESS["MAIN_UI_PAGINATION__PAGED"] = "По сторінках";
$MESS["MAIN_UI_PAGINATION__ALL"] = "Всі";
?>