<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

/**
 * @var array $arResult
 * @var array $arParam
 * @var CBitrixComponentTemplate $this
 */

$this->setFrameMode(true);

if(!$arResult["NavShowAlways"])
{
	if ($arResult["NavRecordCount"] == 0 || ($arResult["NavPageCount"] == 1 && $arResult["NavShowAll"] == false))
		return;
}
?>

<div class="pagenav">
<?
if($arResult["NavPageNomer"] < $arResult["NavPageCount"]):
?>
	<div class="text-center d-lg-none"><a class="mbtn mbtn-brddark" href="<?=$arResult["sUrlPath"]?>?<?=$strNavQueryString?>PAGEN_<?=$arResult["NavNum"]?>=<?=($arResult["NavPageNomer"]+1)?>">Показать еще</a></div>
<?
endif;
?>

<div class="d-none d-lg-block">
  	<div class="pagenav-paginator">

<?
$strNavQueryString = ($arResult["NavQueryString"] != "" ? $arResult["NavQueryString"]."&amp;" : "");
$strNavQueryStringFull = ($arResult["NavQueryString"] != "" ? "?".$arResult["NavQueryString"] : "");

/* Arrow */

if ($arResult["NavPageNomer"] > 1):
	if ($arResult["NavPageNomer"] > 2):
?>
    <div><a class="mbtn mbtn-brddark warrow-left" href="<?=$arResult["sUrlPath"]?>?<?=$strNavQueryString?>PAGEN_<?=$arResult["NavNum"]?>=<?=($arResult["NavPageNomer"]-1)?>"><span>Назад</span></a></div>
<?
	else:
?>
    <div><a class="mbtn mbtn-brddark warrow-left" href="<?=$arResult["sUrlPath"]?><?=$strNavQueryStringFull?>"><span>Назад</span></a></div>
<?
	endif;
else:
?>
	<div><a class="mbtn mbtn-brddark warrow-left" href="javascript:false;"><span>Назад</span></a></div>
<?
endif;

/* Nums */

?>
<div>
	<ul>
<?

if ($arResult["nStartPage"] > 1):
?>
		<li><a href="<?=$arResult["sUrlPath"]?><?=$strNavQueryStringFull?>">1</a></li>
<?
	if ($arResult["nStartPage"] > 2):
?>
		<li><span>...</span></li>
<?
	endif;
endif;

do
{
	if ($arResult["nStartPage"] == $arResult["NavPageNomer"]):
?>
	<li class="active"><a href="javascript:false;"><?=$arResult["nStartPage"]?></a></li>
<?
	else:

		if ($arResult["nStartPage"] == 1):
?>
	<li><a href="<?=$arResult["sUrlPath"]?><?=$strNavQueryStringFull?>">1</a></li>
<?
		else:
?>
	<li><a href="<?=$arResult["sUrlPath"]?>?<?=$strNavQueryString?>PAGEN_<?=$arResult["NavNum"]?>=<?=$arResult["nStartPage"]?>"><?=$arResult["nStartPage"]?></a></li>
<?
		endif;
	endif;
	$arResult["nStartPage"]++;
}
while($arResult["nStartPage"] <= $arResult["nEndPage"]);

if ($arResult["nEndPage"] < $arResult["NavPageCount"]):
	if ($arResult["nEndPage"] < ($arResult["NavPageCount"] - 1)):
?>
		<li><span>...</span></li>
<?
	endif;
?>
		<li><a href="<?=$arResult["sUrlPath"]?>?<?=$strNavQueryString?>PAGEN_<?=$arResult["NavNum"]?>=<?=$arResult["NavPageCount"]?>"><?=$arResult["NavPageCount"]?></a></li>
<?
endif;

?>
	</ul>
</div>
<?
/* Arrow */

if($arResult["NavPageNomer"] < $arResult["NavPageCount"]):
?>
	<div><a class="mbtn mbtn-brddark warrow-right" href="<?=$arResult["sUrlPath"]?>?<?=$strNavQueryString?>PAGEN_<?=$arResult["NavNum"]?>=<?=($arResult["NavPageNomer"]+1)?>"><span>Вперед</span></a></div>
<?
else:
?>
	<div><a class="mbtn mbtn-brddark warrow-right" href="javascript:false;"><span>Вперед</span></a></div>
<?
endif;
?>
      	</div>
    </div>
</div>
