<?
$MESS['nav_of'] = "из";
$MESS['nav_begin'] = "В начало";
$MESS['nav_prev'] = "Пред.";
$MESS['nav_next'] = "След.";
$MESS['nav_end'] = "В конец";
$MESS['nav_paged'] = "По стр.";
$MESS['nav_all'] = "Все";
$MESS['nav_to'] = "-";
$MESS['nav_to'] = "-";
$MESS['RZ_PAGE'] = 'Стр.';
$MESS['RZ_OF'] = 'из';
$MESS['RZ_PAGEN_GOODS'] = 'Товары';