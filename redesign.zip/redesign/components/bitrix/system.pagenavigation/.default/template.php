<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */
/** @var CBitrixComponent $component */
$this->setFrameMode(true);
if (!$arResult["NavShowAlways"]) {
	if ($arResult["NavRecordCount"] == 0 || ($arResult["NavPageCount"] == 1 && $arResult["NavShowAll"] == false)) {
		return;
	}
}
$nPageWindow = $arParams['MAX_PAGE_COUNT'] ?: 2;

/* ============ CustomPageNav start ============ */
if ($arResult["NavPageNomer"] > floor($nPageWindow / 2) + 1 && $arResult["NavPageCount"] > $nPageWindow) {
	$nStartPage = $arResult["NavPageNomer"] - floor($nPageWindow / 2);
} else {
	$nStartPage = 1;
}

if ($arResult["NavPageNomer"] <= $arResult["NavPageCount"] - floor($nPageWindow / 2) && $nStartPage + $nPageWindow - 1 <= $arResult["NavPageCount"]) {
	$nEndPage = $nStartPage + $nPageWindow - 1;
} else {
	$nEndPage = $arResult["NavPageCount"];
	if ($nEndPage - $nPageWindow + 1 >= 1) {
		$nStartPage = $nEndPage - $nPageWindow + 1;
	}
}
$arResult["nStartPage"] = $arResult["nStartPage"] = $nStartPage;
$arResult["nEndPage"] = $arResult["nEndPage"] = $nEndPage;
/* ============ CustomPageNav end ============ */

$strNavQueryString = ($arResult["NavQueryString"] != "" ? $arResult["NavQueryString"] . "&amp;" : "");
$strNavQueryStringFull = ($arResult["NavQueryString"] != "" ? "?" . $arResult["NavQueryString"] : "");

?>
<? if ($arResult["NavTitle"] && (int)$arResult["NavRecordCount"] > 0): ?>
	<div class="catalog-view-status">
		<?= $arResult["NavTitle"], ' ', $arResult["NavFirstRecordShow"], '-', $arResult["NavLastRecordShow"] ?> <?= GetMessage('RZ_OF') ?> <?= $arResult["NavRecordCount"] ?>
	</div>
<? endif ?>
<nav class="pagination-wrap">
	<ul class="pagination">
		<? if ($arResult["bDescPageNumbering"] === true): ?>
			<?= 'Desc navigation not working yet.....' // todo ?>
		<? else: ?>
			<?
			$bFirstPage = $arResult["NavPageNomer"] == 1;
			$bLastPage = $arResult["NavPageNomer"] == $arResult["NavPageCount"];
			?>
			<? if ($arResult["NavPageNomer"] > 1): ?>
				<? if ($arResult["bSavePage"]): ?>
					<li>
						<a href="<?= $arResult["sUrlPath"] ?>?<?= $strNavQueryString ?>PAGEN_<?= $arResult["NavNum"] ?>=1"
						   class="first flaticon-double94"
						   data-param="PAGEN_<?= $arResult["NavNum"] ?>" data-value="1"
						><span class="text"><?= GetMessage("nav_begin") ?></span></a>
					</li>
					<li>
						<a href="<?= $arResult["sUrlPath"] ?>?<?= $strNavQueryString ?>PAGEN_<?= $arResult["NavNum"] ?>=<?= ($arResult["NavPageNomer"] - 1) ?>"
						   data-param="PAGEN_<?= $arResult["NavNum"] ?>" data-value="<?= ($arResult["NavPageNomer"] - 1) ?>" aria-label="Previous"
						   class="flaticon-directional"></a>
					</li>
				<? else: ?>
					<li>
						<a href="<?= $arResult["sUrlPath"] ?><?= $strNavQueryStringFull ?>" class="first flaticon-double94"
						   data-param="PAGEN_<?= $arResult["NavNum"] ?>" data-value="1">
							<span class="text"><?= GetMessage("nav_begin") ?></span>
						</a>
					</li>
					<li>
						<a href="<?= $arResult["sUrlPath"] ?>?<?= $strNavQueryString ?>PAGEN_<?= $arResult["NavNum"] ?>=<?= ($arResult["NavPageNomer"] - 1) ?>"
						   data-param="PAGEN_<?= $arResult["NavNum"] ?>" data-value="<?= ($arResult["NavPageNomer"] - 1) ?>" aria-label="Previous"
						   class="flaticon-directional"></a>
					</li>
				<? endif ?>
			<? else: ?>
				<li class="disabled">
					<a href="javascript:;" class="first flaticon-double94 disabled"><span class="text"><?= GetMessage("nav_begin") ?></span></a>
				</li>
				<li class="disabled">
					<a href="javascript:;" class="flaticon-directional disabled" aria-label="Previous"></a>
				</li>
			<? endif ?>
			<?
			$NavRecordGroup = 1;
			while ($NavRecordGroup <= $arResult["NavPageCount"]):
				if ($NavRecordGroup == $arResult["NavPageNomer"]): ?>
					<li class="active">
						<a href="<?= $arResult["sUrlPath"] ?>?<?= $strNavQueryString ?>PAGEN_<?= $arResult["NavNum"] ?>=<?= $NavRecordGroup ?>"
						   data-param="PAGEN_<?= $arResult["NavNum"] ?>" data-value="<?= $NavRecordGroup ?>">
							<?= $NavRecordGroup ?>
						</a>
					</li>
				<? elseif ($NavRecordGroup == 1 && $arResult["bSavePage"] == false): ?>
					<li>
						<a href="<?= $arResult["sUrlPath"] ?>?<?= $strNavQueryString ?>PAGEN_<?= $arResult["NavNum"] ?>=<?= $NavRecordGroup ?>"
						   data-param="PAGEN_<?= $arResult["NavNum"] ?>" data-value="<?= $NavRecordGroup ?>">
							<?= $NavRecordGroup ?>
						</a>
					</li>
				<? else: ?>
					<li>
						<a href="<?= $arResult["sUrlPath"] ?>?<?= $strNavQueryString ?>PAGEN_<?= $arResult["NavNum"] ?>=<?= $NavRecordGroup ?>"
						   data-param="PAGEN_<?= $arResult["NavNum"] ?>" data-value="<?= $NavRecordGroup ?>">
							<?= $NavRecordGroup ?>
						</a>
					</li>
				<? endif ?>

				<? if ($NavRecordGroup == 1 && $arResult["nStartPage"] > 3 && $arResult["nStartPage"] - $NavRecordGroup > 1): ?>
				<li>
					<a href="<?= $arResult["sUrlPath"] ?>?<?= $strNavQueryString ?>PAGEN_<?= $arResult["NavNum"] ?>=<?= $NavRecordGroup ?>"
					   data-param="PAGEN_<?= $arResult["NavNum"] ?>" data-value="<?= ($arResult["NavPageNomer"] + 1) ?>">...</a>
				</li>
				<? $NavRecordGroup = $arResult["nStartPage"] ?>
			<? elseif ($NavRecordGroup == $arResult["nEndPage"] && $arResult["nEndPage"] < ($arResult["NavPageCount"] - 2)): ?>
				<li>
					<a href="<?= $arResult["sUrlPath"] ?>?<?= $strNavQueryString ?>PAGEN_<?= $arResult["NavNum"] ?>=<?= $NavRecordGroup ?>"
					   data-param="PAGEN_<?= $arResult["NavNum"] ?>" data-value="<?= ($arResult["NavPageNomer"] + 1) ?>">...</a>
				</li>
				<? $NavRecordGroup = $arResult["NavPageCount"] - 1 ?>
			<? else:
				$NavRecordGroup++;
			endif ?>
			<? endwhile ?>
			<? if ($arResult["NavPageNomer"] < $arResult["NavPageCount"]): ?>
				<li>
					<a href="<?= $arResult["sUrlPath"] ?>?<?= $strNavQueryString ?>PAGEN_<?= $arResult["NavNum"] ?>=<?= ($arResult["NavPageNomer"] + 1) ?>"
					   data-param="PAGEN_<?= $arResult["NavNum"] ?>" data-value="<?= ($arResult["NavPageNomer"] + 1) ?>" aria-label="Next"
					   class="flaticon-pointing6"></a>
				</li>
				<li>
					<a href="<?= $arResult["sUrlPath"] ?>?<?= $strNavQueryString ?>PAGEN_<?= $arResult["NavNum"] ?>=<?= $arResult["NavPageCount"] ?>"
					   data-param="PAGEN_<?= $arResult["NavNum"] ?>" data-value="<?= $arResult["NavPageCount"] ?>"
					   class="last flaticon-fast34"><span class="text"><?= GetMessage("nav_end") ?></span></a>
				</li>
			<? else: ?>
				<li class="disabled">
					<a href="javascript:;" class="flaticon-pointing6 disabled" aria-label="Next"></a>
				</li>
				<li class="disabled">
					<a href="javascript:;" class="last flaticon-fast34 disabled"><span class="text"><?= GetMessage("nav_end") ?></span></a>
				</li>
			<? endif ?>

		<? endif ?>
	</ul><!-- /pagination -->
</nav>