<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
use Yenisite\Furniture\Form;
use Yenisite\Furniture\Main;
use Yenisite\Core\Ajax;
use Yenisite\Core\Tools;

$isAjax = Tools::isAjax();
if (!$isAjax) {
	Ajax::saveParams($this, $arParams, 'modal');
}
global $APPLICATION;
$APPLICATION->SetPageProperty('SHOW_HEADER', 'N');
$arAuthResult = $APPLICATION->arAuthResult;
$id = 'bx_dynamic_auth_default';
\Bitrix\Main\Localization\Loc::loadMessages($_SERVER['DOCUMENT_ROOT'].SITE_TEMPLATE_PATH . '/lang/'.LANGUAGE_ID.'/header.php');
$pathToRules = COption::GetOptionString(\Yenisite\Furniture\Settings::getModuleId(),'path_tu_rules_privacy',SITE_DIR.'personal/rules/personal_data.php');
if (!$isAjax):?>
<? if ($USER->IsAuthorized()) return; ?>
		<p>&nbsp;</p>
	<div class="row">
		<div class="col-xs-12 col-md-4 col-md-offset-4"><h1><?= GetMessage('RZ_NEED_AUTH') ?></h1></div>
	</div>
<div class="row">
	<div class="col-xs-12 col-md-4 col-md-offset-4">
	<? $frame = $this->createFrame()->begin(Main::insertCompositLoader()) ?>
		<div class="login-form tab-content">
		<? $APPLICATION->IncludeComponent('bitrix:system.auth.forgotpasswd', 'modal', array('RND' => $arResult["RND"], 'STATIC_FORM' => true)) ?>
		<form name="system_auth_form<?= $arResult["RND"] ?>" method="post" target="_top" <? Ajax::printAjaxDataAttr($this, 'modal') ?>
		action="<?= $arResult["AUTH_URL"] ?>" class="tab-pane fade in active ajax-form" data-validate="true" id="form_auth_static"
		data-spin="submit" >
<? endif ?>
    <input type="hidden" name="privacy_policy" value="N"/>
			<? if (!$USER->IsAuthorized()): ?>
				<? if ($arResult["BACKURL"] <> ''): ?>
					<input type="hidden" name="backurl" value="<?= $arResult["BACKURL"] ?>"/>
				<? endif ?>
				<? foreach ($arResult["POST"] as $key => $value): ?>
					<input type="hidden" name="<?= $key ?>" value="<?= $value ?>"/>
				<? endforeach ?>
				<input type="hidden" name="AUTH_FORM" value="Y"/>
				<input type="hidden" name="TYPE" value="AUTH"/>
				<? if (!empty($arAuthResult)):?>
					<div class="form-message shown">
						<? Main::ShowMessage($arAuthResult) ?>
					</div>
				<? endif ?>
				<label class="form-group">
					<span class="label-text"><?= GetMessage('RZ_LOGIN_EMAIL_OR_PHONE') ?>:</span>
					<input type="text" class="form-control" name="USER_LOGIN" value="<?= $_REQUEST['USER_LOGIN'] ?: '' ?>" required
						   tabindex="1">
				</label>

				<label class="form-group">
					<span class="label-text"><?=GetMessage('RZ_LOGIN_PASSWORD')?>:</span>
					<input type="password" class="form-control input-password" name="USER_PASSWORD" required tabindex="2">
					<i class="flaticon-eye46 password-icon"></i>
					<i class="flaticon-eye48 password-icon"></i>
				</label>

				<? if ($arResult["CAPTCHA_CODE"]): ?>
					<label class="form-group">
						<?=GetMessage("RZ_CAPTCHA_INPUT_TEXT")?>: <span class="required-star">*</span>
						<span class="form-group has-feedback">
							<span class="input-group">
								<span class="input-group-addon captcha-wrap"><img src="/bitrix/tools/captcha.php?captcha_sid=<?= $arResult["CAPTCHA_CODE"] ?>" alt="<?=GetMessage("RZ_CAPTCHA")?>" class="captcha-img"></span>
								<input type="text" name="captcha_word" class="form-control" required tabindex="3">
								<input type="hidden" name="captcha_sid" value="<?= $arResult["CAPTCHA_CODE"] ?>"/>
							</span>
						</span>
					</label>
				<? endif ?>
				<div class="form-group">
					<? if ($arResult["STORE_PASSWORD"] == "Y"): ?>
						<?
						Form::printElement(
								array(
										'NAME' => 'USER_REMEMBER',
										'TEXT' => GetMessage("RZ_REMEMBER_ME"),
										'INDEX' => 4,
										'CHECKED' => 1,
								),
								Form::TYPE_CHECKBOX
						)
						?>
					<? endif ?>
					<a href="#form_reset_static" class="link link-std pull-right" data-toggle="tab"><?=GetMessage("RZ_LOGIN_FORGET_PASSWORD")?></a>
				</div>
                <div class="form-group">
                    <?
                    $text = GetMessage('RZ_RULES_YA') . ' ';
                    $text .=  GetMessage('RZ_ACCEPT') . " <a href='" . $pathToRules . "' target='_blank' class='classic-link'>" . GetMessage('RZ_CONCLUSION') . "</a>";
                    Form::printElement(
                        array(
                            'NAME' => 'PRIVACY_POLICY',
                            'CHECKED' => $_POST['PRIVACY_POLICY'] == 'Y',
                            'TEXT' => $text,
                            'REQ' => true,
                            'INDEX' => ++$tabIndex,
                        ), Form::TYPE_CHECKBOX
                    );
                    ?>
                </div>
				<div class="text-center mar-t-15">
					<button type="submit" class="btn btn-lg btn-primary">
						<?= GetMessage('RZ_LOGIN_LOGIN') ?>
					</button>
				</div>
			<? else : //$USER->IsAuthorized()?>
				<? Main::ShowMessage(GetMessage('RZ_AUTH_SUCCESS'), Main::MSG_TYPE_SUCCESS); ?>
				<script type="text/javascript">
					window.location.reload();
				</script>
			<? endif ?>
<?if(!$isAjax):?>
			</form>
		</div>
	</div>
</div>
	<? $frame->end() ?>
<? endif;