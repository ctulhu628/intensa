<?php
$APPLICATION->AddChainItem(GetMessage("RZ_ZAKAZ_DETALNO"))?>
