<? use Yenisite\Furniture\Main;

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
?>

<div class="order-info">
	<div class="order-actions">
		<a class="back-to-shoping btn-main btn-direction flaticon-left207"
		   href="<?= $arResult["URL_TO_DETAIL"] ?>"><?= GetMessage('SPOD_BACK') ?></a>
	</div>


	<div class="order-info-content">

		<? if (strlen($arResult["ERROR_MESSAGE"]) <= 0): ?>
			<form method="post" class="form_comment" style="display: block;" action="<?= POST_FORM_ACTION_URI ?>">
				<input type="hidden" name="CANCEL" value="Y">
				<input type="hidden" name="action" value="Y"/>
				<?= bitrix_sessid_post() ?>
				<input type="hidden" name="ID" value="<?= $arResult["ID"] ?>">
				<div class="form-group">
					<?= GetMessage("SALE_CANCEL_ORDER1") ?>
					<a href="<?= $arResult["URL_TO_DETAIL"] ?>">
						<?= GetMessage("SALE_CANCEL_ORDER2") ?> #<?= $arResult["ACCOUNT_NUMBER"] ?></a>?
					<br>
					<b><?= GetMessage("SALE_CANCEL_ORDER3") ?></b>
					<br>
					<?= GetMessage("SALE_CANCEL_ORDER4") ?>:
					<br>
				</div>
				<div class="form-group">
					<textarea name="REASON_CANCELED" class="form-control" title=""></textarea>
				</div>
				<div class="form-group">
					<button type="submit" class="btn-main btn-primary"><?= GetMessage("SALE_CANCEL_ORDER_BTN") ?></button>
				</div>
			</form>
		<? else: ?>
			<? Main::ShowMessage($arResult["ERROR_MESSAGE"]) ?>
		<? endif; ?>
	</div>
</div>