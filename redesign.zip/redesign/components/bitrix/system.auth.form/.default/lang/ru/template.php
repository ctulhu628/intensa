<?
$MESS['RZ_ACCOUNT_CONTROLS_HEADER'] = 'Личный кабинет';
$MESS['RZ_ACCOUNT_CONTROLS_LOGIN'] = 'Вход';
$MESS['RZ_ACCOUNT_CONTROLS_REGISTER'] = 'Регистрация';
$MESS['RZ_ACCOUNT_CONTROLS_FAV'] = 'Избранное';
$MESS['RZ_ACCOUNT_CONTROLS_COMP'] = 'Список сравнения';
$MESS['RZ_ACCOUNT_CONTROLS_OPEN_PROFILE'] = 'Профиль';
$MESS['RZ_ACCOUNT_CONTROLS_LOGOUT'] = 'Выйти';
$MESS['RZ_LOGIN_EMAIL_OR_PHONE'] = 'Электронная почта или номер телефона';
$MESS['RZ_LOGIN_PASSWORD'] = 'Пароль';
$MESS['RZ_LOGIN_TEXT_SOCIALS'] = 'Авторизация через социальные сети';
$MESS['RZ_LOGIN_LOGIN'] = 'Войти на сайт';
$MESS['RZ_MODAL_LOGIN_HEADER'] = 'Личный кабинет';
$MESS['RZ_REMEMBER_ME'] = 'Запомнить меня';
$MESS['RZ_CAPTCHA_INPUT_TEXT'] = "Введите слово на картинке";
$MESS['RZ_CAPTCHA'] = "Капча";
$MESS["RZ_AUTH_SUCCESS"] = "Вы были успешно авторизованы. <br> Страница будет перезагружена через несколько секунд";