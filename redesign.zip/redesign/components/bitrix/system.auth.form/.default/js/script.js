$(function () {
	"use strict";
	$('#logout-btn').on('click', function (e) {
		s['user-authorized'].$input.prop('checked', false).change();
	});
});