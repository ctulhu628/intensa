<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
use Yenisite\Furniture\Form;
use Yenisite\Furniture\Main;
use Yenisite\Core\Ajax;
use Yenisite\Core\Tools;

$isAjax = Tools::isAjax();
\Bitrix\Main\Localization\Loc::loadMessages($_SERVER['DOCUMENT_ROOT'].SITE_TEMPLATE_PATH . '/lang/'.LANGUAGE_ID.'/header.php');
$pathToRules = COption::GetOptionString(\Yenisite\Furniture\Settings::getModuleId(),'path_tu_rules_privacy',SITE_DIR.'personal/rules/personal_data.php');
if (!$isAjax) {
	Ajax::saveParams($this, $arParams, 'modal');
}
$id = 'bx_dynamic_auth';
if (!$isAjax || !empty($_REQUEST['TAB_ID'])):?>
<div class="container">
	<? if ($USER->IsAuthorized()) return; ?>
	<? $frame = $this->createFrame()->begin(Main::insertCompositLoader()) ?>
		<div class="login-form tab-content">
        <?if (empty($_REQUEST['TAB_ID'])):?>
		    <? $APPLICATION->IncludeComponent('bitrix:system.auth.forgotpasswd', 'modal', array('RND' => $arResult["RND"], 'STATIC_FORM'=> true)) ?>
        <?endif?>
		<form name="system_auth_form<?= $arResult["RND"] ?>" method="post" target="_top" <? Ajax::printAjaxDataAttr($this, 'modal') ?>
		action="<?= $arResult["AUTH_URL"] ?>" class="tab-pane fade in active ajax-form" data-validate="true" id="form_auth_<?= $arResult["RND"] ?>"
		data-spin="submit" >
<? endif ?>
    <input type="hidden" name="privacy_policy" value="N"/>
			<? if (!$USER->IsAuthorized()): ?>
				<? if ($arResult["BACKURL"] <> ''): ?>
					<input type="hidden" name="backurl" value="<?= $arResult["BACKURL"] ?>"/>
				<? endif ?>
				<? foreach ($arResult["POST"] as $key => $value): ?>
					<input type="hidden" name="<?= $key ?>" value="<?= $value ?>"/>
				<? endforeach ?>
				<input type="hidden" name="AUTH_FORM" value="Y"/>
				<input type="hidden" name="TYPE" value="AUTH"/>
				<? if ($arResult['ERROR']):?>
					<div class="form-message shown">
						<? Main::ShowMessage($arResult['ERROR_MESSAGE']) ?>
					</div>
				<? endif ?>
				<label class="block">
					<?=GetMessage('RZ_LOGIN_EMAIL_OR_PHONE')?><span class="asterisk-required">*</span>:
					<span class="form-group has-feedback">
						<input type="text" class="form-control" name="USER_LOGIN" value="<?= $arResult["USER_LOGIN"] ?>" required tabindex="1"
						<span class="help-block with-errors"></span>
					</span>
				</label>

				<label class="block">
					<?=GetMessage('RZ_LOGIN_PASSWORD')?><span class="asterisk-required">*</span>:
					<span class="form-group has-feedback">
						<i class="btn-pwdswitch flaticon-hide"></i>
						<input type="password" class="form-control" name="USER_PASSWORD" required tabindex="2">
						<span class="help-block with-errors"></span>
					</span>
				</label>

				<? if ($arResult["CAPTCHA_CODE"]): ?>
					<label class="block">
						<?=GetMessage("RZ_CAPTCHA_INPUT_TEXT")?>: <span class="required-star">*</span>
						<span class="form-group has-feedback">
							<span class="input-group">
								<span class="input-group-addon captcha-wrap"><img src="/bitrix/tools/captcha.php?captcha_sid=<?= $arResult["CAPTCHA_CODE"] ?>" alt="<?=GetMessage("RZ_CAPTCHA")?>" class="captcha-img"></span>
								<input type="text" name="captcha_word" class="form-control" required tabindex="3">
								<input type="hidden" name="captcha_sid" value="<?= $arResult["CAPTCHA_CODE"] ?>"/>
							</span>
							<span class="help-block with-errors"></span>
						</span>
					</label>
				<? endif ?>
                <?
                $text = GetMessage('RZ_RULES_YA') . ' ';
                $text .=  GetMessage('RZ_ACCEPT') . " <a href='" . $pathToRules . "' target='_blank' class='classic-link'>" . GetMessage('RZ_CONCLUSION') . "</a>";
                Form::printElement(
                    array(
                        'NAME' => 'PRIVACY_POLICY',
                        'CHECKED' => $_POST['PRIVACY_POLICY'] == 'Y',
                        'TEXT' => $text,
                        'REQ' => true,
                        'INDEX' => ++$tabIndex,
                    ), Form::TYPE_CHECKBOX
                );
                ?>
				<div class="form-group">
					<? if ($arResult["STORE_PASSWORD"] == "Y"): ?>
						<?
						Form::printElement(
								array(
										'NAME' => 'USER_REMEMBER',
										'TEXT' => GetMessage("RZ_REMEMBER_ME"),
										'INDEX' => 4,
										'CHECKED' => 1,
								),
								Form::TYPE_CHECKBOX
						)
						?>
					<? endif ?>
					<a href="#form_reset_<?= $arResult["RND"] ?>" class="link link-std pull-right" data-toggle="tab"><?=GetMessage("RZ_LOGIN_FORGET_PASSWORD")?></a>
				</div>
				<div class="text-center mar-t-15">
					<button type="submit" class="btn btn-lg btn-primary">
						<?=GetMessage('RZ_LOGIN_LOGIN')?>
					</button>
				</div>
			<? else : //$USER->IsAuthorized()?>
				<? Main::ShowMessage(GetMessage('RZ_AUTH_SUCCESS'), Main::MSG_TYPE_SUCCESS); ?>
				<script type="text/javascript">
					window.location.reload();
				</script>
			<? endif ?>
<?if(!$isAjax):?>
			</form>
		</div>
	</div>
	<? $frame->end() ?>
<? endif;