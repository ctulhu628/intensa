<?if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();

$arParams['RESIZER_USER_AVA_ICON'] = (int)$arParams['RESIZER_USER_AVA_ICON'] > 0 ? $arParams['RESIZER_USER_AVA_ICON'] : 5;