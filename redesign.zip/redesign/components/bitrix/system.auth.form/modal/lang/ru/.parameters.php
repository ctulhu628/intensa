<?

// Resizer
$MESS["RESIZER_SETS"] = "Настройка наборов Ресайзера";
$MESS["RESIZER_USER_AVA_ICON"] = "Фото пользователя";
$MESS["FAVORITE_LINK"] = "Ссылка на избранное";