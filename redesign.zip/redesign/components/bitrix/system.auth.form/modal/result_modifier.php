<? use Bitrix\Main\Loader;
use Yenisite\Core\Ajax;

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

$arParams['RESIZER_USER_AVA_ICON'] = (int)$arParams['RESIZER_USER_AVA_ICON'] > 0 ? $arParams['RESIZER_USER_AVA_ICON'] : 5;
$arParams['USE_FAVORITE'] = Loader::includeModule('yenisite.favorite');
if ($arParams['USE_FAVORITE']) {
	$rs = \Yenisite\Favorite\Favorite::getList();
	$arResult['FAVORITE_COUNT'] = $rs->getSelectedRowsCount();
}
$arResult['COMPARE_COUNT'] = 0;
$arResult['COMPARE_LINK'] = '#';

$arCatParams = Ajax::getParams('bitrix:catalog', false, SITE_DIR . '/catalog/');
if (!empty($arCatParams)) {
	$arParams['COMPARE_LINK'] = $arCatParams['SEF_FOLDER'] . $arCatParams['SEF_URL_TEMPLATES']['compare'];
	ob_start();
	$APPLICATION->IncludeComponent('bitrix:catalog.compare.list', 'count', array(
		'IBLOCK_ID' => $arCatParams['IBLOCK_ID'],
		'IBLOCK_TYPE' => $arCatParams['IBLOCK_TYPE'],
		'NAME' => $arCatParams['COMPARE_NAME'],
	));
	$arResult['COMPARE_COUNT'] = strip_tags(ob_get_clean());
}