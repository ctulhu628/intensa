"use strict";
$(function () {
	$('#logout-btn').on('click', function (e) {
		s['user-authorized'].$input.prop('checked', false).change();
	});

	var $body = $(document.body),
		$favCount = $('#personal_favorite_count'),
		$comCount = $('#personal_compare_count');

	var doAjax = function ($target) {
		var action;
		if ($target == $favCount) {
			action = 'UPDATE_FAVORITE';
		} else {
			action = 'UPDATE_COMPARE';
		}
		$target.startAjax();
		$.ajax({
			'url': AJAX_DIR + 'actions.php',
			'data': {'ACTION': action},
			'dataType': 'JSON',
			'success': function (msg) {
				if (msg.success) {
					$target.attr('data-quan', msg.message);
				} else {
					rz_showMessage(msg.message);
				}
				$target.stopAjax();
			}
		})
	};

	if ($comCount.length) {
		$body.on('update_compare', function () {
			doAjax($comCount);
		});
	}

	if ($favCount.length) {
		$body.on('update_favorite', function () {
			doAjax($favCount);
		});
	}
});