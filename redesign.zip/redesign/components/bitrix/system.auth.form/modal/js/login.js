$(function(){

	"use strict"

	$('.account__socials-list.w-login').on('click', '.social-item', function(e){
		var $t = $(this),
			$root = $(e.delegateTarget),
			$form = $root.siblings('.account__social-login').find('.form-group'),
			$imgWrap = $form.find('.img-wrap'),
			$postfix = $form.find('.postfix'),
			postfix = $t.data('postfix') || '',
			$input = $form.find('.form-control'),
			$widget = $($t.data('widget'));
		
		if ($t.hasClass('active')){
			$t.removeClass('active');
			$form.on('hidden.bs.collapse', function(){
				$imgWrap.empty();
				if ($postfix.length) $postfix.remove();
			}).collapse('hide');
		} else {
			$t.addClass('active').siblings().removeClass('active');
			
			if (postfix){
				if ($postfix.length) $postfix.html(postfix);
				else $form.find('.input-group')
					.append('<span class="input-group-addon postfix">' + postfix + '</span>');
			} else if ($postfix.length) $postfix.remove();
			if ($widget.length){
				$input.hide();
				$imgWrap.empty().append($widget.clone());
			} else {
				$input.show();
				$imgWrap.html($t.html());
			}
			
			$form.collapse('show');
		}
		return false;
	});

	$('body').on('mousedown', '.btn-pwdswitch', function(){
		var field = $(this).siblings('input');
		if (field.attr('type') == 'text'){
			field.get(0).type = 'password';
			$(this).removeClass('flaticon-eye46').addClass('flaticon-hide');
			//^ don't use jQuery 'cause it won't allow us to change type
			// for some IE compatibility reasons
			return false;
		}
		if (field.attr('type') == 'password'){
			field.get(0).type = 'text';
			$(this).addClass('flaticon-eye46').removeClass('flaticon-hide');
			return false;
		}
		return false;
	});
	
});