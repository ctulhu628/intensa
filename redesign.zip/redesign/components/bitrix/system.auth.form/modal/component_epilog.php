<?
$Asset = \Bitrix\Main\Page\Asset::getInstance();
$Asset->addJs($templateFolder . '/js/script.js');
$Asset->addJs($templateFolder . '/js/login.js');