<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

use Bitrix\Main\Loader;

$resizer_sets_list = array();
if (Loader::IncludeModule("yenisite.resizer2")) {
	$arSets = \CResizer2Set::GetList();
	while ($arr = $arSets->Fetch()) {
		$resizer_sets_list[$arr["id"]] = "[" . $arr["id"] . "] " . $arr["NAME"];
	}
}

global $arComponentParameters;

// RESIZER:
$arComponentParameters["GROUPS"]["RESIZER_SETS"] = array(
	"NAME" => GetMessage("RESIZER_SETS"),
	"SORT" => 1
);

$arTemplateParameters = array(
	"RESIZER_USER_AVA_ICON" => array(
		"PARENT" => "RESIZER_SETS",
		"NAME" => GetMessage("RESIZER_USER_AVA_ICON"),
		"TYPE" => "LIST",
		"VALUES" => $resizer_sets_list,
		"DEFAULT" => "5",
	),
	"FAVORITE_LINK" => array(
		"PARENT" => "ADDITIONAL",
		"NAME" => GetMessage("FAVORITE_LINK"),
		"TYPE" => "STRING",
		"DEFAULT" => "#SITE_DIR#personal/#personal_favorite_data",
	)
);

?>