<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
/**
 * @var CBitrixComponentTemplate $this
 */
use Yenisite\Furniture\Form;
use Yenisite\Furniture\Main;
use Yenisite\Core\Ajax;
use Yenisite\Core\Tools;

$bOnlyMenu = $GLOBALS['RZ_SECOND_EXEC'] ? 0 : 1;
$isAjax = Tools::isAjax();
\Bitrix\Main\Localization\Loc::loadMessages($_SERVER['DOCUMENT_ROOT'].SITE_TEMPLATE_PATH . '/lang/'.LANGUAGE_ID.'/header.php');
$pathToRules = COption::GetOptionString(\Yenisite\Furniture\Settings::getModuleId(),'path_tu_rules_privacy',SITE_DIR.'personal/rules/personal_data.php');
$tabIndex = 1;
if (!$isAjax) {
	$this->setFrameMode(true);
	Ajax::saveParams($this, $arParams, 'modal');
}
if (!$isAjax):?>
	<? if (!$bOnlyMenu): ?>
		<? ob_start() ?>
		<span id="bx_frame_auth" class="header_auth_compare">
		<? $frame = $this->createFrame('bx_frame_auth', false)->begin(Main::insertCompositLoader()) ?>
			<? if ($arParams['USE_FAVORITE']): ?>
				<a href="<?= $arParams['FAVORITE_LINK'] ?>" class="header-fav-link flaticon-heart296" data-toggle="tooltip"
				   data-placement="bottom" title="<?= GetMessage('RZ_ACCOUNT_CONTROLS_FAV') ?>" id="personal_favorite_count"
				   data-quan="<?= $arResult['FAVORITE_COUNT'] ?>"></a>
			<? endif ?>
			<a href="<?= $arParams['COMPARE_LINK'] ?>" class="header-comp-link flaticon-right130" data-toggle="tooltip"
			   data-placement="bottom" title="<?= GetMessage('RZ_ACCOUNT_CONTROLS_COMP') ?>" id="personal_compare_count"
			   data-quan="<?= $arResult['COMPARE_COUNT'] ?>"></a>
			<? $frame->end() ?>
	</span>
		<?
		$compareContent = ob_get_clean();
		?>
	<? endif ?>
	<div class="account-controls" data-authorized="<?= $USER->IsAuthorized() ? 'true' : 'false' ?>">
		<? if (!$USER->IsAuthorized()): ?>
		<div class="when-not-authorized">
			<ul class="header-ppinvite">
				<li>
					<a href="#modal-login" class="login flaticon-profile8" data-toggle="modal"><?= GetMessage('RZ_ACCOUNT_CONTROLS_LOGIN') ?></a>
				</li>
				<? if ('Y' == COption::GetOptionString('main', 'new_user_registration', 'Y')): ?>
				<li>
					<a href="#modal-reg" class="register flaticon-pencil41" data-toggle="modal"><?= GetMessage('RZ_ACCOUNT_CONTROLS_REGISTER') ?></a>
				</li>
				<? endif ?>
				<? if (!$bOnlyMenu): ?>
					<?= $compareContent ?>
				<? endif ?>
				<? $frame = $this->createFrame()->begin(Main::insertCompositLoader()) ?>
						<?if (\Yenisite\Furniture\Mobile::isMobile()):?>
						<? if ($arParams['USE_FAVORITE']): ?>
							<a href="<?= $arParams['FAVORITE_LINK'] ?>" class="header-fav-link flaticon-heart296" data-toggle="tooltip"
							   data-placement="bottom" title="<?= GetMessage('RZ_ACCOUNT_CONTROLS_FAV') ?>" id="personal_favorite_count"
							   data-quan="<?= $arResult['FAVORITE_COUNT'] ?>"></a>
						<? endif ?>
						<a href="<?= $arParams['COMPARE_LINK'] ?>" class="header-comp-link flaticon-right130" data-toggle="tooltip"
						   data-placement="bottom" title="<?= GetMessage('RZ_ACCOUNT_CONTROLS_COMP') ?>" id="personal_compare_count"
						   data-quan="<?= $arResult['COMPARE_COUNT'] ?>"></a>
					<?endif?>
				<? $frame->end() ?>
			</ul>
		</div>
		<? else: ?>
		<div class="when-authorized">
			<?
			$noPhotoSRC = $_SERVER['DOCUMENT_ROOT'] . SITE_TEMPLATE_PATH . '/img/no_photo/no-avatar.png';
			$userPhoto = Main::GetResizedImg($USER->GetParam("PERSONAL_PHOTO"),
				array('WIDTH' => 22, 'HEIGHT' => 22, 'SET_ID' => $arParams['RESIZER_USER_AVA_ICON']), $noPhotoSRC);
			$userName = $arResult['USER_NAME'] ? $arResult['USER_NAME'] : $arResult['USER_LOGIN'];
			?>
			<ul class="header-ppinvite">
    			<li>
        			<a href="<?= Tools::GetConstantUrl($arParams['PROFILE_URL']) ?>" class="header__account-link">
					<!-- <img src="<?= $userPhoto ?>" alt="<?= $userName ?>"> -->
					<span class="header__account-name"><?= $userName ?></span>
					</a>
                </li>
        		<li>
					<a href="?logout=yes" class="logout flaticon-fast34"><?= GetMessage('RZ_ACCOUNT_CONTROLS_LOGOUT') ?></a>
        		</li>
          	</ul>
		</div>
		<? endif ?>
	</div>
	<? if ($bOnlyMenu) {
		$GLOBALS['RZ_SECOND_EXEC'] = 1;
		return;
	} ?>

	<? if ($USER->IsAuthorized()) return;
	$this->SetViewTarget('modals'); ?>
	<div class="modal fade" id="modal-login" tabindex="-1" role="dialog">
	<div class="modal-dialog modal-login" role="document">
	<div class="modal-content">
	<div class="modal-header">
		<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span class="svg-wrap close"><svg>
					<use xlink:href="#close"></use>
				</svg></span></button>
		<h4 class="modal-title flaticon-profile8"><?=GetMessage('RZ_MODAL_LOGIN_HEADER')?></h4>
	</div>
	<div class="modal-body clearfix">
	<? $frame = $this->createFrame()->begin(Main::insertCompositLoader()) ?>
	<div class="login-form tab-content">
	<? $APPLICATION->IncludeComponent('bitrix:system.auth.forgotpasswd', 'modal', array('RND' => $arResult["RND"])) ?>
	<div class="tab-pane fade in active" id="form_auth">
	<form name="system_auth_form<?= $arResult["RND"] ?>" method="post" target="_top" <? Ajax::printAjaxDataAttr($this, 'modal') ?>
	action="<?= $arResult["AUTH_URL"] ?>" class="modal-login-forms col-xs-12 col-md-5 ajax-form" data-validate="true" data-spin="submit">
<? endif ?>
    <input type="hidden" name="privacy_policy" value="N"/>
<? if (!$USER->IsAuthorized()): ?>
	<? if ($arResult["BACKURL"] <> ''): ?>
<input type="hidden" name="backurl" value="<?= $arResult["BACKURL"] ?>"/>
<? endif ?>
	<? foreach ($arResult["POST"] as $key => $value): ?>
<input type="hidden" name="<?= $key ?>" value="<?= $value ?>"/>
<? endforeach ?>
<input type="hidden" name="AUTH_FORM" value="Y"/>
<input type="hidden" name="TYPE" value="AUTH"/>
	<? if ($arResult['SHOW_ERRORS'] == 'Y' && $arResult['ERROR']):?>
	<div class="form-message shown">
		<? Main::ShowMessage($arResult['ERROR_MESSAGE']) ?>
	</div>
<? endif ?>
	<label class="form-group">
		<span class="label-text"><?=GetMessage('RZ_LOGIN_EMAIL_OR_PHONE')?><span class="asterisk-required">*</span>:</span>
		<input type="text" class="form-control" name="USER_LOGIN" value="<?= $arResult["USER_LOGIN"] ?>" required tabindex="1">
	</label>

	<label class="form-group">
		<span class="label-text"><?=GetMessage('RZ_LOGIN_PASSWORD')?><span class="asterisk-required">*</span>:</span>
		<input type="password" class="form-control input-password" name="USER_PASSWORD" required tabindex="2">
		<i class="flaticon-eye46 password-icon"></i>
		<i class="flaticon-eye48 password-icon"></i>
	</label>
	<a href="#form_reset" class="classic-link forgot-pass pull-right action-link" data-toggle="tab"><?=GetMessage("RZ_LOGIN_FORGET_PASSWORD")?></a>
	<? if ($arResult["CAPTCHA_CODE"]): ?>
	<label class="form-group name">
		<span class="label-text"><?=GetMessage("RZ_CAPTCHA_INPUT_TEXT")?><span class="asterisk-required">*</span>:</span>
		<input type="hidden" name="captcha_sid" value="<?= $arResult["CAPTCHA_CODE"] ?>"/>
		<input type="text" name="captcha_word" class="form-control" required tabindex="3">
											<span class="captcha">
												<span class="input-group">
													<img src="/bitrix/tools/captcha.php?captcha_sid=<?= $arResult["CAPTCHA_CODE"] ?>" alt="<?=GetMessage("RZ_CAPTCHA")?>" class="captcha-img">
												</span>
											</span>
	</label>
<? endif ?>
	<div class="form-group">
		<? if ($arResult["STORE_PASSWORD"] == "Y"): ?>
			<?
			Form::printElement(
				array(
					'NAME' => 'USER_REMEMBER',
					'TEXT' => GetMessage("RZ_REMEMBER_ME"),
					'INDEX' => 4,
					'CHECKED' => 1,
				),
				Form::TYPE_SWITCH
			)
			?>
		<? endif ?>
	</div>
    <div class="form-group">
        <?
       $text = GetMessage('RZ_RULES_YA') . ' ';
        $text .=  GetMessage('RZ_ACCEPT') . " <a href='" . $pathToRules . "' target='_blank' class='classic-link'>" . GetMessage('RZ_CONCLUSION') . "</a>";
        Form::printElement(
            array(
                'NAME' => 'PRIVACY_POLICY',
                'CHECKED' => $_POST['PRIVACY_POLICY'] == 'Y',
                'TEXT' => $text,
                'REQ' => true,
                'INDEX' => ++$tabIndex,
            ), Form::TYPE_CHECKBOX
        );
        ?>
    </div>
	<div class="text-center mar-t-15">
		<button type="submit" class="btn btn-lg btn-primary">
			<?=GetMessage('RZ_LOGIN_LOGIN')?>
		</button>
	</div>
<? else : //$USER->IsAuthorized()?>
<? Main::ShowMessage(GetMessage('RZ_AUTH_SUCCESS'), Main::MSG_TYPE_SUCCESS); ?>
	<script type="text/javascript">
		window.location.reload();
	</script>
<? endif ?>
<?if(!$isAjax):?>
	<div class="or"><?= GetMessage('RZ_OR') ?></div>
	</form>
	<? $APPLICATION->IncludeComponent("bitrix:socserv.auth.form", "modal",
		array(
			"AUTH_SERVICES" => $arResult["AUTH_SERVICES"],
			"AUTH_URL" => $arResult["AUTH_URL"],
			"POST" => $arResult["POST"],
			"POPUP" => "N",
			"SUFFIX" => "form",
		),
		$component,
		array("HIDE_ICONS" => "Y")
	); ?>
	</div>
	</div>
	<? $frame->end() ?>
	</div>
	</div>
	</div>
	</div>
	<? $this->EndViewTarget();
endif;