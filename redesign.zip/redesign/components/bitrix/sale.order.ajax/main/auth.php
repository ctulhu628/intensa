<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();?>
<script>
<!--
function ChangeGenerate(val)
{
	if(val)
	{
		document.getElementById("sof_choose_login").style.display='none';
	}
	else
	{
		document.getElementById("sof_choose_login").style.display='block';
		document.getElementById("NEW_GENERATE_N").checked = true;
	}

	try{document.order_reg_form.NEW_LOGIN.focus();}catch(e){}
}
//-->
</script>
<div class="ui-line auth-order">
	<div class="modal-block">
		<div class="modal-login__column">
			<?if($arResult["AUTH"]["new_user_registration"]=="Y"):?>
				<div class="title-h2"><?echo GetMessage("STOF_2REG")?></div>
			<?endif;?>
			<form method="post" action="" name="order_auth_form">
				<?=bitrix_sessid_post()?>
				<?
				foreach ($arResult["POST"] as $key => $value)
				{
				?>
				<input type="hidden" name="<?=$key?>" value="<?=$value?>" />
				<?
				}
				?>
					<div class="title-h4"><?echo GetMessage("STOF_LOGIN_PROMT")?></div>
					<label class="modal-label">
						<span><?echo GetMessage("STOF_LOGIN")?> <span class="asterisk-required">*</span></span>
							<input required class="personal-information__input textinput" type="text" name="USER_LOGIN" maxlength="30" size="30" value="<?=$arResult["AUTH"]["USER_LOGIN"]?>">
						<span class="textinput-icons">
								<i class="icon-valid"></i>
								<i class="icon-not-valid"></i>
						</span>
					</label>
					<label class="modal-label">
						<span><?echo GetMessage("STOF_PASSWORD")?> <span class="asterisk-required">*</span></span>
							<input required class="textinput modal-input modal-input-password" type="password" name="USER_PASSWORD" maxlength="30" size="30">
						<span class="textinput-icons">
							<a class="show-password" href=""></a>
							<i class="icon-valid"></i>
							<i class="icon-not-valid"></i>
						</span>
					</label>
					<label class="modal-label forgot-href">
						<a href="<?=$arParams["PATH_TO_AUTH"]?>?forgot_password=yes&back_url=<?= urlencode($APPLICATION->GetCurPageParam()); ?>"><?echo GetMessage("STOF_FORGET_PASSWORD")?></a>
					</label>
					<label class="modal-label">
						<span>
							<input class="modal-button" type="submit" value="<?echo GetMessage("STOF_NEXT_STEP")?>">
							<input type="hidden" name="do_authorize" value="Y">
						</span>
					</label>
			</form>
		</div>
		<div class="modal-login__column">
			<?if($arResult["AUTH"]["new_user_registration"]=="Y"):?>
				<div class="title-h2"><?echo GetMessage("STOF_2NEW")?></div>
				<form method="post" action="" name="order_reg_form">
					<?=bitrix_sessid_post()?>
					<?
					foreach ($arResult["POST"] as $key => $value)
					{
					?>
					<input type="hidden" name="<?=$key?>" value="<?=$value?>" />
					<?
					}
					?>
						<label class="modal-label">
							<span>
								<?echo GetMessage("STOF_NAME")?> <span class="asterisk-required">*</span></span>
								<input required class="personal-information__input textinput" type="text" name="NEW_NAME" size="40" value="<?=$arResult["AUTH"]["NEW_NAME"]?>">&nbsp;&nbsp;&nbsp;
							<span class="textinput-icons">
								<i class="icon-valid"></i>
								<i class="icon-not-valid"></i>
							</span>
						</label>
						<label class="modal-label">
							<span>
								<?echo GetMessage("STOF_LASTNAME")?> <span class="asterisk-required">*</span></span>
								<input required class="personal-information__input textinput" type="text" name="NEW_LAST_NAME" size="40" value="<?=$arResult["AUTH"]["NEW_LAST_NAME"]?>">&nbsp;&nbsp;&nbsp;
							<span class="textinput-icons">
								<i class="icon-valid"></i>
								<i class="icon-not-valid"></i>
							</span>
						</label>
						<label class="modal-label">
							<span>
								E-Mail <span class="asterisk-required">*</span></span>
								<input required class="textinput modal-input" type="text" name="NEW_EMAIL" size="40" value="<?=$arResult["AUTH"]["NEW_EMAIL"]?>">&nbsp;&nbsp;&nbsp;
							<span class="textinput-icons">
								<i class="icon-valid"></i>
								<i class="icon-not-valid"></i>
							</span>
						</label>
						<?if($arResult["AUTH"]["new_user_registration_email_confirmation"] != "Y"):?>
						<label class="modal-label radio">
							<input type="radio" id="NEW_GENERATE_N" name="NEW_GENERATE" value="N" OnClick="ChangeGenerate(false)"<?if ($_POST["NEW_GENERATE"] == "N") echo " checked";?>>
								<span><?echo GetMessage("STOF_MY_PASSWORD")?></span>
							</label>
						<?endif;?>
						<?if($arResult["AUTH"]["new_user_registration_email_confirmation"] != "Y"):?>
						<div>
						<?endif;?>
										<label class="modal-label">
											<?if($arResult["AUTH"]["new_user_registration_email_confirmation"] != "Y"):?>
											<span>&nbsp;&nbsp;&nbsp;</span>
											<?endif;?>
											<span><?echo GetMessage("STOF_LOGIN")?> <span class="asterisk-required">*</span></span>
												<input required class="textinput modal-input" type="text" name="NEW_LOGIN" size="30" value="<?=$arResult["AUTH"]["NEW_LOGIN"]?>">
											<span class="textinput-icons">
												<i class="icon-valid"></i>
												<i class="icon-not-valid"></i>
											</span>
										</label>
										<label class="modal-label">
											<?if($arResult["AUTH"]["new_user_registration_email_confirmation"] != "Y"):?>
												<span>&nbsp;&nbsp;&nbsp;</span>
											<?endif;?>
											<span>
												<?echo GetMessage("STOF_PASSWORD")?> <span class="asterisk-required">*</span></span>
												<input required class="textinput modal-input modal-input-password"  type="password" name="NEW_PASSWORD" size="30">
											<span class="textinput-icons">
												<a class="show-password" href=""></a>
												<i class="icon-valid"></i>
												<i class="icon-not-valid"></i>
											</span>
										</label>
										<label class="modal-label">
											<?if($arResult["AUTH"]["new_user_registration_email_confirmation"] != "Y"):?>
												<span>&nbsp;&nbsp;&nbsp;</span>
											<?endif;?>
											<span>
												<?echo GetMessage("STOF_RE_PASSWORD")?> <span class="asterisk-required">*</span></span>
												<input required class="textinput modal-input modal-input-password" type="password" name="NEW_PASSWORD_CONFIRM" size="30">
											<span class="textinput-icons">
												<a class="show-password" href=""></a>
												<i class="icon-valid"></i>
												<i class="icon-not-valid"></i>
											</span>
										</label>
						<?if($arResult["AUTH"]["new_user_registration_email_confirmation"] != "Y"):?>
							</div>
						<?endif;?>
						<?if($arResult["AUTH"]["new_user_registration_email_confirmation"] != "Y"):?>
							<label class="radio">
								<input type="radio" id="NEW_GENERATE_Y" name="NEW_GENERATE" value="Y" OnClick="ChangeGenerate(true)"<?if ($POST["NEW_GENERATE"] != "N") echo " checked";?>>
								<span><?echo GetMessage("STOF_SYS_PASSWORD")?></span>
								<script language="JavaScript">
								<!--
								ChangeGenerate(<?= (($_POST["NEW_GENERATE"] != "N") ? "true" : "false") ?>);
								//-->
								</script>
							</label>
						<?endif;?>
						<?
						if($arResult["AUTH"]["captcha_registration"] == "Y") //CAPTCHA
						{
							?>
							<div class="title-h4"><?=GetMessage("CAPTCHA_REGF_TITLE")?></div>
							<label class="modal-label label-captcha">
								<span><?=GetMessage("CAPTCHA_REGF_PROMT")?><span class="asterisk-required">*</span>:</span>
								<input size="30" type="text" name="captcha_word" class="textinput modal-input" required maxlength="50" value="">
								<span class="modal-captcha">
									<input type="hidden" name="captcha_sid" value="<?=$arResult["AUTH"]["capCode"]?>">
									<img src="/bitrix/tools/captcha.php?captcha_sid=<?=$arResult["AUTH"]["capCode"]?>" width="180" height="40" alt="CAPTCHA">
								</span>
								 <span class="textinput-icons">
									<i class="icon-valid"></i>
									<i class="icon-not-valid"></i>
								</span>
							</label>
							<?
						}
						?>
						<label class="modal-label">
							<span>
								<input class="modal-button" type="submit" value="<?echo GetMessage("STOF_NEXT_STEP")?>">
								<input type="hidden" name="do_register" value="Y">
							</span>
						</label>
				</form>
			<?endif;?>
		</div>
	</div>
</div>
<div>
	<p>
		<?echo GetMessage("STOF_REQUIED_FIELDS_NOTE")?>
	</p>
<?if($arResult["AUTH"]["new_user_registration"]=="Y"):?>
	<p>
		<?echo GetMessage("STOF_EMAIL_NOTE")?>
	</p>
<?endif;?>
	<p>
		<?echo GetMessage("STOF_PRIVATE_NOTES")?>
	</p>
</div>
