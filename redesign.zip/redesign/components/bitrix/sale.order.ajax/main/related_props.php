<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
include 'props_format.php';
$style = (is_array($arResult["ORDER_PROP"]["RELATED"]) && count($arResult["ORDER_PROP"]["RELATED"])) ? "" : "display:none";
?>
<section class="order-details__section" style="<?= $style ?>">
	<h2 class="order-details__section-header">
		<span class="number"><?= ++$stepInt ?></span>
		<?= GetMessage("SOA_TEMPL_RELATED_PROPS") ?>
	</h2>
	<?= PrintPropsForm($arResult["ORDER_PROP"]["RELATED"], $arParams["TEMPLATE_LOCATION"]) ?>
</section><!-- .order-details__section -->