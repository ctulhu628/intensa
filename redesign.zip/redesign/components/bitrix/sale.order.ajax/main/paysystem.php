<? use Yenisite\Furniture\Form;
use Yenisite\Furniture\Main;

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die(); ?>
<script type="text/javascript">
	function changePaySystem(param) {
		var $checkBox = $("#PAY_CURRENT_ACCOUNT"),
				$checkBoxLabel = $("#PAY_CURRENT_ACCOUNT_LABEL");
		if (BX("account_only") && BX("account_only").value == 'Y') {
			if (param == 'account') {
				if ($checkBox.length) {
					$checkBox.prop('checked', true);
					$checkBox.attr("checked", "checked");
					$checkBoxLabel.addClass('selected');
					// deselect all other
					var el = document.getElementsByName("PAY_SYSTEM_ID");
					for (var i = 0; i < el.length; i++)
						el[i].checked = false;
				}
			}
			else {
				BX("PAY_CURRENT_ACCOUNT").checked = false;
				BX("PAY_CURRENT_ACCOUNT").removeAttribute("checked");
				BX.removeClass(BX("PAY_CURRENT_ACCOUNT_LABEL"), 'selected');
			}
		} else if (BX("account_only") && BX("account_only").value == 'N') {
			if (param == 'account') {
				if ($checkBox.length) {
					$checkBox.prop('checked', $checkBox.prop('checked'));

					if ($checkBox.prop('checked')) {
						$checkBox.attr("checked", "checked");
						$checkBoxLabel.addClass('selected');
					} else {
						$checkBox.removeAttr("checked");
						$checkBoxLabel.removeClass('selected');
					}
				}
			}
		}

		submitForm();
	}
</script>
<?
$printPaySystem = function ($arPaySystem) use (&$arParams, &$arResult, &$templateFolder) {
	if (count($arPaySystem["PSA_LOGOTIP"]) > 0):
		$arFileTmp = CFile::ResizeImageGet(
				$arPaySystem["PSA_LOGOTIP"]['ID'],
				array("width" => "95", "height" => "55"),
				BX_RESIZE_IMAGE_PROPORTIONAL,
				true
		);
		$default = false;
		$imgUrl = Main::GetResizedImg($arFileTmp["src"], $arResult['RESIZER_SYSTEMS']);
	else:
		$default = true;
		$imgUrl = Main::GetResizedImg($templateFolder . '/img/logo-default-ps.gif', $arResult['RESIZER_SYSTEMS']);
	endif;
	$name = '';
	//if ($arParams["SHOW_PAYMENT_SERVICES_NAMES"] != "N" || $default) {
	$name = $arPaySystem["PSA_NAME"];
	//	}

	Form::printElement(array(
			'NAME' => 'PAY_SYSTEM_ID',
			'VALUE' => $arPaySystem['ID'],
			'CHECKED' => $arPaySystem["CHECKED"] == "Y" && !($arParams["ONLY_FULL_PAY_FROM_ACCOUNT"] == "Y" && $arResult["USER_VALS"]["PAY_CURRENT_ACCOUNT"] == "Y"),
			'ATTR' => 'onclick="changePaySystem();"',
			'TEXT' => '<span class="radio-image"><img alt="" src="' . $imgUrl . '"/></span><span class="text">' . $name . '</span>',
	), Form::TYPE_RADIO);
	?>
	<span class="description">
			<?
			if ((int)$arPaySystem["PRICE"] > 0) {
				echo str_replace("#PAYSYSTEM_PRICE#",
						SaleFormatCurrency(roundEx($arPaySystem["PRICE"], SALE_VALUE_PRECISION),
								$arResult["BASE_LANG_CURRENCY"]),
						GetMessage("SOA_TEMPL_PAYSYSTEM_PRICE"));
			}
			?>
			<?= $arPaySystem["DESCRIPTION"] ?>
		</span>
	<?
};
?>
<div class="ordering-option payment col-md-6">
	<? if (!empty($arResult["PAY_SYSTEM"]) && is_array($arResult["PAY_SYSTEM"]) || $arResult["PAY_FROM_ACCOUNT"] == "Y") { ?>
	<h3 class="ordering-option__header">
		<span class="option-cloud"><?= ++$stepInt ?></span>
		<?= GetMessage("SOA_TEMPL_PAY_SYSTEM") ?>
	</h3>
	<div class="ordering-option__content">
		<ul class="ordering-radio-options">
		<? }
		if ($arResult["PAY_FROM_ACCOUNT"] == "Y") {
			$accountOnly = ($arParams["ONLY_FULL_PAY_FROM_ACCOUNT"] == "Y") ? "Y" : "N";
			?>
			<li>
				<input type="hidden" id="account_only" value="<?= $accountOnly ?>"/>
				<input type="hidden" name="PAY_CURRENT_ACCOUNT" value="N">
				<label class="radio">
					<input type="checkbox" name="PAY_CURRENT_ACCOUNT" onclick="changePaySystem();" value="Y"
						   class="radio-input state"<?= $arResult["USER_VALS"]["PAY_CURRENT_ACCOUNT"] == "Y" ? ' checked="checked"' : '' ?>>
					<span class="radio-content">
						<span class="radio-image">
							<img alt="" src="<?= Main::GetResizedImg($templateFolder . '/img/logo-default-ps.gif',
									$arResult['RESIZER_SYSTEMS']) ?>">
						</span>
						<span class="text"><?= GetMessage("SOA_TEMPL_PAY_ACCOUNT") ?></span>
					</span>
					<span class="description">
					<?= GetMessage("SOA_TEMPL_PAY_ACCOUNT1") . ' ' . $arResult["CURRENT_BUDGET_FORMATED"] ?>
						<? if ($arParams["ONLY_FULL_PAY_FROM_ACCOUNT"] == "Y"): ?>
							<span><?= GetMessage("SOA_TEMPL_PAY_ACCOUNT3") ?></span>
						<? else: ?>
							<span><?= GetMessage("SOA_TEMPL_PAY_ACCOUNT2") ?></span>
						<? endif; ?>
					</span>
				</label>
			</li>
			<?
		}

		uasort($arResult["PAY_SYSTEM"], "cmpBySort"); // resort arrays according to SORT value

		foreach ($arResult["PAY_SYSTEM"] as $arPaySystem) {
			if (strlen(trim(str_replace("<br />", "", $arPaySystem["DESCRIPTION"]))) > 0 || intval($arPaySystem["PRICE"]) > 0) {
				if (count($arResult["PAY_SYSTEM"]) == 1) {
					?>
					<li>
						<input type="hidden" name="PAY_SYSTEM_ID" value="<?= $arPaySystem["ID"] ?>">
						<? $printPaySystem($arPaySystem) ?>
					</li>
				<? } else { ?>
					<li>
						<? $printPaySystem($arPaySystem) ?>
					</li>
				<? }
			}

			if (strlen(trim(str_replace("<br />", "", $arPaySystem["DESCRIPTION"]))) == 0 && intval($arPaySystem["PRICE"]) == 0) {
				if (count($arResult["PAY_SYSTEM"]) == 1) {
					?>
					<li>
						<input type="hidden" name="PAY_SYSTEM_ID" value="<?= $arPaySystem["ID"] ?>">
						<? $printPaySystem($arPaySystem) ?>
					</li>
					<?
				} else { ?>
					<li>
						<? $printPaySystem($arPaySystem) ?>
					</li>
					<?
				}
			}
		} ?>
	</ul>
	</div>
</div>