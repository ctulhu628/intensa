<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
$arResult['RESIZER_SYSTEMS'] = array('WIDTH' => 164, 'HEIGHT' => 109, 'SET_ID' => $arParams['RESIZER_SYSTEMS']);
$arResult['RESIZER_ITEM'] = array('WIDTH' => 144, 'HEIGHT' => 95, 'SET_ID' => $arParams['RESIZER_IMAGE']);