<? use Yenisite\Furniture\Form;

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

if (count($arResult["PERSON_TYPE"]) > 1) {
	?>
	<? foreach ($arResult["PERSON_TYPE"] as $v) {
		Form::printElement(array(
				'ATTR' => 'id="PERSON_TYPE_' . $v['ID'] . '" onClick="submitForm()"',
				'NAME' => 'PERSON_TYPE',
				'CHECKED' => $v['CHECKED'] == 'Y',
				'VALUE' => $v['ID'],
				'TEXT' => $v['NAME'],

		), Form::TYPE_RADIO);
	}
	?>
	<input type="hidden" name="PERSON_TYPE_OLD" value="<?= $arResult['USER_VALS']['PERSON_TYPE_ID'] ?>"/>
	<?
} else {
	if ((int)($arResult["USER_VALS"]["PERSON_TYPE_ID"])) {
		//for IE 8, problems with input hidden after ajax
		?>
		<span style="display:none;">
			<input type="text" name="PERSON_TYPE" value="<?= (int)$arResult['USER_VALS']['PERSON_TYPE_ID'] ?>" title=""/>
			<input type="text" name="PERSON_TYPE_OLD" value="<?= (int)$arResult['USER_VALS']['PERSON_TYPE_ID'] ?>" title=""/>
		</span>
		<?
	} else {
		foreach ($arResult['PERSON_TYPE'] as $v) {
			?>
			<input type="hidden" id="PERSON_TYPE" name="PERSON_TYPE" value="<?= $v['ID'] ?>"/>
			<input type="hidden" name="PERSON_TYPE_OLD" value="<?= $v['ID'] ?>"/>
			<?
		}
	}
}
?>