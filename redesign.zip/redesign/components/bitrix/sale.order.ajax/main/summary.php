<? use Yenisite\Furniture\Main;

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die(); ?>
<?
$bDefaultColumns = $arResult["GRID"]["DEFAULT_COLUMNS"];
$colspan = ($bDefaultColumns) ? count($arResult["GRID"]["HEADERS"]) : count($arResult["GRID"]["HEADERS"]) - 1;
$bPropsColumn = false;
$bUseDiscount = false;
$bPriceType = false;
$bShowNameWithPicture = ($bDefaultColumns) ? true : false; // flat to show name and picture column in one column
?>
<div class="ordering-option">
	<h3 class="ordering-option__header">
		<span class="option-cloud"><?= $stepInt++ ?></span>
		<?= GetMessage("SALE_PRODUCTS_SUMMARY") ?>
	</h3>

	<div class="ordering-option__content">
		<div class="row">
			<div class="col col-md-8 col-xl-9 table-wrap">
				<table class="cart-table short">
					<thead>
					<tr>
						<?
						$bPreviewPicture = false;
						$bDetailPicture = false;
						$imgCount = 0;

						// prelimenary column handling
						foreach ($arResult["GRID"]["HEADERS"] as $id => $arColumn) {
							if ($arColumn["id"] == "PROPS") {
								$bPropsColumn = true;
							}

							if ($arColumn["id"] == "NOTES") {
								$bPriceType = true;
							}

							if ($arColumn["id"] == "PREVIEW_PICTURE") {
								$bPreviewPicture = true;
							}

							if ($arColumn["id"] == "DETAIL_PICTURE") {
								$bDetailPicture = true;
							}
						}

						if ($bPreviewPicture || $bDetailPicture) {
							$bShowNameWithPicture = true;
						} ?>
						<? foreach ($arResult["GRID"]["HEADERS"] as $id => $arColumn):
							if (in_array($arColumn["id"], array(
									"PROPS",
									"TYPE",
									"NOTES",
									"PREVIEW_PICTURE",
									"DETAIL_PICTURE",
							))) {
								continue;
							}

							if ($arColumn["id"] == "NAME"): ?>
								<td colspan="2" class="for-main-info">
								<?= GetMessage("SALE_PRODUCTS") ?>
							<? elseif ($arColumn["id"] == "PRICE"): ?>
								<td class="hidden-xs">
								<? echo $arColumn["name"];
							else: ?>
								<td class="hidden-xs">
								<?= $arColumn["name"];
							endif ?>
							</td>
						<? endforeach; ?>
					</tr>
					</thead>
					<tbody>
					<? foreach ($arResult["GRID"]["ROWS"] as $k => $arData): ?>
						<tr class="cart-item">
							<? if ($bShowNameWithPicture): ?>
								<td class="img-wrap">
									<?
									$url = Main::GetResizedImg($arData["data"], $arResult['RESIZER_ITEM']);
									?>
									<? if (strlen($arData["data"]["DETAIL_PAGE_URL"]) > 0): ?>
									<a href="<?= $arData["data"]["DETAIL_PAGE_URL"] ?>">
										<? endif ?>
										<img src="<?= $url ?>"/>
										<? if (strlen($arData["data"]["DETAIL_PAGE_URL"]) > 0): ?>
									</a>
								<? endif ?>
								</td>
							<? endif;

							// prelimenary check for images to count column width
							foreach ($arResult["GRID"]["HEADERS"] as $id => $arColumn) {
								$arItem = (isset($arData["columns"][$arColumn["id"]])) ? $arData["columns"] : $arData["data"];
								if (is_array($arItem[$arColumn["id"]])) {
									foreach ($arItem[$arColumn["id"]] as $arValues) {
										if ($arValues["type"] == "image") {
											$imgCount++;
										}
									}
								}
							}

							foreach ($arResult["GRID"]["HEADERS"] as $id => $arColumn):

								$class = ($arColumn["id"] == "PRICE_FORMATED") ? "price" : "";

								if (in_array($arColumn["id"],
										array("PROPS", "TYPE", "NOTES"))) // some values are not shown in columns in this template
								{
									continue;
								}

								if ($arColumn["id"] == "PREVIEW_PICTURE" && $bShowNameWithPicture) {
									continue;
								}

								$arItem = (isset($arData["columns"][$arColumn["id"]])) ? $arData["columns"] : $arData["data"];

								if ($arColumn["id"] == "NAME"):
									?>
									<td class="name-wrap">
										<? if (strlen($arItem["DETAIL_PAGE_URL"]) > 0): ?>
										<a class="classic-link" href="<?= $arItem["DETAIL_PAGE_URL"] ?>">
											<? endif ?>
											<?= $arItem["NAME"] ?>
											<? if (strlen($arItem["DETAIL_PAGE_URL"]) > 0): ?>
										</a>
									<? endif ?>
										<?
										if ($bPropsColumn):
											foreach ($arItem["PROPS"] as $val):
												echo $val["NAME"] . ": " . $val["VALUE"];
											endforeach;
										endif;
										?>
										<?
										if (is_array($arItem["SKU_DATA"])):
											foreach ($arItem["SKU_DATA"] as $propId => $arProp):

												// is image property
												$isImgProperty = false;
												foreach ($arProp["VALUES"] as $id => $arVal) {
													if (isset($arVal["PICT"]) && !empty($arVal["PICT"])) {
														$isImgProperty = true;
														break;
													}
												}

												$full = (count($arProp["VALUES"]) > 5) ? "full" : "";

												if ($isImgProperty): // iblock element relation property
													?>
													<div class="bx_item_detail_scu_small_noadaptive <?= $full ?>">
														<?= $arProp["NAME"] ?>:

														<ul id="prop_<?= $arProp["CODE"] ?>_<?= $arItem["ID"] ?>"
															style="width: 200%;margin-left:0%;">
															<?
															foreach ($arProp["VALUES"] as $valueId => $arSkuValue):

																$selected = "";
																foreach ($arItem["PROPS"] as $arItemProp):
																	if ($arItemProp["CODE"] == $arItem["SKU_DATA"][$propId]["CODE"]) {
																		if ($arItemProp["VALUE"] == $arSkuValue["NAME"]) {
																			$selected = "class=\"bx_active\"";
																		}
																	}
																endforeach;
																?>
																<li <?= $selected ?>>
																	<a href="javascript:void(0);">
																		<img src="<?= Main::GetResizedImg($arSkuValue["PICT"]["SRC"],
																				$arResult['RESIZER_ITEM']) ?>"/>
																	</a>
																</li>
																<?
															endforeach;
															?>
														</ul>
														<div class="bx_slide_left"
															 onclick="leftScroll('<?= $arProp["CODE"] ?>', <?= $arItem["ID"] ?>);"></div>
														<div class="bx_slide_right"
															 onclick="rightScroll('<?= $arProp["CODE"] ?>', <?= $arItem["ID"] ?>);"></div>
													</div>
													<?
												else:
													?>
													<div class="bx_item_detail_size_small_noadaptive <?= $full ?>">

														<?= $arProp["NAME"] ?>:
														<ul id="prop_<?= $arProp["CODE"] ?>_<?= $arItem["ID"] ?>"
															style="width: 200%; margin-left:0%;">
															<?
															foreach ($arProp["VALUES"] as $valueId => $arSkuValue):

																$selected = "";
																foreach ($arItem["PROPS"] as $arItemProp):
																	if ($arItemProp["CODE"] == $arItem["SKU_DATA"][$propId]["CODE"]) {
																		if ($arItemProp["VALUE"] == $arSkuValue["NAME"]) {
																			$selected = "class=\"bx_active\"";
																		}
																	}
																endforeach;
																?>
																<li style="width:10%;" <?= $selected ?>>
																	<a href="javascript:void(0);"><?= $arSkuValue["NAME"] ?></a>
																</li>
																<?
															endforeach;
															?>
														</ul>
														<div class="bx_slide_left"
															 onclick="leftScroll('<?= $arProp["CODE"] ?>', <?= $arItem["ID"] ?>);"></div>
														<div class="bx_slide_right"
															 onclick="rightScroll('<?= $arProp["CODE"] ?>', <?= $arItem["ID"] ?>);"></div>
													</div>
													<?
												endif;
											endforeach;
										endif;
										?>
									</td>
									<?
								elseif ($arColumn["id"] == "PRICE_FORMATED"):
									?>
									<td class="price-wrap">
										<div class="old-price">
											<?
											if (doubleval($arItem["DISCOUNT_PRICE"]) > 0):?>
												<?= round($arItem["PRICE"] + $arItem["DISCOUNT_PRICE"]) ?>
												<? $bUseDiscount = true;
											endif;
											?>
										</div>
										<div class="price"><?= $arItem["PRICE"] ?></div>
										<? if ($bPriceType && strlen($arItem["NOTES"]) > 0): ?>
											<div>
												<div class="type_price"><?= GetMessage("SALE_TYPE") ?></div>
												<div class="type_price_value"><?= $arItem["NOTES"] ?></div>
											</div>
										<? endif; ?>
									</td>
									<?
								elseif ($arColumn["id"] == "DISCOUNT"):
									?>
									<td class="discount <? if ($arItem["DISCOUNT_PRICE"] > 0): ?>active<? endif ?>">
										<?= $arItem["DISCOUNT_PRICE_PERCENT_FORMATED"] ?>
									</td>
									<?
								elseif (in_array($arColumn["id"],
										array("QUANTITY", "WEIGHT_FORMATED", "DISCOUNT_PRICE_PERCENT_FORMATED", "SUM"))):?>
									<td class="<? if ($arColumn["id"] == 'QUANTITY'): ?> number <?
									elseif ($arColumn["id"] == 'SUM'):?> sum<?
									else:?> name<? endif ?>">
										<? if ($arColumn["id"] == 'SUM') {
											$arItem[$arColumn["id"]] = htmlspecialcharsback($arItem[$arColumn["id"]]);
										} ?>
										<?= $arItem[$arColumn["id"]] ?>
									</td>
									<?
								else: // some property value

									if (is_array($arItem[$arColumn["id"]])):

										foreach ($arItem[$arColumn["id"]] as $arValues)
											?>
											<td class="name">
											<?
										foreach ($arItem[$arColumn["id"]] as $arValues):
											if ($arValues["type"] == "image"):
												?>
												<img src="<?= Main::GetResizedImg($arValues["value"], $arResult['RESIZER_ITEM']) ?>"/>
											<? else: // not image
												echo $arValues["value"] . "<br/>";
											endif;
										endforeach;
										?>
										</td>
										<?
									else: // not array, but simple value
										?>
										<td class="sum">
											<?= $arItem[$arColumn["id"]] ?>
										</td>
										<?
									endif;
								endif;
							endforeach;
							?>
						</tr>
					<? endforeach; ?>
					</tbody>
				</table>
			</div>
			<div class="col col-md-4 col-xl-3 table-wrap">
				<div class="big-cart-total clearfix">
					<table>
						<tbody>
						<tr>
							<th colspan="2"><?= GetMessage('SOA_TEMPL_SUM_IT') ?></th>
						</tr>
						<? if ((float)$arResult['ORDER_WEIGHT'] > 0): ?>
							<tr>
								<td><?= GetMessage('SOA_TEMPL_SUM_WEIGHT_SUM') ?></td>
								<td><b><?= $arResult["ORDER_WEIGHT_FORMATED"] ?></b></td>
							</tr>
						<? endif ?>
						<tr>
							<td><?= GetMessage("SOA_TEMPL_SUM_SUMMARY") ?></td>
							<td><b><?= $arResult["ORDER_PRICE_FORMATED"] ?></b></td>
						</tr>
						<? if ($bUseDiscount): ?>
							<tr>
								<td><?= GetMessage('SOA_TEMPL_SUM_DISCOUNT') ?></td>
								<td><b><?= $arResult['DISCOUNT_PRICE_FORMATED'] ?> (<?= $arResult["DISCOUNT_PERCENT_FORMATED"]; ?>)</b></td>
							</tr>
						<? endif ?>
						<? if (!empty($arResult["TAX_LIST"])) : ?>
							<? foreach ($arResult["TAX_LIST"] as $val) : ?>
								<tr>
									<td><?= $val["NAME"] ?> <?= $val["VALUE_FORMATED"] ?>:</td>
									<td><b><?= $val["VALUE_MONEY_FORMATED"] ?></b></td>
								</tr>
							<? endforeach ?>
						<? endif ?>
						<? if (doubleval($arResult["DELIVERY_PRICE"]) > 0): ?>
							<tr>
								<td class="text"><?= GetMessage("SOA_TEMPL_SUM_DELIVERY") ?></td>
								<td class="value"><b><?= $arResult["DELIVERY_PRICE_FORMATED"] ?></b></td>
							</tr>
						<? endif ?>
						<? if (strlen($arResult["PAYED_FROM_ACCOUNT_FORMATED"]) > 0): ?>
							<tr>
								<td><?= GetMessage("SOA_TEMPL_SUM_IT") ?></td>
								<td><b><?= $arResult["ORDER_TOTAL_PRICE_FORMATED"] ?></b></td>
							</tr>
							<tr>
								<td><?= GetMessage("SOA_TEMPL_SUM_PAYED") ?></td>
								<td><b><?= $arResult["PAYED_FROM_ACCOUNT_FORMATED"] ?></b></td>
							</tr>
							<tr>
								<td><?= GetMessage("SOA_TEMPL_SUM_LEFT_TO_PAY") ?></td>
								<td><b><?= $arResult["ORDER_TOTAL_LEFT_TO_PAY_FORMATED"] ?></b></td>
							</tr>
						<? else: ?>
							<tr>
								<td><?= GetMessage("SOA_TEMPL_SUM_IT") ?></td>
								<td><b><?= $arResult["ORDER_TOTAL_PRICE_FORMATED"] ?></b></td>
							</tr>
						<? endif ?>
						</tbody>
					</table>
				</div>
				<a href="#" onclick="submitForm('Y'); return false;"
				   class="btn-main btn-primary btn-checkout"
				   id="ORDER_CONFIRM_BUTTON"><?= GetMessage("SOA_TEMPL_BUTTON") ?></a>
				<input type="hidden" name="confirmorder" id="confirmorder" value="Y">
				<input type="hidden" name="profile_change" id="profile_change" value="N">
				<input type="hidden" name="is_ajax_post" id="is_ajax_post" value="Y">
				<input type="hidden" name="json" value="Y">
			</div>
		</div>
	</div>
</div>
