<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die(); ?>
<? if (!empty($arResult["ORDER"])): ?>
	<? $APPLICATION->SetTitle(GetMessage("SOA_TEMPL_ORDER_COMPLETE")) ?>
	<div class="ordering3">
		<div class="media">
			<div class="media-left">
				<img src="<?= $templateFolder . '/img/order-success.png' ?>" alt=""/>
			</div>
			<div class="media-body">
				<p class="media-heading">
						<?= GetMessage("SOA_TEMPL_ORDER_SUC", Array(
								"#ORDER_DATE#" => $arResult["ORDER"]["DATE_INSERT"],
								"#ORDER_ID#" => $arResult["ORDER"]["ACCOUNT_NUMBER"],
								"#HREF#" => $arParams['PATH_TO_ORDER'] . '?ID=' . $arResult['ORDER']['ID'],
						)) ?>
				</p>
				<p><?= GetMessage("SOA_TEMPL_ORDER_SUC1", Array("#LINK#" => $arParams["PATH_TO_PERSONAL"])) ?></p>
				<?
				if (!empty($arResult["PAY_SYSTEM"])) {
					?>
					<table class="basket-table">
						<tr>
							<td class="ps_logo">
								<div class="pay_name"><?= GetMessage("SOA_TEMPL_PAY") ?></div>
								<img src="<?= Yenisite\Furniture\Main::GetResizedImg($arResult["PAY_SYSTEM"]["LOGOTIP"], $arResult['RESIZER_SYSTEMS'],
										$templateFolder . '/img/logo-default-ps.gif') ?>" alt="">
								<div class="paysystem_name"><?= $arResult["PAY_SYSTEM"]["NAME"] ?></div>
							</td>
						</tr>
						<? if (strlen($arResult["PAY_SYSTEM"]["ACTION_FILE"]) > 0) { ?>
							<tr>
								<td>
									<?
									$service = \Bitrix\Sale\PaySystem\Manager::getObjectById($arResult["ORDER"]['PAY_SYSTEM_ID']);

									if ($arResult["PAY_SYSTEM"]["NEW_WINDOW"] == "Y") {
										?>
										<script language="JavaScript">
											window.open('<?=$arParams["PATH_TO_PAYMENT"]?>?ORDER_ID=<?=urlencode(urlencode($arResult["ORDER"]["ACCOUNT_NUMBER"]))?>&PAYMENT_ID=<?=$arResult['ORDER']["PAYMENT_ID"]?>');
										</script>
									<?= GetMessage("SOA_TEMPL_PAY_LINK",
											Array("#LINK#" => $arParams["PATH_TO_PAYMENT"] . "?ORDER_ID=" . urlencode(urlencode($arResult["ORDER"]["ACCOUNT_NUMBER"])) . "&PAYMENT_ID=" . $arResult['ORDER']["PAYMENT_ID"])) ?>
										<?
										if (CSalePdf::isPdfAvailable() && $service->isAffordPdf()) {
											?><br/>
											<?= GetMessage("SOA_TEMPL_PAY_PDF",
													Array("#LINK#" => $arParams["PATH_TO_PAYMENT"] . "?ORDER_ID=" . urlencode(urlencode($arResult["ORDER"]["ACCOUNT_NUMBER"])) . "&PAYMENT_ID=" . $arResult['ORDER']["PAYMENT_ID"] . "&pdf=1&DOWNLOAD=Y")) ?>
											<?
										}
									} else {
										if ($service) {
											/** @var \Bitrix\Sale\Order $order */
											$order = \Bitrix\Sale\Order::load($arResult["ORDER_ID"]);

											/** @var \Bitrix\Sale\PaymentCollection $paymentCollection */
											$paymentCollection = $order->getPaymentCollection();

											/** @var \Bitrix\Sale\Payment $payment */
											foreach ($paymentCollection as $payment) {
												if (!$payment->isInner()) {
													$context = \Bitrix\Main\Application::getInstance()->getContext();
													$service->initiatePay($payment, $context->getRequest());
													break;
												}
											}
										} else {
											echo '<span style="color:red;">' . GetMessage("SOA_TEMPL_ORDER_PS_ERROR") . '</span>';
										}
									}
									?>
								</td>
							</tr>
							<?
						}
						?>
					</table>
					<?
				}
				?>
			</div>
		</div>
	</div>
<? else: ?>
	<? ob_start() ?>
	<?= GetMessage("SOA_TEMPL_ERROR_ORDER") ?><br>
	<b><?= GetMessage("SOA_TEMPL_ERROR_ORDER_LOST", Array("#ORDER_ID#" => $arResult["ACCOUNT_NUMBER"])) ?></b><br>
	<?= GetMessage("SOA_TEMPL_ERROR_ORDER_LOST1") ?><br>
	<? $strError = ob_get_clean() ?>
	<? \Yenisite\Furniture\Main::ShowMessage($strError) ?>
<? endif ?>