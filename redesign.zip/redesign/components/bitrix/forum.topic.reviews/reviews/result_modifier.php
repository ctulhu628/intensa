<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();
use \Yenisite\Core\Ajax;
$arParams['RESIZER_DETAIL_COMMENTS'] = $arParams['RESIZER_DETAIL_COMMENTS'] ? : 5;
Ajax::saveParams($this, $arParams, 'bitrix_review', SITE_ID);
if ($arResult["IS_AUTHORIZED"]){
    $srUser = CUser::GetByID($arResult["USER"]['ID']);
    $arUser = $srUser->Fetch();
    $arResult["USER"]['PERSONAL_PHOTO'] = CFile::GetPath($arUser['PERSONAL_PHOTO']);
}
