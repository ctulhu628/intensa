<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
use \Yenisite\Furniture\Main;
use \Yenisite\Furniture\Form;

$this->setFrameMode(true);
\Bitrix\Main\Localization\Loc::loadMessages($_SERVER['DOCUMENT_ROOT'] . SITE_TEMPLATE_PATH . '/lang/' . LANGUAGE_ID . '/header.php');
$pathToRules = COption::GetOptionString(\Yenisite\Furniture\Settings::getModuleId(), 'path_tu_rules_privacy', SITE_DIR . 'personal/rules/personal_data.php');
?>
<a href="#add-question" class="action-link has-icon link-add-question flaticon-add20" data-toggle="collapse"
   aria-expanded="false">
    <span class="link-text"><?= GetMessage('FURNITURE_ADD_REVIEW') ?></span>
</a>
<? if (strlen($arResult["ERROR_MESSAGE"]) > 0): ?>
    <?= Main::ShowMessage($arResult["ERROR_MESSAGE"], Main::MSG_TYPE_ERROR) ?>
<? endif; ?>
<? if (strlen($arResult["OK_MESSAGE"]) > 0): ?>
    <?= Main::ShowMessage($arResult["OK_MESSAGE"], Main::MSG_TYPE_SUCCESS) ?>
<? endif; ?>

<? if (count($arResult['MESSAGES']) < 1 && $arParams['GAMIFICATION']): ?>
    <div class="mar-b-15"><?= GetMessage('FURNITURE_BE_FIRST') ?></div>
<? endif ?>

<div class="media question-form collapse <? if (strlen($arResult["ERROR_MESSAGE"]) > 0): ?>in<? endif ?>"
     id="add-question">
    <div class="media-left">
        <? /* if(!empty( $arResult["USER"]['PERSONAL_PHOTO'])):?>
			<img src="<?=CResizer2Resize::ResizeGD2( $arResult["USER"]['PERSONAL_PHOTO'], $arParams['RESIZER_DETAIL_COMMENTS']);?>" alt="<?=$arResult['USER']['SHOWED_NAME']?>">
		<?else:?>
			<img src="<?=CResizer2Resize::ResizeGD2(SITE_TEMPLATE_PATH.'/img/no_photo/no-avatar.png', $arParams['RESIZER_DETAIL_COMMENTS']);?>" alt="<?=$arResult['USER']['SHOWED_NAME']?>">
		<?endif */ ?>
    </div>

    <form method="POST" enctype="multipart/form-data" name="form_comment" action="#" class="media-body"
          id="form_comment_forum">
        <input type="hidden" name="privacy_policy" value="N"/>
        <input type="hidden" name="back_page" value="<?= $arResult["CURRENT_PAGE"] ?>"/>
        <input type="hidden" name="ELEMENT_ID" value="<?= $arParams["ELEMENT_ID"] ?>"/>
        <input type="hidden" name="SECTION_ID" value="<?= $arResult["ELEMENT_REAL"]["IBLOCK_SECTION_ID"] ?>"/>
        <input type="hidden" name="IBLOCK_ID" value="<?= $arParams["IBLOCK_ID"] ?>"/>
        <input type="hidden" name="save_product_review" value="Y"/>
        <input type="hidden" name="preview_comment" value="N"/>
        <?= bitrix_sessid_post() ?>

        <? /* GUEST PANEL */
        if (!$arResult["IS_AUTHORIZED"]): ?>
            <label class="form-group">
                <span class="label-text"><?= GetMessage("FURNITURE_OPINIONS_NAME") ?><span
                            class="asterisk-required">*</span>:</span>
                <input name="REVIEW_AUTHOR" size="30" type="text" title="" class="form-control"
                       placeholder="<?= GetMessage("FURNITURE_OPINIONS_NAME") ?>"
                       value="<?= $arResult["REVIEW_AUTHOR"] ?>" required>
            </label>
            <? if ($arResult["FORUM"]["ASK_GUEST_EMAIL"] == "Y"): ?>
                <label class="form-group">
                    <span class="label-text"><?= GetMessage("FURNITURE_OPINIONS_EMAIL") ?><span
                                class="asterisk-required">*</span>:</span>
                    <input type="text" name="REVIEW_EMAIL" size="30" title="" value="<?= $arResult["REVIEW_EMAIL"] ?>"
                           class="form-control" placeholder="<?= GetMessage("FURNITURE_OPINIONS_EMAIL") ?>">
                </label>
            <? endif; ?>
        <? endif; ?>
            <textarea class="form-control" id="textarea-comment" name="REVIEW_TEXT" cols="12" rows="5"
                      placeholder="<?= GetMessage('FURNITURE_ENTER_MESSAGE') ?>" required></textarea>
        <?
        if (strLen($arResult["CAPTCHA_CODE"]) > 0): ?>
            <label class="form-group name registration-forms">
                <input type="hidden" name="captcha_code" value="<?= $arResult["CAPTCHA_CODE"] ?>">
                <span class="label-text"><?= GetMessage("FURNITURE_F_CAPTCHA_PROMT") ?><span
                            class="asterisk-required">*</span>:</span>
                <input class="form-control" type="text" size="30" name="captcha_word" id="captcha_word_forum_comment"
                       value="" tabindex="7" required placeholder="<?= GetMessage("B_B_MS_CAPTCHA_SYM_SHORT") ?>"
                       autocomplete="off">
                <span class="captcha" data-code="<?= $arResult["CAPTCHA_CODE"] ?>">
						<? /*<img src="/bitrix/tools/captcha.php?captcha_code=<?=$arResult["CAPTCHA_CODE"]?>" alt="<?=GetMessage("FURNITURE_F_CAPTCHA_TITLE")?>">*/ ?>
					</span>
            </label>
        <? endif; ?>
        <br/>
        <?
        $text = GetMessage('RZ_RULES_YA') . ' ';
        $text .= GetMessage('RZ_ACCEPT') . " <a href='" . $pathToRules . "' target='_blank' class='classic-link'>" . GetMessage('RZ_CONCLUSION') . "</a>";
        Form::printElement(
            array(
                'NAME' => 'PRIVACY_POLICY',
                'CHECKED' => $_POST['PRIVACY_POLICY'] == 'Y',
                'TEXT' => $text,
                'REQ' => true,
                'INDEX' => ++$tabIndex,
            ), Form::TYPE_CHECKBOX
        );
        ?>
        <button type="submit" class="btn-main btn-primary btn-add-question"
                value="<?= GetMessage("FURNITURE_OPINIONS_SEND") ?>" type="submit"
                name="send_button"><?= GetMessage("FURNITURE_ADD_QUESTION") ?></button>
    </form>
</div><!-- /.form-wrap -->

<? foreach ($arResult["MESSAGES"] as $arItem):
if ($arItem['LOGIN']) {
    $arItem['AUTHOR_NAME'] = "{$arItem['NAME']} {$arItem['SECOND_NAME']} {$arItem['LAST_NAME']}";
    if (empty($arItem['AUTHOR_NAME'])) $arItem['AUTHOR_NAME'] = $arItem['LOGIN'];
}
?>
<div class="media feedback-item" id="blg-comment-<?= $arItem["ID"] ?>">
    <div class="media-left">
        <? /* if(!empty($arItem['AVATAR']['FILE']['src'])):?>
				<img src="<?=CResizer2Resize::ResizeGD2($arItem['AVATAR']['FILE']['src'], $arParams['RESIZER_DETAIL_COMMENTS']);?>" alt="<?=$arItem['AUTHOR_NAME']?>">
			<?else:?>
				<img src="<?=CResizer2Resize::ResizeGD2(SITE_TEMPLATE_PATH.'/img/no_photo/no-avatar.png', $arParams['RESIZER_DETAIL_COMMENTS']);?>" alt="<?=$arItem['AUTHOR_NAME']?>">
			<?endif */
        ?>
    </div>
    <div class="media-body">
        <div class="media-title">
            <span class="user-name"><?= $arItem['AUTHOR_NAME'] ?></span>
            <span class="date"><?= $arItem['POST_DATE'] ?></span>
        </div>
        <div class="question-text">
            <? // COMMENT TEXT
            $explode_pos = 400;
            if (strlen($arItem["POST_MESSAGE_TEXT"]) > $explode_pos) {
                $explode_pos = strpos($arItem["POST_MESSAGE_TEXT"], " ", $explode_pos);
                $arItem['TEXT_SHORT'] = substr($arItem["POST_MESSAGE_TEXT"], 0, $explode_pos);
                $arItem['TEXT_FULL'] = substr($arItem["POST_MESSAGE_TEXT"], $explode_pos);
            } else {
                $arItem['TEXT_SHORT'] = $arItem["POST_MESSAGE_TEXT"];
            }
            ?>
            <?= $arItem["POST_MESSAGE_TEXT"] ?>
        </div>
    </div>
    <? endforeach; ?>

    <? if (strlen($arResult["NAV_STRING"]) > 0 && $arResult["NAV_RESULT"]->NavPageCount > 1): ?>
        <?= $arResult["NAV_STRING"] ?>
    <? endif; ?>
