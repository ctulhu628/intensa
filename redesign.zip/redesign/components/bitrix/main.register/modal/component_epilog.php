<?
$Asset = \Bitrix\Main\Page\Asset::getInstance();
$Asset->addJs(SITE_TEMPLATE_PATH . '/js/inits/init-phoneMasking.js');
$Asset->addJs(SITE_TEMPLATE_PATH . '/js/vendor/intl-tel-input/js/intlTelInput.min.js');