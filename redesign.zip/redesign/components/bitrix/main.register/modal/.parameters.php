<?
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();
\Bitrix\Main\Localization\Loc::loadLanguageFile($_SERVER['DOCUMENT_ROOT'] . 'bitrix/components/bitrix/main.register/.parameters.php');
$arTemplateParameters['AUTH']['HIDDEN'] = 'Y';
$arTemplateParameters['USE_BACKURL']['HIDDEN'] = 'Y';
$arTemplateParameters['SET_TITLE']['HIDDEN'] = 'Y';
$arTemplateParameters['SUCCESS_PAGE']['HIDDEN'] = 'Y';

/** @noinspection PhpDynamicAsStaticMethodCallInspection */
$rs = CGroup::GetList($by = 'c_sort', $order = 'asc');
$arGroups = array();
while ($ar = $rs->Fetch()) {
	$arGroups[$ar['ID']] = '[' . $ar['ID'] . '] ' . $ar['NAME'];
}

$arFormFields = array(
	'EMAIL' => 1,
	'TITLE' => 1,
	'NAME' => 1,
	'SECOND_NAME' => 1,
	'LAST_NAME' => 1,
	'AUTO_TIME_ZONE' => 1,
	'PERSONAL_PROFESSION' => 1,
	'PERSONAL_WWW' => 1,
	'PERSONAL_ICQ' => 1,
	'PERSONAL_GENDER' => 1,
	'PERSONAL_BIRTHDAY' => 1,
	'PERSONAL_PHOTO' => 1,
	'PERSONAL_PHONE' => 1,
	'PERSONAL_FAX' => 1,
	'PERSONAL_MOBILE' => 1,
	'PERSONAL_PAGER' => 1,
	'PERSONAL_STREET' => 1,
	'PERSONAL_MAILBOX' => 1,
	'PERSONAL_CITY' => 1,
	'PERSONAL_STATE' => 1,
	'PERSONAL_ZIP' => 1,
	'PERSONAL_COUNTRY' => 1,
	'PERSONAL_NOTES' => 1,
	'WORK_COMPANY' => 1,
	'WORK_DEPARTMENT' => 1,
	'WORK_POSITION' => 1,
	'WORK_WWW' => 1,
	'WORK_PHONE' => 1,
	'WORK_FAX' => 1,
	'WORK_PAGER' => 1,
	'WORK_STREET' => 1,
	'WORK_MAILBOX' => 1,
	'WORK_CITY' => 1,
	'WORK_STATE' => 1,
	'WORK_ZIP' => 1,
	'WORK_COUNTRY' => 1,
	'WORK_PROFILE' => 1,
	'WORK_LOGO' => 1,
	'WORK_NOTES' => 1,
);

if (!CTimeZone::Enabled()) {
	unset($arFormFields['AUTO_TIME_ZONE']);
}