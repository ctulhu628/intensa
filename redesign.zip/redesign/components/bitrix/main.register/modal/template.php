<?
/**
 * Bitrix vars
 * @global CMain $APPLICATION
 * @global CUser $USER
 * @var array $arParams
 * @var array $arResult
 * @var CBitrixComponentTemplate $this
 */
use Yenisite\Core\Tools;

if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();
$this->setFrameMode(true);
$rnd = $this->randString();

if ($arParams['EMPTY']) {
	echo '<div>', GetMessage('FURNITURE_REGISTER_TITLE'), '</div>';
	return;
}
$isAjax = Tools::isAjax();
if(!$isAjax || !empty($_REQUEST['TAB_ID']) || !empty($_REQUEST['FULL_FORM'])) {
	if ($USER->IsAuthorized()) {
		return true;
	}
	\Yenisite\Core\Ajax::saveParams($this, $arParams, 'modal');
}

if (count($arResult["ERRORS"]) > 0) {
	foreach ($arResult["ERRORS"] as $key => $error) {
		if (intval($key) == 0 && $key !== 0) {
			$arResult["ERRORS"][$key] = str_replace("#FIELD_NAME#", "&quot;" . GetMessage("RZ_REGISTER_FIELD_" . $key) . "&quot;", $error);
		}
	}
}
if(!$isAjax || !empty($_REQUEST['TAB_ID']) || !empty($_REQUEST['FULL_FORM'])):?>
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span class="svg-wrap close"><svg>
		<use xlink:href="#close"></use>
	</svg></span></button>
					<h4 class="modal-title flaticon-pencil41"><?=GetMessage('RZ_MODAL_REGISTRATION_HEADER')?></h4>
				</div>
				<div class="modal-body">
					<form data-validate="true" novalidate method="post" action="<?= POST_FORM_ACTION_URI ?>" enctype="multipart/form-data"
						class="registration-forms ajax-form" <? \Yenisite\Core\Ajax::printAjaxDataAttr($this, 'modal') ?>>
<? endif ?>
					<? include 'form_content.php' ?>
<?if(!$isAjax || !empty($_REQUEST['TAB_ID']) || !empty($_REQUEST['FULL_FORM'])):?>
					</form>
				</div>
<? endif;