<? use Yenisite\Furniture\Form;
use Yenisite\Furniture\Main;
\Bitrix\Main\Localization\Loc::loadMessages($_SERVER['DOCUMENT_ROOT'].SITE_TEMPLATE_PATH . '/lang/'.LANGUAGE_ID.'/header.php');
$pathToRules = COption::GetOptionString(\Yenisite\Furniture\Settings::getModuleId(),'path_tu_rules_privacy',SITE_DIR.'personal/rules/personal_data.php');
?>
<? if ($USER->IsAuthorized()): ?>
	<?
	if ("Y" == $arResult["USE_EMAIL_CONFIRMATION"]) {
		Main::ShowMessage(GetMessage("RZ_AUTH_EMAIL_SENT"), Main::MSG_TYPE_SUCCESS);
	} else {
		$APPLICATION->arAuthResult['MESSAGE'] .= '<br>' . GetMessage('RZ_WINDOW_RELOAD');
		Main::ShowMessage($APPLICATION->arAuthResult, Main::MSG_TYPE_SUCCESS);
		echo '<script type="text/javascript">window.location.reload()</script>';
	}
	?>
<? else: ?>
	<?
	$arFormTypeFields =  $arParams['USER_PROPERTY'];
	$arFormTypeReq = $arParams['REQUIRED_FIELDS'];
	$arResult['SHOW_FIELDS'] = array_merge($arResult['SHOW_FIELDS'], $arFormTypeFields);
	$arResult['REQUIRED'] = array_merge($arResult['REQUIRED_FIELDS'], $arFormTypeReq);

	foreach ($arFormTypeFields as $FIELD) {
		$arResult['VALUES'][$FIELD] = $_REQUEST['REGISTER'][$FIELD];
	}

	$hasEmail = 0;
	foreach($arResult['SHOW_FIELDS'] as $key => &$FIELD) {
		if ($FIELD == 'LOGIN') {
			$FIELD = 'EMAIL';
			$hasEmail = 1;
			continue;
		}
		if ($FIELD == 'EMAIL' && $hasEmail) {
			unset($arResult['SHOW_FIELDS'][$key]);
		}
		if ($FIELD == 'EMAIL' && !$hasEmail) {
			$hasEmail = 1;
		}
	}
	unset($FIELD);
	if (!$hasEmail) {
		array_unshift($arResult['SHOW_FIELDS'], 'EMAIL');
	}

	$arResult['REQUIRED'] = array_flip($arResult['REQUIRED_FIELDS']);
	if (!isset($arResult['REQUIRED']['EMAIL'])) {
		$arResult['REQUIRED']['EMAIL'] = '';
	}
	$tabIndex = 1;
	?>
	<div class="hint"><?= GetMessage('RZ_REQUIRED_FIELDS_TEXT') ?></div>
	<? if (!empty($arResult["ERRORS"])) {
		Main::ShowMessage($arResult["ERRORS"]);
	} ?>
	<div class="row registration-content">
		<div class="block-table">
			<?
			$arRows = array_chunk($arResult['SHOW_FIELDS'], ceil(count($arResult['SHOW_FIELDS']) / 2));
			$f = 1;
			?>
			<? foreach ($arRows as $arRow): ?>
				<div class="<?= $f ? 'forms-left' : 'forms-right' ?> col-xs-12 col-md-6">
					<? $f = 0 ?>
					<? foreach ($arRow as $FIELD): ?>
						<?
						if ($FIELD == 'LOGIN') continue;
						$isReq = isset($arResult['REQUIRED'][$FIELD]);
						switch ($FIELD) {
							case 'PASSWORD':
							case 'CONFIRM_PASSWORD':
								$FIELD_TYPE = 'password';
								break;
							case 'EMAIL':
								$FIELD_TYPE = 'email';
								break;
							default:
								$FIELD_TYPE = 'text';
						}
						$addClass = '';
						if (strpos($FIELD, 'PHONE') !== false) {
							$addClass = 'input-phone';
						}
						if ($FIELD_TYPE == 'password') {
							$addClass = 'input-password';
						}
						$addClass = $addClass ? ' ' . $addClass : '';
						?>
						<label class="form-group">
							<span class="label-text"><?= GetMessage('RZ_REGISTER_FIELD_' . $FIELD) ?><? if ($isReq): ?><span class="asterisk-required">*</span><? endif ?>:</span>
							<input type="<?= $FIELD_TYPE ?>" name="REGISTER[<?= $FIELD ?>]"
								   class="form-control<?= $addClass ?>" tabindex="<?= ++$tabIndex ?>" <? if ($isReq): ?>required<? endif ?>
								   value="<?= htmlspecialcharsbx($arResult['VALUES'][$FIELD]) ?>">
							<? if ($FIELD_TYPE == 'password'): ?>
								<i class="flaticon-eye46 password-icon"></i>
								<i class="flaticon-eye48 password-icon"></i>
							<? endif ?>
						</label>
					<? endforeach ?>
				</div>
			<? endforeach ?>
		</div>
	</div>
    <input type="hidden" name="privacy_policy" value="N"/>
	<input type="hidden" name="REGISTER[LOGIN]" value="NOT_EMPTY"/>
	<? $frame = $this->createFrame()->begin(Main::insertCompositLoader()) ?>
	<? if ($arResult["USE_CAPTCHA"] == "Y"): ?>
		<? Form::printCaptcha($arResult["CAPTCHA_CODE"], ++$tabIndex) ?>
	<? endif ?>
	<? $frame->end() ?>
		<div class="registration-footer">
			<? if (!empty($arParams['URL_SHOP_RULES']) || !empty($arParams['URL_SHOP_PERSONAL_DATA'])): ?>
				<?
				$text = GetMessage('RZ_RULES_YA') . ' ';
				$text .=  GetMessage('RZ_ACCEPT') . " <a href='" . $pathToRules . "' target='_blank' class='classic-link'>" . GetMessage('RZ_CONCLUSION') . "</a>";
				if ($arParams['URL_SHOP_PERSONAL_DATA']) {
					if (!empty($arParams['URL_SHOP_RULES'])) {
						$text .= ' ' . GetMessage('RZ_RULES_I') . ' ';
					}
					$text .= GetMessage('RZ_RULES_OZNAKOMLEN') . "<a href='" . $arParams['URL_SHOP_PERSONAL_DATA'] . "' target='_blank' class='classic-link'>" . GetMessage('RZ_RULES_PERSONAL_DATA') . "</a>";
				}
				Form::printElement(
						array(
								'NAME' => 'PRIVACY_POLICY',
								'CHECKED' => $_POST['PRIVACY_POLICY'] == 'Y',
								'TEXT' => $text,
								'REQ' => true,
								'INDEX' => ++$tabIndex,
						), Form::TYPE_CHECKBOX
				);
				?>
			<? endif ?>
			<div class="btn-wrap">
				<input type="hidden" name="register_submit_button" value="Y"/>
				<button type="submit" class="btn btn-lg btn-primary"><?= GetMessage('RZ_REGISTER_SUBMIT') ?></button>
			</div>
		</div>
<? endif ?>