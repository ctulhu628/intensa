<?
/**
 * Bitrix vars
 * @var CMain $APPLICATION
 * @var CUser $USER
 * @var array $arParams
 * @var array $arResult
 * @var CBitrixComponentTemplate $this
 */
if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)	die();
//$arParams['URL_SHOP_RULES'] = trim(\Yenisite\Core\Tools::GetConstantUrl($arParams['URL_SHOP_RULES']));
$arParams['URL_SHOP_RULES'] = true;
$arParams['URL_SHOP_PERSONAL_DATA'] = trim(\Yenisite\Core\Tools::GetConstantUrl($arParams['URL_SHOP_PERSONAL_DATA']));