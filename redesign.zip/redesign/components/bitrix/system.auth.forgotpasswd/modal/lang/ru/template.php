<?
$MESS['AUTH_FORGOT_PASSWORD_1'] = "Если вы забыли пароль, введите свой E-Mail.<br />Контрольная строка для смены пароля, а также ваши регистрационные данные, будут отправлены на ваш E-Mail.";
$MESS["RZ_ELEKTRONNAYA_POCHTA_DLYA_SBROSA_PAROLYA"] = "Электронная почта для сброса пароля";
$MESS["RZ_SUBMIT_TEXT"] = "Отправить";
$MESS["RZ_BACK_TEXT"] = "Назад";
$MESS['RZ_LOGIN_FORGET_PASSWORD'] = 'Я забыл пароль';