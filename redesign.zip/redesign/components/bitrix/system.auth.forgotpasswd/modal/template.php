<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die(); ?><?
use Yenisite\Core\Ajax;
use Yenisite\Core\Tools;
use Yenisite\Furniture\Main;
use Yenisite\Furniture\Form;

if ($arParams['STATIC_FORM']){
	$idAuth = 'form_auth_static';
	$idForgot = 'form_reset_static';
} else{
	$idAuth = 'form_auth';
	$idForgot = 'form_reset';
}
\Bitrix\Main\Localization\Loc::loadMessages($_SERVER['DOCUMENT_ROOT'].SITE_TEMPLATE_PATH . '/lang/'.LANGUAGE_ID.'/header.php');
$pathToRules = COption::GetOptionString(\Yenisite\Furniture\Settings::getModuleId(),'path_tu_rules_privacy',SITE_DIR.'personal/rules/personal_data.php');
$isAjax = Tools::isAjax();
if (!$isAjax) {
	Ajax::saveParams($this, $arParams, 'modal');
}
$arResult['USER_LOGIN'] = $arResult['LAST_LOGIN'];
$arResult["RND"] = $arParams['RND'];
?>
<? if (!$isAjax): ?>
	<form name="system_reset_form" method="post" target="_top" <? Ajax::printAjaxDataAttr($this, 'modal') ?>
	action="<?= $arResult["AUTH_URL"] ?>"
	class="tab-pane fade clearfix ajax-form" id="<?= $idForgot ?>" data-validate="true" data-spin="submit">
<? endif ?>
<? if (!empty($APPLICATION->arAuthResult)) {
	Main::ShowMessage($APPLICATION->arAuthResult);
} ?>
    <input type="hidden" name="privacy_policy" value="N"/>
	<input type="hidden" name="AUTH_FORM" value="Y">
	<input type="hidden" name="TYPE" value="SEND_PWD">
	<a href="#"></a>
	<label class="form-group">
		<span class="label-text"><?= GetMessage("RZ_LOGIN_FORGET_PASSWORD") ?><span class="asterisk-required">*</span>:</span>
		<input type="email" name="USER_LOGIN" class="form-control" required placeholder="<?= GetMessage('RZ_ELEKTRONNAYA_POCHTA_DLYA_SBROSA_PAROLYA') ?>">
	</label>
<? if (!empty($arResult["CAPTCHA_CODE"])): ?>
    <label class="form-group col-sm-12 captcha-group">
        <span class="label-text"><?=GetMessage("RZ_VVEDITE_SLOVO_NA_KARTINKE")?><span class="asterisk-required">*</span>:</span>
        <input type="hidden" name="captcha_sid" value="<?= $arResult["CAPTCHA_CODE"] ?>"/>
        <input type="hidden" name="captcha_code" value="<?= $arResult["CAPTCHA_CODE"] ?>"/>
    </label>
    <label class="form-group col-sm-12 captcha-group">
					<span class="captcha"><img
                                src="/bitrix/tools/captcha.php?captcha_sid=<?= $arResult["CAPTCHA_CODE"] ?>"
                                alt="<?= GetMessage("RZ_KAPCHA") ?>" class="captcha-img"></span>
    </label>
    <label class="form-group col-sm-12 captcha-group">
        <input type="text" name="captcha_word" class="form-control" required>
    </label>
<? endif; ?>
    <?
    $text = GetMessage('RZ_RULES_YA') . ' ';
    $text .=  GetMessage('RZ_ACCEPT') . " <a href='" . $pathToRules . "' target='_blank' class='classic-link'>" . GetMessage('RZ_CONCLUSION') . "</a>";
    Form::printElement(
        array(
            'NAME' => 'PRIVACY_POLICY',
            'CHECKED' => $_POST['PRIVACY_POLICY'] == 'Y',
            'TEXT' => $text,
            'REQ' => true,
            'INDEX' => ++$tabIndex,
        ), Form::TYPE_CHECKBOX
    );
    ?>
	<button type="submit" name="send_account_info" value="Y" class="btn btn-lg btn-primary pull-right"><?= GetMessage("RZ_SUBMIT_TEXT") ?></button>
	<a href="#<?= $idAuth ?>" class="link link-std pull-left" data-toggle="tab"><?=GetMessage('RZ_BACK_TEXT')?></a>

<? if (!$isAjax): ?>
	</form>
<? endif ?>