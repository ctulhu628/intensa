<?
$MESS['RZ_SUBSCRIBE-CALL'] = 'Подпишись на рассылку и покупай выгоднее!';
$MESS['RZ_SUBSCRIBE'] = 'Подписаться';
$MESS['RZ_ENTER-YOUR-EMAIL'] = 'Укажите ваш email';