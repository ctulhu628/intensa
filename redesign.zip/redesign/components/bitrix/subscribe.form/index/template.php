<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */
/** @var CBitrixComponent $component */

$frame = $this->createFrame("index-subscribe-form", false)->begin();
?>
<form action="<?= $arResult["FORM_ACTION"] ?>" class="home-middle-subscribe form-group" id="index-subscribe-form">
	<? foreach ($arResult["RUBRICS"] as $itemID => $itemValue): ?>
		<input type="hidden" name="sf_RUB_ID[]" value="<?= $itemValue["ID"] ?>"/>
	<? endforeach; ?>
	<label for="home-middle-subscribe-input">
		<?= GetMessage('RZ_SUBSCRIBE-CALL') ?>
	</label>
	<div class="input-group">
		<input type="text" class="form-control" id="home-middle-subscribe-input" name="sf_EMAIL"
			   placeholder="<?= GetMessage('RZ_ENTER-YOUR-EMAIL') ?>" value="<?= $arResult["EMAIL"] ?>">
			<span class="input-group-btn">
				<button class="btn btn-primary" type="submit" name="OK">
					<span class="visible-xs">OK</span>
					<span class="hidden-xs"><?= GetMessage('RZ_SUBSCRIBE') ?></span>
				</button>
			</span>
	</div>
</form>
<? $frame->end() ?>

