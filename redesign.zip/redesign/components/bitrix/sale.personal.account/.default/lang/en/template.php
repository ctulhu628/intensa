<?
$MESS["SPA_BILL_AT"] = "Account details on";
?>