<?
$MESS["SPA_BILL_AT"] = "СОСТОЯНИЕ СЧЕТА НА";

