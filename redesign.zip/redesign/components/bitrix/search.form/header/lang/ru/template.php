<?
$MESS['RZ_FIND'] = 'Найти товары';
$MESS['RZ_SEARCH-PLACEHOLDER'] = 'Найти в каталоге...';