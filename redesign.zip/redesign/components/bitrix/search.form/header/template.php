<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */
/** @var CBitrixComponent $component */
$this->setFrameMode(true); ?>

<form method="get" action="<?= $arResult["FORM_ACTION"] ?>" class="input-group search-group">
	<? /* todo search category select
	<div class="input-group-btn catalog-choose-wrap hidden-xs">
		<div class="button-text">Search at category:</div>
		<select class="search-select cs-select cs-skin-elastic">
				<option value="value">value</option>
		</select>
	</div><!-- /btn-group -->
	 */ ?>
	<input type="text" name="q" class="form-control text-input" placeholder="<?= GetMessage('RZ_SEARCH-PLACEHOLDER') ?>">
	<i class="flaticon-cross93 hidden-xs" id="btn-clear"></i>
	<div class="input-group-btn search-btn-wrap">
		<button class="btn-main	btn-primary btn-search flaticon-magnifier13">
			<span class="btn-text"><?= GetMessage('RZ_FIND') ?></span>
		</button><!-- find-items -->
	</div>
</form>