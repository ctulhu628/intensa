'use strict';
$(function ($) {
	var $basket = $('#basket-small'),
		$body = $(document.body),
		$basketSummary = $('#small-cart-summary'),
		timer;
	if ($basket.length <= 0) return;

	$basket.on('change', '.quantity-input', function (e) {
		if (timer) {
			clearTimeout(timer);
		}
		timer = setTimeout(
			(function (self) {
				return function () {
					doAjax.call(self)
				}
			})(this), 300);
	});

	$basket.on('click', '.actions button', function (e) {
		e.preventDefault();
		var $this = $(this),
			id = $this.closest('.actions').data('id'),
			productID = $this.closest('.actions').data('product-id'),
			buttonDetail = $('.add-to-cart.sku') ? $('.add-to-cart.sku') : '';

		if(buttonDetail.length > 0) {
			buttonDetail.addClass('sku-change');
			var hasData = buttonDetail.data('id') == productID ? true : false;
			if (!hasData) {
				buttonDetail.addClass('sku-not-in-basket');
			} else {
				buttonDetail.removeClass('sku-not-in-basket');
			}
		}
		doAjax({'id': id, 'action': $this.data('action')});
	});

	$basket.on('click', '.action-link', function (e) {
		e.preventDefault();
		var $this = $(this),
			data = {};
		if ($this.hasClass('rubbish-clean')) {
			data.ACTION = 'FLUSH_CART';
		} else if ($this.hasClass('waitlist-clean')) {
			data.ACTION = 'FLUSH_WAITLIST';
		} else {
			return false;
		}
		$('.add-to-cart.sku').addClass('sku-change');
		$('.add-to-cart.sku').removeClass('sku-not-in-basket');
		$.ajax({
			'url': AJAX_DIR + 'actions.php',
			'dataType': 'JSON',
			'data': data,
			'success': function (msg) {
				if (msg.success) {
					$body.trigger('update_basket');
				} else {
					rz_showMessage(msg.message);
				}
			}
		});
		return false;
	});

	var doAjax = function (extData) {
		var $this = $(this),
			data;

		if (extData) {
			data = extData;
		} else {
			var id = $this.data('id'),
				q = $this.val();
			if (!q || !id)  return;
			data = {'id': id, 'q': q}
		}
		data.ajax = $basket.data('ajax');
		data.BasketRefresh = 'BasketRefresh';

		var $activeTab = $basket.find('.tab-pane.active');
		if ($activeTab.attr('id') == 'smallCartWaitlist') {
			data.isDelayTab = 1;
		}
		if ($basket.hasClass('toggled')) {
			$activeTab = $activeTab.find('.items');
		} else {
			$activeTab = $basket;
		}
		$activeTab.startAjax();
		$.ajax({
			'url': AJAX_DIR + 'cart.php',
			'data': data,
			'success': function (msg) {
				$activeTab.stopAjax();
				$basket.html(msg);
				var content = $basket.find('#small-cart-summary-content').html();
				if (!$(content).hasClass('empty')) {
					$basketSummary.show();
					$basketSummary.html(content);
				}else{
					$basketSummary.hide();
				}
				$basketSummary.closest('.content').removeClass('hidden');
				$basket.refreshForm();
				$.fn.updateBasketItems();
			}
		})

	};

	$body.on('update_basket', function () {
		doAjax({});
	});

	$.fn.updateBasketItems = function () {
		var $obj = $body,
			selector = '';
		if (this.length) {
			$obj = this;
		}
		if (rmz.basketItems && rmz.basketItems.length) {
			selector = '.incart-' + rmz.basketItems.join(', .incart-');
		}
		switchButtons($obj.find('.add-to-cart-small, .add-to-cart, .add-option-in-cart'), selector);
		if (typeof ID_ITEM_DETAIL != 'undefined'){
			var selectorDetail = '',
			 $existInBasket = $('[data-prop-element="'+ID_ITEM_DETAIL+'"]'),
				idsProps = [];
			$existInBasket.each(function(){
				idsProps.push($(this).data('id'));
			})

			if (idsProps && idsProps.length && $existInBasket.length) {
				selectorDetail = '.incart-'+ ID_ITEM_DETAIL + idsProps.join(', .incart-' + ID_ITEM_DETAIL);
				switchButtons($obj.find('.add-to-cart-small, .add-to-cart, .add-option-in-cart'), selectorDetail);
			}
		}

	};

	var switchButtons = function ($obj, filter) {
		$obj.each(function () {
			var $this = $(this);
			if ($this.hasClass('add-option-in-cart')){
				if ($this.is(filter)) {
					$this.find('input').attr('checked',true);
					return;
				} else{
					$this.find('input').attr('checked',false);
					return;
				}
			}
			if ($this.is(filter)) {
				if (!$this.hasClass('active')) {
					var $textOld = $this.attr('data-text');
					$this.attr('data-text',$this.attr('data-toggle-text'));
					$this.attr('data-toggle-text',$textOld);
					$this.attr('data-original-title',BX.message('IN_BASKET'));
					$this.removeClass('flaticon-ecommerce7').addClass('flaticon-checked21 active');
					if ($this.find('.svg-wrap').length > 0){
						$this.find('.svg-wrap').remove();
					}else{
						$this.find('svg').remove();
					}

				}
			} else {
				if ($this.hasClass('active') && !$this.hasClass('sku') || ($this.hasClass('sku-change') && !$this.hasClass('sku-not-in-basket'))) {
					if ($this.hasClass('sku-change')){
						$this.removeClass('sku-change');
						$this.addClass('sku-not-in-basket');
					}
					if ($this.is('button')) {
						$this.attr('data-original-title',BX.message('ADD_BASKET'));
						switchTextButtons ($this);
						if ($this.find('span').length) {
							$this.removeClass('flaticon-checked21 active').find('span').before('<div class="svg-wrap"><svg xmlns="http://www.w3.org/2000/svg"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#cart-add"></use></svg></div>');
						} else {
							$this.removeClass('flaticon-checked21 active').append('<div class="svg-wrap"><svg xmlns="http://www.w3.org/2000/svg"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#cart-add"></use></svg></div>');
						}
					} else{
						$this.removeClass('flaticon-checked21 active').append('<svg xmlns="http://www.w3.org/2000/svg"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#cart-add"></use></svg>');
						$this.attr('data-original-title',BX.message('ADD_BASKET'));
					}
				} else if($this.hasClass('sku-change') && $this.hasClass('sku-not-in-basket')){
					$this.addClass('sku-not-in-basket');
				}
			}
		});
	};

	$.fn.updateBasketItems();
});