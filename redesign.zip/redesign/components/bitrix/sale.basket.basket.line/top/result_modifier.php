<?
use Yenisite\Furniture\Main;

$siteCurrency = CSaleLang::GetLangCurrency(SITE_ID);
$arResult['TOTAL_PRICE_DELAY'] = 0;
$arParams['USE_ONECLICK'] = $arParams['USE_ONECLICK'] ? : 'Y';
$arItems = array();
foreach ($arResult['CATEGORIES'] as $catID => &$arCategory) {
	foreach ($arCategory as $itemID => &$arItem) {
		$arItems[$arItem['PRODUCT_ID']][] = array('ID' => $itemID, 'CATEGORY' => $catID);
		$basketIds[$arItem['ID']] = &$arResult["CATEGORIES"][$catID][$itemID];
		if ($catID == 'DELAY') {
			$price = $arItem['PRICE'];
			if ($siteCurrency != $arItem['CURRENCY']) {
				$price = CCurrencyRates::ConvertCurrency($arItem['PRICE'], $arItem['CURRENCY'], $siteCurrency);
			}
			$arItem['SUM'] = $price * $arItem['QUANTITY'];
			$arResult['TOTAL_PRICE_DELAY'] += $arItem['SUM'];
			$arItem['SUM'] = CCurrencyLang::CurrencyFormat($arItem['SUM'], $siteCurrency);
		}
	}
	unset($arItem);
}
unset($arCategory);


if ($arResult['TOTAL_PRICE_DELAY'] > 0) {
	$arResult['TOTAL_PRICE_DELAY'] = CCurrencyLang::CurrencyFormat($arResult['TOTAL_PRICE_DELAY'], $siteCurrency);
}

if (!empty($arItems)) {
	/** @noinspection PhpDynamicAsStaticMethodCallInspection */
	$rs = CIBlockElement::GetList(array(), array(
		'ID' => array_keys($arItems),
	), false, false, array('ID', 'PROPERTY_MORE_PHOTO', 'DETAIL_PICTURE', 'PREVIEW_PICTURE'));

	while ($ar = $rs->Fetch()) {
		foreach ($ar as $propName => $propVal) {
			if ($propName == 'PROPERTY_MORE_PHOTO_VALUE') {
				$ar['PROPERTIES'] = array(
					'MORE_PHOTO' => array(
						'VALUE' => array($propVal),
					),
				);
				break;
			}
		}
		$imgSrc = Main::GetResizedImg($ar,
			array('WIDTH' => 50, 'HEIGHT' => 59, 'SET_ID' => $arParams['RESIZER_BASKET_ICON']));
		foreach ($arItems[$ar['ID']] as $arCat) {
			$arResult['CATEGORIES'][$arCat['CATEGORY']][$arCat['ID']]['PICTURE'] = $imgSrc;
		}
	}

}

$propsIterator = CSaleBasket::GetPropsList(
	array('BASKET_ID' => 'ASC', 'SORT' => 'ASC', 'ID' => 'ASC'),
	array('BASKET_ID' => array_keys($basketIds))
);
while ($property = $propsIterator->GetNext())
{
	$property['CODE'] = (string)$property['CODE'];
	if ($property['CODE'] == 'CATALOG.XML_ID' || $property['CODE'] == 'PRODUCT.XML_ID')
		continue;
	if (!isset($basketIds[$property['BASKET_ID']]))
		continue;
	$basketIds[$property['BASKET_ID']]['PROPS'][] = $property;
}
unset($property, $propsIterator, $basketIds);