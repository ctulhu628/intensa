<?
/**
 * @var array $arItems
 * @var array $arProducts
 */
use Yenisite\Furniture\Form;

?>
<div class="t-cart">
	<div class="t-cart-body">
		<? if (empty($arItems)): // for w3c validator?>
			<div></div>
		<? else: ?>
			<? foreach ($arItems as $arItem): ?>
				<? $arProducts[$arItem['PRODUCT_ID']] = 0 ?>
				<div class="t-cart-line small-cart-item">
					<div class="img-wrap">
						<a href="<?= $arItem['DETAIL_PAGE_URL'] ?>">
							<img src="<?= $arItem['PICTURE'] ?>" alt="<?= $arItem['NAME'] ?>">
						</a>
					</div>
					<div class="t-cart-item item-availability">
						<div class="t-cart-section t-cart-item-title">
							<a href="<?= $arItem['DETAIL_PAGE_URL'] ?>" class="classic-link"><?= $arItem['NAME'] ?></a>
							<? /* todo: article in small-cart
							<div class="art">article</div>
							*/ ?>
							<? /* todo: SKU in small-cart
							<? include "_/html/color-select-form.html"; ?>
							<? include "_/html/select-default.html"; ?>
							*/ ?>
						</div>
						<?if(!empty($arItem['PROPS'])):?>
							<div class="t-cart-section">
								<dl class="selected-properties">
									<?foreach($arItem['PROPS'] as $arProp):?>
										<?if(empty($arProp['VALUE'])) continue?>
										<dt><span <?if(!empty($arProp['CODE'])):?>data-prop-element="<?=$arProp['CODE']?>" data-id="<?= $arItem['PRODUCT_ID'] ?>"<?endif?> class="properties-name"><?=$arProp['NAME']?>:</span></dt>
										<dd><?=$arProp['VALUE']?></dd>
									<?endforeach?>
								</dl>
							</div>
						<?endif?>
					</div>
					<div class="t-cart-item-footer">
						<div class="text-center actions" data-id="<?= $arItem['ID'] ?>" data-product-id="<?=$arItem['PRODUCT_ID'] ?>">
							<? if ($isWaitlist): ?>
								<button data-action="add" href="#" class="to-cartlist tooltip-simple flaticon-back15" title="<?= GetMessage('RZ_WAITLIST-TO-BASKET') ?>"
										data-toggle="tooltip" data-placement="top" data-trigger="hover"></button>
							<? else: ?>
								<button data-action="delay" href="#" class="to-waitlist tooltip-simple flaticon-back15" title="<?= GetMessage('RZ_BASKET-TO-WAITLIST') ?>"
										data-toggle="tooltip" data-placement="top" data-trigger="hover"></button>
							<? endif ?>
							<button data-action="delete" href="#" class="delete flaticon-delete96 tooltip-simple" title="<?= GetMessage('RZ_BASKET-DELETE') ?>"
									data-toggle="tooltip" data-placement="top" data-trigger="hover"></button>
						</div>
						<div class="t-cart-item">
							<div class="availability">
								<? if ($arItem['CAN_BUY'] == 'Y'): ?>
									<? Form::printElement(array(
										'CLASS' => 'small',
										'VALUE' => $arItem['QUANTITY'],
										'ATTR' => 'data-id="' . $arItem['ID'] . '"',
									), Form::TYPE_QUANTITY) ?>
								<? else: ?>
									<div class="amount">--</div>
								<? endif ?>
							</div>
							<div class="price-wrap">
								<div class="price"><?= $arItem['SUM'] ?></div>
								<? /* todo: small-basket old price support
							<span class="old-price"><?= $arItem['OLD_SUM'] ?></span>
							*/ ?>
							</div>
						</div>
					</div>
				</div>
			<? endforeach ?>
		<? endif ?>
	</div>
</div>