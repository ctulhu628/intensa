<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
use Yenisite\Core\Ajax;
use Yenisite\Furniture\Main;

/**
 * @var CBitrixComponentTemplate $this
 */
$totalCount = count($arResult['CATEGORIES']['READY']);
$delayCount = count($arResult['CATEGORIES']['DELAY']);
$bShowDelay = $arParams['SHOW_DELAY'] == 'Y' && $delayCount > 0;
$bDelayTab = false;
if($bShowDelay && !empty($_REQUEST['isDelayTab'])) {
	$bDelayTab = true;
}
$basketID = 'basket-small';
$isAjax = Ajax::isAjax();
Ajax::saveParams($this, $arParams, $basketID);
$arProducts = array();
?>
<? if ($isAjax): ?>
	<div id="small-cart-summary-content" class="hidden">
		<? if ($totalCount): ?>
			<span class="cart-ordering-count"><?= $totalCount ?></span>
			<span class="cart-ordering-line"> <?= GetMessage('RZ_UNITS_FOR') ?> <?= $arResult['TOTAL_PRICE'] ?></span>
		<?elseif (\Yenisite\Furniture\Mobile::isMobile() && $totalCount <= 0):?>
			<span class="cart-ordering-line empty"></span>
		<? else : ?>
			<span class="cart-ordering-line"><?= GetMessage('RZ_BASKET_EMPTY') ?></span>
		<? endif ?>
	</div>
<? endif ?>
<? if (!$isAjax): ?>
	<? $frame = $this->createFrame()->begin(\Yenisite\Furniture\Main::insertCompositLoader()); ?>
        <a class="header-basket-link" href="<?= $arParams['PATH_TO_BASKET'] ?>">
        	<? if ($totalCount): ?>
        		<i><?= $totalCount ?></i>
				<span class="cart-ordering-line"><?= $arResult['TOTAL_PRICE'] ?></span>
			<? else : ?>
        		<i>0</i>
				<span class="cart-ordering-line">Пусто<?/*= GetMessage('RZ_BASKET_EMPTY') */?></span>
			<? endif ?>
        </a>
	<?$frame->end();?>
<? endif ?>
<? if (!$isAjax): ?>
	<? $this->SetViewTarget('modals') ?>
	<div class="modal fade" id="modal-small-cart">
		<div class="modal-dialog modal-small-cart">
			<div class="modal-content" id="<?= $basketID ?>" <? Ajax::printAjaxDataAttr($this, $basketID) ?>>
			<? $frame = $this->createFrame($basketID, false)->begin(Main::insertCompositLoader()) ?>
<? endif ?>
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span class="svg-wrap close"><svg>
		<use xlink:href="#close"></use>
	</svg></span></button>
					<div class="header-text cart-header flaticon-shopping232">
						<div class="cart-title"><?= GetMessage('RZ_BASKET') ?></div>
						<span class="items-in-cart"><?= GetMessage('RZ_BASKET-ITEMS-INSIDE') ?>:<strong><?= $totalCount ?></strong></span>
					</div><!-- cart-header -->
					<? if ($bShowDelay): ?>
						<div class="header-text waitlist-header flaticon-back15">
							<div class="cart-title"><?= GetMessage('RZ_WAITLIST') ?></div>
							<span class="items-in-cart"><?= GetMessage('RZ_IN_LIST') ?>:<strong><?= $delayCount ?></strong></span>
						</div><!-- cart-header -->
						<ul class="nav nav-pills" role="tablist">
							<li role="presentation"<? if (!$bDelayTab): ?> class="active"<? endif ?>>
								<a href="#smallCartItemList" class="small-cart__waitlist-toggle to-small-cart flaticon-grocery11" role="tab" data-toggle="pill">
									<span class="text"><?= GetMessage('RZ_BACK_TO_BASKET') ?></span>
								</a>
							</li>
							<li role="presentation"<? if ($bDelayTab): ?> class="active"<? endif ?>>
								<a href="#smallCartWaitlist" class="small-cart__waitlist-toggle to-waitlist flaticon-back15" role="tab" data-toggle="pill">
									<span class="text"><?= GetMessage('RZ_WAITLIST-ITEMS-SHORT') ?></span>
									<span class="items-in-waitlist"><?= $delayCount ?></span>
								</a>
							</li>
						</ul>
					<? endif ?>
				</div><!-- modal-header -->
				<div class="modal-body wrapper wrapper__small-cart">
					<div class="scroller">
						<div class="tab-content">
							<div class="small-cart__item-list tab-pane fade<? if (!$bDelayTab): ?> active in<? endif ?>" id="smallCartItemList">
								<?
								$arItems = $arResult['CATEGORIES']['READY'];
								$isWaitlist = false;
								require 'items.php';
								?>
							</div><!-- .tab-pane -->
							<? if ($bShowDelay) : ?>
								<div class="small-cart__waitlist tab-pane fade<? if ($bDelayTab): ?> active in<? endif ?>" id="smallCartWaitlist">
									<?
									$arItems = $arResult['CATEGORIES']['DELAY'];
									$isWaitlist = true;
									require 'items.php';
									?>
								</div><!-- .tab-pane -->
							<? endif ?>
							<script type="text/javascript" data-skip-moving="true">
								if (typeof rmz == 'undefined') {
									rmz = {};
								}
								rmz.basketItems = <?= CUtil::PhpToJSObject(array_keys($arProducts)) ?>;
							</script>
						</div><!-- tab-content -->
						<div class="scroller__track small-cart-track">
	    			        <div class="scroller__bar"></div>
	    			    </div>
					</div><!-- scroller -->
				</div><!-- modal-body -->
				<div class="modal-footer">
					<div class="summary">
						<div>
							<?= GetMessage("RZ_ITOGO") ?>: <span class="total-cost"><?= $arResult['TOTAL_PRICE'] ?></span>
						</div>
						<? /* todo: small-cart weight
						<div>
							<?= GetMessage("RZ_BASKET-HEADER-WEIGHT-TOTAL") ?>: <span class="total-weight">185</span>
						</div>
 						*/?>
					</div><!-- summary -->
					<div class="btns-buy-action">
						<?if(Main::isOneClick() && $arParams['SHOW_ONE_CLICK']):?>
							<a data-basket="Y"  href="#" class="buy-one-click btn-main btn-secondary" data-toggle="modal" data-target="#modal-quick-order">
								<div class="tooltip-simple" data-toggle="tooltip" data-placement="top" title="<?=GetMessage('RZ_BUY_IN_ONE_CLICK')?>"></div>
								<svg xmlns="http://www.w3.org/2000/svg">
									<use xlink:href="#buy-one-click"></use>
								</svg>
							</a>
						<?endif?>
						<a href="<?= $arParams['PATH_TO_BASKET'] ?>" class="btn-main btn-primary btn-checkout"><?= GetMessage("RZ_OFORMIT_ZAKAZ") ?></a>
					</div>
					<?if($totalCount > 0):?>
						<div class="clean">
							<a href="#" class="action-link has-icon flaticon-delete96 rubbish-clean"><span class="link-text"><?= GetMessage('RZ_DELETE_CART') ?></span></a>
							<a href="#" class="action-link has-icon flaticon-delete96 waitlist-clean"><span class="link-text"><?= GetMessage('RZ_DELETE_WAITLIST') ?></span></a>
						</div>
					<?endif?>
	    		</div><!-- modal-footer -->
				<? if ($isAjax && !empty($_REQUEST['isDelayTab']) && $delayCount <= 0): ?>
					<script type="text/javascript">
						$('#modal-small-cart').find('.modal-small-cart').removeClass('waitlist');
					</script>
				<? endif ?>
<? if (!$isAjax): ?>
	<? $frame->end() ?>
			</div><!-- .modal-content -->
		</div><!-- .modal-dialog -->
	</div><!-- #modal-small-cart -->
	<? $this->EndViewTarget() ?>
<? endif ?>