<?
/**
 * @var CBitrixComponentTemplate $this
 * @var array $arResult
 * @var array $arParams
 */
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
$firstEl = '';
foreach($arResult['STORES'] as $key => $arStore) {
	if ($arStore['REAL_AMOUNT'] >= $arParams['MIN_AMOUNT']) {
		$firstEl = $arResult['STORES'][$key];
		unset($arResult['STORES'][$key]);
		break;
	}
}
if (empty($firstEl)){
	$oneStep = ceil($arParams['MIN_AMOUNT'] / 3);

	foreach($arResult['STORES'] as $key => $arStore) {
		if (ceil($arStore['REAL_AMOUNT'] / $oneStep) >= 2) {
			$firstEl = $arResult['STORES'][$key];
			unset($arResult['STORES'][$key]);
			break;
		}
	}
	if (empty($firstEl)) {
		foreach($arResult['STORES'] as $key => $arStore) {
			if (ceil($arStore['REAL_AMOUNT'] / $oneStep) > 0) {
				$firstEl = $arResult['STORES'][$key];
				unset($arResult['STORES'][$key]);
				break;
			}
		}
	}
}
if (!empty($firstEl)) {
	$saveFirstEl = array_shift($arResult['STORES']);
	array_unshift($arResult['STORES'],$firstEl,$saveFirstEl);
}

$arParams['SECTION_PAGE'] = !empty($arParams['SECTION_PAGE']) ?  : false;
$arParams['TABLE_SECTION'] = !empty($arParams['TABLE_SECTION']) ?  : false;
