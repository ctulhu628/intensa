<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */
/** @var CBitrixComponent $component */
use \Yenisite\Core\Ajax;
$this->setFrameMode(true);
if (empty($arResult["STORES"])) return;
$bShowNumbers = $arParams['SHOW_NUMBERS'] == 'Y';
$oneStep = ceil($arParams['MIN_AMOUNT'] / 3);
$ajID = 'store-amount-item';
\Yenisite\Core\Ajax::saveParams($this, $arParams,$ajID,SITE_ID);
$isAjax = \Yenisite\Core\Ajax::isAjax();
$count = 0;
?>
<?if (!$isAjax || $arParams['SECTION_PAGE']):?>
<div <?Ajax::printAjaxDataAttr($this, $ajID) ?> id="store-amount_<?=$arParams['PARENT_ID']?>" class="availability">
	<?if (!$arParams['TABLE_SECTION']):?><div class="availability-title"><?=GetMessage('RZ_NALICHIE')?>:</div><?endif?>
<?endif?>
	<? foreach ($arResult['STORES'] as &$arStore): ?>
		<?
		if($count >= $arParams['STORES_COUNT']) break;
		$approx = 0;
		$class = 'few';
		$title = $arResult['JS']['MESSAGES']['ABSENT'];

		if ($arStore['REAL_AMOUNT'] >= $arParams['MIN_AMOUNT']) {
			$class = 'lots';
			$title = $arResult['JS']['MESSAGES']['LOT_OF_GOOD'];
		} else {
			$approx = ceil($arStore['REAL_AMOUNT'] / $oneStep);

			if ($approx >= 2) {
				$title = $arResult['JS']['MESSAGES']['NOT_MUCH_GOOD'];
				$class = 'plenty';
			} elseif ($approx > 0) {
				$title = $arResult['JS']['MESSAGES']['NOT_MUCH_GOOD'];
				$class = 'few';
			} else{
				$title = GetMessage('RZ_FURNITURE_EMPTY');
				$class = 'empty';
			}
		}

		if (empty($title)){
			if ($arStore['REAL_AMOUNT'] >= $arParams['MIN_AMOUNT']) {
				$title = GetMessage('RZ_FURNITURE_LOT');
			} else {
				$approx = ceil($arStore['REAL_AMOUNT'] / $oneStep);

				if ($approx <= 0) {
					$title = GetMessage('RZ_FURNITURE_EMPTY');
				} elseif ($approx > 0 && $approx < 2) {
					$title = GetMessage('RZ_FURNITURE_FEW');
				} elseif ($approx >= 2) {
					$title = GetMessage('RZ_FURNITURE_LOT');
				}
			}
		}
		$messItems = \Yenisite\Furniture\Main::BITGetDeclNum($arStore['REAL_AMOUNT']);
		?>
		<div class="availability-item">
			<span class="availability-text"><?= $arStore['TITLE'] ?>:<?// <span class="stock">��������, 49�</span>?></span>
			<div class="on-stock">
				<div class="on-stock-stripes">
					<span class="on-stock-stripes <?= $class ?>"></span>
				</div>
		<?if (!$arParams['TABLE_SECTION']):?><span class="on-stock-text"><?= $bShowNumbers ? "(".$arStore['REAL_AMOUNT'].' '.$messItems.")" : '('.$title.')' ?></span><?endif?>
			</div>
		</div>
		<?$count++;?>
	<? endforeach;
	unset($arStore) ?>
	<?if(!empty($arResult['STORES']) && $arParams['STORES_COUNT'] < count($arResult['STORES'])):?>
		<div class="item-link-wrap">
		<a href="#" class="choose-another action-link action-popover"><?=GetMessage('RZ_ALL_STORE')?></a>
		<div class="popover-content hidden">
			<div class="another-store">

				<button type='button' class='close-popover' aria-label='Close' data-dialog-close><span aria-hidden='true'>&times;</span></button>
				<div class="title"><?=GetMessage('RZ_STORES')?>:</div>
				<? foreach ($arResult['STORES'] as &$arStore): ?>
					<?
					$approx = 0;
					$class = 'few';
					$title = $arResult['JS']['MESSAGES']['ABSENT'];

					if ($arStore['REAL_AMOUNT'] >= $arParams['MIN_AMOUNT']) {
						$class = 'lots';
						$title = $arResult['JS']['MESSAGES']['LOT_OF_GOOD'];
					} else {
						$approx = ceil($arStore['REAL_AMOUNT'] / $oneStep);

						if ($approx >= 2) {
							$title = $arResult['JS']['MESSAGES']['NOT_MUCH_GOOD'];
							$class = 'plenty';
						} elseif ($approx > 0) {
							$title = $arResult['JS']['MESSAGES']['NOT_MUCH_GOOD'];
							$class = 'few';
						}
						else{
							$title = GetMessage('RZ_FURNITURE_EMPTY');
							$class = 'empty';
						}
					}

					if (empty($title)){
						if ($arStore['REAL_AMOUNT'] >= $arParams['MIN_AMOUNT']) {
							$title = GetMessage('RZ_FURNITURE_LOT');
						} else {
							$approx = ceil($arStore['REAL_AMOUNT'] / $oneStep);

							if ($approx <= 0) {
								$title = GetMessage('RZ_FURNITURE_EMPTY');
							} elseif ($approx > 0 && $approx < 2) {
								$title = GetMessage('RZ_FURNITURE_FEW');
							} elseif ($approx >= 2) {
								$title = GetMessage('RZ_FURNITURE_LOT');
							}
						}
					}
					$messItems = \Yenisite\Furniture\Main::BITGetDeclNum($arStore['REAL_AMOUNT']);
					?>
					<div class="availability-item">
						<span class="availability-text"><?= $arStore['TITLE'] ?>:<?// <span class="stock">��������, 49�</span>?></span>
						<div class="on-stock">
							<div class="on-stock-stripes">
								<span class="on-stock-stripes <?= $class ?>"></span>
							</div>
					<?if (!$arParams['TABLE_SECTION']):?><span class="on-stock-text"><?= $bShowNumbers ? "(".$arStore['REAL_AMOUNT'].' '.$messItems.")" : '('.$title.')' ?></span><?endif?>
						</div>
					</div>
				<? endforeach;
				unset($arStore) ?>
			</div>
		</div>
	</div>
	<?endif?>
<?if (!$isAjax || $arParams['SECTION_PAGE']):?>
</div>
<?endif?>
