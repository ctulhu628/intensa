<?
$MESS["RZ_NALICHIE"] = "Наличие";
$MESS["RZ_FURNITURE_LOT"] = "достаточно";
$MESS["RZ_FURNITURE_FEW"] = "мало";
$MESS["RZ_FURNITURE_EMPTY"] = "отсутствует";
$MESS["RZ_ALL_STORE"] = "Все склады";
$MESS["RZ_STORES"] = "Склады";
