<?
/**
 * @var array $arResult
 * @var array $arParams
 * @var array $arItem
 * @var CBitrixComponentTemplate $this
 */
use Yenisite\Furniture\Form;
use Yenisite\Furniture\Main;
use Yenisite\Core\Tools;

$bHasSKU = !empty($arItem['OFFERS']);
$rnd = $this->randString();
?>
<div class="catalog-item <?= $arItem['CAN_BUY'] ? 'in-stock' : 'out-of-stock' ?>">
	<div class="img-wrap">
		<a href="<?= $arItem['DETAIL_PAGE_URL'] ?>"><img src="<?= $arItem['PHOTO'] ?>" alt="<?= $arItem['NAME'] ?>" class="big-img"></a>

		<? $APPLICATION->IncludeComponent("yenisite:stickers", "", array(
				"ELEMENT" => $arItem,
				"STICKER_NEW" => $arParams['STICKER_NEW'],
				"STICKER_HIT" => $arParams['STICKER_HIT'],
				"TAB_PROPERTY_NEW" => $arParams['TAB_PROPERTY_NEW'],
				"TAB_PROPERTY_HIT" => $arParams['TAB_PROPERTY_HIT'],
				"TAB_PROPERTY_SALE" => $arParams['TAB_PROPERTY_SALE'],
				"TAB_PROPERTY_BESTSELLER" => $arParams['TAB_PROPERTY_BESTSELLER'],
				"MAIN_SP_ON_AUTO_NEW" => $arParams['MAIN_SP_ON_AUTO_NEW'],
				"SHOW_DISCOUNT_PERCENT" => $arParams['SHOW_DISCOUNT_PERCENT'],
		),
				$component, array("HIDE_ICONS" => "Y")
		); ?>
		<? if ($arItem['ARTICLE']): ?>
			<span id="<?=$arIDs['ARTICUL']?>" class="art"><?= $arItem['ARTICLE_NAME'] ?>: <span class="value-art"><?= $arItem['ARTICLE'] ?></span></span>
		<? endif ?>
		<? if (!empty($arItem['img-btn'])): ?>
			<div class="catalog-item-img-btn-wrap">
				<button class="catalog-item-img-btn <?= $arItem['img-btn']['classes'] ?>"
						data-text="<?= $arItem['img-btn']['text'] ?>"></button>
			</div>

		<? endif ?>

		<? if (!empty($arItem['GALLERY']) && count($arItem['GALLERY']) > 1): ?>
			<div class="catalog-item-thumbs-wrap">
				<div class="catalog-item-thumbs">
					<? foreach ($arItem['GALLERY'] as $key => $arPhoto): ?>
						<div class="catalog-item-thumb <?= ($key == 0) ? 'active' : '' ?>" data-big="<?= $arPhoto['SRC'] ?>">
							<img src="<?= $arPhoto['THUMB'] ?>" alt="<?= $arItem['NAME'] ?>">
						</div>
					<? endforeach ?>
				</div>
			</div>
		<? endif ?>

	</div><!-- .img-wrap -->
	<div class="info-wrap">
		<div class="name-wrap">
			<div class="name-inner-wrap">
				<div class="caret-wrap collapsed">
					<span class="caret"></span>
				</div>
				<a href="<?= $arItem['DETAIL_PAGE_URL'] ?>" class="link link-std"><?= $arItem['NAME'] ?></a>
			</div>
		</div>
		<div class="price-wrap">
			<span class="price"><?= $arItem['MIN_PRICE']['PRINT_DISCOUNT_VALUE'] ?></span>
			<? if (!empty($arItem['CATALOG_MEASURE_NAME'])): ?>
				/ <span class="price-unit"><?= $arItem['CATALOG_MEASURE_NAME'] ?></span>
			<? endif ?>
		</div>
		<div class="actions-wrap">
			<?
			Form::printElement(array('STEP' => $arItem['CATALOG_MEASURE_RATIO'], 'SIZE' => 'sm', 'ATTR' => 'id="' . $rnd . '-q_' . $arItem['ID'] . '"'), Form::TYPE_QUANTITY);
			?>
			<div class="action-btns">
				<? if ($arParams['USE_FAVORITE']): ?>
					<span class="action-btn favorite-btn icon-only flaticon-heart295 favorite-<?= $arItem['ID'] ?>"
						  title="<?= GetMessage('RZ_FAVORITE_ADD') ?>" data-toggle-title="<?= GetMessage('RZ_FAVORITE_DELETE') ?>"
						  data-tooltip data-id="<?= $arItem['ID'] ?>"></span>
				<? endif ?>
				<span class="action-btn compare-btn icon-only flaticon-rising compare-<?= $arItem['ID'] ?>" data-id="<?= $arItem['ID'] ?>"
					  title="<?= GetMessage('RZ_COMPARE_ADD') ?>" data-toggle-title="<?= GetMessage('RZ_COMPARE_DELETE') ?>"
					  data-tooltip></span>
			</div>
			<div class="availability"
				 data-when-in-stock="<?= GetMessage('RZ_WHEN-IN-STOCK') ?>"
				 data-when-out-of-stock="<?= GetMessage('RZ_OUT-OF-STOCK') ?>">
			</div>
			<? if ($bHasSKU): ?>
				<a href="<?= $arItem['DETAIL_PAGE_URL'] ?>" class="btn btn-lg btn-primary btn-add-to-cart incart-<?= $arItem['ID'] ?> no-icon"
				   data-text="<?= GetMessage('RZ_CHOOSE_ITEM') ?>"></a>
			<? else : ?>
				<a href="<?= $arParams['BASKET_URL'] ?>" rel="nofollow"
				   class="btn btn-lg btn-primary btn-add-to-cart flaticon-shopping66<?= $arItem['CAN_BUY'] ? '' : ' disabled' ?> incart-<?= $arItem['ID'] ?>"
				   data-text="<?= GetMessage('RZ_ADD-TO-BASKET') ?>" data-id="<?= $arItem['ID'] ?>"
				   data-props='<?=$arItem['CART_PROP']?>' data-q="#<?= $rnd, '-q_', $arItem['ID'] ?>"
				   data-toggle-text="<?= GetMessage('RZ_ALREADY-IN-BASKET') ?>"
				   data-when-out-of-stock="<?= GetMessage('RZ_NOT_ALLOWED') ?>"></a>
			<? endif ?>
			<?if($arItem['CAN_BUY'] && Main::isOneClick() && !$bHasSKU && $arParams['USE_ONECLICK']):?>
				<button data-target="#modal-quickbuy" data-props="<?= \Yenisite\Core\Tools::GetEncodedArParams($arParams['OFFER_TREE_PROPS']) ?>"  data-id="<?= $arItem['ID'] ?>" data-toggle="modal" class="btn btn-primary buy-one-click"><?=GetMessage('RZ_BU_IN_ONECLICK')?></button>
			<?endif?>
		</div>
	</div><!-- .info-wrap -->
</div>