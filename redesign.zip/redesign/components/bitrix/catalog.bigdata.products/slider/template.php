<? use Bitrix\Main\Localization\Loc;

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
/** @var CBitrixComponentTemplate $this */
/** @var array $arParams */
/** @var array $arResult */
/** @global CDatabase $DB */

Loc::loadLanguageFile($_SERVER['DOCUMENT_ROOT'] . SITE_TEMPLATE_PATH . '/catalog.php');

$injectId = 'bigdata_products_' . rand();

// ajax send request
if (isset($arResult['REQUEST_ITEMS'])) {
	CJSCore::Init(array('ajax'));

	// component parameters
	$signer = new \Bitrix\Main\Security\Sign\Signer;
	$signedParameters = $signer->sign(
			base64_encode(serialize($arResult['_ORIGINAL_PARAMS'])),
			'bx.bd.products.recommendation'
	);
	$signedTemplate = $signer->sign($arResult['RCM_TEMPLATE'], 'bx.bd.products.recommendation');
	?>
	<div id="<?= $injectId ?>_wrapper">
		<div class="catalog-blocks-carousel carousel-frame" id="<?= $injectId ?>"></div>
	</div>

	<script type="application/javascript">
		BX.ready(function () {

			var params = <?=CUtil::PhpToJSObject($arResult['RCM_PARAMS'])?>;
			var url = 'https://analytics.bitrix.info/crecoms/v1_0/recoms.php';
			var data = BX.ajax.prepareData(params);

			if (data) {
				url += (url.indexOf('?') !== -1 ? "&" : "?") + data;
				data = '';
			}

			BX.cookie_prefix = '<?=CUtil::JSEscape(COption::GetOptionString("main", "cookie_name", "BITRIX_SM"))?>';
			BX.current_server_time = '<?=time()?>';
			var doAjax = function (response) {
				var data = {
					'parameters': '<?=CUtil::JSEscape($signedParameters)?>',
					'template': '<?=CUtil::JSEscape($signedTemplate)?>',
					'rcm': 'yes'
				};
				var $target = $('#<?= $injectId ?>');
				if ($target.length > 0) {
					$.ajax({
						url: AJAX_DIR + 'bigdata.php?' + BX.ajax.prepareData({'AJAX_ITEMS': response.items, 'RID': response.id}),
						type: 'POST',
						data: data,
						success: function (msg) {
							$target.html(msg);
							$target.refreshForm();
						}
					});
				}
			};
			BX.ajax({
				'method': 'GET',
				'dataType': 'json',
				'url': url,
				'timeout': 3,
				'onsuccess': BX.delegate(doAjax),
				'onfailure': BX.delegate(doAjax),
			});
		});
	</script>
	<?
	return;
}

if (empty($arResult['ITEMS'])) {
	return;
}
?>
<? if ($arParams['TITLE']): ?><h2><?= $arParams['TITLE'] ?></h2><? endif ?>
<div id="<?= $injectId ?>_items" class="slidee">
	<input type="hidden" name="bigdata_recommendation_id" value="<?= htmlspecialcharsbx($arResult['RID']) ?>">
	<? foreach ($arResult['ITEMS'] as &$arItem) {
		include 'item.php';
	}
	unset($arItem);
	?>
</div>
<? /*
<div class="carousel-controls">
	<button type="button" class="carousel-arrow prev flaticon-left17 btn-primary"></button>
	<span class="dots"></span>
	<span class="text-numbers">
		<span class="current">1</span> / <span class="total"><?= count($arResult['ITEMS']) ?></span>
	</span>
	<button type="button" class="carousel-arrow next flaticon-arrow73 btn-primary"></button>
</div>
*/ ?>
