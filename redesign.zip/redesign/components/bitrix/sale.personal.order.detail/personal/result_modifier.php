<? use Yenisite\Core\Resize;
use Yenisite\Furniture\Main;

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
$resizerImage = array('WIDTH' => 140, 'HEIGHT' => 140, 'SET_ID' => $arParams['RESIZER_ITEM']);
$cp = $this->__component;
if (is_object($cp)) {
	CModule::IncludeModule('iblock');

	if (empty($arResult['ERRORS']['FATAL'])) {

		$hasDiscount = false;
		$hasProps = false;
		$productSum = 0;
		$basketRefs = array();

		$noPict = array(
			'SRC' => $noPhotoSRC,
		);

		if (is_readable($nPictFile = $_SERVER['DOCUMENT_ROOT'] . $noPict['SRC'])) {
			$noPictSize = getimagesize($nPictFile);
			$noPict['WIDTH'] = $noPictSize[0];
			$noPict['HEIGHT'] = $noPictSize[1];
		}
		$arProducts = array();
		foreach ($arResult["BASKET"] as $k => &$prod) {
			$arProducts[$prod['PRODUCT_ID']] = $k;
			if (floatval($prod['DISCOUNT_PRICE'])) {
				$hasDiscount = true;
			}

			// move iblock props (if any) to basket props to have some kind of consistency
			if (isset($prod['IBLOCK_ID'])) {
				$iblock = $prod['IBLOCK_ID'];
				if (isset($prod['PARENT'])) {
					$parentIblock = $prod['PARENT']['IBLOCK_ID'];
				}

				foreach ($arParams['CUSTOM_SELECT_PROPS'] as $prop) {
					$key = $prop . '_VALUE';
					if (isset($prod[$key])) {
						// in the different iblocks we can have different properties under the same code
						if (isset($arResult['PROPERTY_DESCRIPTION'][$iblock][$prop])) {
							$realProp = $arResult['PROPERTY_DESCRIPTION'][$iblock][$prop];
						} elseif (isset($arResult['PROPERTY_DESCRIPTION'][$parentIblock][$prop])) {
							$realProp = $arResult['PROPERTY_DESCRIPTION'][$parentIblock][$prop];
						}

						if (!empty($realProp)) {
							$prod['PROPS'][] = array(
								'NAME' => $realProp['NAME'],
								'VALUE' => htmlspecialcharsEx($prod[$key]),
							);
						}
					}
				}

			}

			// if we have props, show "properties" column
			if (!empty($prod['PROPS'])) {
				$hasProps = true;
			}

			$productSum += $prod['PRICE'] * $prod['QUANTITY'];

			$basketRefs[$prod['PRODUCT_ID']][] =& $arResult["BASKET"][$k];
		}

		$arResult['HAS_DISCOUNT'] = $hasDiscount;
		$arResult['HAS_PROPS'] = $hasProps;

		if ($img = intval($arResult["DELIVERY"]["STORE_LIST"][$arResult['STORE_ID']]['IMAGE_ID'])) {

			$pict = Main::GetResizedImg($img,
				array('WIDTH' => 53, 'HEIGHT' => 81, 'SET_ID' => $arParams['RESIZER_ITEM']), $noPhotoSRC);

			if (strlen($pict['src'])) {
				$pict = array_change_key_case($pict, CASE_UPPER);
			}

			$arResult["DELIVERY"]["STORE_LIST"][$arResult['STORE_ID']]['IMAGE'] = $pict;
		}

		if (!empty($arProducts)) {
			/** @noinspection PhpDynamicAsStaticMethodCallInspection */
			$rs = CIBlockElement::GetList(array(), array('ID' => array_keys($arProducts)), false, false,
				array('ID', 'PREVIEW_PICTURE', 'DETAIL_PICTURE', 'PROPERTY_MORE_PHOTO'));
			while ($ar = $rs->GetNext(0, 0)) {
				$arResult["BASKET"][$arProducts[$ar['ID']]]['PICTURE']['SRC'] = Resize::GetResizedImg($ar, $resizerImage);
			}
		}

	}

	$arParams['PATH_TO_PAYMENT'] = str_replace("#ID#", $arResult['ID'], $arParams['PATH_TO_PAYMENT']);
}
$arResult['ORDER_PROPS_BY_GROUP'] = array();

foreach ($arResult["ORDER_PROPS"] as &$arProp) {
	$arResult['ORDER_PROPS_BY_GROUP'][$arProp['PROPS_GROUP_ID']]['ITEMS'][] = $arProp;
	$arResult['ORDER_PROPS_BY_GROUP'][$arProp['PROPS_GROUP_ID']]['NAME'] = $arProp['GROUP_NAME'];
}