<? use Yenisite\Furniture\Main;

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
?>
<div class="order-info">

	<div class="order-actions">
		<a class="back-to-shoping btn-main btn-direction flaticon-left207"
		   href="<?= $arResult["URL_TO_LIST"] ?>?#order-history"><?= GetMessage('SPOD_BACK') ?></a>
		<? if ($arResult["CAN_CANCEL"] == "Y"): ?>
			<a class="btn-main btn-primary cancel-order"
			   href="<?= $arResult["URL_TO_CANCEL"] ?>"><?= GetMessage("SPOD_CANCEL_ORDER") ?></a>
		<? endif ?>
	</div>
	<? if (strlen($arResult["ERROR_MESSAGE"])): ?>
		<? Main::ShowMessage($arResult["ERROR_MESSAGE"]); ?>
	<? else: ?>
		<div class="order-info-content">
			<h2 class="order-name">
				<? $APPLICATION->ShowTitle(false) ?>
				<? if (strlen($arResult["DATE_INSERT_FORMATED"])): ?>
					<?= GetMessage("SPOD_FROM") ?> <?= $arResult["DATE_INSERT_FORMATED"] ?>
				<? endif ?>
			</h2>
			<table class="order-info-table">
				<tbody>
				<tr>
					<td><?= GetMessage('SPOD_ORDER_STATUS') ?>:</td>
					<td>
						<?= $arResult["STATUS"]["NAME"] ?>
						<? if (strlen($arResult["DATE_STATUS_FORMATED"])): ?>
							(<?= GetMessage("SPOD_FROM") ?> <?= $arResult["DATE_STATUS_FORMATED"] ?>)
						<? endif ?>
					</td>
				</tr>
				<tr>
					<td><?= GetMessage('SPOD_ORDER_PRICE') ?>:</td>
					<td>
						<?= $arResult["PRICE_FORMATED"] ?>
					</td>
				</tr>
				</tbody>
			</table>
			<? if (intval($arResult["USER_ID"])): ?>
				<table class="order-info-table">
					<caption><?= GetMessage('SPOD_ACCOUNT_DATA') ?></caption>
					<? if (strlen($arResult["USER_NAME"])): ?>
						<tr>
							<td><?= GetMessage('SPOD_ACCOUNT') ?>:</td>
							<td><?= $arResult["USER_NAME"] ?></td>
						</tr>
					<? endif ?>
					<tr>
						<td><?= GetMessage('SPOD_EMAIL') ?>:</td>
						<td><?= $arResult["USER"]["EMAIL"] ?></td>
					</tr>
				</table>
			<? endif ?>
			<table class="order-info-table">
				<caption><?= GetMessage('SPOD_ORDER_PROPERTIES') ?></caption>
				<tr>
					<td><?= GetMessage('SPOD_ORDER_PERS_TYPE') ?></td>
					<td><?= $arResult["PERSON_TYPE"]["NAME"] ?></td>
				</tr>
			</table>
			<? if (!empty($arResult['ORDER_PROPS_BY_GROUP'])): ?>
				<? foreach ($arResult['ORDER_PROPS_BY_GROUP'] as $arGroup): ?>
					<table class="order-info-table">
						<caption><?= $arGroup["NAME"] ?></caption>
						<? foreach ($arGroup['ITEMS'] as $prop): ?>
							<tr>
								<td><?= $prop['NAME'] ?></td>
								<td>
									<? if ($prop["TYPE"] == "CHECKBOX"): ?>
										<?= GetMessage('SPOD_' . ($prop["VALUE"] == "Y" ? 'YES' : 'NO')) ?>
									<? else: ?>
										<?= $prop["VALUE"] ?>
									<? endif ?>
								</td>
							</tr>
						<? endforeach ?>
					</table>
				<? endforeach ?>
			<? endif ?>
			<table class="order-info-table">
				<caption><?= GetMessage('SPOD_ORDER_PAYED_STATUS') ?></caption>
				<tr>
					<td><?= GetMessage('SPOD_ORDER_PAYED') ?>:</td>
					<td>
						<? if ($arResult["PAYED"] == "Y"): ?>
							<?= GetMessage('SPOD_YES') ?>
							<? if (strlen($arResult["DATE_PAYED_FORMATED"])): ?>
								(<?= GetMessage('SPOD_FROM') ?> <?= $arResult["DATE_PAYED_FORMATED"] ?>)
							<? endif ?>
						<? else: ?>
							<?= GetMessage('SPOD_NO') ?>
						<? endif ?>
					</td>
				</tr>
			</table>
			<table class="order-info-table">
				<caption><?= GetMessage('SPOD_ORDER_PAYMENT_DELIVERY') ?></caption>
				<tr>
					<td><?= GetMessage('SPOD_DELIVERY_SYSTEM') ?>:</td>
					<td>
						<? if (strpos($arResult["DELIVERY_ID"], ":") !== false || intval($arResult["DELIVERY_ID"])): ?>
							<?= $arResult["DELIVERY"]["NAME"] ?>
						<? else: ?>
							<?= GetMessage("SPOD_NONE") ?>
						<? endif ?>
					</td>
				</tr>
			</table>
			<table class="order-info-table">
				<caption><?= GetMessage('SPOD_ORDER_PAYMENT') ?></caption>
				<tr>
					<td><?= GetMessage('SPOD_ORDER_PAYMENT') ?>:</td>
					<td>
						<? if (intval($arResult["PAY_SYSTEM_ID"])): ?>
							<?= $arResult["PAY_SYSTEM"]["NAME"] ?>
						<? else: ?>
							<?= GetMessage("SPOD_NONE") ?>
						<? endif ?>
					</td>
				</tr>
				<? if ($arResult["CAN_REPAY"] == "Y" && $arResult["PAY_SYSTEM"]["PSA_NEW_WINDOW"] == "Y"): ?>
					<tr>
						<td colspan="2">
							<a href="<?= $arResult["PAY_SYSTEM"]["PSA_ACTION_FILE"] ?>" class="btn btn-primary"
							   target="_blank"><?= GetMessage("SPOD_PAYMENT_FOR_ORDER") ?></a>
						</td>
					</tr>
				<? endif ?>
				<? if ($arResult["CAN_REPAY"] == "Y" && $arResult["PAY_SYSTEM"]["PSA_NEW_WINDOW"] != "Y"): ?>
					<tr id="pay-button-here">
						<td colspan="2">
							<?
							$ORDER_ID = $arResult['ACCOUNT_NUMBER'];
							try {
								include($arResult["PAY_SYSTEM"]["PSA_ACTION_FILE"]);
							} catch (\Bitrix\Main\SystemException $e) {
								if ($e->getCode() == CSalePaySystemAction::GET_PARAM_VALUE) {
									$message = GetMessage("SOA_TEMPL_ORDER_PS_ERROR");
								} else {
									$message = $e->getMessage();
								}

								Main::ShowMessage($message);
							}
							?>
						</td>
					</tr>
					<script type="text/javascript">
						$(function () {
							var $payB = $('#pay-button-here');
							if ($payB.length) {
								$payB.find('a').addClass('btn btn-primary');
							}
						});
					</script>
				<? endif ?>
			</table>
		</div>
		<h2><?= GetMessage('SPOD_ITEMS_IN_ORDER') ?></h2>
		<table class="cart-table short">
			<thead>
			<tr>
				<td class="for-main-info" colspan="2"><?= GetMessage('SPOD_ITEMS') ?></td>
				<td class="for-summary"><?= GetMessage('SPOD_QUANTITY') ?></td>
				<td class="for-summary"><?= GetMessage('SPOD_PRICE') ?></td>
				<td class="for-discount"><?= GetMessage('SPOD_DISCOUNT') ?></td>
				<td class="for-summary"><?= GetMessage('SPOD_SUMM') ?></td>
			</tr>
			</thead>
			<tbody>
			<? foreach ($arResult["BASKET"] as $prod): ?>
				<tr class="cart-item">
					<? $hasLink = !empty($prod["DETAIL_PAGE_URL"]); ?>

					<? if ($prod['PICTURE']['SRC']): ?>
						<td class="img-wrap">
							<? if ($hasLink): ?>
							<a href="<?= $prod["DETAIL_PAGE_URL"] ?>" target="_blank">
								<? endif ?>
								<img alt="<?= $prod['NAME'] ?>" src="<?= $prod['PICTURE']['SRC'] ?>">
								<? if ($hasLink): ?>
							</a>
						<? endif ?>
						</td>
					<? endif ?>

					<td class="name-wrap">
						<? if ($hasLink): ?>
						<a href="<?= $prod["DETAIL_PAGE_URL"] ?>" class="classic-link" target="_blank">
							<? endif ?>
							<?= htmlspecialcharsEx($prod["NAME"]) ?>
							<? if ($arResult['HAS_PROPS']): ?>
								<?
								$actuallyHasProps = is_array($prod["PROPS"]) && !empty($prod["PROPS"]);
								?>
								<? if ($actuallyHasProps): ?>
									(
									<? foreach ($prod["PROPS"] as $prop): ?>
										<? if (!empty($prop['SKU_VALUE'])): ?>
											<?= $prop["NAME"] . ': ' . $prop["VALUE"] ?>
										<? endif ?>
									<? endforeach ?>
									)
								<? endif ?>
							<? endif ?>
							<? if ($hasLink): ?>
						</a>
					<? endif ?>
					</td>
					<td>
						<?= $prod["QUANTITY"] ?>
						<? if (strlen($prod['MEASURE_TEXT'])): ?>
							<?= $prod['MEASURE_TEXT'] ?>
						<? else: ?>
							<?= GetMessage('SPOD_DEFAULT_MEASURE') ?>
						<? endif ?>
					</td>
					<td class="price-wrap">
						<? if ($arResult['HAS_DISCOUNT']): ?>
							<div class="old-price"><?= $prod['OLD_PRICE_FORMATED'] ?></div>
							<?= $prod["PRICE_FORMATED"] ?>
						<? else: ?>
							<div class="price"><?= $prod["PRICE_FORMATED"] ?></div>
						<? endif ?>
					</td>
					<td class="discount"><span class="discount-amount"><?= $prod["DISCOUNT_PRICE_PERCENT_FORMATED"] ?></span></td>
					<td class="price-wrap">
						<div class="price"><?= CurrencyFormat($prod['QUANTITY'] * $prod['PRICE'], $prod['CURRENCY']) ?></div>
					</td>
				</tr>
			<? endforeach ?>
			</tbody>
		</table>
	<? endif ?>
</div>