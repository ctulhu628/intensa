$(function () {
	var $orderFilter = $('#personal_orders_filter'),
		$orderContent = $('#personal_orders_content'),
		$body = $(document.body);

	var doAjax = function (addData) {
		var data;
		if (typeof addData == 'object') {
			data = addData;
		} else {
			data = {};
		}

		data.push({'name': 'ajax', 'value': $orderFilter.data('ajax')});
		$orderContent.startAjax();
		$.ajax({
			'url': AJAX_DIR + 'personal_orders.php',
			'type': 'POST',
			'data': data,
			'success': function (msg) {
				$orderContent.html(msg);
				$orderContent.refreshForm();
				$orderContent.stopAjax();
			}
		})
	};

	$body.on('rmz.switch', '.order-history__status-switch a', function (e) {
		var $this = $(this);
		if (!$this.hasClass('active')) return false;
		doAjax([{'name': 'status', 'value': $this.data('status-id')}]);
	});

	$orderFilter.on('submit', function (e) {
		e.preventDefault();
		var $this = $(this),
			data = $this.find(':input').not(emptyInputs).serializeArray();
		doAjax(data);
	});
});
