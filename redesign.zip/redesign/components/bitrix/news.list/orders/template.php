<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
use Yenisite\Furniture\Main;
use \Yenisite\Core\Tools;
use \Yenisite\Core\Ajax;

$isAjax = Tools::isAjax();
if (!$isAjax) {
	Ajax::saveParams($this, $arParams, 'personal_orders');
}

?>
<? if (!empty($arResult['ERRORS']['FATAL'])): ?>
	<? Main::ShowMessage($arResult['ERRORS']['FATAL']); ?>
<? else: ?>
	<? if (!empty($arResult['ERRORS']['NONFATAL'])): ?>
		<? Main::ShowMessage($arResult['ERRORS']['NONFATAL'], Main::MSG_TYPE_WARNING); ?>
	<? endif ?>
	<? if (!empty($arResult['ITEMS'])): ?>
		<table class="order-history-table">
			<thead>
			<tr>
				<th><?= GetMessage('RZ_NUM_ZAK') ?></th>
				<th><?= GetMessage('RZ_STOIM_ZAK') ?></th>
				<th><?= GetMessage('MARKETPLACE_SPOL_STATUS') ?></th>
				<th><?= GetMessage('MARKETPLACE_ITEMS') ?></th>
				<th><?= GetMessage('MARKETPLACE_PAYMENT_DELIVERY') ?></th>
				<th><?if($arResult["checkRobokassa"] == true){ ?><?= GetMessage('MARKETPLACE_SPOL_ACTIONS') ?><? } ?></th>
			</tr>
			</thead>
			<tbody>
			<? foreach ($arResult["ITEMS"] as $key => $order): ?>
				<tr>
					<td>
						<a href="<?= $order["DETAIL_PAGE_URL"] ?>"
						   class="classic-link order-number"><?= $order['FIELDS']["ID"] ?></a>
						<div class="order-number-text order-date"><?= GetMessage('MARKETPLACE_SPOL_FROM') ?> <?= $order["FIELDS"]["DATE_CREATE"]; ?></div>
						</td>
					<td>
						<span class="order-price"><?= $order["TOTAL_SUM_FORMATTED"] ?></span>
					</td>
					<td>
						<span class="order-status <?= ($order["DISPLAY_PROPERTIES"]['STATUS']['VALUE'] ==  GetMessage('MARKETPLACE_PAYED') || $order["DISPLAY_PROPERTIES"]['STATUS']['VALUE'] ==  GetMessage('MARKETPLACE_BRING')) ? ' paid' : ' awaiting' ?>">
								<?= $order["DISPLAY_PROPERTIES"]['STATUS']['VALUE'] ?>
						</span>
					</td>
					<td class="order-content">
						<? if ($order["DISPLAY_PROPERTIES"]['ITEMS']['LINK_ELEMENT_VALUE']): ?>
						<? foreach ($order["DISPLAY_PROPERTIES"]['ITEMS']['LINK_ELEMENT_VALUE'] as $arItem)://use str_replace DETAIL_TEXT for like default version
							$hasLink = !empty($arItem["DETAIL_PAGE_URL"]); ?>
							<div class="order-item">
								<? if ($hasLink): ?>
									<a href="<?= $arItem['DETAIL_PAGE_URL'] ?>" class="classic-link"><span
												class="text"><?= $arItem['NAME'] ?></span></a>
								<? else: ?>
									<span class="text"><?= $arItem['NAME'] ?></span>
								<? endif ?>
							</div>
						<? endforeach ?>
						<? endif ?>
					</td>
					<td>
						<?= $arResult['LIST_PAYMENT_DELIVERY'][$order['PROPERTIES']['PAYMENT_E']['VALUE']]["NAME"] ?>
						<? if (intval($order['PROPERTIES']['DELIVERY_E']['VALUE'] > 0)): ?>
							 /<?= $arResult['LIST_PAYMENT_DELIVERY'][$order['PROPERTIES']['DELIVERY_E']['VALUE']]["NAME"] ?>
						<? endif ?>
					</td>
					<td>
					<?if($arResult["checkRobokassa"] == true){ ?>
						<div>
							<?if($arResult['LIST_PAYMENT_DELIVERY'][$order['PROPERTIES']['PAYMENT_E']['VALUE']]['CODE'] == 'robokassa' && ($order["DISPLAY_PROPERTIES"]['STATUS']['VALUE_XML_ID'] == "added" || $order["DISPLAY_PROPERTIES"]['STATUS']['VALUE'] == GetMessage('ADD_ORDER'))):?>
								<a href="<?= SITE_DIR ?>personal/cart/?payment=Y&id=<?=$order['ID']?>" class="repeat action-link has-icon flaticon-update24">
									<?=GetMessage('PAY_ORDER')?>
								</a>
								<!--div class="UI-element">
									<a href="/personal/order/?payment=Y&id=<?=$order['ID']?>" class="btn-submit"><span class="btn-text"><?=GetMessage('PAY_ORDER')?></span></a>
								</div-->
							<?endif?>
						</div>
					<? } ?>
					</td>
				</tr>
			<? endforeach ?>
			</tbody>
		</table>
		<?if($arParams["DISPLAY_BOTTOM_PAGER"]):
			$arResult["NAV_STRING"] = preg_replace('#PAGEN_1=(\d+)#', 'PAGEN_1=$1#personal_history_header', $arResult["NAV_STRING"]);?>
			<br /><?= preg_replace('#personal/"#', 'personal/#personal_history_header"', $arResult["NAV_STRING"]); ?>
		<?endif;?>
	<? else: ?>
		<? Main::ShowMessage(GetMessage('MARKETPLACE_SPOL_NO_ORDERS'), Main::MSG_TYPE_WARNING) ?>
	<? endif ?>
<? endif ?>


