<?	if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
use Yenisite\Furniture\Main;

$arResult["checkRobokassa"] = false;
$arrDelivery = array();
$arrPayment = array();

foreach ($arResult["ITEMS"] as $key => &$order){
	$order['TOTAL_SUM_FORMATTED'] = Main::getElementPriceFormat(false, $order["DISPLAY_PROPERTIES"]['AMOUNT']["VALUE"]);
	$arrPaymentAndDelivery[] = $order['PROPERTIES']['DELIVERY_E']['VALUE'];
	$arrPaymentAndDelivery[] = $order['PROPERTIES']['PAYMENT_E']['VALUE'];
}

$arSelect = Array("ID", "NAME", "CODE");
$arFilter = Array("ACTIVE"=>"Y", "ID" => $arrPaymentAndDelivery);
$res = CIBlockElement::GetList(Array(), $arFilter, false, Array(), $arSelect);
while($element = $res->GetNext())
{
	$arResult['LIST_PAYMENT_DELIVERY'][$element["ID"]]["NAME"] = $element["NAME"];
	$arResult['LIST_PAYMENT_DELIVERY'][$element["ID"]]["CODE"] = $element["CODE"];
	if($arResult["checkRobokassa"] == false && $element["CODE"] == "robokassa") $arResult["checkRobokassa"] = true;
}