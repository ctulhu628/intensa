<?$MESS["RESIZER_MED_SLIDER"] = "Картинка для слайдера среднего размера";
$MESS["RESIZER_SMALL_SLIDER"] = "Картинка для слайдера маленького размера размера";
$MESS["RESIZER_MAIN_BANNER_NOT_FULL"] = "Картинка для не на всю ширину (когда меню слева)";