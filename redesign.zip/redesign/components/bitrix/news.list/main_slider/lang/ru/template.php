<?
$MESS["RZ_UZNAT_BOLSHE"] = "узнать больше";

