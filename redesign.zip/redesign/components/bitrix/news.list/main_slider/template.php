<? use Yenisite\Core\Tools;
use Yenisite\Furniture\Main;
use Yenisite\Furniture\Mobile;
global $rz_options;
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */
/** @var CBitrixComponent $component */
$this->setFrameMode(true);
if (empty($arResult['ITEMS'])) return;
?>

<!-- welcome-->
<section class="welcome">
  <div class="container">
    <div class="swiper-container welcome-sl">
      <div class="swiper-wrapper">
		<? foreach ($arResult['ITEMS'] as &$arItem): ?>
        <div class="swiper-slide welcome-sl-el" style="background-image: url(<?= $arItem['PREVIEW_PICTURE']['SRC'] ?>);">
			<? $href = $arItem['PROPERTIES']['HREF']['VALUE'] ?: '' ?>
	        <div class="welcome-sl-body">
            <? if (!empty($arItem['PREVIEW_TEXT'])): ?>
        		<div class="welcome-sl-category"><?= $arItem['PREVIEW_TEXT'] ?></div>
			<? endif ?>
			<? if (!empty($arItem['NAME'])): ?>
        		<div class="welcome-sl-name"><?= $arItem['NAME'] ?></div>
			<? endif ?>
	            <div class="welcome-sl-price">
				<? if (!empty($arItem['PROPERTIES']['OLD_PRICE']['VALUE'])): ?>
	              	<div class="welcome-sl-price-old"><?= $arItem['PROPERTIES']['OLD_PRICE']['VALUE'] ?> руб.</div>
				<? endif ?>
				<? if (!empty($arItem['PROPERTIES']['PRICE']['VALUE'])): ?>
	              	<div class="welcome-sl-price-new"><?= $arItem['PROPERTIES']['PRICE']['VALUE'] ?> руб.</div>
				<? endif ?>
	            </div>
			<? if ($href): ?>
				<div><a class="mbtn mbtn-brdwhite warrow-right" href="<?= Tools::GetConstantUrl($href) ?>"><span>Посмотреть</span></a></div>
			<? endif ?>
	            
	        </div>
		</div>
		<? endforeach;
		unset($arItem) ?>
      </div>
      <div class="swiper-button swiper-button-prev"></div>
      <div class="swiper-button swiper-button-next"></div>
    </div>
  </div>
</section>
<!-- /welcome-->
