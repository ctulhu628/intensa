<?
global $rz_options;

if($rz_options['main_menu_position'] == 'at-vertical' && $APPLICATION->GetCurPage(true) == SITE_DIR.'index.php'){
	$APPLICATION->SetPageProperty("prop_menu_slider", "menu_slider");
}