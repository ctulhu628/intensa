<?php
if($arParams["DISPLAY_PREVIEW_TEXT"]!="Y" && empty($arItem["PREVIEW_TEXT"])) return;
$arParams['SECTION_COUNT_SYMBOL_FOR_DESCRIPTION'] = empty($arParams['SECTION_COUNT_SYMBOL_FOR_DESCRIPTION']) ? 50 : $arParams['SECTION_COUNT_SYMBOL_FOR_DESCRIPTION'];

if (empty($arResult['ITEMS'])) return;

foreach ($arResult['ITEMS'] as &$arItem) {
    if (strlen($arItem["PREVIEW_TEXT"]) <=  $arParams['SECTION_COUNT_SYMBOL_FOR_DESCRIPTION']) continue;

    $text = substr($arItem["PREVIEW_TEXT"], 0, $arParams['SECTION_COUNT_SYMBOL_FOR_DESCRIPTION']);
    $text = rtrim($text, "!,.-");
    $text = substr($text, 0, strrpos($text, ' '));
    $text .="...";

    $arItem["PREVIEW_TEXT"] = $text;
}
