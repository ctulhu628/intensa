<?
/**
 * @var array $MESS
 */

$MESS['RZ_BASKET'] = 'Корзина';
$MESS['RZ_BASKET_PRINT'] = 'распечатать корзину';
$MESS['RZ_WAITLIST'] = 'Отложенные';
$MESS['RZ_NO_ITEMS'] = 'В вашей корзине ещё нет товаров.';
$MESS['RZ_TOTAL'] = 'Итого:';

$MESS['RZ_BASKET-CLEAR'] = 'Удалить всё из корзины';
$MESS['RZ_BASKET_BACK_TO'] = 'Вернуться к покупкам';

$MESS["RZ_WAITLIST-TO-BASKET"] = "Вернуть в корзину";
$MESS["RZ_BASKET-TO-WAITLIST"] = "Отложить";
$MESS["RZ_BASKET-DELETE"] = "Удалить";

$MESS['RZ_BASKET-ITEMS-INSIDE'] = 'Товаров в корзине:';
$MESS['RZ_BASKET-TOTAL-PRICE'] = 'На сумму:';
$MESS['RZ_BASKET-TOTAL-DISCOUNT'] = 'Скидка:';
$MESS['RZ_BASKET-OUT-OF-STOCK'] = 'Товар отсутствует';
$MESS['RZ_WAITLIST-ITEMS'] = 'Отложенные товары';
$MESS['RZ_WAITLIST-ITEMS-SHORT'] = 'Отложено';
$MESS['RZ_WAITLIST-ITEMS-INSIDE'] = 'Отложенных товаров:';
$MESS['RZ_BACK-TO-BASKET'] = 'Товары в корзине';
$MESS['RZ_BACK-TO-BASKET-SHORT'] = 'В корзине';
$MESS['RZ_INFORM-ME'] = 'Сообщить о наличии';

$MESS['RZ_BIG-BASKET-HEADER'] = 'Корзина заказа';
$MESS['RZ_BIG-BASKET-PRINT'] = 'Распечатать корзину';
$MESS['RZ_BIG-BASKET-ADD-BY-CODE'] = 'Добавить товары по артикулу:';
$MESS['RZ_BIG-BASKET-ENTER-VENDORCODE'] = 'Введите артикул товара';

$MESS['RZ_BIG-BASKET-SUBMIT-ORDER'] = 'Оформить заказ';
$MESS['RZ_BIG-BASKET-TOTAL-WEIGHT'] = 'Общий вес:';
$MESS['RZ_BIG-BASKET-ASK-FOR-PROMOCODE'] = 'Знаете промо-код на скидку?';
$MESS['RZ_BIG-BASKET-ENTER-PROMOCODE'] = 'Введите код в это поле...';
$MESS['RZ_BIG-BASKET-ENTER-PROMOCODE2'] = 'Добавить еще промокод...';

$MESS['RZ_ADD'] = 'Добавить';
$MESS['RZ_QUICK-BUY'] = 'Быстрый заказ';
$MESS['RZ_VENDOR-CODE'] = 'Артикул';


$MESS['RZ_BASKET-HEADER-NAME'] = 'Товар';
$MESS['RZ_BASKET-HEADER-QUANTITY'] = 'Количество';
$MESS['RZ_BASKET-HEADER-WEIGHT'] = 'Вес, ед.';
$MESS['RZ_BASKET-HEADER-TOTAL_WEIGHT'] = 'Общий вес';
$MESS['RZ_BASKET-HEADER-PRICE'] = 'Цена, ед.';
$MESS['RZ_BASKET-HEADER-TYPE'] = 'Тип цены';
$MESS['RZ_BASKET-HEADER-DISCOUNT'] = 'Скидка';
$MESS['RZ_BASKET-HEADER-SUM'] = 'Сумма';
$MESS['RZ_BASKET-HEADER-PROPS'] = 'Свойства';
$MESS['RZ_BASKET-HEADER-PROPS'] = 'Свойства';
$MESS['RZ_BASKET-HEADER-VAT'] = 'НДС';
$MESS['RZ_BASKET-HEADER-DELETE'] = 'Удалить';
$MESS['RZ_BASKET-HEADER-DELAY'] = 'Отложить';

$MESS['RZ_BASKET-HELP-FOR-QUICK'] = 'Вам нужно будет указать только имя и номер телефона';
$MESS['RZ_BASKET-QUICK-ORDER'] = 'Быстрый заказ';
$MESS['FOR_ITEM'] = 'за ед.';
$MESS['SUMM'] = 'сумма';