<?
/**
 * @var array $arItems
 * @var array $arResult
 * @var array $arParams
 */
use Yenisite\Furniture\Form;
use Yenisite\Furniture\Main;

$resizeItem = array('WIDTH' => 100, 'HEIGHT' => 100, 'SET_ID' => $arParams['RESIZER_IMAGE']);
$langPrefix = 'RZ_BASKET-HEADER-';
if (empty($arItems)) {
	Main::ShowMessage(GetMessage('RZ_NO_ITEMS'), Main::MSG_TYPE_WARNING, false);
	return;
}
?>
<table class="cart-table">
	<thead>
	<tr>
		<?
		$arSkipFields = array(
				'PROPS' => 0,
				'DELAY' => 0,
				'DELETE' => 0,
				'TYPE' => 0,
		);
		if ($isWaitlist) {
			$arSkipFields['SUM'] = 0;
			$arSkipFields['DISCOUNT'] = 0;
		}
		$arAllHeaders = array();
		foreach ($arResult['GRID']['HEADERS'] as $arHeader):
			$class = '';
			$attr = '';

			$arHeader['name'] = $arHeader['name'] ?: GetMessage($langPrefix . $arHeader['id']);
			if (!in_array($arHeader['id'], array('NAME', 'QUANTITY'))) {
				$class = 'hidden-xs';
			}
			if (isset($arSkipFields[$arHeader['id']])) {
				$arSkipFields[$arHeader['id']] = 1;
				continue;
			}
			if ($arHeader['id'] == 'NAME') {
				$attr = ' colspan="2"';
				$class .= ' for-item-name';
			}
			if ($arHeader['id'] == 'QUANTITY') {
				$class .= ' for-amount';
			}
			$arAllHeaders[$arHeader['id']] = strtolower($arHeader['id']);
			?>
			<td<?= $attr ?> class='print <?= $class ?>'><?= $arHeader['name'] ?></td>
		<? endforeach ?>
		<td class='print hidden-xs'></td>
	</tr>
	</thead>
	<tbody>
	<? foreach ($arItems as &$arItem):
		$PIC = Main::GetResizedImg($arItem, $resizeItem);
		$bCanBuy = $arItem['CAN_BUY'] == 'Y';
		?>
		<tr class="cart-item <?= $bCanBuy ? 'in-stock' : 'out-of-stock' ?>">
			<? foreach ($arAllHeaders as $id => $class):
				switch ($id):
					case 'NAME':
						?>
						<td class="img-wrap print">
							<a href="<?= $arItem['DETAIL_PAGE_URL'] ?>">
								<img src="<?= $PIC ?>" alt="<?= $arItem['NAME'] ?>">
							</a>
						</td>
						<td class="name-wrap print">
							<a href="<?= $arItem['DETAIL_PAGE_URL'] ?>" class="classic-link"><?= $arItem['NAME'] ?></a>
							<?if(!empty($arItem['PROPS'])):?>
								<?foreach ($arItem['PROPS'] as $arProp):?>
									<?if(empty($arProp)) continue?>
									<div class="chosen-parameter">
										<span class="parameter-title"><?=$arProp['NAME']?>:</span>
										<span class="parameter-value"><?=$arProp['VALUE'] ?></span>
									</div>
								<?endforeach?>
							<?endif?>
						</td>
						<? break;
					case 'QUANTITY':
						?>
						<td class="availability print" data-when-out-of-stock="<?= GetMessage('RZ_BASKET-OUT-OF-STOCK') ?>">
							<? if ($bCanBuy): ?>
								<? Form::printElement(array('CLASS' => 'small', 'STEP' => $arItem['CATALOG_MEASURE_RATIO'], 'VALUE' => $arItem['QUANTITY'], 'NAME' => 'QUANTITY_' . $arItem['ID']),
										Form::TYPE_QUANTITY) ?>
							<? else: ?>
								<? /* todo: big_basket inform modal
								<div class="link-wrap">
									<a href="#modal-notice"
									   class="pseudo-link link-black flaticon-mail"
									   data-toggle="modal">
										<?= GetMessage('RZ_INFORM-ME') ?>
									</a>
								</div>
								*/ ?>
							<? endif ?>
							<? if ($isWaitlist):?>
								<input type="hidden" name="DELAY_<?= $arItem["ID"] ?>" id="DELAY_<?= $arItem["ID"] ?>" value="Y"/>
								<input type="hidden" name="DELETE_<?= $arItem["ID"] ?>" id="DELETE_<?= $arItem["ID"] ?>" value="N"/>
							<? endif ?>
						</td>
						<? break;
					case 'DISCOUNT':
						$dp = $arItem['DISCOUNT_PRICE_PERCENT'];
						if ($dp == 0) {
							$discountClass = 'no-discount';
						} elseif ($dp <= 5) {
							$discountClass = 'discount-md';
						} elseif ($dp < 15) {
							$discountClass = 'discount-md';
						} else {
							$discountClass = 'discount-xl';
						}
						?>
						<td class="print discount hidden-xs"><span class="discount-amount <?= $discountClass ?>"><?= $arItem['DISCOUNT_PRICE_PERCENT_FORMATED'] ?></span></td>
						<? break;
					case 'PRICE':
						?>
						<td class="print price-wrap">
							<div class="price"><?= \Yenisite\Furniture\Mobile::isMobile() ? GetMessage('FOR_ITEM').': ' : ''?><?= $arItem['PRICE_FORMATED'] ?></div>
							<? if ($arItem['DISCOUNT_PRICE_PERCENT'] > 0): ?>
								<div class="old-price"><?= $arItem['FULL_PRICE_FORMATED'] ?></div>
							<? endif ?>
						</td>
						<? break;
					default:
						if (empty($arItem[$id])) continue;
						?>
						<td class="print <?= $class ?>">
							<?if($class == 'sum' && \Yenisite\Furniture\Mobile::isMobile()):?><?=GetMessage('SUMM')?>: <?endif?><?= $arItem[$id] ?>
						</td>
					<? endswitch ?>
			<? endforeach ?>
			<td class="text-right actions">
				<? if ($isWaitlist): ?>
					<button type="submit" name="<?= $arParams['ACTION_VARIABLE'] ?>" value="add_<?= $arItem['ID'] ?>"
							class="basket-action-btn add-to-wish-list tooltip-simple flaticon-back15" title="<?= GetMessage('RZ_WAITLIST-TO-BASKET') ?>"
							data-toggle="tooltip" data-placement="top" data-trigger="hover"></button>
				<? else: ?>
					<button type="submit" name="<?= $arParams['ACTION_VARIABLE'] ?>" value="delay_<?= $arItem['ID'] ?>"
							class="basket-action-btn add-to-wish-list tooltip-simple flaticon-back15" title="<?= GetMessage('RZ_BASKET-TO-WAITLIST') ?>"
							data-toggle="tooltip" data-placement="top" data-trigger="hover"></button>
				<? endif ?>
				<button type="submit" name="<?= $arParams['ACTION_VARIABLE'] ?>" value="delete_<?= $arItem['ID'] ?>"
						class="basket-action-btn delete flaticon-delete96 tooltip-simple" title="<?= GetMessage('RZ_BASKET-DELETE') ?>"
						data-toggle="tooltip" data-placement="top" data-trigger="hover"></button>
			</td>
		</tr>
	<? endforeach;
	unset($arItem); ?>
	</tbody>
</table>
