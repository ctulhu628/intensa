<? use Bitrix\Sale\DiscountCouponsManager;
use Yenisite\Core\Ajax;
use Yenisite\Furniture\Main;

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */
/** @var CBitrixBasketComponent $component */

$isAjax = Ajax::isAjax();
$totalReady = count($arResult['ITEMS']['AnDelCanBuy']);
$totalDelay = count($arResult['ITEMS']['DelDelCanBuy']);
$emptyCart = !($totalReady || $totalDelay);

?>
<? if ($emptyCart): ?>
	<div class="ordering1"><? Main::ShowMessage(GetMessage('RZ_NO_ITEMS'), Main::MSG_TYPE_WARNING, false) ?></div>
	<? return ?>
<? endif ?>
<?
if (!$isAjax):
Ajax::saveParams($this, $arParams, 'main_basket');
?>
<div class="ordering1">
	<form method="POST" action="<?= POST_FORM_ACTION_URI ?>" name="main_basket" id="main_basket" <? Ajax::printAjaxDataAttr($this,
			'main_basket') ?>>
<? endif ?>
		<input type="hidden" name="BasketRefresh" value="BasketRefresh"/>
		<div class="order-actions">
			<a href="javascript:history.back();"
			   class="back-to-shoping btn-main btn-direction flaticon-left207"><?= GetMessage('RZ_BASKET_BACK_TO') ?></a>
			<div class="add-items-wrap">
				<a  href="#" onclick="print()" class="action-link has-icon print pull-right flaticon-printer70">
					<span class="link-text"><?=GetMessage('RZ_BASKET_PRINT')?></span>
				</a>
			</div>
		</div><!-- order-actions -->
		<ul class="wish-list-wrap">
			<li class="active">
				<a href="#basket-active" class="action-link has-icon wish-list flaticon-back15" data-toggle="tab">
					<?= GetMessage('RZ_BACK-TO-BASKET') ?>:
				</a> <?= $totalReady ?>
			</li>
			<? if ($arResult['ShowDelay'] == 'Y'): ?>
				<li>
					<a href="#basket-waitlist" class="action-link has-icon wish-list flaticon-back15" data-toggle="tab">
						<?= GetMessage('RZ_WAITLIST-ITEMS') ?>:
					</a> <?= count($arResult['ITEMS']['DelDelCanBuy']) ?>
				</li>
			<? endif ?>
		</ul>
		<div class="tab-content">
			<div class="cart-wrap tab-pane active fade in" id="basket-active">
				<div class="cart-header">
					<span class="text">
						<?= GetMessage('RZ_BASKET-ITEMS-INSIDE') ?>
						<b><?= $totalReady ?></b>
					</span>
					<span class="text">
						<?= GetMessage('RZ_BASKET-TOTAL-PRICE') ?>
						<b><?= $arResult['allSum_FORMATED'] ?></b>
					</span>
				</div>
				<?
				$arItems = &$arResult['ITEMS']['AnDelCanBuy'];
				$bHasItemsForOrder = !empty($arItems);
				include 'items.php';
				?>
			</div>
			<? if ($arResult['ShowDelay'] == 'Y'): ?>
				<div class="cart-wrap tab-pane waitlist-wrap fade" id="basket-waitlist">
					<div class="cart-header">
						<span class="text">
							<?= GetMessage('RZ_WAITLIST-ITEMS-INSIDE') ?>
							<b><?= $totalDelay ?></b>
						</span>
					</div>
					<div class="basket-wrap collapse in" id="basket-waitlist-tablewrap">
						<?
						$arItems = &$arResult['ITEMS']['DelDelCanBuy'];
						$isWaitlist = true;
						include 'items.php';
						?>
					</div>
				</div>
			<? endif ?>
		</div>
		<? if ($bHasItemsForOrder): ?>
			<div class="cart-wrap">
				<div class="table-footer clearfix">
				<div class="big-cart-total">
					<table class="total">
						<tr>
							<th colspan="2"><?= GetMessage('RZ_TOTAL') ?></th>
						</tr>
						<tr>
							<td><?= GetMessage('RZ_BASKET-ITEMS-INSIDE') ?></td>
							<td><?= $totalReady ?></td>
						</tr>
						<? if ($arResult['allWeight']): ?>
							<tr>
								<td><?= GetMessage('RZ_BIG-BASKET-TOTAL-WEIGHT') ?></td>
								<td><?= $arResult['allWeight_FORMATED'] ?></td>
							</tr>
						<? endif ?>
						<? if ($arResult['DISCOUNT_PRICE_ALL']): ?>
							<tr>
								<td><?= GetMessage('RZ_BASKET-TOTAL-DISCOUNT') ?></td>
								<td><?= $arResult['DISCOUNT_PRICE_ALL_FORMATED'] ?></td>
							</tr>
						<? endif ?>
						<tr>
							<td><?= GetMessage('RZ_BASKET-TOTAL-PRICE') ?></td>
							<td><?= $arResult['allSum_FORMATED'] ?></td>
						</tr>
					</table>
				</div>
				<div class="input-group">
					<span class="input-group-addon"><?= GetMessage('RZ_BIG-BASKET-ASK-FOR-PROMOCODE') ?></span>
					<? if (!empty($arResult['COUPON_LIST'])) :
						$couponHasError = 0;
						foreach ($arResult['COUPON_LIST'] as $arCoupon) {
							$bError = 0;
							$couponClass = '';
							switch ($arCoupon['STATUS']) {
								case DiscountCouponsManager::STATUS_NOT_FOUND:
								case DiscountCouponsManager::STATUS_FREEZE:
									$couponClass = 'has-error';
									$bError = 1;
									//$couponHasError = 1;
									break;
								case DiscountCouponsManager::STATUS_APPLYED:
									$couponClass = 'disabled has-success';
									break;
							}
							$codeText = $arCoupon['CHECK_CODE_TEXT'];
							$codeText = is_array($codeText) ? implode(",\n", $codeText) : $codeText;
							?>
							<div class="input-group <?= $couponClass ?>" data-tooltip title="<?= $codeText ?>">
								<input type="text" class="form-control" value="<?= htmlspecialcharsbx($arCoupon['COUPON']) ?>"
									   name="OLD_COUPON[]"<?= $bError ? '' : ' readonly' ?>>
								<? if ($bError): ?>
									<span class="input-group-btn">
										<button type="submit" class="three-color-p btn-enter-promocode flaticon-pointing6"></button>
									</span>
								<? endif ?>
							</div>
							<?
						}
						unset($couponClass, $arCoupon);
					endif ?>
					<?
					if (!$couponHasError):
						$promoCodeText = GetMessage('RZ_BIG-BASKET-ENTER-PROMOCODE');
						if (!empty($arResult['COUPON_LIST'])) {
							$promoCodeText = GetMessage('RZ_BIG-BASKET-ENTER-PROMOCODE2');
						}
						?>
						<div class="input-group">
							<input type="text" class="form-control" name="COUPON" placeholder="<?= $promoCodeText ?>">
							<span class="input-group-btn">
								<button class="three-color-p btn-enter-promocode flaticon-pointing6"></button>
							</span>
						</div>
					<? endif ?>
				</div>
			</div>
			</div>
		<? endif ?>
		<? if ($isAjax && $bHasItemsForOrder): ?>
		<script type="text/javascript">
			$('#big-basket-submit-btn').removeAttr('disabled');
		</script>
		<? endif ?>
		<div class="big-cart-buttons">
			<?if(Main::isOneClick()):?>
				<div class="quick-order-wrap">
					<a data-basket="Y" href="#" class="btn-main btn-secondary quick-order" data-toggle="modal" data-target="#modal-quick-order">
					<span class="svg-wrap">
						<svg xmlns="http://www.w3.org/2000/svg">
							<use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#buy-one-click"></use>
						</svg>
					</span>
						<?=GetMessage('RZ_QUICK-BUY')?>
					</a>
					<div class="quick-order-prompt"><?=$arParams['TIP_BUY_IN_ONE_CLICK']?></div>
				</div>
			<?endif?>
			<button type="submit" name="BasketOrder" value="BasketOrder"
					class="btn-main btn-primary btn-checkout" <? if (!$bHasItemsForOrder): ?> disabled<? endif ?>
					id="big-basket-submit-btn"><?= GetMessage('RZ_BIG-BASKET-SUBMIT-ORDER') ?></button>
		</div>
<? if (!$isAjax): ?>
	</form>
</div>
<? endif ?>