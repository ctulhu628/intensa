'use strict';
$(function () {
	var $mainBasket = $('#main_basket'),
		timer, ajaxStarted;
	var doAjax = function (addData) {
		if (ajaxStarted) return false; // fix strange bug on chrome 51.0
		var data;
		if (typeof addData == 'object') {
			data = addData;
		} else {
			data = $mainBasket.serializeArray();
		}
		data.push({'name': 'ajax', 'value': $mainBasket.data('ajax')});
		$mainBasket.startAjax();
		ajaxStarted = 1;
		$.ajax({
			'url': AJAX_DIR + 'cart.php',
			'type': 'post',
			'data': data,
			'success': function (msg) {
				$mainBasket.html(msg);
				$mainBasket.refreshForm();
				$mainBasket.stopAjax();
				ajaxStarted = 0;
			}
		});
	};

	$mainBasket.on('submit', function (e) {
		if ($mainBasket.data('submit')) {
			$mainBasket.find(':input[name="BasketRefresh"]').remove();
			return true;
		} else {
			e.preventDefault();
			doAjax();
			return false;
		}
	});

	$mainBasket.on('change', '.quantity-input', function (e) {
		if (timer) {
			clearTimeout(timer);
		}
		timer = setTimeout(
			function () {
				$mainBasket.submit();
			}, 300);
	});

	$mainBasket.on('click', '.basket-action-btn', function (e) {
		e.preventDefault();
		var $this = $(this);
		doAjax([
			{'name': $this.attr('name'), 'value': $this.attr('value')},
			{'name': 'BasketRefresh', 'value': 'BasketRefresh'}
		]);
		return false;
	});

	$mainBasket.on('click', '[name="BasketOrder"]', function (e) {
		$mainBasket.data('submit', true);
	});

	/*$mainBasket.on('change', ':input:not(.quantity-input)', function (e) {
	 e.preventDefault();
	 $mainBasket.submit();
	 return false;
	 });*/
});