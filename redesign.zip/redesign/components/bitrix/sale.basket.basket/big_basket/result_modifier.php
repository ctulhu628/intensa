<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
$arParams['USE_ONECLICK'] = $arParams['USE_ONECLICK'] ? : 'Y';
$arParams['TIP_BUY_IN_ONE_CLICK'] = $arParams['TIP_BUY_IN_ONE_CLICK'] ? : GetMessage('RZ_BASKET-HELP-FOR-QUICK');