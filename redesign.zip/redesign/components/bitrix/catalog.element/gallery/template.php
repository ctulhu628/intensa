<?
/**
 * @var CBitrixComponentTemplate $this
 */

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

$i = 1;
?>

<!-- gallery-->
<section class="block-padd">
  <div class="container">
    <div class="zgallery row">
    <?php foreach ($arResult['PROPERTIES']['gallery']['VALUE'] as $image):
        $src = CFile::GetPath($image) ?>
        <!-- el-->
        <div class="zgallery-item <?= ($i % 4 == 0 || $i % 4 == 1) ? 'col-5' : 'col-7'; ?>"><a class="zgallery-link" href="<?= $src ?>" data-fancybox="zGallery" style="background-image: url(<?= $src ?>);"></a></div>
        <!-- /el-->
    <?php $i++;
    endforeach ?>
    </div>
  </div>
</section>
<!-- /gallery-->