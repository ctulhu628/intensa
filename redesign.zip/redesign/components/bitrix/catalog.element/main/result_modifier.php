<?
/**
 * @var CBitrixComponentTemplate $this
 * @var array $arResult
 * @var array $arParams
 */
use Bitrix\Main\Loader;
use Yenisite\Furniture\Main;

\Bitrix\Main\Localization\Loc::loadLanguageFile($_SERVER['DOCUMENT_ROOT'] . SITE_TEMPLATE_PATH . '/catalog.php');

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
if (empty($arResult['ID'])) return;
$arItem = &$arResult;
$arParams['RESIZER_BRAND_DETAIL'] = $arParams['RESIZER_BRAND_DETAIL'] ? : 5;

$resizeThumb = array('WIDTH' => 77, 'HEIGHT' => 77, 'SET_ID' => $arParams['RESIZER_BIG_THUMB']);
$resizeItem = array('WIDTH' => 465, 'HEIGHT' => 465, 'SET_ID' => $arParams['RESIZER_BIG_IMAGE']);
$resizeBig = array('WIDTH' => 1000, 'HEIGHT' => 1000, 'SET_ID' => $arParams['RESIZER_MAX_IMAGE']);
$resizeBrand = array('WIDTH' => 100, 'HEIGHT' => 40, 'SET_ID' => $arParams['RESIZER_BRAND_DETAIL']);

$arResizer = array('THUMB' => $resizeThumb, 'SRC' => $resizeItem, 'BIG' => $resizeBig);
$arParams['OFFER_TREE_PROPS'] = &$arParams['OFFERS_CART_PROPERTIES'];
if (CModule::IncludeModule("catalog"))
Main::prepareSku($arResult, $arParams, $arResizer);
$arItem['GALLERY'] = Main::getGallery($arItem, $arResizer);
Main::processCatalogItem($arItem, $arParams['OFFERS_PROPERTY_CODE']);
Main::preparePropsForCart($arItem, $arParams);

foreach ($arItem['GALLERY'] as $i => &$arPhoto){
	if(empty($arPhoto['TEXT'])){
		$arPhoto['TEXT'] = $arItem['MORE_PHOTO'][$i]['DESCRIPTION'];
		if(empty($arPhoto['TEXT']) || (count($arItem['MORE_PHOTO'])<count($arItem['GALLERY'])))	$arPhoto['TEXT'] = $arItem['NAME'];
	}
}

$arItem['ARTICLE'] = '';
$arItem['ARTICLE_NAME'] = GetMessage('RZ_ARTICLE_NAME');
$strProp = 'CML2_ARTICLE';
if (!empty($arParams['ARTICUL_PROP']) && $arParams['ARTICUL_PROP'] != '-') {
    $strProp = $arParams['ARTICUL_PROP'];
}
$arProp = $arItem['PROPERTIES'][$strProp];
if (!empty($arProp['VALUE'])) {
    $arItem['ARTICLE_NAME'] = $arProp['NAME'];
    if (is_array($arProp['VALUE'])) {
        $arItem['ARTICLE'] = reset($arProp['VALUE']);
    } else {
        $arItem['ARTICLE'] = $arProp['VALUE'];
    }
}

$arParams['USE_FAVORITE'] = $arParams['USE_FAVORITE'] != 'N' && Loader::includeModule('yenisite.favorite');
$arParams['USE_ONECLICK'] = $arParams['USE_ONECLICK'] != 'N' && Loader::includeModule('yenisite.oneclick');

$strProp = 'CML2_MANUFACTURER';
if ('Y' == $arParams['BRAND_USE'] && !empty($arParams['BRAND_PROP_CODE']) && $arParams['BRAND_PROP_CODE'] != '-') {
    $strProp = $arParams['BRAND_PROP_CODE'];
}
$arProp = $arItem['PROPERTIES'][$strProp];
if (!empty($arProp['VALUE'])) {
    $hlblock = \Bitrix\Highloadblock\HighloadBlockTable::getList(
        array(
            "filter" => array(
                'TABLE_NAME' => $arProp['USER_TYPE_SETTINGS']['TABLE_NAME'],
            ),
        )
    )->fetch();
    if ($hlblock) {
        $entity = \Bitrix\Highloadblock\HighloadBlockTable::compileEntity($hlblock);
        $entityDataClass = $entity->getDataClass();
        $arFilter = array('filter' => array('UF_XML_ID' => $arProp['~VALUE']));
        $arHLElement = $entityDataClass::getList($arFilter)->fetch();
        if ($arHLElement) {
            $arResult['BRAND']['URL'] = str_replace('#ID#', $arHLElement['ID'], $arParams['BRAND_DETAIL']);
            $arResult['BRAND']['NAME'] = $arHLElement['UF_NAME'];
            $arResult['BRAND']['DESCRIPTION'] = $arHLElement['UF_DESCRIPTION'];
            $arResult['BRAND']['LOGO'] = Main::GetResizedImg($arHLElement['UF_FILE'], $resizeBrand);
        }
    }
}
if (!empty($arResult['MIN_PRICE']['PRICE_ID'])) $priceID = $arResult['MIN_PRICE']['PRICE_ID'];

$this->__component->setResultCacheKeys(array('MIN_PRICE'));

if (empty($arResult['MIN_PRICE']['PRICE_ID'])) $arResult['MIN_PRICE']['PRICE_ID'] =  $priceID;

if (!empty($arItem['OFFERS'])) {
    foreach ($arItem['OFFERS'] as $keyOffer => $arJSOffer) {
        if (empty($arResult['MIN_PRICE']['PRICE_ID'])) $arResult['MIN_PRICE']['PRICE_ID'] = $arJSOffer['MIN_PRICE']['PRICE_ID'];
        $strProps = '';
        if (!empty($arJSOffer['CATALOG_WEIGHT'])): ?>
           <?$strProps .= '<p class="sku has-icon flaticon-two328">'.GetMessage('WEIGHT').': <b>'.$arJSOffer['CATALOG_WEIGHT'].' '.GetMessage('WEIGHT_MESURE') .'</b></p>';?>
        <? endif ?>

        <?if (!empty($arJSOffer['CATALOG_WIDTH']) || !empty($arJSOffer['CATALOG_HEIGHT']) || !empty($arJSOffer['CATALOG_LENGTH'])): ?>
            <?$strProps .= '<p class="sku has-icon flaticon-ruler12">'.GetMessage('SIZE').':
                <b>';
            if(!empty($arJSOffer['CATALOG_WIDTH'])):
                $strProps .= $arJSOffer['CATALOG_WIDTH'];
            endif;
            if(!empty($arJSOffer['CATALOG_HEIGHT'])):
                $strProps .= ' � '.$arJSOffer['CATALOG_HEIGHT'];
            endif;
            if(!empty($arJSOffer['CATALOG_LENGTH'])):
                $strProps .= ' � '.$arJSOffer['CATALOG_LENGTH'];
            endif;
            $strProps .=' ('.GetMessage('SANTIMETR').')</b></p>'?>
        <? endif ?>

        <? if (!empty($arJSOffer['DISPLAY_PROPERTIES'])) {
            foreach ($arJSOffer['DISPLAY_PROPERTIES'] as $arOneProp) {
                if (empty($arOneProp['VALUE'])) $arOneProp['VALUE'] = $arItem['DISPLAY_PROPERTIES'][$arOneProp['CODE']]['VALUE'];
                if (!empty($arItem['OFFER_PROP'][$arOneProp['CODE']])) continue;
        $class = '';
        $hint = false;
        if (!empty($arOneProp['HINT'])) $hint = true;
                $strProps .= ' <p  class="sku ">';

        if ($hint): ?>
           <?$strProps .= '<span class="property-name">';?>
        <?endif?>
        <?$strProps .= $arOneProp["NAME"].':'?>
        <?if ($hint): ?>
            <?$strProps .='<i class="help-icon" data-tooltip="" data-placement="right" title="" data-original-title="'.$arOneProp['HINT'].'"></i></span>'?>
        <? endif ?>
               <? $strProps .=' '.(
                    is_array($arOneProp['VALUE'])
                    ? implode(' / ', $arOneProp['VALUE'])
                    : $arOneProp['VALUE']
                    );
            $strProps .= '</p>';
                unset($arItem['DISPLAY_PROPERTIES'][$arOneProp['CODE']]);
                unset($arItem['DISPLAY_PROPERTIES'][$arOneProp['CODE']]);
            }
        }
        $arItem['JS_OFFERS']['ITEMS'][$arJSOffer['ID']]['DISPLAY_PROPERTIES'] = $strProps ? : ' ';
        if ($arItem['JS_OFFERS']['ITEMS'][$arJSOffer['ID']]['DISPLAY_PROPERTIES'] != ' ' && ! $arItem['JS_OFFERS_PROPERTIES']) {
            $arItem['JS_OFFERS_PROPERTIES'] = true;
        }
    }
}

if (Main::isCatchBuy()) {
    $arParams['CATCHBUY'] = Main::getCatchBuyList();
}

//Prices for MARKET
if (CModule::IncludeModule('yenisite.furniturelite') && CModule::IncludeModule('yenisite.market')) {
	if(!empty($arItem['PROPERTIES']['MEASURE_NAME']['VALUE_ENUM'])) $arItem['CATALOG_MEASURE_NAME'] = $arItem['PROPERTIES']['MEASURE_NAME']['VALUE_ENUM'];
	$prices = CMarketPrice::GetItemPriceValues($arItem["ID"], $arItem['PRICES']);
	if(count($prices)>0)
		unset ($arItem["PRICES"]);
	$minPrice = false;
	foreach ($prices as $k => $pr) {
		$pr = floatval($pr);
		$arItem["PRICES"][$k]["VALUE"] = $pr;
		$arItem["PRICES"][$k]["PRINT_VALUE"] = $pr;
		if ((empty($minPrice) || $minPrice > $pr) && $pr > 0) {
			$minPrice = $pr;
			$minPriceId = $k;
		}
	}
	if ($minPrice !== false) {
	
		$minPrice = Main::getElementPriceFormat($arItem['MIN_PRICE']['CURRENCY'], $minPrice, $arItem['MIN_PRICE']['PRINT_VALUE']);
		
		$arItem['MIN_PRICE']['PRICE_ID'] = $minPriceId;
		$arItem['MIN_PRICE']['VALUE'] = $minPrice;
		$arItem['MIN_PRICE']['DISCOUNT_VALUE'] = $minPrice;
		$arItem['MIN_PRICE']['PRINT_DISCOUNT_VALUE'] = $minPrice;
		$arItem['CAN_BUY'] = true;
		
	}
	$arItem['CHECK_QUANTITY'] = (CMarketCatalog::UsesQuantity($arParams['IBLOCK_ID']) == 1);

	$arItem['CATALOG_QUANTITY'] = intval($arItem['PROPERTIES']['MARKET_QUANTITY']['VALUE']);
	
	if ($arItem['CHECK_QUANTITY'] && $arItem['CATALOG_QUANTITY'] <= 0) {
		$arItem['CAN_BUY'] = false;
	}

	$arItem['CATALOG_WEIGHT'] = $arItem['PROPERTIES']['CATALOG_WEIGHT']['VALUE'];
	$arItem['CATALOG_TYPE'] = 1; //simple product
}
$arResult['PAID_OPTIONS'] = \Yenisite\Furniture\Main::getElementsFromIblock($arParams['IBLOCK_OPTIONS_ID'],$arResult['MIN_PRICE']['PRICE_ID']);
//end Prices for MARKET