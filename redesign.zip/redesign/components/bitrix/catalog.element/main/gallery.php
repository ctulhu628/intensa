<?$transparent = SITE_TEMPLATE_PATH.'/img/transparent.gif'?>
<div class="gallery-photo-viewer <?= ($galleryID == 'modal-gallery-carousel') ? 'modal-photo-viewer' : 'normal-photo-viewer' ?>">
	<div class="carousel slide gallery-carousel <?= ($galleryID == 'modal-gallery-carousel') ? 'modal-big-img' : '' ?>"
		 id="<?= $galleryID ?>" data-interval="false">
		<div class="carousel-inner <?= ($galleryID == 'modal-gallery-carousel') ? 'modal-dialog' : '' ?>" id="<?= $galleryID ?>_src">
			<? foreach ($arItem['GALLERY'] as $i => &$arPhoto): ?>
				<div class="item<?= ($i == 0) ? ' active' : '' ?>">
					<?
					$SRC = $arPhoto['SRC'];
					if ($galleryID == 'modal-gallery-carousel') {
						$SRC = $arPhoto['BIG'];
					} ?>
						<img class="gallery-zoom gallery-carousel-image" src="<?=($galleryID == 'modal-gallery-carousel') ? $transparent : $SRC; ?>" data-zoom-image="<?=$SRC?>" alt="<?= $productTitle, $i ?>">
					<? if ($galleryID == 'modal-gallery-carousel'): ?>
						<div class="modal-gallery-item-caption<?= $arPhoto['TEXT'] ? '' : ' hidden' ?>"><?= $arPhoto['TEXT'] ?></div>
					<? endif ?>
				</div>
			<? endforeach ?>
			<a class="left carousel-control<?= (count($arResult['GALLERY']) <= 1) ? ' hidden' : '' ?>" href="#<?= $galleryID ?>" role="button" data-slide="prev">
		        <span class="glyphicon glyphicon-chevron-left" aria-hidden="true">
		        	<span class="cbutton cbutton--effect-lazar cbutton--effect-lazar-inverted"></span>
		        </span>
				<span class="sr-only">Previous</span>
			</a>
			<a class="right carousel-control<?= (count($arResult['GALLERY']) <= 1) ? ' hidden' : '' ?>" href="#<?= $galleryID ?>" role="button" data-slide="next">
		        <span class="glyphicon glyphicon-chevron-right" aria-hidden="true">
		        	<span class="cbutton cbutton--effect-lazar"></span>
		        </span>
				<span class="sr-only">Next</span>
			</a>
			<? if ($galleryID != 'modal-gallery-carousel'): ?>
				<div data-slide-zoom="0" class="btn-zoom three-color-p flaticon-zoom61" data-toggle="modal" data-target="#modal-gallery"></div>
				<? /* todo: detail gallery 3D model
				<button class="three-color-p btn-3d flaticon-3d80"><?= GetMessage("RZ_3D_MODEL") ?></button>
				*/ ?>
			<? endif ?>
		</div>
	</div>
	<div class="thumbs <?= ($galleryID == 'modal-gallery-carousel') ? 'modal-thumbs' : 'normal-thumbs' ?><?= (count($arResult['GALLERY']) <= 1) ? ' hidden' : '' ?>">
		<div class="thumbs-wrap" data-breakpoint="<?= ($galleryID == 'modal-gallery-carousel') ? 100000 : 1199 ?>">
			<div class="thumbs-inner" id="<?= $galleryID ?>_thumb">
				<? foreach ($arItem['GALLERY'] as $i => &$arPhoto): ?>
					<div class="thumb<?= ($i == 0) ? ' active' : '' ?>" data-target="#<?= $galleryID ?>" data-slide-to="<?= $i ?>">
					<?if(count($arItem['GALLERY']) > 1):?>
						<img src="<?= $arPhoto['THUMB'] ?>" alt="<?= $productTitle, $i ?>" class="thumb-image gallery-carousel-image">
					<?endif?>
					</div>
				<? endforeach ?>
			</div>
		</div>
		<button class="thumbs-control up flaticon-left207<?= (count($arResult['GALLERY']) <= 1) ? ' hidden' : '' ?>"></button>
		<button class="thumbs-control down flaticon-right218<?= (count($arResult['GALLERY']) <= 1) ? ' hidden' : '' ?>"></button>
	</div>
</div>