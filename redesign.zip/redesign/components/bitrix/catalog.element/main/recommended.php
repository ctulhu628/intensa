<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();
if (Bitrix\Main\Loader::includeModule('catalog')):
$APPLICATION->IncludeComponent(
	"bitrix:catalog.recommended.products",
	"furniture",
	Array(
		"IBLOCK_TYPE" => $arParams["IBLOCK_TYPE"],
		"IBLOCK_ID" => $arParams["IBLOCK_ID"],
		"ID" => $arResult['ID'],
		"PROPERTY_LINK" => "RECOMMEND",
		"SHOW_PRODUCTS_".$arParams["IBLOCK_ID"] => "Y",///////////
		"CACHE_TYPE" => $arParams["CACHE_TYPE"],
		"CACHE_TIME" => $arParams["CACHE_TIME"],
		"BASKET_URL" => $arParams["BASKET_URL"],
		"ACTION_VARIABLE" => $arParams["ACTION_VARIABLE"],
		"PRODUCT_ID_VARIABLE" => $arParams["PRODUCT_ID_VARIABLE"],
		"PRODUCT_QUANTITY_VARIABLE" => $arParams["PRODUCT_QUANTITY_VARIABLE"],
		"ADD_PROPERTIES_TO_BASKET" => (isset($arParams["ADD_PROPERTIES_TO_BASKET"]) ? $arParams["ADD_PROPERTIES_TO_BASKET"] : ''),
		"PRODUCT_PROPS_VARIABLE" => $arParams["PRODUCT_PROPS_VARIABLE"],
		"PARTIAL_PRODUCT_PROPERTIES" => (isset($arParams["PARTIAL_PRODUCT_PROPERTIES"]) ? $arParams["PARTIAL_PRODUCT_PROPERTIES"] : ''),
		"PAGE_ELEMENT_COUNT" => $arParams["PAGE_ELEMENT_COUNT"],
		"SHOW_OLD_PRICE" => $arParams['SHOW_OLD_PRICE'],
		"SHOW_DISCOUNT_PERCENT" => $arParams['SHOW_DISCOUNT_PERCENT'],
		"PRICE_CODE" => $arParams["PRICE_CODE"],
		"SHOW_PRICE_COUNT" => $arParams["SHOW_PRICE_COUNT"],
		"PRODUCT_SUBSCRIPTION" => 'N',
		"PRICE_VAT_INCLUDE" => $arParams["PRICE_VAT_INCLUDE"],
		"USE_PRODUCT_QUANTITY" => $arParams['USE_PRODUCT_QUANTITY'],
		"CART_PROPERTIES_{$arParams['IBLOCK_ID']}" => $arParams['PRODUCT_PROPERTIES'],
		"SHOW_NAME" => "Y",
		"SHOW_IMAGE" => "Y",
		'MESS_BTN_BUY' => $arParams['MESS_BTN_BUY'],
		'MESS_BTN_ADD_TO_BASKET' => $arParams['MESS_BTN_ADD_TO_BASKET'],
		'MESS_BTN_SUBSCRIBE' => $arParams['MESS_BTN_SUBSCRIBE'],
		'MESS_BTN_COMPARE' => $arParams['MESS_BTN_COMPARE'],
		'MESS_NOT_AVAILABLE' => $arParams['MESS_NOT_AVAILABLE'],
		"HIDE_NOT_AVAILABLE" => $arParams["SLIDERS_HIDE_NOT_AVAILABLE"],

		//sku:
		'PRODUCT_DISPLAY_MODE' => $arParams['PRODUCT_DISPLAY_MODE'],
		'OFFER_ADD_PICT_PROP' => $arParams['OFFER_ADD_PICT_PROP'],
		"OFFERS_CART_PROPERTIES" => $arParams["OFFERS_CART_PROPERTIES"],
		"OFFERS_FIELD_CODE" => $arParams["DETAIL_OFFERS_FIELD_CODE"],
		"OFFERS_PROPERTY_CODE" => array_merge($arParams["OFFERS_CART_PROPERTIES"], $arParams["DETAIL_OFFERS_PROPERTY_CODE"]),
		"OFFERS_SORT_FIELD" => $arParams["OFFERS_SORT_FIELD"],
		"OFFERS_SORT_ORDER" => $arParams["OFFERS_SORT_ORDER"],
		"OFFERS_SORT_FIELD2" => $arParams["OFFERS_SORT_FIELD2"],
		"OFFERS_SORT_ORDER2" => $arParams["OFFERS_SORT_ORDER2"],
		"OFFER_VAR_NAME" => $arParams["OFFER_VAR_NAME"],
		"ADD_PARENT_PHOTO" => $arParams["ADD_PARENT_PHOTO"],
		"ADDITIONAL_PICT_PROP_".$arParams["IBLOCK_ID"] => $arParams['ADD_PICT_PROP'],

		"CONVERT_CURRENCY" => $arParams["CONVERT_CURRENCY"],
		"CURRENCY_ID" => $arParams["CURRENCY_ID"],
		"RESIZER_THUMB" => $arParams['RESIZER_THUMB'],
		"RESIZER_IMAGE" => $arParams['RESIZER_IMAGE'],
		'COMPARE_PATH' => $arParams['COMPARE_PATH'],
		'SHOW_CATCH_BUY' => $arParams['SHOW_CATCH_BUY'],
		'USE_ONECLICK' => $arParams['USE_ONECLICK'],
		'TITLE_RECOMMEND' => $arParams['TITLE_RECOMMEND'],
		'SHOW_THUMBS' => $arParams['SHOW_THUMBS'],
		'SHOW_ONE_CLICK' => $arParams['SHOW_ONE_CLICK'],

		//articul:
		"ARTICUL_PROP" => $arParams['ARTICUL_PROP'],
	),
	$component
);
endif;
