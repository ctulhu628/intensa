$(function () {
//	requires
//------------------------------
//	jQuery
//	spin.js
//	sly.js
//	bootstrap carousel.js
//	jquery.mobile.just-touch.min.js
//		or another lib with swipeleft/swiperight events support

//	resizeHandlers in globals
//------------------------------
	"use strict";
	window.RZ_onFilterSKU = function () {
		var $form = this;
		$form.find('select').each(function () {
			$(this).data('selectfx').refresh();
		});
	};

	window.RZ_skuGalleryChange = function (el) {
		var offer = this;
		if ('GALLERY' in this && $.isArray(this.GALLERY)) {
			var activeCache = {};


			var templateIt = function (NAME, SRC, OBJ, template, MODAL) {
				var result = '';
				if (NAME in el && el[NAME].length && SRC in OBJ && OBJ[SRC].length) {
					template = template.replace('#ACTIVE#', (activeCache[NAME]) ? '' : ' active');
					if (MODAL && typeof offer.TRANSPARENT !='undefined' && activeCache[NAME]) {
						template = template.replace('#BIG#', OBJ[SRC]);
						template = template.replace('#SRC#', offer.TRANSPARENT);
					} else if(MODAL && typeof offer.TRANSPARENT !='undefined' && !activeCache[NAME]){
                        template = template.replace('#BIG#', OBJ[SRC]);
                        template = template.replace('#SRC#', OBJ[SRC]);
					}
					else{
						template = template.replace('#SRC#', OBJ[SRC]);
					}
                    activeCache[NAME] = true;
					result += template;
				}
				return result;
			};
			var galSRC = '',
				galThumb = '',
				galModalSrc = '',
				galModalThumb = '',
				total = 0;

			var galleryID = el.GALLERY_SRC.selector.replace(/_src$/, ''),
				galleryIDModal = el.GALLERY_MODAL_SRC.selector.replace(/_src$/, '');

			this.GALLERY.forEach(function (obj) {
				galSRC += templateIt('GALLERY_SRC', 'SRC', obj, '<div class="item#ACTIVE#"><img class="gallery-zoom gallery-carousel-image" src="#SRC#" data-zoom-image="#BIG#" alt=""></div>', false);
				galThumb += templateIt('GALLERY_THUMB', 'THUMB', obj, '<div class="thumb#ACTIVE#" data-target="' + galleryID + '" data-slide-to="' + total + '"><img src="#SRC#" alt=""></div>', false);
				galModalSrc += templateIt('GALLERY_MODAL_SRC', 'SRC', obj, '<div class="item#ACTIVE#"><img class="gallery-zoom gallery-carousel-image" src="#SRC#" data-zoom-image="#BIG#" alt=""></div>', true);
				galModalThumb += templateIt('GALLERY_MODAL_THUMB', 'THUMB', obj, '<div class="thumb#ACTIVE#" data-target="' + galleryIDModal + '" data-slide-to="' + total + '"><img src="#SRC#" alt=""></div>', false);
				total++;
			});

			if (galSRC.length) {
				if (this.GALLERY.length > 1){
                    galSRC += '<a class="left carousel-control" href="' + galleryID + '" role="button" data-slide="prev"><span class="glyphicon glyphicon-chevron-left" aria-hidden="true"><span class="cbutton cbutton--effect-lazar cbutton--effect-lazar-inverted"></span></span><span class="sr-only">Previous</span></a>' +
                        '<a class="right carousel-control" href="' + galleryID + '" role="button" data-slide="next"><span class="glyphicon glyphicon-chevron-right" aria-hidden="true"><span class="cbutton cbutton--effect-lazar"></span></span><span class="sr-only">Next</span></a>';
				}
				galSRC += '<div class="btn-zoom three-color-p flaticon-zoom61" data-toggle="modal" data-target="#modal-gallery"></div>';
				el.GALLERY_SRC.html(galSRC);
				initDialogs(el.GALLERY_SRC);
			}
			if (galThumb.length) {
				el.GALLERY_THUMB.html(galThumb);
			}
			if (galModalSrc.length) {
                if (this.GALLERY.length > 1){
                    galModalSrc += '<a class="left carousel-control" href="' + galleryIDModal + '" role="button" data-slide="prev"><span class="glyphicon glyphicon-chevron-left" aria-hidden="true"><span class="cbutton cbutton--effect-lazar cbutton--effect-lazar-inverted"></span></span><span class="sr-only">Previous</span></a>' +
                        '<a class="right carousel-control" href="' + galleryIDModal + '" role="button" data-slide="next"><span class="glyphicon glyphicon-chevron-right" aria-hidden="true"><span class="cbutton cbutton--effect-lazar"></span></span><span class="sr-only">Next</span></a>';
                }

				el.GALLERY_MODAL_SRC.html(galModalSrc);
			}
			if (galModalThumb.length) {
				el.GALLERY_MODAL_THUMB.html(galModalThumb);
			}
			if ('GALLERY_TOTAL' in el && el.GALLERY_TOTAL.length) {
				el.GALLERY_TOTAL.text(total);
			}

			var $thumbWrap = el.GALLERY_THUMB.closest('.gallery-thumbs');
			if (total <= 1) {
				$thumbWrap.addClass('hidden');
			} else {
				$thumbWrap.removeClass('hidden');
			}

			$thumbWrap = el.GALLERY_MODAL_THUMB.closest('.gallery-thumbs');
			if (total <= 1) {
				$thumbWrap.addClass('hidden');
			} else {
				$thumbWrap.removeClass('hidden');
			}

			$(".thumbs-wrap:visible, .modal .thumbs-wrap").each(function () {
				initVSly(this);
			});
		}
	};

});
