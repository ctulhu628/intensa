<?
/**
 * @var array $arParams
 * @var array $arResult
 * @var array $arItem
 * @var CUser $USER
 * @var CBitrixComponent $component
 */
?>
<? $APPLICATION->IncludeComponent(
	'yenisite:feedback.add',
	'catalog',
	array(
		'IBLOCK_TYPE' => $arParams['FEEDBACK_IBLOCK_TYPE'],
		'IBLOCK' => $arParams['FEEDBACK_IBLOCK_ID'],
		'NAME_FIELD' => 'NAME',
		'SUCCESS_TEXT' => $arParams['FEEDBACK_SUCCESS_TEXT'],
		'USE_CAPTCHA' => $USER->IsAuthorized() ? 'N' : 'Y',
		'SHOW_SECTIONS' => 'N',
		'PRINT_FIELDS' => array(
			0 => 'NAME',
			1 => 'ELEMENT_ID',
		),
		'AJAX_MODE' => 'Z',
		'CACHE_TYPE' => 'A',
		'CACHE_TIME' => '300',
		'ACTIVE' => 'N',
		'EVENT_NAME' => '',
		'TEXT_REQUIRED' => 'Y',
		'TEXT_SHOW' => 'Y',
		'NAME' => 'NAME',
		'PHONE' => '',
		'EMPTY' => '',
		'SECTION_CODE' => 'ITEM_REVIEW_' . $arItem['ID'],
		'ELEMENT_ID' => $arItem['ID'],
		'AJAX_OPTION_JUMP' => 'N',
		'AJAX_OPTION_STYLE' => 'N',
		'AJAX_OPTION_HISTORY' => 'N',
	),
	$component,
	array(
		'HIDE_ICONS' => 'N',
	)
);
?>
<div class="media">
#FEEDBACK_LIST#
</div>