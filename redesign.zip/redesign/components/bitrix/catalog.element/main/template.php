<?
/**
 * @var CBitrixComponentTemplate $this
 */
use Yenisite\Core\Tools;
use Yenisite\Furniture\Form;
use Yenisite\Furniture\Main;

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
$this->setFrameMode(true);
$isAjax = \Yenisite\Core\Ajax::isAjax();
$arItem = &$arResult;
$bHasSKU = $arResult['OFFERS'] ? true : false;
if (empty($arItem['ID'])) return;
$productTitle = $arResult["IPROPERTY_VALUES"]["ELEMENT_PAGE_TITLE"] ?: $arResult["NAME"];

$arCatchBuy = $arParams['OFFER_ID'] ? $arParams['CATCHBUY'][$arParams['OFFER_ID']] : $arParams['CATCHBUY'][$arResult['ID']];
$bTimer = !empty($arCatchBuy['ACTIVE_TO']);
$bProgressBar = $arCatchBuy['MAX_USES'] > 0;

if (!$arParams['SHOW_CATCH_BUY']) {
    $bTimer = false;
    $bProgressBar = false;
};
$arCatchBuy['PERCENT'] = ($bProgressBar) ? $arCatchBuy['COUNT_USES'] / $arCatchBuy['MAX_USES'] * 100 : 0;

$arJsCache = \Yenisite\Furniture\Main::getJSCache($component);
$_SESSION['RZ_DETAIL_JS_FILE'] = $arJsCache['file'];
$templateData['jsFile'] = $arJsCache['path'].'/'.$arJsCache['idJS'];
$templateData['jsFullPath'] = $arJsCache['path-full'];


$rnd = $this->randString();
$arIDs = array(
    'FORM' => 'form_' . $rnd . '_' . $arItem['ID'],
    'BUY_BUTTON' => 'button_' . $rnd . '_' . $arItem['ID'],
    'PRICE' => 'current_price',
    'OLD_PRICE' => 'old_price_' . $rnd . '_' . $arItem['ID'],
    'OLD_PRICE_CONTAINER' => 'old_price_' . $rnd . '_' . $arItem['ID'] . '_container',
    'DISCOUNT_PERCENT_CONTAINER' => 'price_percent' . $rnd . '_' . $arItem['ID'] . '_container',
    'DISCOUNT_PERCENT' => 'price_percent' . $rnd . '_' . $arItem['ID'],
    'BUY_ONECLICK' => 'button_one_click' . $rnd . '_' . $arItem['ID'],
    'GALLERY_SRC' => 'gallery-carousel_src',
    'GALLERY_THUMB' => 'gallery-carousel_thumb',
    'GALLERY_MODAL_SRC' => 'modal-gallery-carousel_src',
    'GALLERY_MODAL_THUMB' => 'modal-gallery-carousel_thumb',
    'STORE_AMOUNT' => 'store-amount_' . $rnd . '_' . $arItem['ID'],
    'COUNTDOWN_CONT' => 'count_down_' . $rnd . '_' . $arItem['ID'],
    'DETAIL_CONT' => $ajID,
    'ARTICUL' => 'article_' . $rnd . '_' . $arItem['ID'],
);

$strObName = 'RZSkuItem'.$arItem['ID'];
$templateData['strObName'] = $strObName;
?>

<section class="block-padd">
  <div class="container">
    <nav class="d-none d-lg-block" aria-label="breadcrumb">
      <ol class="breadcrumb">
        <li class="breadcrumb-item" aria-current="page"><a href="#">Главная</a></li>
        <li class="breadcrumb-item" aria-current="page"><a href="#">Каталог</a></li>
        <li class="breadcrumb-item" aria-current="page"><a href="#">Офисная мебель</a></li>
        <li class="breadcrumb-item" aria-current="page"><a href="#">Кабинеты руководителей</a></li>
        <li class="breadcrumb-item" aria-current="page"><a href="#">Бизнес класс</a></li>
        <li class="breadcrumb-item" aria-current="page"><a href="#">Кресла</a></li>
        <li class="breadcrumb-item active" aria-current="page">КРЕСЛО "ВЕНТА"</li>
      </ol>
    </nav>

    <div class="pageccard">
      <div class="h1 d-lg-none"><?= $productTitle ?></div>
      <div class="pageccard-lcolumn">
        <div class="swiper-container pageccard-imgssl">
          <div class="swiper-wrapper">
            <!-- th-->
            <div class="swiper-slide pageccard-imgssl-el"><a class="pageccard-imgssl-link" href="<?= SITE_TEMPLATE_PATH ?>/assets/images/content/goods/img-g-00.jpg" data-fancybox="images"><img src="<?= SITE_TEMPLATE_PATH ?>/assets/images/content/goods/img-g-00.jpg" alt=""></a></div>
            <!-- /th-->
            <!-- th-->
            <div class="swiper-slide pageccard-imgssl-el"><a class="pageccard-imgssl-link" href="<?= SITE_TEMPLATE_PATH ?>/assets/images/content/goods/img-g-00.jpg" data-fancybox="images"><img src="<?= SITE_TEMPLATE_PATH ?>/assets/images/content/goods/img-g-01.jpg" alt=""></a></div>
            <!-- /th-->
            <!-- th-->
            <div class="swiper-slide pageccard-imgssl-el"><a class="pageccard-imgssl-link" href="<?= SITE_TEMPLATE_PATH ?>/assets/images/content/goods/img-g-00.jpg" data-fancybox="images"><img src="<?= SITE_TEMPLATE_PATH ?>/assets/images/content/goods/img-g-02.jpg" alt=""></a></div>
            <!-- /th-->
            <!-- th-->
            <div class="swiper-slide pageccard-imgssl-el"><a class="pageccard-imgssl-link" href="<?= SITE_TEMPLATE_PATH ?>/assets/images/content/goods/img-g-00.jpg" data-fancybox="images"><img src="<?= SITE_TEMPLATE_PATH ?>/assets/images/content/goods/img-g-03.jpg" alt=""></a></div>
            <!-- /th-->
            <!-- th-->
            <div class="swiper-slide pageccard-imgssl-el"><a class="pageccard-imgssl-link" href="<?= SITE_TEMPLATE_PATH ?>/assets/images/content/goods/img-g-00.jpg" data-fancybox="images"><img src="<?= SITE_TEMPLATE_PATH ?>/assets/images/content/goods/img-g-00.jpg" alt=""></a></div>
            <!-- /th-->
            <!-- th-->
            <div class="swiper-slide pageccard-imgssl-el"><a class="pageccard-imgssl-link" href="<?= SITE_TEMPLATE_PATH ?>/assets/images/content/goods/img-g-00.jpg" data-fancybox="images"><img src="<?= SITE_TEMPLATE_PATH ?>/assets/images/content/goods/img-g-01.jpg" alt=""></a></div>
            <!-- /th-->
            <!-- th-->
            <div class="swiper-slide pageccard-imgssl-el"><a class="pageccard-imgssl-link" href="<?= SITE_TEMPLATE_PATH ?>/assets/images/content/goods/img-g-00.jpg" data-fancybox="images"><img src="<?= SITE_TEMPLATE_PATH ?>/assets/images/content/goods/img-g-02.jpg" alt=""></a></div>
            <!-- /th-->
            <!-- th-->
            <div class="swiper-slide pageccard-imgssl-el"><a class="pageccard-imgssl-link" href="<?= SITE_TEMPLATE_PATH ?>/assets/images/content/goods/img-g-00.jpg" data-fancybox="images"><img src="<?= SITE_TEMPLATE_PATH ?>/assets/images/content/goods/img-g-03.jpg" alt=""></a></div>
            <!-- /th-->
          </div>
        </div>
        <div class="swiper-container pageccard-previewsl">
          <div class="swiper-wrapper">
            <!-- th-->
            <div class="swiper-slide pageccard-previewsl-el"><span class="pageccard-previewsl-link"><img src="<?= SITE_TEMPLATE_PATH ?>/assets/images/content/goods/img-g-00.jpg" alt=""></span></div>
            <!-- /th-->
            <!-- th-->
            <div class="swiper-slide pageccard-previewsl-el"><span class="pageccard-previewsl-link"><img src="<?= SITE_TEMPLATE_PATH ?>/assets/images/content/goods/img-g-01.jpg" alt=""></span></div>
            <!-- /th-->
            <!-- th-->
            <div class="swiper-slide pageccard-previewsl-el"><span class="pageccard-previewsl-link"><img src="<?= SITE_TEMPLATE_PATH ?>/assets/images/content/goods/img-g-02.jpg" alt=""></span></div>
            <!-- /th-->
            <!-- th-->
            <div class="swiper-slide pageccard-previewsl-el"><span class="pageccard-previewsl-link"><img src="<?= SITE_TEMPLATE_PATH ?>/assets/images/content/goods/img-g-03.jpg" alt=""></span></div>
            <!-- /th-->
            <!-- th-->
            <div class="swiper-slide pageccard-previewsl-el"><span class="pageccard-previewsl-link"><img src="<?= SITE_TEMPLATE_PATH ?>/assets/images/content/goods/img-g-00.jpg" alt=""></span></div>
            <!-- /th-->
            <!-- th-->
            <div class="swiper-slide pageccard-previewsl-el"><span class="pageccard-previewsl-link"><img src="<?= SITE_TEMPLATE_PATH ?>/assets/images/content/goods/img-g-01.jpg" alt=""></span></div>
            <!-- /th-->
            <!-- th-->
            <div class="swiper-slide pageccard-previewsl-el"><span class="pageccard-previewsl-link"><img src="<?= SITE_TEMPLATE_PATH ?>/assets/images/content/goods/img-g-02.jpg" alt=""></span></div>
            <!-- /th-->
            <!-- th-->
            <div class="swiper-slide pageccard-previewsl-el"><span class="pageccard-previewsl-link"><img src="<?= SITE_TEMPLATE_PATH ?>/assets/images/content/goods/img-g-03.jpg" alt=""></span></div>
            <!-- /th-->
          </div>
          <div class="swiper-button swiper-button-prev"></div>
          <div class="swiper-button swiper-button-next"></div>
        </div>
      </div>
      <div class="pageccard-content">
        <div class="pageccard-body">
          <div class="h1 d-none d-lg-block"><?= $productTitle ?></div>
          <div class="pageccard-item">
            <?php if ($arItem['CAN_BUY']): ?>
              <div class="pageccard-stock in">В наличии</div>
            <?php else: ?>
              <div class="pageccard-stock out">Нет в наличии</div>
            <?php endif ?>
          </div>
          <div class="pageccard-item">
            <div class="pageccard-tocart">
              <div class="row align-items-center">
                <div class="col-12 col-sm-auto">
                  <div class="pageccard-price">
                    <?php if ($arItem['MIN_PRICE']['PRINT_VALUE']): ?>
                    <div class="pageccard-price-old"><?= $arItem['MIN_PRICE']['PRINT_VALUE'] ?></div>
                    <?php endif ?>
                    <div class="pageccard-price-new"><?= $arItem['MIN_PRICE']['PRINT_DISCOUNT_VALUE'] ?></div>
                  </div>
                </div>
                <div class="col-auto">
                  <div class="pageccard-number">
                    <input class="number-styled" type="number" value="1" min="1">
                  </div>
                </div>
                <div class="col-auto"><a class="mbtn mbtn-primary addcart" href="#"><span>В корзину</span></a></div>
              </div>
            </div>
          </div>
          <div class="pageccard-item">
            <div class="pageccard-title">Доступные цвета</div>
            <ul class="pageccard-listcolors">
              <li>
                <label>
                  <input type="radio" name="colors" checked="checked"><span data-container="body" data-placement="top" data-content="Название цвета"><span style="background-image: url('<?= SITE_TEMPLATE_PATH ?>/assets/images/content/colors/img-c-00.png');"></span></span>
                </label>
              </li>
              <li>
                <label>
                  <input type="radio" name="colors"><span data-container="body" data-placement="top" data-content="Название цвета"><span style="background-image: url('<?= SITE_TEMPLATE_PATH ?>/assets/images/content/colors/img-c-01.png');"></span></span>
                </label>
              </li>
              <li>
                <label>
                  <input type="radio" name="colors"><span data-container="body" data-placement="top" data-content="Название цвета"><span style="background-image: url('<?= SITE_TEMPLATE_PATH ?>/assets/images/content/colors/img-c-02.png');"></span></span>
                </label>
              </li>
              <li>
                <label>
                  <input type="radio" name="colors"><span data-container="body" data-placement="top" data-content="Название цвета"><span style="background-image: url('<?= SITE_TEMPLATE_PATH ?>/assets/images/content/colors/img-c-03.png');"></span></span>
                </label>
              </li>
              <li>
                <label>
                  <input type="radio" name="colors"><span data-container="body" data-placement="top" data-content="Название цвета"><span style="background-image: url('<?= SITE_TEMPLATE_PATH ?>/assets/images/content/colors/img-c-04.png');"></span></span>
                </label>
              </li>
              <li>
                <label>
                  <input type="radio" name="colors"><span data-container="body" data-placement="top" data-content="Название цвета"><span style="background-image: url('<?= SITE_TEMPLATE_PATH ?>/assets/images/content/colors/img-c-05.png');"></span></span>
                </label>
              </li>
              <li>
                <label>
                  <input type="radio" name="colors"><span data-container="body" data-placement="top" data-content="Название цвета"><span style="background-image: url('<?= SITE_TEMPLATE_PATH ?>/assets/images/content/colors/img-c-06.png');"></span></span>
                </label>
              </li>
              <li>
                <label>
                  <input type="radio" name="colors"><span data-container="body" data-placement="top" data-content="Название цвета"><span style="background-image: url('<?= SITE_TEMPLATE_PATH ?>/assets/images/content/colors/img-c-07.png');"></span></span>
                </label>
              </li>
              <li>
                <label>
                  <input type="radio" name="colors"><span data-container="body" data-placement="top" data-content="Название цвета"><span style="background-image: url('<?= SITE_TEMPLATE_PATH ?>/assets/images/content/colors/img-c-08.png');"></span></span>
                </label>
              </li>
              <li>
                <label>
                  <input type="radio" name="colors"><span data-container="body" data-placement="top" data-content="Название цвета"><span style="background-image: url('<?= SITE_TEMPLATE_PATH ?>/assets/images/content/colors/img-c-09.png');"></span></span>
                </label>
              </li>
              <li>
                <label>
                  <input type="radio" name="colors"><span data-container="body" data-placement="top" data-content="Название цвета"><span style="background-image: url('<?= SITE_TEMPLATE_PATH ?>/assets/images/content/colors/img-c-10.png');"></span></span>
                </label>
              </li>
              <li>
                <label>
                  <input type="radio" name="colors"><span data-container="body" data-placement="top" data-content="Название цвета"><span style="background-image: url('<?= SITE_TEMPLATE_PATH ?>/assets/images/content/colors/img-c-01.png');"></span></span>
                </label>
              </li>
              <li>
                <label>
                  <input type="radio" name="colors"><span data-container="body" data-placement="top" data-content="Название цвета"><span style="background-image: url('<?= SITE_TEMPLATE_PATH ?>/assets/images/content/colors/img-c-02.png');"></span></span>
                </label>
              </li>
              <li>
                <label>
                  <input type="radio" name="colors"><span data-container="body" data-placement="top" data-content="Название цвета"><span style="background-image: url('<?= SITE_TEMPLATE_PATH ?>/assets/images/content/colors/img-c-03.png');"></span></span>
                </label>
              </li>
              <li>
                <label>
                  <input type="radio" name="colors"><span data-container="body" data-placement="top" data-content="Название цвета"><span style="background-image: url('<?= SITE_TEMPLATE_PATH ?>/assets/images/content/colors/img-c-04.png');"></span></span>
                </label>
              </li>
              <li>
                <label>
                  <input type="radio" name="colors"><span data-container="body" data-placement="top" data-content="Название цвета"><span style="background-image: url('<?= SITE_TEMPLATE_PATH ?>/assets/images/content/colors/img-c-05.png');"></span></span>
                </label>
              </li>
              <li>
                <label>
                  <input type="radio" name="colors"><span data-container="body" data-placement="top" data-content="Название цвета"><span style="background-image: url('<?= SITE_TEMPLATE_PATH ?>/assets/images/content/colors/img-c-06.png');"></span></span>
                </label>
              </li>
              <li>
                <label>
                  <input type="radio" name="colors"><span data-container="body" data-placement="top" data-content="Название цвета"><span style="background-image: url('<?= SITE_TEMPLATE_PATH ?>/assets/images/content/colors/img-c-07.png');"></span></span>
                </label>
              </li>
              <li>
                <label>
                  <input type="radio" name="colors"><span data-container="body" data-placement="top" data-content="Название цвета"><span style="background-image: url('<?= SITE_TEMPLATE_PATH ?>/assets/images/content/colors/img-c-08.png');"></span></span>
                </label>
              </li>
              <li>
                <label>
                  <input type="radio" name="colors"><span data-container="body" data-placement="top" data-content="Название цвета"><span style="background-image: url('<?= SITE_TEMPLATE_PATH ?>/assets/images/content/colors/img-c-09.png');"></span></span>
                </label>
              </li>
              <li>
                <label>
                  <input type="radio" name="colors"><span data-container="body" data-placement="top" data-content="Название цвета"><span style="background-image: url('<?= SITE_TEMPLATE_PATH ?>/assets/images/content/colors/img-c-10.png');"></span></span>
                </label>
              </li>
            </ul>
          </div>
          <div class="pageccard-item">
            <div class="textdes">
              <div class="textdes-title">Описание</div><a class="textdes-link" href="#"><span>Описание</span></a>
              <div class="textdes-slide">
                <ul>
                  <li>Ламинированная ДСтП, кромка ПВХ</li>
                  <li>Топ, каркас шкафа и&nbsp;полки – 25&nbsp;мм, кромка ПВХ 0,4&nbsp;мм</li>
                  <li>Двери шкафа – 18&nbsp;мм, кромка ПВХ 0,4&nbsp;мм.</li>
                  <li>Профиль МДФ 30&nbsp;мм</li>
                  <li>Ручки – пластиковые, цвет – черный</li>
                  <li>Изделие является стенкой из&nbsp;двух закрытых шкафов и&nbsp;узкого стеллажа для документов под общим топом</li>
                  <li>Каждая из секций шкафа имеет регулировочные опоры и&nbsp;1&nbsp;регулируемую по&nbsp;высоте полку</li>
                  <li>Проемы каждой секции шкафа обеспечивают размещение стандартных папок CORONA высотой 320&nbsp;мм</li>
                  <li>Отделка топа, нижнего щита, промежуточной и&nbsp;боковых стенок декоративным профилем МДФ</li>
                  <li>Шкаф укомплектован четырьмя дверями из ЛДСтП без замка</li>
                  <li>Задняя стенка изготовлена из ЛДСтП 10&nbsp;мм и&nbsp;установлена в&nbsp;пазы корпуса каждой секции</li>
                  <li>Шкаф собирается с&nbsp;использованием фурнитуры для многократной сборки</li>
                  <li>Шкаф поставляется в&nbsp;разобранном виде</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="page-line"></div>
    <? Tools::IncludeAreaEdit('index', 'recommend-list') ?>
    <!-- goods hits-->
    <div class="ptitle row justify-content-center">
      <div class="col-auto">
        <div class="h2">Вы уже смотрели</div>
      </div>
    </div>
    <div class="swiper-container goods-sl goods-slhits">
      <div class="swiper-wrapper">
        <!-- el-->
        <div class="swiper-slide goods-sl-el">
          <div class="ccard">
            <div class="ccard-body">
              <div class="marker"><span class="new">new</span><span class="sale">sale</span><span class="hit">hit</span></div><a class="ccard-name" href="#"><span>Шкаф для документов «‎Премьер»</span></a><a class="ccard-img" href="#"><img src="<?= SITE_TEMPLATE_PATH ?>/assets/images/content/goods/img-g-00.jpg" alt=""></a>
              <div class="ccard-des">Размеры (ШxГxВ): 850х750х680</div>
              <div class="ccard-price">
                <div class="ccard-price-old">20 000 руб.</div>
                <div class="ccard-price-new">14 860 руб.</div>
              </div>
            </div>
            <div class="ccard-popup"><a class="mbtn mbtn-primary addcart" href="#"><span>В&nbsp;корзину</span></a></div>
          </div>
        </div>
        <!-- /el-->
        <!-- el-->
        <div class="swiper-slide goods-sl-el">
          <div class="ccard">
            <div class="ccard-body">
              <div class="marker"><span class="new">new</span>
                <!--span.sale sale-->
                <!--span.hit hit-->
              </div><a class="ccard-name" href="#"><span>Стол брифинг «‎Премьер»</span></a><a class="ccard-img" href="#"><img src="<?= SITE_TEMPLATE_PATH ?>/assets/images/content/goods/img-g-01.jpg" alt=""></a>
              <div class="ccard-des">Размеры (ШxГxВ): 850х750х680</div>
              <div class="ccard-price">
                <div class="ccard-price-new">14 860 руб.</div>
              </div>
            </div>
            <div class="ccard-popup"><a class="mbtn mbtn-primary addcart" href="#"><span>В&nbsp;корзину</span></a></div>
          </div>
        </div>
        <!-- /el-->
        <!-- el-->
        <div class="swiper-slide goods-sl-el">
          <div class="ccard">
            <div class="ccard-body">
              <!--.marker-->
              <!--  span.new new-->
              <!--  span.sale sale-->
              <!--  span.hit hit--><a class="ccard-name" href="#"><span>Стол «‎Вента»</span></a><a class="ccard-img" href="#"><img src="<?= SITE_TEMPLATE_PATH ?>/assets/images/content/goods/img-g-02.jpg" alt=""></a>
              <div class="ccard-des">Размеры (ШxГxВ): 850х750х680</div>
              <div class="ccard-price">
                <!--.ccard-price-old 20 000 руб.-->
                <div class="ccard-price-new">14 860 руб.</div>
              </div>
            </div>
            <div class="ccard-popup"><a class="mbtn mbtn-primary addcart" href="#"><span>В&nbsp;корзину</span></a></div>
          </div>
        </div>
        <!-- /el-->
        <!-- el-->
        <div class="swiper-slide goods-sl-el">
          <div class="ccard">
            <div class="ccard-body">
              <div class="marker"><span class="new">new</span><span class="sale">sale</span>
                <!--span.hit hit-->
              </div><a class="ccard-name" href="#"><span>Диван Сидней&nbsp;К2</span></a><a class="ccard-img" href="#"><img src="<?= SITE_TEMPLATE_PATH ?>/assets/images/content/goods/img-g-03.jpg" alt=""></a>
              <div class="ccard-des">Размеры (ШxГxВ): 850х750х680</div>
              <div class="ccard-price">
                <div class="ccard-price-old">20 000 руб.</div>
                <div class="ccard-price-new">14 860 руб.</div>
              </div>
            </div>
            <div class="ccard-popup"><a class="mbtn mbtn-primary addcart" href="#"><span>В&nbsp;корзину</span></a></div>
          </div>
        </div>
        <!-- /el-->
        <!-- el-->
        <div class="swiper-slide goods-sl-el">
          <div class="ccard">
            <div class="ccard-body">
              <div class="marker"><span class="new">new</span><span class="sale">sale</span><span class="hit">hit</span></div><a class="ccard-name" href="#"><span>Шкаф для документов «‎Премьер»</span></a><a class="ccard-img" href="#"><img src="<?= SITE_TEMPLATE_PATH ?>/assets/images/content/goods/img-g-00.jpg" alt=""></a>
              <div class="ccard-des">Размеры (ШxГxВ): 850х750х680</div>
              <div class="ccard-price">
                <div class="ccard-price-old">20 000 руб.</div>
                <div class="ccard-price-new">14 860 руб.</div>
              </div>
            </div>
            <div class="ccard-popup"><a class="mbtn mbtn-primary addcart" href="#"><span>В&nbsp;корзину</span></a></div>
          </div>
        </div>
        <!-- /el-->
        <!-- el-->
        <div class="swiper-slide goods-sl-el">
          <div class="ccard">
            <div class="ccard-body">
              <div class="marker"><span class="new">new</span>
                <!--span.sale sale-->
                <!--span.hit hit-->
              </div><a class="ccard-name" href="#"><span>Стол брифинг «‎Премьер»</span></a><a class="ccard-img" href="#"><img src="<?= SITE_TEMPLATE_PATH ?>/assets/images/content/goods/img-g-01.jpg" alt=""></a>
              <div class="ccard-des">Размеры (ШxГxВ): 850х750х680</div>
              <div class="ccard-price">
                <div class="ccard-price-new">14 860 руб.</div>
              </div>
            </div>
            <div class="ccard-popup"><a class="mbtn mbtn-primary addcart" href="#"><span>В&nbsp;корзину</span></a></div>
          </div>
        </div>
        <!-- /el-->
        <!-- el-->
        <div class="swiper-slide goods-sl-el">
          <div class="ccard">
            <div class="ccard-body">
              <!--.marker-->
              <!--  span.new new-->
              <!--  span.sale sale-->
              <!--  span.hit hit--><a class="ccard-name" href="#"><span>Стол «‎Вента»</span></a><a class="ccard-img" href="#"><img src="<?= SITE_TEMPLATE_PATH ?>/assets/images/content/goods/img-g-02.jpg" alt=""></a>
              <div class="ccard-des">Размеры (ШxГxВ): 850х750х680</div>
              <div class="ccard-price">
                <!--.ccard-price-old 20 000 руб.-->
                <div class="ccard-price-new">14 860 руб.</div>
              </div>
            </div>
            <div class="ccard-popup"><a class="mbtn mbtn-primary addcart" href="#"><span>В&nbsp;корзину</span></a></div>
          </div>
        </div>
        <!-- /el-->
        <!-- el-->
        <div class="swiper-slide goods-sl-el">
          <div class="ccard">
            <div class="ccard-body">
              <div class="marker"><span class="new">new</span><span class="sale">sale</span>
                <!--span.hit hit-->
              </div><a class="ccard-name" href="#"><span>Диван Сидней&nbsp;К2</span></a><a class="ccard-img" href="#"><img src="<?= SITE_TEMPLATE_PATH ?>/assets/images/content/goods/img-g-03.jpg" alt=""></a>
              <div class="ccard-des">Размеры (ШxГxВ): 850х750х680</div>
              <div class="ccard-price">
                <div class="ccard-price-old">20 000 руб.</div>
                <div class="ccard-price-new">14 860 руб.</div>
              </div>
            </div>
            <div class="ccard-popup"><a class="mbtn mbtn-primary addcart" href="#"><span>В&nbsp;корзину</span></a></div>
          </div>
        </div>
        <!-- /el-->
      </div>
    </div>
    <div class="text-center pt-4 d-md-none"><a class="mbtn mbtn-brddark warrow-right" href="#"><span>Показать еще</span></a></div>
    <!-- /goods hits-->

<?if($arParams['SHOW_RECOMMEND']):?>
    <div id="#recomend_items">
        <?/*include "recommended.php"*/?>
    </div>
<?endif?>
<? if ($arParams['SHOW_SIMILAR']): ?>
    <?/* include "similar_price.php"; */?>
<? endif ?>
<?$templateData['JS_OFFERS'] = array('ELEMENT_ID' => $arItem['ID'], 'IBLOCK_ID' => $arItem['IBLOCK_ID'])?>
<?$templateData['ID_ITEM'] = $arResult['ID']?>
  </div>
</section>