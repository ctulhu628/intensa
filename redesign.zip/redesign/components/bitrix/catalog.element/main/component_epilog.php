<? use Yenisite\Core\Tools;

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
$Asset = \Bitrix\Main\Page\Asset::getInstance();
$Asset->addJs(SITE_TEMPLATE_PATH . '/js/vendor/jquery.mobile.just-touch.min.js');
$Asset->addJs(SITE_TEMPLATE_PATH . '/js/backend/element_page/handlers.js');
$Asset->addJs(SITE_TEMPLATE_PATH . '/js/backend/element_page/ajax_request.js');
$Asset->addJs($templateFolder . '/js/script.js');

if (\Bitrix\Main\Loader::includeModule('currency')) {
	CJSCore::Init(array('currency'));
	$currency = $arResult['MIN_PRICE']['CURRENCY'];
	$currencyFormat = CCurrencyLang::GetFormatDescription($currency);
	ob_start();
	?>
	<script type="text/javascript">
		BX.Currency.setCurrencyFormat('<?= $currency ?>', <?= CUtil::PhpToJSObject($currencyFormat, false, true); ?>);
		BX.Currency.defaultCurrency = '<?= $currency ?>';
	</script>
	<?
	$formatScript = ob_get_clean();
	$Asset->addString($formatScript);
}?>
<?/*
$frame = new \Bitrix\Main\Page\FrameBuffered("element_epilog_SAVE_ID_ITEM");
$frame->begin('');?>
	<script type="text/javascript">
		var ID_ITEM_DETAIL = <?=$templateData['ID_ITEM']?>;
	</script>
<?$frame->end();*/

//Needs for iblock.vote to not break composite
if (empty($templateData['arJSParams']) || !empty($_REQUEST['REQUEST_URI'])) return;
IncludeAJAX();


$frame = new \Bitrix\Main\Page\FrameBuffered("element_epilog_RZSKU");
$frame->begin('');?>
<?
$jsString = 'var RZSkuHandlerChild = new RZSkuHandler('. CUtil::PhpToJSObject($templateData['arJSParams']).',{
	\'onAfterItemsFilter\': \'RZ_onFilterSKU\',
	\'onBeforeOfferSet\': \'RZ_skuGalleryChange\'
	});';

if (!empty($_SESSION['RZ_DETAIL_JS_FILE'])) {
	$bytes = fwrite($_SESSION['RZ_DETAIL_JS_FILE'], $jsString);
	if ($bytes === false || $bytes != mb_strlen($jsString, 'windows-1251')) {
		$templateData['jsFile'] = false;
		if (file_exists($templateData['jsFullPath'])) {
			unlink($templateData['jsFullPath']);
		}
	}
	fclose($_SESSION['RZ_DETAIL_JS_FILE']);
	unset($_SESSION['RZ_DETAIL_JS_FILE']);
}

if (!empty($templateData['jsFile']) && file_exists($templateData['jsFullPath']) && !Tools::isAjax() && !Tools::isComposite() && Tools::isComponentCacheOn($arParams)):?>
	<script type="text/javascript" src="<?=$templateData['jsFile']?>?<?echo @filemtime($templateData['jsFullPath'])?>"></script>
	<script>
		<?/*if(!!<?=$templateData['strObName']?>.init)<?=$templateData['strObName']?>.init();*/?>
	</script>
<? else: ?>
	<script type="text/javascript">
		<?=$jsString?>
		<?/*if(!!<?=$templateData['strObName']?>.init)<?=$templateData['strObName']?>.init();*/?>
	</script>
<?endif;?>
<?$frame->end();

?>