<?if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();?>
<?
$curEnc = \Yenisite\Core\Tools::getLogicalEncoding();
$arProp = array(array("NAME" =>  GetMessage('FOR_ITEM'),"CODE" => $arResult['ID'], "VALUE" =>  $arResult['NAME']));
\Yenisite\Core\Tools::encodeArray($arProp,$curEnc,'utf-8');
?>
<div class="additional-services">
    <div class="detail-parameter-block-title"><?=$arParams['HEADER_PAID_OPTIONS'] ? : GetMessage('HEADER_PAID_OPTIONS') ?>:</div>
    <ul class="checkbox-options">
    <?foreach($arResult['PAID_OPTIONS'] as $arOption):?>
            <li>
                <label data-q="1" data-id="<?=$arOption['ID']?>" data-props="<?= \Yenisite\Core\Tools::GetEncodedArParams($arProp) ?>" class="incart-<?= $arResult['ID'].$arOption['ID']?> checkbox-label add-option-in-cart">
                    <input <?if (!$arResult['CAN_BUY']):?>disabled<?endif?> type="checkbox" class="checkbox-input state">
                    <span class="checkbox-content">
                        <span class="check flaticon-checked21"></span>
                        <?=$arOption['NAME']?> <span class="price-options"><?=GetMessage('PRICE')?>: <?=\Yenisite\Furniture\Events::CurrencyFormat(SITE_ID,$arOption['CATALOG_PRICE_'.$arResult['MIN_PRICE']['PRICE_ID']],$arResult['MIN_PRICE']['CURRENCY'])?></span>
                    </span>
                </label>
            </li>
        <?endforeach?>
    </ul><!-- checkbox-options -->
</div>
