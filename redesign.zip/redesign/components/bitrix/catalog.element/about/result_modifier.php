<?php
use \Yenisite\Furniture\Main;

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
\Bitrix\Main\Localization\Loc::loadLanguageFile($_SERVER['DOCUMENT_ROOT'] . SITE_TEMPLATE_PATH . '/catalog.php');
$arParams['BASKET_URL'] = $arParams['BASKET_URL'] ?: SITE_DIR . 'personal/cart/';
$arItem = &$arResult;

$arResizer = array('SRC' => array('WIDTH' => 177, 'HEIGHT' => 177, 'SET_ID' => $arParams['RESIZER_BIG_IMAGE']));
$arParams['OFFER_TREE_PROPS'] = &$arParams['OFFERS_CART_PROPERTIES'];

if (CModule::IncludeModule("catalog"))
Main::prepareSku($arResult, $arParams, $arResizer);
$arItem['GALLERY'] = Main::getGallery($arItem, $arResizer);
Main::processCatalogItem($arItem, $arParams['OFFERS_PROPERTY_CODE']);

//Prices for MARKET
if (CModule::IncludeModule('yenisite.furniturelite') && CModule::IncludeModule('yenisite.market')) {
	if(!empty($arItem['PROPERTIES']['MEASURE_NAME']['VALUE_ENUM'])) $arItem['CATALOG_MEASURE_NAME'] = $arItem['PROPERTIES']['MEASURE_NAME']['VALUE_ENUM'];
	$prices = CMarketPrice::GetItemPriceValues($arItem["ID"], $arItem['PRICES']);
	if(count($prices)>0)
		unset ($arItem["PRICES"]);
	$minPrice = false;
	foreach ($prices as $k => $pr) {
		$pr = floatval($pr);
		$arItem["PRICES"][$k]["VALUE"] = $pr;
		$arItem["PRICES"][$k]["PRINT_VALUE"] = $pr;
		if ((empty($minPrice) || $minPrice > $pr) && $pr > 0) {
			$minPrice = $pr;
			$minPriceId = $k;
		}
	}
	if ($minPrice !== false) {
	
		$minPrice = Main::getElementPriceFormat($arItem['MIN_PRICE']['CURRENCY'], $minPrice, $arItem['MIN_PRICE']['PRINT_VALUE']);
		
		$arItem['MIN_PRICE']['PRICE_ID'] = $minPriceId;
		$arItem['MIN_PRICE']['VALUE'] = $minPrice;
		$arItem['MIN_PRICE']['DISCOUNT_VALUE'] = $minPrice;
		$arItem['MIN_PRICE']['PRINT_DISCOUNT_VALUE'] = $minPrice;
		$arItem['CAN_BUY'] = true;
		
	}
	$arItem['CHECK_QUANTITY'] = (CMarketCatalog::UsesQuantity($arParams['IBLOCK_ID']) == 1);

	$arItem['CATALOG_QUANTITY'] = intval($arItem['PROPERTIES']['MARKET_QUANTITY']['VALUE']);
	
	if ($arItem['CHECK_QUANTITY'] && $arItem['CATALOG_QUANTITY'] <= 0) {
		$arItem['CAN_BUY'] = false;
	}

	$arItem['CATALOG_WEIGHT'] = $arItem['PROPERTIES']['CATALOG_WEIGHT']['VALUE'];
	$arItem['CATALOG_TYPE'] = 1; //simple product
}
//end Prices for MARKET