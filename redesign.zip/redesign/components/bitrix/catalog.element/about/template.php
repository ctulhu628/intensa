<?
/**
 * @var CBitrixComponentTemplate $this
 */

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
$arItem = &$arResult;
?>

<?php foreach ($arResult['PROPERTIES']['gallery']['VALUE'] as $image):
	$src = CFile::GetPath($image) ?>
<!-- el-->
<div class="swiper-slide partners-sl-el">
	<div class="partners-sl-body">
		<img src="<?= $src ?>" alt="">
	</div>
</div>
 <!-- /el-->
<?php endforeach ?>
