<?
$MESS["RZ_TOVAR_DOBAVLEN_V_KORZINU"] = "Товар добавлен в корзину";
$MESS["RZ_VERNUTSYA_K_POKUPKAM"] = "Вернуться к покупкам";
$MESS["RZ_PEREJTI_V_KORZINU"] = "Перейти в корзину";
$MESS["RZ_ART_"] = "арт.";
