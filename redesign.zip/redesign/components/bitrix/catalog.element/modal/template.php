<?
/**
 * @var CBitrixComponentTemplate $this
 */

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
$arItem = &$arResult;
?>
<div class="modal-header">
	<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span class="svg-wrap close"><svg>
		<use xlink:href="#close"></use>
	</svg></span></button>
	<h4 class="modal-title flaticon-shopping102"><?= GetMessage("RZ_TOVAR_DOBAVLEN_V_KORZINU") ?></h4>
</div>
<div class="modal-body">
	<div class="media">
		<div class="media-left">
			<a href="<?= $arItem['DETAIL_PAGE_URL'] ?>">
				<img class="media-object" src="<?= $arItem['GALLERY'][0]['SRC'] ?>" alt="<?= $arItem['NAME'] ?>">
			</a>
		</div><!-- media-left -->
		<div class="media-body">
			<a href="<?= $arItem['DETAIL_PAGE_URL'] ?>" class="classic-link"><?= $arItem['NAME'] ?></a>
			<? /* todo: modal-cart-after-add article
			<div class="art"><?= GetMessage("RZ_ART_") ?> 495687</div>
			*/ ?>
			<div>
				<? $APPLICATION->IncludeComponent("bitrix:iblock.vote", "section", array(
						"IBLOCK_TYPE" => $arParams['IBLOCK_TYPE'],
						"IBLOCK_ID" => $arParams['IBLOCK_ID'],
						"ELEMENT_ID" => $arItem['ID'],
						"CACHE_TYPE" => $arParams["CACHE_TYPE"],
						"CACHE_TIME" => $arParams["CACHE_TIME"],
						"MAX_VOTE" => "5",
						"VOTE_NAMES" => array("1", "2", "3", "4", "5"),
						"SET_STATUS_404" => "N",
				),
						$component, array("HIDE_ICONS" => "Y")
				); ?>
			</div>
			<div class="price"><?= $arItem['MIN_PRICE']['PRINT_DISCOUNT_VALUE'] ?></div>
			<? if ($arItem['MIN_PRICE']['DISCOUNT_VALUE'] != $arItem['MIN_PRICE']['VALUE']): ?>
				<span class="old-price"><?= $arItem['MIN_PRICE']['PRINT_VALUE'] ?></span>
			<? endif ?>
		</div><!-- media-body -->
	</div><!-- media -->
	<? /* todo: modal-cart-after-add bigdata
	<div class="other">Buy with this item:</div>
	<? $addBtns=""; include "_/html/items-gallery.php"; ?>
	*/ ?>
</div><!-- modal-body -->
<div class="modal-footer">
	<a href="#modal-added-to-cart" class="btn-direction back-to-shoping pull-left flaticon-left207"
	   data-dismiss="modal"><?= GetMessage("RZ_VERNUTSYA_K_POKUPKAM") ?></a>
	<a href="<?= $arParams['BASKET_URL'] ?>" class="btn-direction to-cart pull-right flaticon-right218"
	   data-dismiss="modal"><?= GetMessage("RZ_PEREJTI_V_KORZINU") ?></a>
</div>
