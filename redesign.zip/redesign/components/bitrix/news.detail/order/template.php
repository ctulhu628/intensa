<? use Yenisite\Furniture\Main;

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
?>
<div class="order-info">
	<? if ($USER->IsAuthorized()) { ?>
	<div class="order-actions">
		<a class="back-to-shoping btn-main btn-direction flaticon-left207"
		   href="<?= $arParams["IBLOCK_URL"] ?>?#order-history"><?= GetMessage('SPOD_BACK') ?></a>
	</div>
	<? } ?>
	<? if (strlen($arResult["ERROR_MESSAGE"])): ?>
		<? Main::ShowMessage($arResult["ERROR_MESSAGE"]); ?>
	<? else: ?>
		<div class="order-info-content">
			<h2 class="order-name">
				<?= GetMessage("TITLE_ORDER").$arResult["ID"] ?>
				<? if (strlen($arResult["DATE_CREATE"])): ?>
					<?= GetMessage("SPOD_FROM") ?> <?= $arResult["DATE_CREATE"] ?>
				<? endif ?>
			</h2>
			<table class="order-info-table">
				<tbody>
				<tr>
					<td><?= GetMessage('SPOD_ORDER_STATUS') ?>:</td>
					<td>
						<?= $arResult["PROPERTIES"]['STATUS']['VALUE'] ?>
						<? if (strlen($arResult["PROPERTIES"]['STATUS']['TIMESTAMP_X'])): ?>
							(<?= GetMessage("SPOD_FROM") ?> <?= $arResult["PROPERTIES"]['STATUS']['TIMESTAMP_X'] ?>)
						<? endif ?>
					</td>
				</tr>
				<tr>
					<td><?= GetMessage('SPOD_ORDER_PRICE') ?>:</td>
					<td>
						<? if (floatval($arResult["PROPERTIES"]["AMOUNT"]['VALUE'])): ?>
							<?= $arResult["PROPERTIES"]["AMOUNT"]['TOTAL_SUM_FORMATTED'] ?>
						<? endif ?>
					</td>
				</tr>
				</tbody>
			</table>
			<? if (!empty($arResult['DISPLAY_PROPERTIES'])): ?>
				<table class="order-info-table">
				<caption><?= GetMessage('SPOD_ORDER_PROPERTIES') ?></caption>
				<? foreach ($arResult['DISPLAY_PROPERTIES'] as $prop): ?>
					<? if($prop['CODE'] != 'DELIVERY_E' && $prop['CODE'] != 'PAYMENT_E'): ?>
						<tr>
							<td><?= $prop['NAME'] ?></td>
							<td>
								<? if ($prop["USER_TYPE"] == "CHECKBOX"): ?>
									<?= GetMessage('SPOD_' . ($prop["VALUE"] == "Y" ? 'YES' : 'NO')) ?>
								<? elseif($prop["USER_TYPE"] == "HTML"): ?>
									<?= $prop["VALUE"]["TEXT"] ?>
								<? else: ?>
									<?= $prop["VALUE"] ?>
								<? endif ?>
							</td>
						</tr>
					<? endif ?>
				<? endforeach ?>
				</table>
			<? endif ?>
			<table class="order-info-table">
				<caption><?= GetMessage('SPOD_ORDER_PAYED_STATUS') ?></caption>
				<tr>
					<td><?= GetMessage('SPOD_ORDER_PAYED') ?>:</td>
					<td>
						<? if ($arResult["PROPERTIES"]['STATUS']['VALUE']  == GetMessage('PAYED')): ?>
							<?= GetMessage('SPOD_YES') ?>
						<? else: ?>
							<?= GetMessage('SPOD_NO') ?>
						<? endif ?>
					</td>
				</tr>
			</table>
			<table class="order-info-table">
				<caption><?= GetMessage('SPOD_ORDER_PAYMENT_DELIVERY') ?></caption>
				<tr>
					<td><?= GetMessage('SPOD_ORDER_DELIVERY') ?>:</td>
					<td>
						<? if (intval($arResult["DISPLAY_PROPERTIES"]['DELIVERY_E']['VALUE'])): ?>
							<?= $arResult["DISPLAY_PROPERTIES"]['DELIVERY_E']['LINK_ELEMENT_VALUE'][$arResult['DISPLAY_PROPERTIES']['DELIVERY_E']['VALUE']]['NAME'] ?>
							<? if (strlen($arResult['DISPLAY_PROPERTIES']['DELIVERY_E']['VALUE_DELIVERY'])): ?>
								- <?= $arResult['DISPLAY_PROPERTIES']['DELIVERY_E']['VALUE_DELIVERY'] ?>
							<? endif ?>							
						<? else: ?>
							<?= GetMessage("SPOD_NONE") ?>
						<? endif ?>
					</td>
				</tr>
			</table>
			<table class="order-info-table">
				<caption><?= GetMessage('SPOD_ORDER_PAYMENT') ?></caption>
				<tr>
					<td><?= GetMessage('SPOD_ORDER_PAYMENT') ?>:</td>
					<td>
						<? if (intval($arResult["DISPLAY_PROPERTIES"]['PAYMENT_E']['VALUE'])): ?>
							<?= $arResult["DISPLAY_PROPERTIES"]['PAYMENT_E']['LINK_ELEMENT_VALUE'][$arResult['DISPLAY_PROPERTIES']['PAYMENT_E']['VALUE']]['NAME'] ?>
						<? else: ?>
							<?= GetMessage("SPOD_NONE") ?>
						<? endif ?>
					</td>
				</tr>
				<? if($arResult["DISPLAY_PROPERTIES"]['PAYMENT_E']['LINK_ELEMENT_VALUE'][$arResult['DISPLAY_PROPERTIES']['PAYMENT_E']['VALUE']]['CODE'] == "robokassa" && ($arResult['PROPERTIES']['STATUS']['VALUE_XML_ID'] == "added" || $arResult['PROPERTIES']['STATUS']['VALUE'] == GetMessage('ADD_ORDER'))){ ?>
					<tr id="pay-button-here">
						<td colspan="2">
							<a href="<?= SITE_DIR ?>personal/cart/?payment=Y&id=<?=$arResult["ID"]?>"
							class="btn btn-primary"><?= GetMessage('SPOD_PAYMENT_FOR_ORDER') ?></a>
						</td>
					</tr>
				<? } ?>
			</table>
		</div>
		<h2><?= GetMessage('SPOD_ITEMS_IN_ORDER') ?></h2>
		<table class="cart-table short">
			<thead>
			<tr>
				<td class="for-main-info" colspan="2"><?= GetMessage('SPOD_ITEMS') ?></td>
				<td class="for-summary"><?= GetMessage('SPOD_PRICE') ?></td>
				<td class="for-summary"><?= GetMessage('SPOD_QUANTITY') ?></td>
				<td class="for-summary"><?= GetMessage('SPOD_SUMM') ?></td>
			</tr>
			</thead>
			<tbody>
			<? foreach ($arResult['PROPERTIES']['ITEMS']['BASKET'] as $key => $prod): ?>
				<tr class="cart-item">
					<? $hasLink = !empty($prod["DETAIL_PAGE_URL"]); ?>
					<td class="img-wrap">
						<? if ($prod['PICTURE']): ?>
							<? if ($hasLink): ?>
								<a href="<?= $prod["DETAIL_PAGE_URL"] ?>" target="_blank">
									<? endif ?>
									<img alt="<?= $prod['NAME'] ?>" src="<?= $prod['PICTURE'] ?>">
									<? if ($hasLink): ?>
								</a>
							<? endif ?>
						<? endif ?>
					</td>
					<td class="name-wrap">
						<a href="<?= $prod["DETAIL_PAGE_URL"] ?>" class="classic-link"  target="_blank"><?= $prod['NAME'] ?></a>
					</td>
					<td class="price-wrap">
						<div class="price"><?= $prod["PRICE_FORMATTED"] ?></div>
					</td>					
					<td>
						<?= $arResult['BASKET_ITEMS'][$prod['ID']]['COUNT'] ?>
						<span class="price-unit"><?= $arItem['PROPERTY_MEASURE_NAME'] ?></span>
					</td>
					<td class="price-wrap">
						<div class="price"><?= $arResult['BASKET_ITEMS'][$prod['ID']]['PRICE'] ?></div>
					</td>
				</tr>
			<? endforeach ?>
			</tbody>
		</table>
	<? endif ?>
</div>