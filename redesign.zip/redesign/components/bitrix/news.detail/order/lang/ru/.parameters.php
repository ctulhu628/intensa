<?
$MESS["RESIZER_SETS"] = "Настройка наборов Ресайзера";
$MESS["RESIZER_BASKET_PHOTO"] = "Фото товара";