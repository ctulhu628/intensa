<? use Yenisite\Furniture\Main;

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

$arResult["PROPERTIES"]["AMOUNT"]['TOTAL_SUM_FORMATTED'] = Main::getElementPriceFormat(false, $arResult["PROPERTIES"]["AMOUNT"]['VALUE']);
$arSelect = Array("ID", "NAME", "PROPERTY_PRICE_BASE", "PROPERTY_MARKET_QUANTITY", "PREVIEW_PICTURE", "DETAIL_PICTURE", "DETAIL_PAGE_URL", "PROPERTY_MEASURE_NAME");
$arFilter = Array("ID"=>$arResult['PROPERTIES']['ITEMS']['VALUE']);
$res = CIBlockElement::GetList(Array(), $arFilter, false, Array(), $arSelect);
while($element = $res->GetNext())
{
	$arResult['PROPERTIES']['ITEMS']['BASKET'][$element['ID']] = $element;
	$arResult['PROPERTIES']['ITEMS']['BASKET'][$element['ID']]['PICTURE'] = Main::getElementPictureById($element['ID'], $arParams['RESIZER_BASKET_PHOTO']);
	$arResult['PROPERTIES']['ITEMS']['BASKET'][$element['ID']]['PRICE_FORMATTED'] = Main::getElementPriceFormat(false, $arResult['PROPERTIES']['ITEMS']['BASKET'][$element['ID']]['PROPERTY_PRICE_BASE_VALUE']);
}

$regExp = '/<p class="basket_item" data-id="item_([^"]+)">.*<span class="item_name">([^<]*)<\\/span>.*<span class="item_count">([^<]*)<\\/span>.*<span class="item_price">([^<]*)</U';
$out = array();
preg_match_all($regExp, $arResult['DETAIL_TEXT'], $out, PREG_SET_ORDER);

$arResult['BASKET_ITEMS'] = array();
foreach ($out as $match) {
	$arItem = array();
	$arItem['ID'] = intval($match[1]);
	$arItem['NAME_FULL'] = htmlspecialcharsBx($match[2]);
	$arItem['COUNT'] = intval($match[3]);
	$arItem['PRICE'] = floatval($match[4])*$arItem['COUNT'];
	$arItem['PRICE'] = Main::getElementPriceFormat(false, $arItem['PRICE']);
	$arResult['BASKET_ITEMS'][$arItem['ID']] = $arItem;
}
$regExp = '#.*<span class="delivery_price">([^<]*)</span>.*#Um';
$out = null;
preg_match($regExp, $arResult['DETAIL_TEXT'], $out);
if (is_array($out) && array_key_exists(1, $out) && is_array($arResult['DISPLAY_PROPERTIES']['DELIVERY_E']['LINK_ELEMENT_VALUE'])) {
	$arResult['DISPLAY_PROPERTIES']['DELIVERY_E']['VALUE_DELIVERY'] = Main::getElementPriceFormat(false, floatval($out[1]));
}