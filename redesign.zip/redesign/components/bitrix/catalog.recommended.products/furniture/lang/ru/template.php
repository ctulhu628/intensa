<?
$MESS['RZ_OPEN_ALL'] = 'Смотреть все';
$MESS['RZ_NO_FAVORITE_ITEMS'] = 'У вас еще нет избранных товаров';
$MESS['RZ_PRODUCT_PAGE_RECOMMENDED'] = 'Рекомендуемые товары';
$MESS['RZ_UNTIL_END'] = 'До конца распродажи';
$MESS['RZ_SOLD'] = 'продано';