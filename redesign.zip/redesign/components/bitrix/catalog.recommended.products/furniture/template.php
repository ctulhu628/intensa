<?
/**
 * @var CBitrixComponentTemplate $this
 */
use Bitrix\Main\Localization\Loc;

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
$this->setFrameMode(true);
if (empty($arResult['ITEMS'])) return;
Loc::loadLanguageFile($_SERVER['DOCUMENT_ROOT'] . SITE_TEMPLATE_PATH . '/catalog.php');
?>
<? if (!empty($arParams['TITLE_RECOMMEND'])): ?>
	<h2><?= $arParams['TITLE_RECOMMEND'] ?>:</h2>
<? endif ?>
<div class="item-frame">
	<div class="items-gallery">
		<?
		foreach ($arResult['ITEMS'] as &$arItem) {
			include 'item.php';
		}
		unset($arItem);
		?>
	</div>
</div>
<div class="pages-wrap">
	<button class="prevPage three-color-p flaticon-left207">
		<span class="cbutton cbutton--effect-lazar cbutton--effect-lazar-inverted"></span>
	</button>
	<div class="nums"><span class="num-current"></span> / <span class="num-total"></span></div>
	<ul class="pages">
		<li></li>
	</ul>
	<button class="nextPage three-color-p flaticon-right218"><span class="cbutton cbutton--effect-lazar"></span></button>
</div><!-- pages-wrap -->
