<?
use Yenisite\Core\Tools;

/**
 * @var CBitrixComponent $this
 */
\Bitrix\Main\Localization\Loc::loadLanguageFile(__FILE__);
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
$tmpl = array($this->__name, $this->__templateName);
ob_start();
if (Tools::isIncludeAreaNotEmpty($tmpl, 'heading_1') || Tools::isIncludeAreaNotEmpty($tmpl, 'heading_2')
		|| Tools::isIncludeAreaNotEmpty($tmpl, 'icons')
): ?>
	<div class="categories-advertisement">
		<div class="adv1"><?= Tools::IncludeAreaEdit($tmpl, 'heading_1',
					array('TITLE' => GetMessage("RZ_IZMENIT_ZAGOLOVOK") . ' 1')) ?></div>
		<div class="adv2"><?= Tools::IncludeAreaEdit($tmpl, 'heading_2',
					array('TITLE' => GetMessage("RZ_IZMENIT_ZAGOLOVOK") . ' 2')) ?></div>
		<div class="categories-advertisement__icons">
			<?= Tools::IncludeAreaEdit($tmpl, 'icons', array('TITLE' => GetMessage("RZ_IZMENIT_IKONKI"))) ?>
		</div>
	</div>
<? endif ?>
<?
$content = ob_get_clean();
$arResult['TEMPLATE'] = str_replace('#INCLUDE_AREA#', $content, $arResult['TEMPLATE']);
?>
<?= $arResult['TEMPLATE'];