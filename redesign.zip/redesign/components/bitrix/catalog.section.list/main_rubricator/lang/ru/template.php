<?
$MESS["RZ_ESHE_KATEGORII"] = "Еще категории";
$MESS["RZ_CATEGORY_QUANTITY"] = "Товаров в разделе";
$MESS["RZ_CATEGORIES-HEADER"] = "Мы рады предложить вам более 1000 наименований различных товаров";
