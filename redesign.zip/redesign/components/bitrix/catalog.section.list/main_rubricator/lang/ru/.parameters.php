<?
$MESS['RZ_CATALOG_URL'] = 'Ссылка на все категории';