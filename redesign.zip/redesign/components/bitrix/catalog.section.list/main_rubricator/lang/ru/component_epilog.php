<?
$MESS["RZ_IZMENIT_ZAGOLOVOK"] = "Изменить заголовок";
$MESS["RZ_IZMENIT_IKONKI"] = "Изменить иконки";