<? use Yenisite\Core\Resize;
use Yenisite\Core\Tools;
use Yenisite\Furniture\Main;

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */
/** @var CBitrixComponent $component */
$this->setFrameMode(true);
ob_start();
?>
<div class="categories">
	#INCLUDE_AREA#
	<div class="categories-list">
		<? foreach ($arResult['SECTIONS'] as &$arItem): ?>
			<? if ($arItem['DEPTH_LEVEL'] > 1) continue ?>
			<a href="<?= $arItem['SECTION_PAGE_URL'] ?>" class="category-link">
				<? if (!empty($arItem['PICTURE']['ID'])): ?>
					<div class="category-image__wrap">
						<img src="<?= Resize::GetResizedImg($arItem['PICTURE']['ID'],
								array('WIDTH' => 70, 'HEIGHT' => 50, 'SET_ID' => $arParams['RESIZER_IMAGE'])) ?>"
							 alt="<?= $arItem['NAME'] ?>" class="category-img">
					</div>
				<? endif ?>
				<?= $arItem['NAME'] ?>
			</a>
		<? endforeach;
		unset($arItem) ?>
	</div><!-- categories-list -->

	<? if (!empty($arParams['CATALOG_URL'])): ?>
		<a href="<?= $arParams['CATALOG_URL'] ?>" class="categories-more-link">
			<i class="flaticon-more23"></i>
			<span class="categories-more-text"><?= GetMessage("RZ_ESHE_KATEGORII") ?></span>
		</a>
	<? endif ?>
</div><!-- categories -->
<?
$arResult['TEMPLATE'] = ob_get_clean();
?>