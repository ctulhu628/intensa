<?
$MESS['FURNITURE_DESC_SHOW_FULL'] = 'Показать полностью';
$MESS['FURNITURE_DESC_HIDE_FULL'] = 'Свернуть';
$MESS['FURNITURE_SHOW_MORE'] = 'Показать еще';
