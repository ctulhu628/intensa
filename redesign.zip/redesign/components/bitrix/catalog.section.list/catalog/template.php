<?
use Yenisite\Furniture\Main;
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */
/** @var CBitrixComponent $component */
if (method_exists($this, 'setFrameMode')) $this->setFrameMode(true);

$bHasImg = !empty($arResult['SECTION']['PICTURE']) && !$arParams['HIDE_IMG'];
$bSeoFilter = \Bitrix\Main\Loader::includeModule('yenisite.seofilter');
$arDesc = explode('#DELIMETER#', $arResult['SECTION']['DESCRIPTION']);
if (!$arParams['IS_BOTTOM']) {
	$desc = $arDesc[0];
} elseif (count($arDesc) > 0) {
	$desc = $arDesc[1] ? : $arDesc[0];
}
?>
<?if ($arParams['SHOW_DESCRIPTION']): ?>
	<div class="catalog-description-block">
        <?= $desc ?>
	</div>
<? endif ?>
<?if ($arParams['SHOW_SUBSECTIONS']): ?>
	<div class="sub-categories">
		<? foreach ($arResult['SECTIONS'] as $arSection): ?>
            <a href="<?= $arSection['SECTION_PAGE_URL'] ?>">
				<?= $arSection['NAME'] ?><sup><?= $arSection['ELEMENT_CNT'] ?></sup>
			</a>
		<? endforeach ?>
	</div>
<? endif ?>

