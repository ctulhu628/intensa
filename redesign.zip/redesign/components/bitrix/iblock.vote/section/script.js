$(function () {
	"use strict";

	$.fn.rmzRating = function (action) {
		this.each(function () {
			var $t = $(this),
				$dummy = $t.children('.hover-dummy'),
				width = $t.outerWidth(),
				offsetX = $t.offset().left,
				isMoving = false;

			$t.on({
				'click.rating': function (e) {
					var x = e.pageX,
						percent = (x - offsetX) * 100 / width,
						rating = Math.ceil(percent / 20);

					if ($t.hasClass('disabled')) return;

					$(document).trigger('ratingchange', {item: $t.get(0), rating: rating});
					$t.attr('data-colorrating', rating);
					$t.children('.real-value').css('width', rating * 20 + '%');

					return false;
				},
				'mouseenter.rating': function (e) {
					offsetX = $t.offset().left;
					// ^ if init was on hidden rating, this helps
					isMoving = true;
				},
				'mouseleave.rating': function (e) {
					isMoving = false;
					$t.removeAttr('data-hoverrating');
				},
				'mousemove.rating': function (e) {
					var x = e.pageX,
						percent = (x - offsetX) * 100 / width,
						rating = Math.ceil(percent / 20);

					if ($t.hasClass('disabled')) return;

					$t.attr('data-hoverrating', rating);
					$dummy.css('width', rating * 20 + '%');
				}
			});
		});

		return this;
	};
	$('.rating-stars').rmzRating();
});


$(document).on('ratingchange', function (e, data) {
	var $this = $(data.item),
		voteId = $this.data('id') | 0,
		rating = data.rating | 0;
	if (voteId > 0 && rating > 0 && !$this.hasClass('disabled')) {
		return $.ajax({
			type: "POST",
			data: {
				'ajax': $this.data('ajax'),
				'vote_id': voteId,
				'rating': rating,
				'arParams': $this.data('arparams'),
				'template': $this.data('template'),
			},
			dataType: 'json',
			url: AJAX_DIR + 'rate.php',
			success: function (json) {
				if (!json.success) {
					alert(json.msg);
				} else {
					$this.addClass('disabled').attr('disabled', true);
				}
			}
		});
	}
	console.log(data);
});

