<? use Yenisite\Core\Ajax;
use Yenisite\Core\Tools;

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */
/** @var CBitrixComponent $component */
if (method_exists($this, 'setFrameMode')) $this->setFrameMode(true);
$isJson = (isset($_REQUEST['json']) && $_REQUEST['json'] == 'Y');
if ($arResult["PROPERTIES"]["vote_count"]["VALUE"]) {
	$votesValue = round($arResult["PROPERTIES"]["vote_sum"]["VALUE"] / $arResult["PROPERTIES"]["vote_count"]["VALUE"], 2);
} else {
	$votesValue = 0;
}

$votesCount = intval($arResult["PROPERTIES"]["vote_count"]["VALUE"]);
$bActive = !($arResult["VOTED"] || $arParams["READ_ONLY"] === "Y");
Ajax::saveParams($this, $arResult["~AJAX_PARAMS"], 'rate_' . $arResult['ID']);
?>
<? if ($isJson):
	echo json_decode($votesValue);
else:?>
	<span class="stars" itemprop="aggregateRating" itemscope itemtype="http://schema.org/AggregateRating"
		  data-realrating="<?= $votesValue ?>" data-rating="<?= (int)$votesValue ?>" data-id="<?= $arResult['ID'] ?>"
		  data-template="<?= $templateName ?>">
		<meta itemprop="ratingValue" content="<?= (int)$votesValue ?>">
		<meta itemprop="worstRating" content="0">
		<? for ($i = 0; $i++ < 5;): ?>
			<i class="flaticon-star129" data-index="<?= $i ?>"></i>
		<? endfor ?>
	</span>
<? endif ?>