<?
$MESS ['BITRONIC2_T_IBLOCK_VOTE_RESULTS'] = "(Голосов: #VOTES#, Рейтинг: #RATING#)";
$MESS ['BITRONIC2_T_IBLOCK_VOTES_COUNT'] = "Голосов: ";
$MESS ['BITRONIC2_T_IBLOCK_VOTE_NO_RESULTS'] = "(Нет голосов)";
$MESS ['BITRONIC2_T_IBLOCK_VOTE_MSG'] = "Спасибо, Ваш голос принят!";
$MESS ['BITRONIC2_IBLOCK_VOTE_REVIEWS'] = "отзывов";
$MESS ['BITRONIC2_IBLOCK_VOTE_BE_FIRST'] = "Оцени первым!";