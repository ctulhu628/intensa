$(document).on('ratingchange', function (e, data) {
	var $this = $(data.ratingElement),
		voteId = data.itemid | 0,
		rating = data.rating | 0;
	if (voteId > 0 && rating > 0 && !$this.hasClass('disabled')) {
		return $.ajax({
			type: "POST",
			data: {
				'ajax': $this.data('ajax'),
				'vote_id': voteId,
				'rating': rating,
				'arParams': $this.data('arparams'),
				'template': $this.data('template'),
			},
			dataType: 'json',
			url: AJAX_DIR + 'rate.php',
			success: function (json) {
				if (!json.success) {
					alert(json.msg);
				} else {
					$this.addClass('disabled').attr('disabled', true);
				}
			}
		});
	}
	console.log(data);
});