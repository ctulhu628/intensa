<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
use Yenisite\Core\Tools;

/**
 * @var CBitrixComponent $component
 */
include_once $_SERVER['DOCUMENT_ROOT'] . SITE_TEMPLATE_PATH . '/include/load_module.php';
$component = $this->__component;
$arSessionParams = array(
	"PAGE_PARAMS" => array("ELEMENT_ID"),
);
foreach ($arParams as $k => $v) {
	if (strncmp("~", $k, 1) && !in_array($k, $arSessionParams["PAGE_PARAMS"])) {
		$arSessionParams[$k] = $v;
	}
}
$arSessionParams["COMPONENT_NAME"] = $component->getName();
$arSessionParams["TEMPLATE_NAME"] = $component->getTemplateName();
if ($parent = $component->getParent()) {
	$arSessionParams["PARENT_NAME"] = $parent->getName();
	$arSessionParams["PARENT_TEMPLATE_NAME"] = $parent->getTemplateName();
	$arSessionParams["PARENT_TEMPLATE_PAGE"] = $parent->getTemplatePage();
}
$idSessionParams = md5(serialize($arSessionParams));

$component->arResult["AJAX"] = array(
	"SESSION_KEY" => $idSessionParams,
	"SESSION_PARAMS" => $arSessionParams,
);

$arResult["~AJAX_PARAMS"] = array(
	"SESSION_PARAMS" => $idSessionParams,
	"PAGE_PARAMS" => array(
		"ELEMENT_ID" => $arParams["ELEMENT_ID"],
	),
	"sessid" => bitrix_sessid(),
	"AJAX_CALL" => "Y",
);
$component->setResultCacheKeys(array('AJAX'));
$arResult["AJAX_PARAMS"] = Tools::GetEncodedArParams($arResult["~AJAX_PARAMS"]);