<?
$MESS["RZ_POSTAVIT_OTCENKU"] = "поставить оценку";
$MESS["RZ_NA_OSNOVE"] = "на основе";
$MESS["RZ_OTCENOK"] = "оценок";
$MESS["RZ_RATE_THIS_TITLE"] = "оцените товар";
$MESS["RZ_RATE_THIS"] = "Оцените, пожалуйста данный товар";