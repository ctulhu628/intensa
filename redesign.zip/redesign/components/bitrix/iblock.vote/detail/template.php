<? use Yenisite\Core\Ajax;
use Yenisite\Core\Tools;

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */
/** @var CBitrixComponent $component */
if (method_exists($this, 'setFrameMode')) $this->setFrameMode(true);
$isJson = (isset($_REQUEST['json']) && $_REQUEST['json'] == 'Y');
if ($arResult["PROPERTIES"]["vote_count"]["VALUE"]) {
	$votesValue = round($arResult["PROPERTIES"]["vote_sum"]["VALUE"] / $arResult["PROPERTIES"]["vote_count"]["VALUE"], 2);
} else {
	$votesValue = 0;
}

$votesCount = intval($arResult["PROPERTIES"]["vote_count"]["VALUE"]);
$bActive = !($arResult["VOTED"] || $arParams["READ_ONLY"] === "Y");
Ajax::saveParams($this, $arResult["~AJAX_PARAMS"], 'rate_' . $arResult['ID']);
$tmpl = $this->__component->__parent->__template ?: $this->__component->__template;
?>
<? if ($isJson):
	echo json_decode($votesValue);
else:?>
	<div class="item-rating" itemprop="aggregateRating" itemscope itemtype="http://schema.org/AggregateRating">
		<meta itemprop="ratingValue" content="<?= (int)$votesValue ?>">
		<meta itemprop="worstRating" content="0">

		<span class="stars" itemprop="aggregateRating" itemscope itemtype="http://schema.org/AggregateRating"
			  data-realrating="<?= $votesValue ?>" data-rating="<?= (int)$votesValue ?>" data-id="<?= $arResult['ID'] ?>"
			  data-disabled="<?= !$bActive ? 'true' : 'false' ?>" data-arparams="<?= $arResult['AJAX_PARAMS'] ?>"
			  data-template="<?= $templateName ?>">
			<? for ($i = 0; $i++ < 5;): ?>
				<i class="flaticon-star129" data-index="<?= $i ?>"></i>
			<? endfor ?>
		</span>
		<span class="rate-text"><?= $votesValue ?></span>
		<? /* todo: start detail rate-base
		<span class="rate-based"><?=GetMessage("RZ_NA_OSNOVE")?> <span itemprop="ratingCount reviewCount">12</span> <?=GetMessage("RZ_OTCENOK")?></span>
		*/ ?>
		<?if($bActive):?>
			<div class="item-rating__actions">
				<a href="#" class="action-link estimate" data-toggle="modal"
				   data-target="#modal-rate"><?= GetMessage("RZ_POSTAVIT_OTCENKU") ?></a>
				<? /* todo: detail vote comments count
				<a href="#detail-comments" class="action-link has-icon show-reviews flaticon-chat94"><span
							class="link-text">#VOTE_STRING#</span></a>
				*/ ?>
			</div>
		<?endif?>
	</div>
	<? $tmpl->SetViewTarget('modals') ?>
	<div class="modal fade" id="modal-rate" tabindex="-1">
		<div class="modal-dialog modal-rate">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span class="svg-wrap close"><svg>
		<use xlink:href="#close"></use>
	</svg></span>
					</button>
					<h4 class="modal-title"><?= GetMessage('RZ_RATE_THIS_TITLE') ?></h4>
				</div>
				<div class="modal-body">
					<span><?= GetMessage('RZ_RATE_THIS') ?></span>
					<div class="stars"<?= !$bActive ? '' : ' data-rating-enabled' ?> data-id="<?= $arResult['ID'] ?>"
						 data-realrating="<?= $votesValue ?>" data-colorrating="<?= (int)$votesValue ?>"
						 data-disabled="<?= !$bActive ? 'true' : 'false' ?>"
						 data-arparams="<?= $arResult['AJAX_PARAMS'] ?>"
						 data-template="<?= $templateName ?>">
						<? for ($i = 0; $i++ < 5;): ?>
							<i class="flaticon-star129" data-index="<?= $i ?>"></i>
						<? endfor ?>
					</div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn-main btn-primary" onclick="location.reload();"
							data-dismiss="modal"><?= GetMessage("RZ_POSTAVIT_OTCENKU") ?></button>
				</div>
			</div>
		</div>
	</div>
	<? $tmpl->EndViewTarget() ?>
<? endif ?>