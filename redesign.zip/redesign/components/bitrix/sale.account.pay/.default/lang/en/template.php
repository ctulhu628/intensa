<?
$MESS["SAP_BUY_MONEY"] = "Top up account";
$MESS["SAP_FIXED_PAYMENT"] = "Fixed payment";
$MESS["SAP_LINK_TITLE"] = "Add funds to account";
$MESS["SAP_INPUT_PLACEHOLDER"] = "Enter value";
$MESS["SAP_ERROR_INPUT"] = "Enter positive value";
$MESS["SAP_BUTTON"] = "Buy";
$MESS["SAP_SUM"] = "Amount";
$MESS["SAP_TYPE_PAYMENT_TITLE"] = "Payment method";
?>