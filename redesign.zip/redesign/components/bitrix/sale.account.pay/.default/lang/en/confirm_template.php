<?
$MESS["SAP_ORDER_SUC"] = "Your order <b>##ORDER_ID#</b> of #ORDER_DATE# has been created successfully.";
$MESS["SAP_PAYMENT_SUC"] = "Your payment ID: <b>#PAYMENT_ID#</b>";
$MESS["SAP_PAY_LINK"] = "If you don't see any payment information, click here: <a href=\"#LINK#\" target=\"_blank\">Pay and place order</a>.";
?>