<?php
$MESS['SAP_ORDER_SUC'] = "Ваш заказ <b>№#ORDER_ID#</b> от #ORDER_DATE# успешно создан.";
$MESS['SAP_PAYMENT_SUC'] = "Номер вашей оплаты: <b>№#PAYMENT_ID#</b>";
$MESS['SAP_PAY_LINK'] = "Если окно с платежной информацией не открылось автоматически, нажмите на ссылку <a href=\"#LINK#\" target=\"_blank\">Оплатить заказ</a>.";